#!/usr/bin/env python3
"""Build scripts/gen_v15_phase7_report.js from the validated Phase 6
generator (same R1-cover architecture), replacing the content block,
cover config and output path. Keeps every skill-compliant structural
decision intact."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "gen_v15_phase6_report.js")
CONTENT = os.path.join(HERE, "p7_content.js")
OUT = os.path.join(HERE, "gen_v15_phase7_report.js")

src = open(SRC, encoding="utf-8").read()
content = open(CONTENT, encoding="utf-8").read()
if not content.endswith("\n"):
    content += "\n"

# 1. header comment
src = src.replace(
    "// APEIRON-X v15 — Phase 6 Mathematical Reasoning (deliverable docx)",
    "// APEIRON-X v15 — Phase 7 Experimental Validation Intelligence (deliverable docx)", 1)

# 2. content region replacement (from first content marker to the DOCUMENT banner)
start_marker = "// ---- 1 Executive Summary"
end_marker = "// ================================================================== DOCUMENT"
i = src.index(start_marker)
j = src.index(end_marker)
src = src[:i] + content + src[j:]

# 3. running header + cover config
src = src.replace('text: "APEIRON-X v15 Phase 6 Report"',
                  'text: "APEIRON-X v15 Phase 7 Report"', 1)
src = src.replace('title: "APEIRON-X v15 Mathematical Reasoning"',
                  'title: "APEIRON-X v15 Experimental Validation"', 1)
src = src.replace(
    'subtitle: "Phase 6: Module E frozen P8 knowledge graph, eight new '
    'proof obligations, the fingerprint-portability gate and memoized '
    'coupling with a determinism theorem"',
    'subtitle: "Phase 7: Module F frozen CT.gov/GEO metadata registry, '
    'the validation-plan engine with stage gates, and the status '
    'discipline that names the evidence required to change a status"', 1)
old_meta = '''        metaLines: [
          "Round: v15 Phase 6 (P6-1 P8 graph, P6-2 eight obligations, P6-3 fingerprint gate, P6-4 memo)",
          "Evidence: 1539 typed edges / 726 nodes, 48 provenance records, 73 recorded absences",
          "Benchmark: 10/10 theorems PROVEN_MATH; 10/10 battery checks; byte-identical regeneration",
          "Gate: full cascade 15/15 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
new_meta = '''        metaLines: [
          "Round: v15 Phase 7 (P7-1 plan engine, P7-2 dataset hooks, P7-3 status discipline)",
          "Evidence: 158 CT.gov studies + 35 GEO series, metadata + accession only, 4 recorded absences",
          "Benchmark: 7/7 theorems PROVEN_MATH; 14/14 battery checks; 20 plans (10 EVIDENCED+)",
          "Gate: full cascade 16/16 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
assert old_meta in src, "metaLines block not found"
src = src.replace(old_meta, new_meta, 1)
src = src.replace('footerRight: "v15 Phase 6 Report"',
                  'footerRight: "v15 Phase 7 Report"', 1)
src = src.replace(
    '"/home/z/my-project/download/APEIRON-X_v15_Phase6_Mathematical_Reasoning.docx"',
    '"/home/z/my-project/download/APEIRON-X_v15_Phase7_Experimental_Validation.docx"', 1)
src = src.replace('console.log("written: APEIRON-X_v15_Phase6_Mathematical_Reasoning.docx")',
                  'console.log("written: APEIRON-X_v15_Phase7_Experimental_Validation.docx")', 1)

# sanity: no Phase 6 content markers survived
for leftover in ("P6-1 P8 graph", "fingerprint-portability gate and memoized",
                 "Phase 6: Module E", "Phase6_Mathematical_Reasoning",
                 "theorem_graph_consistency\"", "memoized coupling"):
    assert leftover not in src, leftover
assert src.count("// ---- 1 Executive Summary") == 1
assert "validation-plan engine" in src and "REGISTRY_ACTIVITY_PRESENT" in src

open(OUT, "w", encoding="utf-8").write(src)
print(f"wrote {OUT} ({len(src)} chars)")
