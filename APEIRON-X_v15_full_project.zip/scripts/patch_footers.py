#!/usr/bin/env python3
"""Post-process docx footers: add PAGE format switches per section
(Roman for front matter, arabic for body) and strip empty pgNumType."""
import re
import shutil
import sys
import zipfile
import os
import tempfile

path = sys.argv[1]
tmpdir = tempfile.mkdtemp()

with zipfile.ZipFile(path) as z:
    z.extractall(tmpdir)

doc_path = os.path.join(tmpdir, "word", "document.xml")
with open(doc_path, encoding="utf-8") as fh:
    doc = fh.read()

# 1. strip empty pgNumType (cover section artifact)
doc = doc.replace("<w:pgNumType/>", "")

# 2. map section order -> footer rIds
sect_prs = re.findall(r"<w:sectPr.*?</w:sectPr>", doc, re.S)
print(f"sections found: {len(sect_prs)}")
sect_footers = []
for spr in sect_prs:
    m = re.findall(r'<w:footerReference w:type="default" r:id="(rId\d+)"', spr)
    fmt = re.search(r'<w:pgNumType[^/]*w:fmt="([^"]+)"', spr)
    sect_footers.append((m[0] if m else None, fmt.group(1) if fmt else None))
    print("  footer rId:", m[0] if m else None, "| pgNumType fmt:",
          fmt.group(1) if fmt else None)

# 3. resolve rIds to footer files
rels_path = os.path.join(tmpdir, "word", "_rels", "document.xml.rels")
with open(rels_path, encoding="utf-8") as fh:
    rels = fh.read()
rid_to_file = dict(re.findall(r'Id="(rId\d+)"[^>]*Target="(footer\d+\.xml)"', rels))
print("rid->footer:", rid_to_file)

# 4. patch each footer according to its section format
patched = set()
for rid, fmt in sect_footers:
    if not rid or rid not in rid_to_file:
        continue
    fpath = os.path.join(tmpdir, "word", rid_to_file[rid])
    if fpath in patched:
        continue
    with open(fpath, encoding="utf-8") as fh:
        fxml = fh.read()
    switch = "ROMAN" if fmt == "upperRoman" else "arabic"
    fxml2 = re.sub(r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
                   rf"\1 PAGE \\* {switch} \\* MERGEFORMAT \2", fxml)
    if fxml2 != fxml:
        with open(fpath, "w", encoding="utf-8") as fh:
            fh.write(fxml2)
        patched.add(fpath)
        print(f"  patched {rid_to_file[rid]} -> PAGE \\* {switch}")

with open(doc_path, "w", encoding="utf-8") as fh:
    fh.write(doc)

# 5. rezip
newpath = path + ".tmp"
with zipfile.ZipFile(newpath, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(tmpdir):
        for f in files:
            full = os.path.join(root, f)
            z.write(full, os.path.relpath(full, tmpdir))
shutil.move(newpath, path)
shutil.rmtree(tmpdir)
print("footer post-processing done")
