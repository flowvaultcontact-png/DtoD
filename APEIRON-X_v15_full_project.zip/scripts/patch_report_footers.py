#!/usr/bin/env python3
"""Post-process a v15 phase-report docx for WPS/Word page-number correctness
(parameterized version of patch_v15_footers.py).

Per docx skill toc.md:
1. Map each section's default footerReference -> footer XML part via rels.
2. Section 2 (front matter) footer: PAGE -> PAGE \\* ROMAN \\* MERGEFORMAT
   Section 3 (body) footer:         PAGE -> PAGE \\* arabic \\* MERGEFORMAT
3. Remove empty <w:pgNumType/> emitted for the cover section.
Usage: python3 patch_report_footers.py <file.docx>
"""
import re
import sys
import zipfile

DOCX = sys.argv[1]
TMP = DOCX + ".tmp"

with zipfile.ZipFile(DOCX) as z:
    names = z.namelist()
    data = {n: z.read(n) for n in names}

doc = data["word/document.xml"].decode("utf-8")
rels = data["word/_rels/document.xml.rels"].decode("utf-8")

rel_map = dict(re.findall(r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"', rels))

sect_footers = []
for sect in re.findall(r"<w:sectPr[ >].*?</w:sectPr>", doc, flags=re.S):
    m = re.search(r'<w:footerReference w:type="default" r:id="([^"]+)"', sect)
    sect_footers.append(m.group(1) if m else None)
print("section default footers:", sect_footers)


def patch_footer(rid, fmt):
    if rid is None:
        return
    target = rel_map.get(rid)
    if not target:
        print("missing rel target for", rid)
        return
    part = "word/" + target.lstrip("/")
    xml = data[part].decode("utf-8")
    new = re.sub(r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
                 lambda m: m.group(1) + f" PAGE \\* {fmt} \\* MERGEFORMAT " + m.group(2),
                 xml)
    if new != xml:
        data[part] = new.encode("utf-8")
        print(f"patched {part} -> PAGE \\* {fmt}")
    else:
        print(f"no bare PAGE field found in {part} (may already be patched)")


assert len(sect_footers) >= 3, "expected 3 sections"
patch_footer(sect_footers[1], "ROMAN")
patch_footer(sect_footers[2], "arabic")

doc2 = doc.replace("<w:pgNumType/>", "")
if doc2 != doc:
    print("stripped empty <w:pgNumType/>")
data["word/document.xml"] = doc2.encode("utf-8")

with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        z.writestr(n, data[n])
import os
os.replace(TMP, DOCX)
print("footer/pgNumType post-processing done:", DOCX)
