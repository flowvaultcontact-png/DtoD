"""Network reachability probe for APEIRON-X v15 scientific data connectors.

Checks (read-only, no key required):
  1. Open Targets Platform GraphQL API
  2. ChEMBL REST API (release status)
  3. UniProt REST API
Exit code is always 0; failures are printed as FAIL lines.
"""
import json
import urllib.request
import urllib.parse


def _post_json(url: str, body: dict, timeout: int = 25):
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read(400)


def _get_json(url: str, timeout: int = 25):
    req = urllib.request.Request(url, headers={"Accept": "application/json"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read(400)


def main() -> None:
    # 1. Open Targets
    try:
        q = ('query{search(queryString:"chronic kidney disease", entityNames:["disease"])'
             "{hits{id name entity}}}")
        status, body = _post_json(
            "https://api.platform.opentargets.org/api/v4/graphql", {"query": q})
        print(f"OT-OK status={status} body={body[:200]!r}")
    except Exception as exc:  # noqa: BLE001 - diagnostic script
        print(f"OT-FAIL {type(exc).__name__}: {str(exc)[:200]}")

    # 2. ChEMBL
    try:
        status, body = _get_json("https://www.ebi.ac.uk/chembl/api/core/status.json")
        print(f"CHEMBL-OK status={status} body={body[:200]!r}")
    except Exception as exc:  # noqa: BLE001
        print(f"CHEMBL-FAIL {type(exc).__name__}: {str(exc)[:200]}")

    # 3. UniProt
    try:
        params = urllib.parse.urlencode({
            "query": "gene:SLC5A2 AND organism_id:9606",
            "format": "json", "fields": "accession,id", "size": "1",
        })
        status, body = _get_json(f"https://rest.uniprot.org/uniprotkb/search?{params}")
        print(f"UNIPROT-OK status={status} body={body[:200]!r}")
    except Exception as exc:  # noqa: BLE001
        print(f"UNIPROT-FAIL {type(exc).__name__}: {str(exc)[:200]}")


if __name__ == "__main__":
    main()
