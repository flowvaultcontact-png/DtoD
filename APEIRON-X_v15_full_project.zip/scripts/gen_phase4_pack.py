#!/usr/bin/env python3
"""Generate the FROZEN Phase 4 pack: v15/repurposing_data.py.

Authoring doctrine (mirrors target_data.py of Phase 3):
  * machine fields (drug records, indication memberships, citations,
    UniProt records) are copied VERBATIM from
    v15/out/phase4_verified_values.json (the freeze of
    refresh_phase4_cache.py --live),
  * curated law-channel content (target->channel table, pre-2015
    disease-channel profiles, adjacency bridge, ground truth rows) is
    authored here explicitly and cites only machine-verified record ids,
  * KB-membership / KB mechanism class / KB safety penalties are read
    from the v14.1 hash-pinned corpus READ-ONLY at generation time and
    frozen as data.

The generated module is pure data + a validation function: it imports
nothing. After generation, run v15/kb_extensions/freeze_repurposing.py
to pin the sha256.
"""

import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(os.path.dirname(HERE), "apeiron")   # apeiron/ repo root
sys.path.insert(0, ROOT)

from disease_drug_kb import DRUGS as KB_DRUGS, DISEASES as KB_DISEASES  # noqa: E402
from apeiron_structure_proof import StructLayer  # noqa: E402

VALUES_PATH = os.path.join(ROOT, "v15", "out", "phase4_verified_values.json")
OUT_PATH = os.path.join(ROOT, "v15", "repurposing_data.py")

# ---------------------------------------------------------------------
# Curated law-channel tables (authored; every citation id below is
# machine-verified in the freeze).
# ---------------------------------------------------------------------
TARGET_CHANNEL_MAP = {
    "SLC5A2": {"channels": ["KIDNEY_TUBULE_GLUCOSE"],
               "action_expected": "INHIBITOR", "uniprot": "P31639"},
    "ACE": {"channels": ["NEUROHORMONAL_RAAS"],
            "action_expected": "INHIBITOR", "uniprot": "P12821"},
    "AGTR1": {"channels": ["NEUROHORMONAL_RAAS"],
              "action_expected": "ANTAGONIST", "uniprot": "P30556"},
    "ADRB1": {"channels": ["NEUROHORMONAL_ADRENERGIC"],
              "action_expected": "ANTAGONIST", "uniprot": "P08588"},
    "ADRB2": {"channels": ["NEUROHORMONAL_ADRENERGIC"],
              "action_expected": "ANTAGONIST", "uniprot": "P07550"},
    "ADRA1A": {"channels": ["VASCULAR_TONE"],
               "action_expected": "ANTAGONIST", "uniprot": "P25100"},
    "NR3C2": {"channels": ["NEUROHORMONAL_MRA"],
              "action_expected": "ANTAGONIST", "uniprot": "P08235"},
    "HMGCR": {"channels": ["LIPID_METABOLISM"],
              "action_expected": "INHIBITOR", "uniprot": "P04035"},
    "DPP4": {"channels": ["GLUCOSE_HOMEOSTASIS"],
             "action_expected": "INHIBITOR", "uniprot": "P27487"},
    "KCNJ11": {"channels": ["GLUCOSE_HOMEOSTASIS"],
               "action_expected": "BLOCKER", "uniprot": "Q14654"},
    "ABCC8": {"channels": ["GLUCOSE_HOMEOSTASIS"],
              "action_expected": "BLOCKER", "uniprot": "Q09428"},
    "GLP1R": {"channels": ["GLUCOSE_HOMEOSTASIS"],
              "action_expected": "AGONIST", "uniprot": "P43220"},
    "CACNA1C": {"channels": ["VASCULAR_TONE"],
                "action_expected": "BLOCKER", "uniprot": "Q13936"},
}

MECH_CLASS_CHANNELS = {
    "SGLT2_INHIBITOR": ["KIDNEY_TUBULE_GLUCOSE"],
    "ACEI_RAAS": ["NEUROHORMONAL_RAAS"],
    "ARB_RAAS": ["NEUROHORMONAL_RAAS"],
    "BETA1_BLOCKER": ["NEUROHORMONAL_ADRENERGIC"],
    "MINERALOCORTICOID_ANTAGONIST": ["NEUROHORMONAL_MRA"],
    "BIGUANIDE_HEPATIC_GLUCOSE": ["GLUCOSE_HOMEOSTASIS"],
    "DPP4_INHIBITOR": ["GLUCOSE_HOMEOSTASIS"],
    "SULFONYLUREA": ["GLUCOSE_HOMEOSTASIS"],
    "HMGCR_INHIBITOR": ["LIPID_METABOLISM"],
    "CCB_DHP": ["VASCULAR_TONE"],
}

DISEASES_P4 = {
    "HFREF": {
        "name": "heart failure with reduced ejection fraction",
        "kb_did": "D02",
        "channels_pre2015": [
            {"channel": "NEUROHORMONAL_RAAS",
             "precedent_class": "ACEI_RAAS",
             "sources": ["EPMC:PMID-2883575"],
             "note": "enalapril survival benefit in severe HF (CONSENSUS, "
                     "1987) anchors RAAS blockade as pre-2015 HF channel; "
                     "ACE-inhibitor class precedent"},
            {"channel": "NEUROHORMONAL_MRA",
             "precedent_class": "MINERALOCORTICOID_ANTAGONIST",
             "sources": ["EPMC:PMID-10471456"],
             "note": "spironolactone survival benefit in severe HF (RALES, "
                     "1999); MRA class precedent"},
            {"channel": "CARDIORENAL",
             "precedent_class": None,
             "sources": ["EPMC:PMID-21253529"],
             "note": "cardiorenal-syndrome literature (2010 review) "
                     "anchors the kidney-heart bridge channel; deliberately "
                     "NO precedent class - this is the repurposing frontier"},
        ],
    },
    "HFPEF": {
        "name": "heart failure with preserved ejection fraction",
        "kb_did": "D61",
        "channels_pre2015": [
            {"channel": "CARDIORENAL",
             "sources": ["EPMC:PMID-21253529"],
             "note": "no disease-modifying therapy was established "
                     "pre-2015; the cardiorenal bridge is the only "
                     "cited pre-2015 channel (recorded honestly)"},
        ],
    },
    "CKD": {
        "name": "chronic kidney disease",
        "kb_did": None,
        "channels_pre2015": [
            {"channel": "NEUROHORMONAL_RAAS",
             "precedent_class": "ARB_RAAS",
             "sources": ["EPMC:PMID-11967819"],
             "note": "RENAAL program (losartan renal protection) anchors "
                     "RAAS blockade as pre-2015 renal channel; ARB class "
                     "precedent"},
            {"channel": "KIDNEY_TUBULE_GLUCOSE",
             "precedent_class": None,
             "sources": ["EPMC:PMID-25525338"],
             "note": "pre-2015 dapagliflozin mechanism review + the "
                     "UniProt SLC5A2 function record anchor renal "
                     "glucose reabsorption as a kidney channel; NO "
                     "precedent class - the repurposing frontier"},
            {"channel": "CARDIORENAL",
             "sources": ["EPMC:PMID-21253529"],
             "note": "cardiorenal bridge channel"},
        ],
    },
    "DKD": {
        "name": "diabetic kidney disease",
        "kb_did": None,
        "channels_pre2015": [
            {"channel": "KIDNEY_TUBULE_GLUCOSE",
             "precedent_class": None,
             "sources": ["EPMC:PMID-25525338"],
             "note": "renal glucose reabsorption in the diabetic kidney; "
                     "NO precedent class - the repurposing frontier"},
            {"channel": "NEUROHORMONAL_RAAS",
             "precedent_class": "ARB_RAAS",
             "sources": ["EPMC:PMID-11967819"],
             "note": "RAAS blockade in diabetic nephropathy (RENAAL); ARB "
                     "class precedent"},
            {"channel": "HYPERGLYCEMIA",
             "precedent_class": "BIGUANIDE_HEPATIC_GLUCOSE",
             "sources": ["EPMC:PMID-9742976"],
             "note": "tight glycemic control reduces diabetic "
                     "complications incl. nephropathy (UKPDS 33, 1998; "
                     "metformin backbone); biguanide class precedent"},
        ],
    },
    "T2DM": {
        "name": "type 2 diabetes mellitus",
        "kb_did": "D08",
        "channels_pre2015": [
            {"channel": "GLUCOSE_HOMEOSTASIS",
             "precedent_class": "BIGUANIDE_HEPATIC_GLUCOSE",
             "sources": ["EPMC:PMID-9742976"],
             "note": "glycemic control as the canonical T2D channel "
                     "(UKPDS 33; metformin backbone); biguanide class "
                     "precedent"},
            {"channel": "KIDNEY_TUBULE_GLUCOSE",
             "precedent_class": None,
             "sources": ["EPMC:PMID-25525338"],
             "note": "renal glucose excretion as a T2D treatment channel "
                     "(pre-2015 gliflozin literature); already an "
                     "established T2D mechanism, no precedent field"},
        ],
    },
}

CHANNEL_ADJACENCY = {
    "KIDNEY_TUBULE_GLUCOSE": {
        "adjacent": ["CARDIORENAL"],
        "sources": ["EPMC:PMID-21253529"],
        "note": "cardiorenal bridge: kidney-tubule channels grant "
                "adjacent support in diseases carrying CARDIORENAL",
    },
    "GLUCOSE_HOMEOSTASIS": {
        "adjacent": ["HYPERGLYCEMIA"],
        "sources": ["EPMC:PMID-9742976"],
        "note": "glycemic-control channel grants adjacent support in "
                "diseases carrying HYPERGLYCEMIA",
    },
}

TEMPORAL_SPLIT_YEAR = 2015
PREDICTION_DISEASES = ["HFREF", "HFPEF", "CKD", "DKD"]

# Ground truth: post-2015 repurposing outcomes. Every row cites a
# machine-verified trial publication; `ot_status` records what the
# frozen OT rows served (approval rows where present; the coverage gaps
# are kept visible in the note field, never smoothed away).
GROUND_TRUTH_POST2015 = [
    {"drug": "dapagliflozin", "disease_key": "HFREF", "evidence_year": 2019,
     "citations": ["EPMC:PMID-31535829"],
     "ot_status": "APPROVAL row served (drug side)",
     "note": "DAPA-HF landmark publication (2019)"},
    {"drug": "dapagliflozin", "disease_key": "CKD", "evidence_year": 2020,
     "citations": ["EPMC:PMID-32970396"],
     "ot_status": "APPROVAL row served (drug side)",
     "note": "DAPA-CKD landmark publication (2020)"},
    {"drug": "empagliflozin", "disease_key": "HFREF", "evidence_year": 2020,
     "citations": ["EPMC:PMID-32865377"],
     "ot_status": "NO approval row served for this pair (gap recorded)",
     "note": "EMPEROR-Reduced landmark publication (2020); the frozen OT "
             "rows did not serve an empagliflozin x HFrEF approval row — "
             "regulatory-row coverage gap, kept visible"},
    {"drug": "empagliflozin", "disease_key": "CKD", "evidence_year": 2023,
     "citations": ["EPMC:PMID-36331190"],
     "ot_status": "APPROVAL row served (drug side)",
     "note": "EMPA-KIDNEY publication (Europe PMC serves the 2023 print "
             "year; posted online 2022)"},
    {"drug": "canagliflozin", "disease_key": "DKD", "evidence_year": 2019,
     "citations": ["EPMC:PMID-30990260"],
     "ot_status": "PHASE_3 row served for DKD (drug side)",
     "note": "CREDENCE landmark publication (2019)"},
    {"drug": "dapagliflozin", "disease_key": "HFPEF", "evidence_year": 2022,
     "citations": ["EPMC:PMID-36027570"],
     "ot_status": "NO indication row served for this pair (gap recorded)",
     "note": "DELIVER landmark publication (2022)"},
]

HONEST_LIMITS = [
    "Indication membership rows are an undated 2026 snapshot: they are "
    "used ONLY for current-era status labels (P4-2), never for the "
    "pre-2015 prediction axes. The prediction itself uses molecules "
    "(ChEMBL first_approval), channel anchors and precedent classes "
    "that carry pre-2015 literature citations.",
    "track_record is a CLASS-PRECEDENT axis derived from the pre-2015 "
    "literature anchors of the matched channels (CONSENSUS 1987 -> "
    "ACEI_RAAS; RALES 1999 -> MINERALOCORTICOID_ANTAGONIST; RENAAL "
    "2000 -> ARB_RAAS; UKPDS 33 1998 -> BIGUANIDE_HEPATIC_GLUCOSE); "
    "channels without a precedent class (KIDNEY_TUBULE_GLUCOSE, "
    "CARDIORENAL) are the documented repurposing frontier, and the "
    "frontier is exactly where the SGLT2 outcomes landed.",
    "The HFREF profile carries no NEUROHORMONAL_ADRENERGIC channel "
    "because no pre-2015 beta-blocker HF citation was fetched and "
    "verified in this freeze — a channel with no verified anchor is "
    "NOT invented (carvedilol therefore earns no direct support).",
    "The OT freeze did not serve an empagliflozin x HFREF approval row "
    "although the EMPEROR-Reduced trial verified; the gap is recorded "
    "in the ground-truth note, not smoothed over.",
    "UniProt function excerpts are CURRENT records (retrieval-time); "
    "they anchor identifier-level target biology, never a temporal "
    "claim. Temporal claims cite dated literature rows only.",
    "The v14.1 Theta_d bridge uses the CURRENT hash-pinned KB (which "
    "includes the post-2015 guideline-drift rows D61-D63); it is "
    "therefore a CONSISTENCY check on outputs, never an input to the "
    "pre-2015 prediction.",
    "ChEMBL first_approval years are served as-is (US-centric in some "
    "eras, e.g. metformin 1995); no year is hand-corrected.",
    "Scores are transparent counting functions with documented "
    "defaults; the aggregate is labelled COMPUTATIONAL_RANK and is "
    "never a probability, and no output is clinical advice.",
]


HEADER_TEMPLATE = '''# =====================================================================
# APEIRON-X v15 - FROZEN REPURPOSING PACK (P4, Module C)
# ---------------------------------------------------------------------
# Phase 4 counterpart of v15/target_data.py: a FROZEN, hash-pinned pack
# authored VERBATIM from machine-verified connector fetches
# (v15/connectors/refresh_phase4_cache.py --live; audit values in
# v15/out/phase4_verified_values.json; pack generated @GEN_UTC@).
#
# DOCTRINE (V15_IMPLEMENTATION_PLAN section 5):
#   1. Every drug record, indication membership, citation and UniProt
#      excerpt below was machine-fetched on FROZEN_UTC and is byte-
#      traceable to the frozen cache. Nothing is hand-invented; absent
#      data is recorded as absent (HONEST_LIMITS / row notes).
#   2. FROZEN: after authoring, sha256 pinned in
#      v15/kb_extensions/repurposing_pins.json via freeze_repurposing.py;
#      v15.repurposing.load_pack() refuses to serve on a mismatch.
#   3. Pure data module: imports nothing; derivation code (Module C)
#      consumes it read-only (C0-style connector isolation, machine-
#      checked by the phase-4 battery).
#   4. Claim tiers: predictions are COMPUTATIONAL; statuses derived from
#      regulatory/trial rows are EVIDENCED and cite record ids.
# =====================================================================

PACK_SCHEMA_VERSION = "15.4.0"
FROZEN_UTC = "@UTC@"

SOURCE_RECORDS = {
    "SRC:OT_P4": {
        "resource": "Open Targets Platform GraphQL API",
        "resource_version": "live schema (introspection-verified: Drug "
                            "type carries maximumClinicalStage + paged "
                            "indications; Disease.drugAndClinicalCandidates "
                            "replaces the retired knownDrugs)",
        "retrieval_utc": "@UTC@",
        "url": "https://api.platform.opentargets.org/api/v4/graphql",
        "license": "CC-BY-4.0 (opentargets.org licensing; datasource terms)",
        "evidence_type": "annotation",
        "confidence": "machine_fetched_drug_and_indication_rows_verbatim",
        "limitations": "indication rows are an undated 2026 snapshot; "
                       "some regulatory approval rows are absent (recorded)",
    },
    "SRC:CHEMBL_P4": {
        "resource": "ChEMBL webresource (REST /chembl/api/data)",
        "resource_version": "live API served verbatim @UTC@",
        "retrieval_utc": "@UTC@",
        "url": "https://www.ebi.ac.uk/chembl/api/data",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_fetched_first_approval_and_mechanisms",
        "limitations": "first_approval years served as-is (no hand "
                       "correction); /status.json release probe does not "
                       "exist on the current build",
    },
    "SRC:UNIPROT_P4": {
        "resource": "UniProtKB REST (reviewed Swiss-Prot entries)",
        "resource_version": "REST snapshot @UTC@",
        "retrieval_utc": "@UTC@",
        "url": "https://rest.uniprot.org/uniprotkb",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_verified_reviewed_entry",
        "limitations": "function excerpts are CURRENT records (no "
                       "temporal claim is ever based on them)",
    },
    "SRC:EPMC_P4": {
        "resource": "Europe PMC REST (EXT_ID + search)",
        "resource_version": "REST snapshot @UTC@",
        "retrieval_utc": "@UTC@",
        "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
        "license": "SEE_TERMS (PubMed abstract metadata, vendor terms)",
        "evidence_type": "literature",
        "confidence": "machine_verified_citation_metadata",
        "limitations": "PMID hints were used as search candidates only; "
                       "every admitted record passed EXT_ID verification "
                       "+ title-token filtering",
    },
    "SRC:KB_P4": {
        "resource": "APEIRON-X v14.1 hash-pinned corpus "
                    "(disease_drug_kb.py / drug_structures.py)",
        "resource_version": "frozen-file sha256 snapshot "
                            "(docs/baseline/frozen_files_sha256_before.txt)",
        "retrieval_utc": "@UTC@",
        "url": "internal://apeiron",
        "license": "project-internal",
        "evidence_type": "guideline",
        "confidence": "kb_row_and_structure_corpus_membership",
        "limitations": "KB mechanism classes and safety penalties are the "
                       "guideline-anchored rows verbatim",
    },
}

INTERNAL_SOURCE_RECORDS = {
    ("KB:%s" % did): {
        "resource": "APEIRON-X v14.1 disease_drug_kb.py (hash-pinned corpus)",
        "resource_version": "guideline-drift round (D61-D63) included",
        "retrieval_utc": "@UTC@",
        "url": "internal://apeiron/disease_drug_kb.py",
        "license": "project-internal",
        "evidence_type": "guideline",
        "confidence": "kb_disease_row_pointer",
        "limitations": "KB rows are CURRENT-era guideline anchors; the "
                       "Theta_d bridge derived from them is a consistency "
                       "check, never a temporal-prediction input",
    }
    for did in ("D02", "D61", "D08")
}

# ---- machine-verbatim literature (13 records, Europe PMC) ----------
LITERATURE = @LIT@

# ---- machine-verbatim drug universe (18 drugs) ----------------------
DRUGS_P4 = @DRUGS@

# ---- curated law channel: target -> channel table --------------------
# Sources: UniProt identifier-level records (SRC:UNIPROT_P4) + action
# types verbatim from the OT mechanism rows (SRC:OT_P4).
TARGET_CHANNEL_MAP = @TCM@

# Fallback law channel from v14.1 KB mechanism classes (SRC:KB_P4).
MECH_CLASS_CHANNELS = @MCC@

# ---- curated pre-2015 disease-channel profiles -----------------------
DISEASES_P4 = @DISEASES@

# ---- curated adjacency bridge ----------------------------------------
CHANNEL_ADJACENCY = @ADJ@

TEMPORAL_SPLIT_YEAR = @SPLIT@
PREDICTION_DISEASES = @PRED@

# ---- machine-verbatim disease panel ----------------------------------
DISEASE_PANEL = @PANEL@

# ---- machine-verbatim indication evidence -----------------------------
INDICATION_EVIDENCE = @EVID@

# ---- curated ground truth (post-2015 repurposing outcomes) ------------
GROUND_TRUTH_POST2015 = @GT@

HONEST_LIMITS = @LIMITS@


def validate_repurposing_module():
    """Self-validation (run by the pin-checked facade at load time)."""
    problems = []
    known_channels = set()
    for spec in TARGET_CHANNEL_MAP.values():
        known_channels.update(spec["channels"])
    for cs in MECH_CLASS_CHANNELS.values():
        known_channels.update(cs)
    for dname, d in DRUGS_P4.items():
        if not d.get("chembl_id"):
            problems.append("drug %s: missing chembl_id" % dname)
        if not isinstance(d.get("first_approval"), int):
            problems.append("drug %s: first_approval not an int" % dname)
        for sid in d.get("sources", []):
            if sid not in SOURCE_RECORDS:
                problems.append("drug %s: unknown source %s" % (dname, sid))
        if d.get("kb_member") and not d.get("kb_mech_class"):
            problems.append("drug %s: kb_member without mech class" % dname)
    for row in INDICATION_EVIDENCE:
        if row["drug"] not in DRUGS_P4:
            problems.append("evidence row: unknown drug %s" % row["drug"])
    for key, prof in DISEASES_P4.items():
        for ch in prof["channels_pre2015"]:
            if not ch["sources"]:
                problems.append("disease %s: channel %s uncited"
                                % (key, ch["channel"]))
            for sid in ch["sources"]:
                if sid not in LITERATURE:
                    problems.append("disease %s: channel %s cites unknown "
                                    "%s" % (key, ch["channel"], sid))
            rec = LITERATURE.get(ch["sources"][0])
            if rec is not None and not rec.get("year"):
                problems.append("disease %s: citation year missing"
                                % key)
            if rec is not None and ch.get("note", "").find("pre-2015") >= 0:
                if int(rec["year"]) >= TEMPORAL_SPLIT_YEAR:
                    problems.append("disease %s: channel %s claims pre-2015"
                                    " but citation year is %s"
                                    % (key, ch["channel"], rec["year"]))
        if prof["kb_did"] is not None and \
                ("KB:%s" % prof["kb_did"]) not in INTERNAL_SOURCE_RECORDS:
            problems.append("disease %s: kb_did not resolvable" % key)
    for bridge, spec in CHANNEL_ADJACENCY.items():
        if bridge not in known_channels:
            problems.append("adjacency: unknown source channel %s" % bridge)
        for tgt in spec["adjacent"]:
            disease_channels = {ch["channel"]
                                for p in DISEASES_P4.values()
                                for ch in p["channels_pre2015"]}
            if tgt not in known_channels | disease_channels:
                problems.append("adjacency: unknown target channel %s"
                                % tgt)
        for sid in spec["sources"]:
            if sid not in LITERATURE:
                problems.append("adjacency: unknown citation %s" % sid)
    for row in GROUND_TRUTH_POST2015:
        if row["drug"] not in DRUGS_P4:
            problems.append("ground truth: unknown drug %s" % row["drug"])
        if row["disease_key"] not in DISEASES_P4:
            problems.append("ground truth: unknown disease %s"
                            % row["disease_key"])
        if row["evidence_year"] < TEMPORAL_SPLIT_YEAR:
            problems.append("ground truth %s/%s predates the split"
                            % (row["drug"], row["disease_key"]))
        for cid in row["citations"]:
            if cid not in LITERATURE:
                problems.append("ground truth: unknown citation %s" % cid)
    seen_pairs = set()
    for row in GROUND_TRUTH_POST2015:
        pair = (row["drug"], row["disease_key"])
        if pair in seen_pairs:
            problems.append("ground truth: duplicate pair %s" % (pair,))
        seen_pairs.add(pair)
    return problems
'''


def main() -> int:
    v = json.load(open(VALUES_PATH, encoding="utf-8"))
    frozen_utc = v["frozen_utc"]
    assert v["absences"] == [], "refusing to freeze with unrecorded absences"

    # ---- KB facts, read-only -----------------------------------------
    layer = StructLayer()
    kb_components = set(layer.drug_components)
    kb_class = {name: cls for name, (_, cls) in KB_DRUGS.items()}
    kb_safety = {}
    for row in KB_DISEASES:
        for (dname, _tier, _eff, safety) in row["drugs"]:
            kb_safety[dname] = max(kb_safety.get(dname, 0), safety)

    # ---- machine-verbatim drug rows -----------------------------------
    drugs_out = {}
    for name in sorted(v["drugs"]):
        d = v["drugs"][name]
        mol = d.get("chembl_molecule", {})
        rec = d.get("ot_record", {})
        kb = name in kb_components
        drugs_out[name] = {
            "chembl_id": d.get("chembl_id"),
            "ot_name": rec.get("moa_rows") and d.get("ot_name") or d.get("ot_name"),
            "maximum_clinical_stage": rec.get("maximum_clinical_stage"),
            "first_approval": mol.get("first_approval"),
            "withdrawn_flag": bool(mol.get("withdrawn_flag")),
            "withdrawn_reason": mol.get("withdrawn_reason"),
            "kb_member": kb,
            "kb_mech_class": kb_class.get(name) if kb else None,
            "kb_safety_penalty_max": kb_safety.get(name) if kb else None,
            "moa_rows": rec.get("moa_rows", []),
            "panel_indication_rows": rec.get("panel_indication_rows", []),
            "indications_count": rec.get("indications_count"),
            "sources": ["SRC:OT_P4", "SRC:CHEMBL_P4"]
            + (["SRC:KB_P4"] if kb else []),
        }

    # ---- machine-verbatim literature ----------------------------------
    lit_out = {}
    for key, c in sorted(v["citations"].items()):
        lit_out[f"EPMC:PMID-{c['pmid']}"] = {
            "key": key, "pmid": c["pmid"], "title": c["title"],
            "journal": c["journal"], "year": c["year"], "doi": c["doi"],
            "via": c["via"], "note": c.get("note", ""),
        }

    # ---- disease panel + indication evidence --------------------------
    panel_out = {}
    for key, dd in sorted(v["diseases"].items()):
        panel_out[key] = {
            "disease_id": dd.get("disease_id"),
            "disease_name": dd.get("disease_name"),
            "candidate_count": dd.get("count"),
        }
    evidence_out = []
    for name in sorted(v["drugs"]):
        for r in v["drugs"][name].get("ot_record", {}).get(
                "panel_indication_rows", []) or []:
            evidence_out.append({"drug": name, "side": "drug_record",
                                 "disease_id": r.get("disease_id"),
                                 "disease_name": r.get("disease_name"),
                                 "stage": r.get("max_clinical_stage")})
    for key in sorted(v["diseases"]):
        for r in v["diseases"][key].get("our_drug_rows", []):
            evidence_out.append({"drug": r["drug_name"].lower(),
                                 "side": "disease_page",
                                 "disease_id": v["diseases"][key].get("disease_id"),
                                 "disease_name": v["diseases"][key].get("disease_name"),
                                 "stage": r.get("max_clinical_stage"),
                                 "panel_key": key})

    gen_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    from pprint import pformat

    def lit(p):
        return pformat(p, width=96, sort_dicts=True)

    body = HEADER_TEMPLATE.replace("@GEN_UTC@", gen_utc)
    body = body.replace("@UTC@", frozen_utc)
    body = body.replace("@LIT@", lit(lit_out))
    body = body.replace("@DRUGS@", lit(drugs_out))
    body = body.replace("@TCM@", lit(TARGET_CHANNEL_MAP))
    body = body.replace("@MCC@", lit(MECH_CLASS_CHANNELS))
    body = body.replace("@DISEASES@", lit(DISEASES_P4))
    body = body.replace("@ADJ@", lit(CHANNEL_ADJACENCY))
    body = body.replace("@SPLIT@", str(TEMPORAL_SPLIT_YEAR))
    body = body.replace("@PRED@", repr(PREDICTION_DISEASES))
    body = body.replace("@PANEL@", lit(panel_out))
    body = body.replace("@EVID@", lit(evidence_out))
    body = body.replace("@GT@", lit(GROUND_TRUTH_POST2015))
    body = body.replace("@LIMITS@", lit(HONEST_LIMITS))

    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        fh.write(body)
    print(f"wrote {OUT_PATH} ({os.path.getsize(OUT_PATH)} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())

