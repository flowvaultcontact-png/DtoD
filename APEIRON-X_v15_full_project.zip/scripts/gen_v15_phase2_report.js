// APEIRON-X v15 — Phase 2 Knowledge Expansion (deliverable docx)
// Skill-compliant: R1 cover recipe (DS-1), 3-section numbering, TOC field +
// refresh hint, three-line tables, postcheck-ready. Same architecture as the
// Phase 1 generator (validated), content replaced.
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, SectionType,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  TableLayoutType, TableOfContents,
} = require("docx");
const fs = require("fs");

// ---------------------------------------------------------------- palette (DS-1 Deep Sea)
const PAL = {
  bg: "0B1C2C", accent: "529286",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "529286", headerText: "FFFFFF", accentLine: "529286", innerLine: "BECFCC", surface: "E8ECEB" },
  primary: "0B1C2C", body: "000000", secondary: "5B6B7D",
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ------------------------------------------------------- title layout (English-aware width)
function textWidthTwips(text, pt) {
  let w = 0;
  for (const ch of text) w += /[\u4e00-\u9fff]/.test(ch) ? pt * 20 : pt * 11;
  return w;
}
function splitTitleLines(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const wd of words) {
    const cand = cur ? cur + " " + wd : wd;
    if (textWidthTwips(cand, pt) <= maxWidthTwips || !cur) cur = cand;
    else { lines.push(cur); cur = wd; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLines(title, maxWidthTwips, titlePt);
    if (lines.length <= 3 && lines.every(l => textWidthTwips(l, titlePt) <= maxWidthTwips)) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(p) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = p;
  const SAFETY = 1200;
  const usable = pageHeight - marginTop - marginBottom - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (12 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (10 * 23 + 100);
  const implicit = 3 * 300;
  const content = titleH + subH + engH + metaH + fixedHeight + implicit;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(remaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ------------------------------------------------------------------ cover recipe R1
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.cover.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.cover.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.cover.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        ", size: 16, color: P.cover.footerColor }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders, children,
      })],
    })],
  })];
}

// ------------------------------------------------------------------ body helpers
const F = { ascii: "Times New Roman", eastAsia: "SimSun" };
const FH = { ascii: "Times New Roman", eastAsia: "SimHei" };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: PAL.primary, font: FH })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: PAL.primary, font: FH })],
  });
}
function body(text, opts = {}) {
  const runs = Array.isArray(text) ? text : [new TextRun({ text, size: 24, color: PAL.body, font: F })];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: opts.after !== undefined ? opts.after : 120 },
    children: runs,
  });
}
function caption(text) {
  return new Paragraph({
    keepNext: true, spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: PAL.secondary, font: FH })],
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      spacing: { line: 312 },
      children: [new TextRun({ text, size: opts.header ? 21 : 20,
        bold: !!opts.header, color: opts.header ? PAL.table.headerText : PAL.body,
        font: opts.header ? FH : F })],
    })],
    shading: opts.header ? { type: ShadingType.CLEAR, fill: PAL.table.headerBg }
      : (opts.zebra ? { type: ShadingType.CLEAR, fill: PAL.table.surface } : undefined),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
  });
}
function dataTable(widths, header, rows, zebra = true) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: header.map((t, i) => cell(t, { header: true, width: widths[i] })),
      }),
      ...rows.map((r, ri) => new TableRow({
        cantSplit: true,
        children: r.map((t, i) => cell(t, { width: widths[i], zebra: zebra && ri % 2 === 1 })),
      })),
    ],
  });
}
function codeBlock(lines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      left: { style: BorderStyle.SINGLE, size: 12, color: PAL.table.accentLine },
      right: NB, insideHorizontal: NB, insideVertical: NB,
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: "F4F7F6" },
        margins: { top: 120, bottom: 120, left: 200, right: 160 },
        children: lines.map(l => new Paragraph({
          spacing: { line: 312, after: 20 },
          children: [new TextRun({ text: l, size: 18, color: "24313B", font: { ascii: "Courier New", eastAsia: "SimSun" } })],
        })),
      })],
    })],
  });
}

// ------------------------------------------------------------------ footers/headers
function pageFooter() {
  return new Footer({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: F })],
  })] });
}
function bodyHeader() {
  return new Header({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine, space: 4 } },
    children: [new TextRun({ text: "APEIRON-X v15 Phase 2 Report", size: 18, color: "808080", font: F })],
  })] });
}

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

// ================================================================== BODY CONTENT
const B = [];

// ---- 1 Executive Summary
B.push(h1("1. Executive Summary"));
B.push(body("This report closes Phase 2 of the APEIRON-X v15 program: scientific knowledge expansion (Module A). The phase delivered four things. First, a frozen, machine-verified additive vocabulary (P2-1): eight disease-ontology records cross-checked against the EBI OLS4 API and eight gene records cross-checked against the HGNC and UniProt REST APIs, every row carrying source, version, retrieval timestamp, license, evidence type and known limitations. Second, the universal disease-profile model (P2-2) gained a real derivation path: cited channel candidates are resolved against the live v14.1 vocabulary or the verdict is explicitly NOT_ENCODABLE, and the profile-to-encoding round trip plus corpus injectivity are machine-checked on the whole 68-disease corpus. Third, the growth-pack machinery (P2-3) automates the audited expansion checklist end to end: validate, prove, insert, re-freeze, re-pin, and re-run the entire proof cascade as the merge gate. Fourth, the first knowledge pack (P2-3 data, P2-4 gate) was applied: five new diseases D64 to D68 across five organ systems the corpus previously lacked, with a documented re-freeze of the hash-pinned corpus."));
B.push(body("The binding acceptance gate held at every step. After the re-freeze the full cascade ran 11 of 11 stages exit 0, including the complete v14.1 proof batteries: the grown corpus now learns 561 monomials, every one at depth exactly 2 (528 at 63 diseases before), so the anti-collapse invariant survives the expansion untouched. The novel-disease harness still resolves its eight guideline cases correctly and still refuses foreign encodings soundly. A functional spot check resolves each new disease to its guideline first-line agent, and a novel out-of-corpus variant is soundly refused. Nothing in this round weakened a theorem, edited a law, or touched the chemical layer: the pack introduces no new drug, molecule, mechanism class or sibling pair, so the structure-side laws are unchanged by construction."));

// ---- 2 Scope and doctrine
B.push(h1("2. Scope, Doctrine and What Deliberately Did Not Change"));
B.push(body("Phase 2 was bounded by the plan's inviolable principles. The v14.1 cascade had to exit 0 after the round. No mathematical constraint was weakened and no law was edited to make a test pass. Every emitted artifact keeps the four-tier claim separation: proven mathematics on the encoded corpus, cited guideline evidence, computational inference, and speculative hypothesis. Missing data is reported as missing with the field named. The expansion therefore took the safest scientifically honest route: the knowledge pack extends the disease side only, reusing drugs whose structure laws are already proved, so the entire chemical layer (117 structure laws, 183 identity laws, the sibling doctrine, the PubChem table) is bit-identical before and after the round."));
B.push(body("Two identity properties of the platform were re-verified rather than assumed. The hash-pinned corpus discipline now includes a documented re-freeze event: the data modules changed, the axiom corpus was rebuilt deterministically, and every pin that references it was updated in the same transaction and re-checked by the regression runner. And the claim-tier scan (no efficacy language outside quoted citations) was re-run across all v15 sources: clean."));

// ---- 3 P2-1 vocabulary
B.push(h1("3. P2-1: The Frozen Additive Vocabulary"));
B.push(body("The vocabulary module is a data file frozen under the same discipline as the v14.1 axiom corpus: after authoring, its sha256 is pinned in a sidecar file, and the loader refuses to serve any record if the live hash differs from the pin, so a silent edit cannot flow into any derivation. Two resource classes were verified this round, both machine-checked rather than transcribed from memory."));
B.push(h2("3.1 Disease-ontology records (EBI OLS4, MONDO release 2026-11-03)"));
B.push(caption("Table 1: Verified disease-ontology records (retrieval 2026-11-24)"));
B.push(dataTable([24, 20, 22, 34],
  ["Disease", "MONDO", "ICD-10 / MeSH xrefs", "Anchored corpus row"],
  [
    ["impetigo", "MONDO:0004592", "L01 (WHO+CM), MeSH D007169", "D64 (new, this round)"],
    ["purulent acute otitis media", "MONDO:0001031", "H66.0", "D65 (new, this round)"],
    ["bacterial vaginosis", "MONDO:0005316", "MeSH D016585; ICD-10-CM N76.0 via coding index", "D66 (new, this round)"],
    ["suppurative periapical periodontitis", "MONDO:0006989", "MeSH D010482; ICD-10 K04.7 via coding index", "D67 (new, this round)"],
    ["preeclampsia", "MONDO:0005081", "O14, MeSH D011225", "D68 (new, this round)"],
    ["type 2 diabetes mellitus", "MONDO:0005148", "E11, MeSH D003924, OMIM 125853", "D08 (existing)"],
    ["hypertensive disorder", "MONDO:0005044", "I10-I1x, MeSH D006973", "D01 (existing)"],
    ["asthma", "MONDO:0004979", "J45, MeSH D001249", "D15/D16 (existing)"],
  ]));
B.push(body("Verification caught one real error before it could enter the corpus: a MONDO identifier proposed for rheumatoid arthritis resolved to hypopituitarism in OLS, and the record was excluded rather than corrected by guesswork. Cross-references are exactly the ones the MONDO release carries; where MONDO has no ICD-10 xref (bacterial vaginosis, periapical abscess), the ICD-10 code is sourced from a coding index and labelled as a secondary source in the record. This is why the table shows two evidence qualities, and the record carries the distinction explicitly.", { after: 160 }));
B.push(h2("3.2 Gene records (HGNC REST + UniProt REST, snapshot 2026-11-24)"));
B.push(caption("Table 2: Verified gene records linked to v14.1 mechanism classes"));
B.push(dataTable([14, 16, 18, 24, 28],
  ["Symbol", "HGNC", "UniProt", "Linked class", "Linked diseases"],
  [
    ["SLC5A2 (SGLT2)", "HGNC:11037", "P31639", "SGLT2_INHIBITOR", "D02, D08, D61"],
    ["HMGCR", "HGNC:5006", "P04035", "HMGCR_INHIBITOR", "D05"],
    ["EGFR", "HGNC:3236", "P00533", "EGFR_TYROSINE_KINASE_INHIBITOR", "D51"],
    ["PTGS1 (COX1)", "HGNC:9604", "P23219", "COX1_PLATELET_INHIBITOR", "D06, D68"],
    ["ACE", "HGNC:2707", "P12821", "ACEI_RAAS", "D01, D02"],
    ["ABL1", "HGNC:76", "P00519", "BCR_ABL_TYROSINE_KINASE_INHIBITOR", "D50"],
    ["PCSK9", "HGNC:20001", "Q8NBP7", "(no KB class yet)", "Phase 3 benchmark"],
    ["CFTR", "HGNC:1884", "P13569", "(no KB class yet)", "Phase 3 benchmark"],
  ]));
B.push(body("Honest absence is part of the design: the pathway-ontology and HPO tables are deliberately empty this round, each with a named-limitations note explaining that numeric Reactome and KEGG identifiers were not machine-verified and will arrive through the Phase 3 connector skeleton, which freezes raw responses with retrieval metadata before any derivation consumes them. Two gene records carry an explicit ensembl-absent note rather than a guessed identifier."));

// ---- 4 P2-2 profiles
B.push(h1("4. P2-2: Universal Disease Profiles and the Encoding Contract"));
B.push(body("The profile model layers eleven evidence fields (ontology identifiers, genetics, expression, protein abnormality, metabolic, immune, cellular, tissue, pathway, progression, environmental) over the six-channel spine, each field carrying a status of established, inferred or unknown. The derivation path added this round resolves the six channels from cited channel-value candidates against the live vocabulary. The verdict ladder is deliberately three-valued: ENCODABLE when all six channels resolve uniquely with citations; PARTIALLY_ENCODABLE when some resolve; NOT_ENCODABLE when none do. An out-of-vocabulary candidate value raises an error and is never coerced into the corpus, which extends the v14.1 honesty doctrine (sound refusals) to v15 data."));
B.push(body("Acceptance evidence: the round trip is machine-checked for all 68 rows (row to profile to checked encoding reproduces the original six channels and passes the strict v14.1 normalizer), the injectivity theorem reports 68 distinct six-channel tuples over 68 rows with zero counterexamples, and the verdict ladder plus refusal paths are covered by the new test battery (6 of 6 checks passing, together with the Phase 1 scaffold's 5 of 5)."));

// ---- 5 P2-3 machinery
B.push(h1("5. P2-3: The Growth-Pack Machinery"));
B.push(body("The audited expansion checklist is now one command. The applier validates the pack (schema, guideline field, drug and mechanism cross-checks against the live tables, merged-corpus injectivity, vocabulary admission contract, ontology anchors resolving in the frozen vocabulary, complete provenance records), proves the cardinality theorem, inserts the rows with unique-anchor assertions, re-validates both edited modules in a fresh subprocess, rebuilds the axiom corpus, re-pins the correspondence lock, updates the hash snapshot and the corpus pins consumed by the tests, and finally runs the entire regression cascade as the merge gate. A failing cascade refuses the pack; the engine certifies only what it re-proved."));
B.push(body("Operational modes are explicit: a dry run that mutates nothing, an apply that refuses a double-apply, a recovery path that resumes an interrupted run at the re-freeze without ever re-inserting rows, and a debug-only cascade skip. In the applied state the validator switches to verbatim consistency: live rows must equal the pack byte for byte, which makes accidental drift detectable at any later time. The interrupted-run recovery path was exercised in practice during this round when the sandbox reset mid-apply (RDKit was reinstalled at the pinned version 2026.09.2), and the final state was produced by the resumed, fully gated run.", { after: 160 }));
B.push(caption("Table 3: One-command acceptance gate"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/kb_extensions/apply_pack.py --dry-run  # 166/166 checks + T5 proved",
  "python3 v15/kb_extensions/apply_pack.py            # refuses double-apply",
  "python3 v15/run_full_regression.py                 # 11/11 stages exit 0",
  "python3 ../scripts/apeiron_v15_phase2_spotcheck.py # D64-D68 spot verdicts",
]));

// ---- 6 the pack
B.push(h1("6. The First Growth Pack: D64 to D68"));
B.push(body("The pack adds five diseases spanning five organ systems the corpus lacked (dermatologic, otolaryngologic, gynecologic, oral-dental, obstetric). Every row is guideline-anchored with a content-verified citation, and every listed drug already exists in the knowledge base with a proved structure law, so the chemical layer is untouched by construction. Efficacy values are calibrated to guideline reality, notably aspirin at 5 of 10 for pre-eclampsia prophylaxis, reflecting partial risk reduction rather than cure-like numbers."));
B.push(caption("Table 4: The five new diseases, guideline anchors as cited in the rows"));
B.push(dataTable([16, 24, 34, 26],
  ["Row", "Disease", "Guideline anchor (verified source)", "Tier-1 drug (class)"],
  [
    ["D64", "Impetigo (widespread)", "NICE CKS impetigo: flucloxacillin first-line, clarithromycin if unsuitable", "flucloxacillin (beta-lactam cell-wall)"],
    ["D65", "Acute otitis media (bacterial)", "NICE CKS: amoxicillin 5-7 days when an antibiotic is required", "amoxicillin (beta-lactam cell-wall)"],
    ["D66", "Bacterial vaginosis", "CDC STI 2021: metronidazole 500 mg twice daily 7 days", "metronidazole (nitroimidazole)"],
    ["D67", "Dentoalveolar abscess", "NICE CKS: amoxicillin or phenoxymethylpenicillin; metronidazole for penicillin allergy", "amoxicillin (beta-lactam cell-wall)"],
    ["D68", "Pre-eclampsia prophylaxis", "NICE NG133 rec 1.1.2: aspirin 75-150 mg daily from 12 weeks, high-risk women", "aspirin (COX1 platelet inhibitor)"],
  ]));
B.push(body("Citation integrity was verified, not assumed. The CDC page returned HTTP 200 at authoring time. The NICE properties return HTTP 403 to non-browser agents, so the slugs and prescribing content were verified through search-result snapshots and the limitation is recorded verbatim inside each source record, in line with the platform's rule that known limits are documented, never hidden. Ontology anchors for all five rows resolve in the frozen vocabulary with matching corpus links."));

// ---- 7 T5
B.push(h1("7. P2-4: The Cardinality Guard Theorem (T5)"));
B.push(body("The depth-2 doctrine degrades only if a channel value becomes silently degenerate. Theorem T5, machine-checked counting on the merged corpus, closes that door: every channel value a pack uses must reach merged-cardinality at least 2, or carry a documented degenerate-channel consequence in the pack. On this pack the theorem passes with 8 values non-degenerate and 14 documented, zero counterexamples. Two values were deliberately strengthened instead of minted degenerate: the pack shares the anaerobic-overgrowth microbe value between D66 and D67 (born at cardinality 2) and reuses the existing platelet-aggregation pathway for D68, raising it from 1 to 2, because antiplatelet prophylaxis is biologically the same pathway as post-plaque antiplatelet therapy."));
B.push(caption("Table 5: T5 verdict on the pack (base counts normalized, pre-merge == post-merge)"));
B.push(dataTable([30, 24, 20, 26],
  ["Value", "Channel", "Merged cardinality", "Verdict"],
  [
    ["BACTERIAL", "etiology", "12 -> 16", "non-degenerate"],
    ["ANAEROBE_MIXED_OVERGROWTH", "microbe", "new, born at 2", "non-degenerate"],
    ["PW_PLATELET_AGGREGATION", "pathway", "1 -> 2", "non-degenerate"],
    ["SKIN_SOFT_TISSUE", "site", "1 -> 2", "non-degenerate"],
    ["DERMATOLOGIC / OTOLARYNGOLOGIC / GYNECOLOGIC / ORAL_DENTAL / OBSTETRIC", "system", "new, 1 each", "documented degenerate"],
    ["PLACENTAL_VASCULAR_DYSFUNCTION", "etiology", "new, 1", "documented degenerate"],
    ["4 new site values, 4 new pathway values", "site / pathway", "new, 1 each", "documented degenerate"],
  ]));
B.push(body("Each documented-degenerate value carries a consequence note stating that disease identity still rests on system-anchored depth-2 conjunctions, which remain valid, and that the value cannot support a shared cross-disease class-law anchor until a second row reuses it. Nothing enters the corpus silently degenerate."));

// ---- 8 re-freeze evidence
B.push(h1("8. The Documented Re-Freeze"));
B.push(body("Because the corpus is hash-pinned, growth is a re-freeze event, and the round treats it as a first-class artifact. The axiom corpus was rebuilt deterministically from the grown tables and its new sha256 was re-pinned into the correspondence engine in the same transaction; the hash snapshot and the corpus pins were updated; and the regression runner verifies all four frozen files against the new pins on every run. The proof engine was re-proved on the grown corpus, not assumed."));
B.push(caption("Table 6: Post-refreeze pins (full values committed in the repository)"));
B.push(dataTable([40, 60],
  ["Artifact", "New value"],
  [
    ["postulates_v14.json", "f8f59e5f9ab8c1087358a23daa0353b5b06e59443e9c8eed44cd9c5d025c5715"],
    ["disease_drug_kb.py", "76dcfe011c58d658... (68 diseases, 18 systems)"],
    ["disease_mechanism_table.py", "2ad2e5f1b66dd250... (68 mechanism profiles)"],
    ["drug_structures.py", "7dc763c480443789... unchanged (chemical layer untouched)"],
    ["corpus pins", "diseases 68, drugs 203, mech profiles 68, systems 18"],
  ]));
B.push(caption("Table 7: Cascade after the re-freeze, 11 of 11 stages exit 0"));
B.push(dataTable([44, 12, 44],
  ["Stage", "Exit", "Key evidence on the grown corpus"],
  [
    ["v11.1 core T-battery", "0", "domain sweep exact on 68 rows; anti-collapse doctrine enforced"],
    ["v12.1 structure S-battery", "0", "chemical layer unchanged; all structure/identity laws re-proved"],
    ["v13.0 direct-law D-battery", "0", "direct laws re-derived; held-out pairs and refusals clean"],
    ["v13.1 equation E-battery", "0", "equation chain exact for every disease"],
    ["v14.0 correspondence C-battery", "0", "hermetic derivation true; axiom lock matches new pin"],
    ["demo: full mapping", "0", "every disease maps to guideline rank-1 on both paths"],
    ["demo: extension stress", "0", "synthetic worlds; re-anchoring checks pass"],
    ["v14.1 novel-disease harness", "0", "561/561 monomials at depth 2; Tier A 8/8; Tier D clean"],
    ["v14.1 smoke test", "0", "SGLT2 law present; exclusivity confirmed"],
    ["v15 scaffold tests", "0", "5/5 checks (pins-driven corpus sizes)"],
    ["v15 phase-2 tests", "0", "6/6 checks (vocab, profiles, pack refusals)"],
  ]));

// ---- 9 verification evidence
B.push(h1("9. Functional Verification of the Expanded Corpus"));
B.push(body("Three independent probes show the grown corpus behaves exactly as the doctrine requires. The novel-disease harness re-ran green: 561 learned monomials all at depth exactly 2; the eight guideline Tier A cases still resolve (stroke prophylaxis to COX1 platelet inhibition, heart failure with preserved ejection fraction to SGLT2 inhibition, binge-eating disorder to amphetamine release); and the adversarial Tier C probes still produce sound refusals, including an out-of-vocabulary pathway and a malformed encoding."));
B.push(caption("Table 8: Spot check on the five new diseases (live oracle, post-merge)"));
B.push(dataTable([10, 40, 20, 30],
  ["Row", "Disease", "Verdict", "First line"],
  [
    ["D64", "Impetigo (widespread non-bullous/bullous)", "PROVEN_EXACT", "flucloxacillin"],
    ["D65", "Acute otitis media (bacterial)", "PROVEN_EXACT", "amoxicillin"],
    ["D66", "Bacterial vaginosis (symptomatic)", "PROVEN_EXACT", "metronidazole"],
    ["D67", "Dentoalveolar abscess (systemic)", "PROVEN_EXACT", "amoxicillin"],
    ["D68", "Pre-eclampsia prophylaxis (high-risk)", "PROVEN_EXACT", "aspirin"],
    ["probe", "impetigo-like tuple, chronic variant (NOT in corpus)", "UNPROVEN", "sound refusal"],
  ]));
B.push(body("The last row is the anti-collapse doctrine doing its job: a chronic impetigo-like encoding shares five of six channels with D64 but is not in the corpus, and the oracle refuses rather than inheriting the therapy through a single shared channel. The claim-tier scan across all v15 sources found no efficacy language outside quoted citations."));

// ---- 10 honest limits
B.push(h1("10. Honest Limits and Next Steps"));
B.push(body("Nothing in this round claims clinical validity for anything: the knowledge base remains a mathematical identification corpus, the new rows prove theorems about encoded data, and the guideline citations anchor the encoding, not a treatment claim. The pack deliberately contains no new drug, molecule, mechanism class or sibling pair, so no chemical claim changed; the first pack that adds a molecule will run the full structure-law admission path with sibling auditing. Numeric pathway-ontology and phenotype identifiers are absent by design and are named as absent. The NICE citations carry recorded fetch limitations. The five new system values are cardinality-1 with documented consequences; the first pack that reuses them will convert those entries to non-degenerate automatically."));
B.push(body("Next steps, in plan order: Phase 3 delivers biological target discovery (Module B), the connector skeleton with the frozen-response pattern (Open Targets, UniProt, Reactome under license review), the ten-disease target benchmark with honest recall including misses, and the association-is-not-causation flag propagating into rankings. Phase 4 delivers the repurposing engine with status discipline and the temporal benchmark whose canonical case is the SGLT2 heart-failure class. Every subsequent round lands only with the same acceptance gate: full cascade exit 0, frozen hashes intact or documented re-freeze, claim-tier scan clean, changelog updated."));

// ---- Appendix
B.push(h1("Appendix A. Reproduce This Round"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/kb_extensions/apply_pack.py --dry-run    # pack gate + T5",
  "python3 v15/tests/test_v15_phase2.py                # 6/6 checks",
  "python3 v15/tests/test_v15_scaffold.py              # 5/5 checks",
  "python3 v15/run_full_regression.py                  # 11 stages + pins",
  "python3 ../scripts/apeiron_v15_phase2_spotcheck.py  # spot verdicts JSON",
  "python3 ../scripts/verify_vocab_ols.py              # 9/9 MONDO ids",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));
B.push(body("Verification tooling added this round: scripts/verify_vocab_ols.py with its machine-check report (scripts/ols_verification_report.json), and the vocabulary freeze tool v15/kb_extensions/freeze_vocab.py. The change log (docs/CHANGELOG.md, entry v15 Phase 2) lists every file touched with reasons and reproduction commands.", { after: 200 }));

// ================================================================== DOCUMENT
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: F, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FH, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FH, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FH, size: 24, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 200, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: cover
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: buildCoverR1({
        title: "APEIRON-X v15 Knowledge Expansion",
        subtitle: "Phase 2: Module A vocabulary, profiles, growth-pack machinery and the first knowledge pack D64-D68",
        englishLabel: "APEIRON-X V15 PROGRAM",
        metaLines: [
          "Round: v15 Phase 2 (P2-1 vocab, P2-2 profiles, P2-3 packs, P2-4 theorem)",
          "Growth: 63 -> 68 diseases across 5 new organ systems, documented re-freeze",
          "Gate: full cascade 11/11 exit 0; 561/561 monomials at depth 2",
          "Date: 2026-11-24",
        ],
        footerLeft: "APEIRON-X Computational Drug-Discovery Platform",
        footerRight: "v15 Phase 2 Report",
        palette: PAL,
      }),
    },
    { // Section 2: front matter (TOC) — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 240, after: 160 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FH, color: PAL.primary })],
        }),
        new Paragraph({
          spacing: { after: 80 },
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: F })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
      ],
    },
    { // Section 3: body — Arabic, restart at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: bodyHeader() },
      footers: { default: pageFooter() },
      children: B,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON-X_v15_Phase2_Knowledge_Expansion.docx", buf);
  console.log("written: APEIRON-X_v15_Phase2_Knowledge_Expansion.docx");
});
