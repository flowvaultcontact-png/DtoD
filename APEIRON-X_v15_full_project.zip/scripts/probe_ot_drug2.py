"""Bisect the OT Drug schema: which fields exist? (probe, not frozen flow)"""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def q(name, query, vid="CHEMBL1201595"):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": {"id": vid}}).encode(),
                         {"Content-Type": "application/json"}, 40, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:200])
        else:
            print(f"{name}: OK", json.dumps(p["data"])[:400])
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:120]}")


q("basic", 'query($id:String!){drug(chemblId:$id){id name isApproved '
           'withdrawn maximumClinicalTrialPhase}}')
q("firstApproval", 'query($id:String!){drug(chemblId:$id){firstApproval}}')
q("approvedInd", 'query($id:String!){drug(chemblId:$id){approvedIndications}}')
q("moa_plain", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction{ '
               'rows{ actionType mechanismOfAction targetId } } } }')
q("moa_targets_id", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction{ '
                    'rows{ targetId targets{ id } } } } }')
q("moa_targets_sym", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction{ '
                     'rows{ targets{ id approvedSymbol } } } } }')
