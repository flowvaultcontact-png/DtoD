"""Probe exact row-field shapes: MOA rows, drug indications rows,
disease.knownDrugs rows; sample dapagliflozin (CHEMBL1201549?) end-to-end.
(probe, not part of frozen flow)"""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None, maxlen=1600):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 40, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:200])
        else:
            print(f"{name}: OK {json.dumps(p['data'])[:maxlen]}")
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:120]}")


run("moa_r1", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction'
              '{rows{actionType}}}}', {"id": "CHEMBL1201595"})
run("moa_r2", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction'
              '{rows{mechanismOfAction}}}}', {"id": "CHEMBL1201595"})
run("moa_r3", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction'
              '{rows{targetId}}}}', {"id": "CHEMBL1201595"})
run("moa_r4", 'query($id:String!){drug(chemblId:$id){mechanismsOfAction'
              '{rows{targets{id approvedSymbol}}}}}', {"id": "CHEMBL1201595"})
run("mcs", 'query($id:String!){drug(chemblId:$id){maximumClinicalStage}}',
    {"id": "CHEMBL1201595"})
run("ind_r1", 'query($id:String!){drug(chemblId:$id){indications{count}}}',
    {"id": "CHEMBL1201595"})
run("ind_r2", 'query($id:String!){drug(chemblId:$id){indications{rows'
              '{indication{id name}}}}}', {"id": "CHEMBL1201595"})
run("kd1", 'query($efo:String!){disease(efoId:$efo){knownDrugs(page:'
           '{size:2,index:0}){count rows{drug{id name}}}}}',
    {"efo": "MONDO_0005300"})
