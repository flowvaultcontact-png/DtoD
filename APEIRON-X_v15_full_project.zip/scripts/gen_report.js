/**
 * APEIRON-X novel-disease generalization test report (DOCX, English).
 * Skill compliance: R1 cover recipe + MC-1 palette, 3-section page numbering,
 * HeadingLevel headings, TableOfContents + refresh hint + PageBreak,
 * percentage-width tables with margins/tableHeader/cantSplit/keepNext,
 * line spacing 312, justified body, no markdown artifacts.
 */
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, AlignmentType, HeadingLevel,
  WidthType, BorderStyle, ShadingType, TableOfContents, PageBreak,
  SectionType, TableLayoutType,
} = require("docx");
const fs = require("fs");

/* ------------------------------------------------------------------ */
/* Palette MC-1 Medical Blue (design-system.md)                        */
/* ------------------------------------------------------------------ */
const P = {
  bg: "F5F8FC", primary: "1A5276", accent: "2E86C1",
  cover: { titleColor: "1A5276", subtitleColor: "606060", metaColor: "707070", footerColor: "A0A0A0" },
  table: { headerBg: "2E86C1", headerText: "FFFFFF", accentLine: "1A5276", innerLine: "D0DDE8", surface: "EDF3F8" },
  body: "000000", secondary: "506070",
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

/* ------------------------------------------------------------------ */
/* Cover layout helpers (calcTitleLayout / calcCoverSpacing)           */
/* ------------------------------------------------------------------ */
function estimateTextWidth(text, pt) {
  // CJK chars ~ pt*20 twips; Latin chars ~ pt*10 twips (half-width average)
  let w = 0;
  for (const ch of text) {
    w += /[\u4e00-\u9fff\u3000-\u30ff]/.test(ch) ? pt * 20 : pt * 10;
  }
  return w;
}

function splitTitleLines(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const word of words) {
    const cand = cur ? cur + " " + word : word;
    if (estimateTextWidth(cand, pt) <= maxWidthTwips || !cur) {
      cur = cand;
    } else {
      lines.push(cur);
      cur = word;
    }
  }
  if (cur) lines.push(cur);
  // no 1-2 char orphan
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}

function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt;
  let lines;
  while (titlePt >= minPt) {
    lines = splitTitleLines(title, maxWidthTwips, titlePt);
    if (lines.length <= 3) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) {
    lines = splitTitleLines(title, maxWidthTwips, minPt);
    titlePt = minPt;
  }
  return { titlePt, titleLines: lines };
}

function calcCoverSpacing(params) {
  const {
    titleLineCount = 1, titlePt = 36, hasSubtitle = false,
    hasEnglishLabel = false, metaLineCount = 0,
    fixedHeight = 800, pageHeight = 16838,
    marginTop = 0, marginBottom = 0,
  } = params;
  const SAFETY = 1200;
  const usableHeight = pageHeight - marginTop - marginBottom - SAFETY;
  const titleHeight = titleLineCount * (titlePt * 23 + 200);
  const subtitleHeight = hasSubtitle ? (12 * 23 + 600) : 0;
  const englishLabelHeight = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaHeight = metaLineCount * (10 * 23 + 100);
  const implicitParaHeight = 3 * 300;
  const contentHeight = titleHeight + subtitleHeight + englishLabelHeight +
                        metaHeight + fixedHeight + implicitParaHeight;
  const remainingSpace = usableHeight - contentHeight;
  const safeRemaining = Math.max(remainingSpace, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(safeRemaining * 0.45);
  const rawBottom = Math.floor(safeRemaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(safeRemaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

/* ------------------------------------------------------------------ */
/* Cover recipe R1 (Pure Paragraph Left)                               */
/* ------------------------------------------------------------------ */
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length,
    fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];

  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));

  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }

  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }

  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }

  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200, right: padR }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }

  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));

  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        " }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.footerColor, font: { ascii: "Arial" } }),
    ],
  }));

  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders,
        children,
      })],
    })],
  })];
}

/* ------------------------------------------------------------------ */
/* Body building blocks                                                */
/* ------------------------------------------------------------------ */
function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: P.primary,
      font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: P.primary,
      font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
  });
}
function body(text, opts = {}) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    indent: { firstLine: 360 },
    spacing: { line: 312, after: 120 },
    children: runsWithBold(text, { size: 24, color: P.body }),
    ...opts,
  });
}
/** Supports **bold** spans inside plain text (converted to TextRun bold). */
function runsWithBold(text, base) {
  const runs = [];
  const parts = String(text).split("**");
  for (let i = 0; i < parts.length; i++) {
    if (!parts[i]) continue;
    runs.push(new TextRun({ text: parts[i], bold: i % 2 === 1, size: base.size, color: base.color,
      font: { ascii: "Times New Roman", eastAsia: "SimSun" } }));
  }
  return runs;
}
function note(text) {
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 160, before: 60 },
    indent: { left: 360 },
    children: [new TextRun({ text, italics: true, size: 21, color: P.secondary,
      font: { ascii: "Times New Roman", eastAsia: "SimSun" } })],
  });
}
function tableTitle(text) {
  return new Paragraph({
    keepNext: true,
    spacing: { before: 200, after: 100, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: P.primary,
      font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
  });
}
function cellPara(text, opts = {}) {
  return new Paragraph({
    alignment: opts.align || AlignmentType.LEFT,
    spacing: { line: 312 },
    children: runsWithBold(text, { size: opts.size || 20, color: opts.color || P.body }),
  });
}
function makeTable(headers, rows, widths) {
  const headerRow = new TableRow({
    tableHeader: true, cantSplit: true,
    children: headers.map((text, i) => new TableCell({
      children: [cellPara(text, { bold: true, color: P.table.headerText, size: 20 })],
      shading: { type: ShadingType.CLEAR, fill: P.table.headerBg },
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  });
  const dataRows = rows.map((row, r) => new TableRow({
    cantSplit: true,
    children: row.map((text, i) => new TableCell({
      children: [cellPara(text)],
      shading: r % 2 === 1 ? { type: ShadingType.CLEAR, fill: P.table.surface } : undefined,
      margins: { top: 60, bottom: 60, left: 100, right: 100 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 4, color: P.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 4, color: P.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: P.table.innerLine },
      insideVertical: NB,
    },
    rows: [headerRow, ...dataRows],
  });
}

/* ------------------------------------------------------------------ */
/* Content data (all values from the actual test run)                  */
/* ------------------------------------------------------------------ */
const tierASet = [
  ["A1", "Secondary prevention of ischaemic stroke (non-cardioembolic)", "Aspirin 50-325 mg or clopidogrel 75 mg (antiplatelet)", "AHA/ASA 2021 stroke prevention guideline"],
  ["A2", "VTE prophylaxis after total hip replacement", "DOAC: apixaban or rivaroxaban (alt. LMWH)", "CHEST 2022; arthroplasty prophylaxis literature"],
  ["A3", "Heart failure with preserved ejection fraction (HFpEF)", "SGLT2 inhibitor: empagliflozin or dapagliflozin (class I)", "ESC 2023 focused update on heart failure"],
  ["A4", "NSAID-induced peptic ulcer prophylaxis", "Proton pump inhibitor (omeprazole/pantoprazole)", "ACG gastroprotection guidance"],
  ["A5", "Trigeminal neuralgia (NEUROELECTRIC encoding)", "Carbamazepine (or oxcarbazepine)", "AAN-EFNS 2008 trigeminal neuralgia guideline"],
  ["A6", "Trigeminal neuralgia (STRUCTURAL_MECHANICAL encoding)", "Carbamazepine (or oxcarbazepine)", "AAN-EFNS 2008 (encoding-sensitivity variant)"],
  ["A7", "Binge-eating disorder, moderate-severe", "Lisdexamfetamine (only FDA-approved BED drug)", "FDA approval 2015; NICE guidance"],
  ["A8", "Vasospastic (Prinzmetal) angina", "Calcium channel blocker or nitrate; avoid beta-blockers", "Coronary artery spasm reviews (Lanza 2023)"],
];

const tierAResults = [
  ["A1", "COX1_PLATELET_INHIBITOR", "aspirin", "aspirin / clopidogrel", "PASS"],
  ["A2", "FACTOR_XA_INHIBITOR", "apixaban", "apixaban / rivaroxaban", "PASS"],
  ["A3", "ACEI_RAAS", "ramipril", "empagliflozin / dapagliflozin", "FAIL"],
  ["A4", "PROTON_PUMP_INHIBITOR", "omeprazole", "omeprazole / pantoprazole", "PASS"],
  ["A5", "SODIUM_CHANNEL_BLOCKER_AED", "carbamazepine", "carbamazepine", "PASS"],
  ["A6", "SODIUM_CHANNEL_BLOCKER_AED", "carbamazepine", "carbamazepine", "PASS"],
  ["A7", "DOPAMINE_TRANSPORTER_INHIBITOR", "methylphenidate", "lisdexamfetamine", "FAIL"],
  ["A8", "BETA1_BLOCKER", "bisoprolol", "amlodipine / isosorbide mononitrate", "FAIL"],
];

const lawEvidence = [
  ["ACEI_RAAS", "pathway = PW_NEUROHORMONAL_REMODELING", "A3 (HFpEF): fires although etiology differs from HFrEF"],
  ["BETA1_BLOCKER", "pathway = PW_MYOCARDIAL_O2_BALANCE", "A8 (vasospastic angina): fires although etiology differs from stable angina"],
  ["COX1_PLATELET_INHIBITOR", "pathway = PW_PLATELET_AGGREGATION", "A1: correct, pathway is stroke-specific in the KB"],
  ["FACTOR_XA_INHIBITOR", "pathway = PW_COAGULATION_CASCADE", "A2: correct; 2 disjuncts share the same pathway value"],
  ["PROTON_PUMP_INHIBITOR", "pathway = PW_GASTRIC_ACID_SECRETION (or PW_HELICOBACTER_COLONIZATION)", "A4: correct, acid-secretion pathway maps to PPI"],
  ["SODIUM_CHANNEL_BLOCKER_AED", "pathway = PW_CORTICAL_HYPEREXCITABILITY", "A5/A6: correct, cortical hyperexcitability maps to sodium-channel AED"],
  ["DOPAMINE_TRANSPORTER_INHIBITOR", "pathway = PW_NORADRENERGIC_EXECUTIVE_DEFICIT", "A7 (BED on ADHD pathway): fires the ADHD-row primary class"],
];

const tierBTable = [
  ["B1", "Neurocysticercosis / schistosomiasis", "Forced PROTOZOAN encoding (helminth value does not exist)", "Predicted artemether/lumefantrine (ACT)", "Confident wrong prediction under mis-encoding"],
  ["B2", "Relapsing-remitting multiple sclerosis", "Closest in-vocabulary encoding (autoimmune brain, type-1 IFN pathway)", "Predicted hydroxychloroquine", "Confident wrong class; MS drugs absent from KB"],
  ["B3", "Chronic insomnia", "Forced cholinergic-deficit pathway (no sleep pathway exists)", "Predicted donepezil", "Confident wrong prediction under forced encoding"],
  ["B4", "Hereditary haemochromatosis", "Not encodable (no iron-overload pathway; therapy is phlebotomy / chelators outside KB)", "No probe run", "Honest gap: outside the encoding vocabulary"],
  ["B5", "Idiopathic pulmonary fibrosis", "Not encodable (no fibrosis pathway; antifibrotics outside KB)", "No probe run", "Honest gap: outside the encoding vocabulary"],
  ["B6", "Pulmonary arterial hypertension", "Not encodable (no vascular-remodelling pathway; PAH agents outside KB)", "No probe run", "Honest gap: outside the encoding vocabulary"],
];

const tierCTable = [
  ["C1", "Out-of-vocabulary pathway value (PW_FOREIGN_UNKNOWN)", "UNPROVEN - refused (closed world A1)", "Sound refusal"],
  ["C2", "Incomplete encoding (2 of 6 channels)", "UNPROVEN - refused (malformed query)", "Sound refusal"],
  ["C3", "Empty channel value", "UNPROVEN - refused (non-empty string required)", "Sound refusal"],
  ["C4", "Giant cell arteritis forced through the rheumatoid-arthritis pathway", "Predicted methotrexate (DMARD class)", "Dangerous if mis-encoded; true therapy is urgent high-dose glucocorticoid"],
  ["C5", "Takotsubo stress cardiomyopathy forced through the HFrEF pathway", "Predicted ramipril (ACEI class)", "Plausible class (acceptable for this acute condition)"],
];

const reverseTable = [
  ["S1", "Paracetamol (not in KB)", "UNPROVEN - no KB-identity claim", "Sound"],
  ["S2", "Ibuprofen (in KB, NSAID)", "PROVEN_CLASS_MATCH - exact drug recovered (ibuprofen, M01AE01)", "Correct positive control"],
  ["S3", "Caffeine (not in KB)", "UNPROVEN - no KB-identity claim", "Sound"],
  ["S4", "Metformin (in KB, biguanide)", "PROVEN_CLASS_MATCH - exact drug recovered (metformin, A10BA02)", "Correct positive control"],
  ["S5", "Malformed SMILES string", "UNPROVEN - refused", "Sound"],
];

/* ------------------------------------------------------------------ */
/* Page furniture                                                      */
/* ------------------------------------------------------------------ */
const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

function pageNumFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080",
        font: { ascii: "Times New Roman" } })],
    })],
  });
}
function runningHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.innerLine, space: 4 } },
      children: [new TextRun({ text: "APEIRON-X v14.0 Novel-Disease Drug Prediction Test Report",
        size: 18, color: "808080", font: { ascii: "Times New Roman" } })],
    })],
  });
}

/* ------------------------------------------------------------------ */
/* Body content                                                        */
/* ------------------------------------------------------------------ */
const bodyChildren = [];

/* ---------- 1 Executive summary ---------- */
bodyChildren.push(h1("1. Executive Summary"));
bodyChildren.push(body(
  "This report answers a single question: **can the APEIRON-X v14.0 engine predict drugs for diseases that are not in the project?** The delivered system contains a knowledge base of 60 diseases and 203 drugs. Twenty-four independent probes were executed against the engine, covering three tiers: fair novel diseases with guideline ground truth, diseases the knowledge base cannot molecularly serve, and adversarial probes, plus name-level queries and reverse molecule-level queries."));
bodyChildren.push(body(
  "The engine itself is intact in this environment: the full v14.0 proof battery was re-run first and all 10 C-theorems re-passed with zero counterexamples (exit code 0, 72.5 seconds). On top of that verified base, the test found a nuanced picture. **By disease name, the system refuses every unknown disease (4 of 4 refused)**, which is the documented soundness doctrine rather than a prediction. **By six-channel encoding, the generic path does produce real predictions for novel diseases: on 8 fair novel diseases with verified guideline ground truth, the rank-1 drug was guideline-correct in 5 of 8 cases (62.5 percent)** and a wrong drug class in 3 of 8 cases (37.5 percent). The three failures (HFpEF, binge-eating disorder, vasospastic angina) share one root cause: every mechanism-class law in the system collapses to a single rule on the pathway channel, so two diseases that share a pathway value but differ in etiology receive the same therapy class regardless of the other five channels."));
bodyChildren.push(body(
  "The safety behaviour held everywhere it was tested: out-of-vocabulary values, incomplete encodings and malformed inputs were refused without exception, and the reverse path never claimed a false drug identity for any non-KB molecule. The main hazard is different: **if a user forces a plausible-but-wrong encoding, the engine predicts confidently** (a mis-encoded helminth infection received an antimalarial, a mis-encoded multiple-sclerosis probe received hydroxychloroquine). **Overall verdict: conditional pass.** The system generalizes to novel diseases at mechanism-class level when the encoding is faithful, and it fails honestly or safely in most other situations, but its novel-disease predictions are class-level hypotheses that require clinical verification before any medical use."));

/* ---------- 2 System under test ---------- */
bodyChildren.push(h1("2. System Under Test and the Generalization Contract"));
bodyChildren.push(body(
  "APEIRON-X v14.0 is a proof-based disease-to-drug engine. Its knowledge base (disease_drug_kb.py) defines 60 diseases D01 to D60 across 13 organ systems, 203 drugs, and a semantic encoding of every disease as a six-channel vector: system, etiology, microbe, site, chronicity and pathway. The engine learns 54 mechanism-class laws (a disjunctive normal form over channels per therapy class), 117 chemical structure laws (SMARTS feature conjunctions per class over 191 molecules), and 203 drug-channel laws. The v14 correspondence layer derives a structure-containment law (chi_D contained in chi_m implies cure) from a hash-locked axiom corpus without reading the datasets, then uses the datasets only as examiner."));
bodyChildren.push(body(
  "The system documents a precise contract for out-of-domain inputs, and the test plan follows it. **First, by disease name**, queries resolve against the proved domain D (the 60 diseases); anything else must be refused with UNPROVEN rather than guessed. **Second, by encoding**, the generic indication path (theorem S4 in the structure layer) accepts any six-channel encoding whose values lie inside the observed vocabulary; if exactly one mechanism-class law fires, it returns the ranked, structure-verified candidate drugs of that class, and it must refuse when no law or more than one law fires. **Third, at pair level**, the built-in C7 battery already validates guideline pairs that are absent from the knowledge base: 18 of 18 external pairs predicted and 11 of 11 guideline-true refusals refused. Note that these 29 pairs sit on the existing 60 diseases; they validate pair generalization, not disease generalization, which is why this independent test was needed."));
bodyChildren.push(body(
  "The README is explicit that the engine is a mathematical demonstration and not clinical advice. The test below therefore measures two different properties separately: **soundness** (does the engine refuse or stay silent where it should, and does it ever claim something false about its own domain) and **medical correctness** (does a predicted rank-1 drug match published guideline first-line therapy for a genuinely new disease)."));

/* ---------- 3 Scope, environment, method ---------- */
bodyChildren.push(h1("3. Test Scope, Environment and Method"));
bodyChildren.push(body(
  "The complete uploaded bundle (APEIRON-X_v14_complete.zip) was extracted unmodified. The environment was Linux with Python 3, and the rdkit dependency (version 2026.09.2) was installed before any engine code ran. As a baseline integrity check, the full v14.0 correspondence battery was executed before testing; it re-proved all 10 C-theorems with 0 counterexamples (exit code 0, 72.5 seconds), and the C7 held-out section reported 18 of 18 external pairs predicted and 11 of 11 guideline-true refusals refused, matching the shipped certificate."));
bodyChildren.push(body(
  "The test harness (scripts/apeiron_novel_disease_test.py) builds the same machinery the engine itself uses in its demos: the RDKit structure layer, the DrugOracle with its learned class laws, and the GenericOracle generic path. For every novel disease the harness first asserts that the six-channel encoding is NOT identical to any of the 60 knowledge-base encodings, so every Tier A case is genuinely out-of-domain. Ground-truth first-line therapies were verified against published guidance before scoring: AHA/ASA 2021 for secondary stroke prevention (aspirin 50-325 mg or clopidogrel 75 mg), ESC 2023 focused update for HFpEF (empagliflozin or dapagliflozin, class I level A), CHEST 2022 and the arthroplasty literature for post-operative VTE prophylaxis (apixaban or rivaroxaban), AAN-EFNS 2008 for trigeminal neuralgia (carbamazepine or oxcarbazepine), FDA approval of lisdexamfetamine (2015) for moderate-to-severe binge-eating disorder, and coronary-artery-spasm reviews (Lanza 2023; Harris 2016) for vasospastic angina (calcium channel blockers first-line; beta-blockade may exacerbate spasm)."));
bodyChildren.push(body(
  "Scoring is strict: **PASS** requires the guideline first-line drug at rank 1; **FAIL** means the rank-1 drug belongs to a class that is not guideline-recommended for that disease; refusals are scored separately. All raw outputs, candidate lists and refusal reasons were saved verbatim to machine-readable files (apeiron_novel_disease_results.json and apeiron_novel_disease_transcript.txt) alongside this report, so every number below can be re-derived by re-running the harness."));

/* ---------- 4 Test case design ---------- */
bodyChildren.push(h1("4. Test Case Design"));
bodyChildren.push(body(
  "Tier A contains eight diseases that do not exist in the knowledge base but can be represented faithfully inside the existing channel vocabulary, each with a guideline-established first-line therapy. They were chosen to stress three different generalization mechanisms: a novel combination of known channels (A1, A2, A4), a therapy class that also exists in the KB but for a different disease (A5, A6, A7), and a disease that shares its pathway value with a different KB disease (A3, A8)."));
bodyChildren.push(tableTitle("Table 1. Tier A test set: novel diseases and guideline ground truth"));
bodyChildren.push(makeTable(
  ["ID", "Novel disease (outside the 60)", "Guideline first-line therapy", "Ground-truth source"],
  tierASet, [7, 33, 30, 30]));
bodyChildren.push(body(
  "Tier B contains six diseases that the knowledge base cannot serve: their true therapies are absent from the drug table (biologics, chelators, antifibrotics, non-drug therapy) or their pathophysiology has no representation in the pathway vocabulary (helminth infection, demyelination, fibrosis, iron overload). For three of them a closest-possible in-vocabulary encoding was forced through the engine to observe its behaviour; for the other three the honest answer is documented non-encodability."));
bodyChildren.push(body(
  "Tier C contains adversarial probes: one out-of-vocabulary value, two malformed encodings, two clinically dangerous mis-encodings, and five reverse-path molecule probes (two non-KB molecules, two KB positive controls, one malformed SMILES)."));

/* ---------- 5 Results ---------- */
bodyChildren.push(h1("5. Test Results Summary"));

bodyChildren.push(h2("5.1 Name-level queries: universal refusal"));
bodyChildren.push(body(
  "Four real diseases that are absent from the knowledge base were queried by name through the v14 correspondence CLI: heart failure with preserved ejection fraction, chronic kidney disease with albuminuria, neurocysticercosis, and absence epilepsy. **All four were refused** with the message: UNPROVEN - disease name not in the proved domain D. This is the documented contract working as designed: at name level the engine never predicts, and in particular it cannot be coaxed into guessing a drug for an unknown disease name. Users who want a prediction must supply a six-channel encoding instead, which is where the rest of the test applies."));

bodyChildren.push(h2("5.2 Tier A: eight fair novel diseases"));
bodyChildren.push(body(
  "All eight Tier A encodings were verified as novel (no collision with any of the 60 known encodings) and all eight produced a confident PROVEN_CLASS_THERAPY verdict with exactly one firing mechanism class, so no ambiguity refusals occurred. The engine returned structure-verified candidate sets in every case. The outcomes split 5 PASS to 3 FAIL."));
bodyChildren.push(tableTitle("Table 2. Tier A results (rank-1 prediction versus guideline ground truth)"));
bodyChildren.push(makeTable(
  ["ID", "Fired mechanism class", "Predicted rank-1", "Guideline ground truth", "Outcome"],
  tierAResults, [7, 27, 20, 27, 19]));
bodyChildren.push(body(
  "The five passes are medically sound. For secondary stroke prevention the engine fired the antiplatelet class on the platelet-aggregation pathway and ranked **aspirin first**, exactly the AHA/ASA class-I recommendation. For post-operative VTE prophylaxis it fired the factor-Xa-inhibitor class and ranked **apixaban first**, matching current prophylaxis practice. For NSAID ulcer prophylaxis it returned **omeprazole** with the full PPI class beneath it. For trigeminal neuralgia, under two different etiology encodings, it consistently returned **carbamazepine** as rank-1 of the sodium-channel AED class, with lamotrigine and oxcarbazepine ranked behind it, matching the AAN-EFNS first-line recommendation."));
bodyChildren.push(body(
  "The three failures are instructive. **A3 (HFpEF)** fired the ACE-inhibitor class and ranked ramipril first; current ESC guidance recommends SGLT2 inhibitors (class I) for HFpEF, and ACE inhibitors are not guideline-recommended therapy for this population. The engine can never reach empagliflozin here for two structural reasons detailed in section 6. **A7 (binge-eating disorder)** encoded on the ADHD pathway fired the dopamine-transporter-inhibitor class and ranked methylphenidate first; the licensed therapy, lisdexamfetamine, belongs to a different class (amphetamine releaser) that is not the primary class of the pathway row, although methylphenidate does have off-label evidence in BED. **A8 (vasospastic angina)** shared the stable-angina pathway value and therefore received the beta-blocker class with **bisoprolol first, which is not guideline therapy for vasospastic angina** and may theoretically aggravate spasm; the first-line calcium channel blocker class never fired because the pathway channel dominates the law."));

bodyChildren.push(h2("5.3 Tier B: diseases the knowledge base cannot serve"));
bodyChildren.push(body(
  "For the three Tier B probes where an in-vocabulary encoding was forced, the engine predicted confidently in every case, and every prediction was wrong for the true disease. This is the single most important safety finding of the test."));
bodyChildren.push(tableTitle("Table 3. Tier B probes and outcomes"));
bodyChildren.push(makeTable(
  ["ID", "True disease", "Encoding used", "Engine output", "Assessment"],
  tierBTable, [7, 24, 30, 21, 18]));
bodyChildren.push(body(
  "The remaining three Tier B diseases (haemochromatosis, idiopathic pulmonary fibrosis, pulmonary arterial hypertension) cannot be encoded at all: the pathway vocabulary contains no iron-overload, fibrosis or vascular-remodelling value, and their drugs are absent from the molecule table. For these the system has no interface at all, which is honest but must be understood as a coverage boundary: **absence from the project means either a refusal (name level) or a silent inability to even ask (encoding level)**."));

bodyChildren.push(h2("5.4 Tier C: adversarial probes"));
bodyChildren.push(tableTitle("Table 4. Tier C adversarial probes and outcomes"));
bodyChildren.push(makeTable(
  ["ID", "Probe", "Engine output", "Assessment"],
  tierCTable, [7, 34, 30, 29]));
bodyChildren.push(body(
  "Robustness held: the out-of-vocabulary pathway value, the incomplete encoding and the empty channel were all refused with precise reasons (closed-world A1 and malformed-query guards). The two mis-encoding probes behaved exactly as the mechanism analysis predicts: the engine trusts the encoding. Giant cell arteritis pushed through the rheumatoid-arthritis pathway received methotrexate, which would be a dangerous therapy for an emergency vasculitis; the Takotsubo cardiomyopathy probe received an ACE inhibitor, which is an acceptable class for that condition. The lesson is that soundness is defined relative to the encoding, not relative to the patient."));

bodyChildren.push(h2("5.5 Reverse path: molecules to identity claims"));
bodyChildren.push(tableTitle("Table 5. Reverse-path probes (SMILES to drug identity)"));
bodyChildren.push(makeTable(
  ["ID", "Molecule", "Engine output", "Assessment"],
  reverseTable, [7, 26, 42, 25]));
bodyChildren.push(body(
  "The reverse direction is fully sound in this test: non-KB molecules (paracetamol, caffeine) never received a KB-identity claim, malformed input was refused, and the two KB positive controls (metformin, ibuprofen) were recovered exactly, including their ATC codes and indication rows."));

/* ---------- 6 Root cause ---------- */
bodyChildren.push(h1("6. Defect Analysis and Root Cause"));
bodyChildren.push(body(
  "All three Tier A failures and all wrong Tier B predictions trace back to one structural property of the learned laws. Inspecting the disjuncts of the fired class laws shows that **every mechanism-class law in the system reduces to a single-channel rule on the pathway channel**. The other five channels do not participate in class firing at all."));
bodyChildren.push(tableTitle("Table 6. Disjuncts of the fired class laws (evidence)"));
bodyChildren.push(makeTable(
  ["Class law", "Learned disjunct condition", "Consequence in this test"],
  lawEvidence, [30, 32, 38]));
bodyChildren.push(body(
  "Three consequences explain every observation. **First, the pathway channel carries all therapeutic information.** The CEGIS-style law learner found that pathway alone separates the 60 training diseases perfectly, so generalization to a novel disease reduces to a pathway lookup: share the pathway of a KB disease and you inherit its therapy class, whatever your etiology or site. This yields correct answers wherever the pathway vocabulary is disease-specific (stroke, coagulation, gastric acid, cortical hyperexcitability) and wrong answers wherever one pathway value serves two therapeutically distinct diseases (neurohormonal remodelling serves both HFrEF and HFpEF; myocardial O2 balance serves both stable and vasospastic angina)."));
bodyChildren.push(body(
  "**Second, SGLT2 inhibition is not a proved class in the law set.** SGLT2 inhibitors appear in the KB only as secondary entries of the type-2-diabetes and HFrEF rows, whose primary classes are biguanide and ACE inhibitor; the GenericOracle restricts candidates to the fired class, so empagliflozin is structurally unreachable for any novel-disease query, including HFpEF where it is the modern guideline answer. **Third, the knowledge base is anchored to the guideline era of its sources.** The HFrEF row names ACE inhibitors as cornerstone (ESC 2021 era) and the stable-angina row names a beta-blocker as rank-1; the ESC 2023 SGLT2 update and the CCB-first vasospastic doctrine postdate the encoding, producing guideline drift on exactly the novel diseases that lean on those rows."));
bodyChildren.push(body(
  "A related boundary observation from the shipped C7 battery: the system refuses dabigatran for the existing VTE-treatment disease because that pair is outside its anchored mechanism profile, although dabigatran is an approved VTE drug in practice. This confirms that refusals and predictions are both defined relative to the frozen profile of the knowledge base, not to the whole of medicine; the closed world is honest about this, but consumers of the output must not forget it."));

/* ---------- 7 Risk assessment ---------- */
bodyChildren.push(h1("7. Risk Assessment and Limitations"));
bodyChildren.push(body(
  "The test supports four risk statements, ordered by severity. **R1 (high, misuse-driven):** for any genuinely new disease whose pathway value is chosen by analogy, the engine returns a confident, structure-verified, proof-branded prediction that can be medically wrong (three of eight fair cases; all forced-encoding probes). The proof guarantees are relative to the encoding, so the branding can create false confidence. **R2 (medium):** diseases outside the encoding vocabulary are silently unreachable; the interface refuses names and cannot ask questions about helminthiases, demyelination, fibrosis, iron overload or sleep disorders, so a user may mistake silence for completeness. **R3 (medium):** guideline drift is invisible inside the system; predictions reflect the KB anchor era, and no mechanism warns when external guidance has moved (HFpEF being the clearest case). **R4 (low):** rank order inside a correct class followed guideline preference in every Tier A pass, and refusals for guideline-true non-pairs behaved as documented, so within-profile behaviour shows no defect in this test."));
bodyChildren.push(body(
  "Limitations of this test itself: eight fair novel diseases is a small sample chosen to expose mechanisms rather than estimate a rate; ground truth is guideline first-line therapy, which is one legitimate standard among several; strict rank-1 scoring treats an off-label class neighbour (methylphenidate for binge-eating disorder) as a failure although it has some evidence; and the test exercises the generic path of v12.1 machinery embedded in v14.0, which is the only novel-disease interface the system provides."));

/* ---------- 8 Conclusions ---------- */
bodyChildren.push(h1("8. Test Conclusions and Recommendations"));
bodyChildren.push(body(
  "**Answer to the test question.** The system can produce drug predictions for diseases that are not in the project, but only through their six-channel encodings, and only at mechanism-class level: 5 of 8 fair novel diseases received the guideline-correct rank-1 drug (62.5 percent), with all structural verifications and refusals behaving soundly, and 3 of 8 received a wrong therapy class caused by a pathway-dominated law design and an older guideline anchor. By name the system refuses all unknown diseases; outside the encoding vocabulary it cannot represent a disease at all; and under mis-encoding it predicts confidently rather than refusing. The verdict is a **conditional pass**: sound relative to its encodings, medically reliable only where the pathway vocabulary is disease-specific."));
bodyChildren.push(body(
  "Five recommendations follow for anyone extending or using this engine. **(1) Treat every novel-disease output as a class-level hypothesis** that requires clinical and guideline verification before use; the proof branding must not be read as clinical validation. **(2) Diversify the class-law disjuncts**: require laws to condition on at least two channels (or add etiology-sensitive disjuncts) so that HFrEF and HFpEF, or stable and vasospastic angina, do not collapse into one class. **(3) Promote modern guideline classes to first-class proved rows** (SGLT2 inhibitors for HFpEF and diabetes-adjacent syndromes) so the candidate sets can reach current first-line therapy. **(4) Add an encoding-faithfulness warning** to the CLI output when the supplied pathway is borrowed from a different system or etiology, which would have flagged every dangerous probe in Tier B and Tier C. **(5) Keep this battery as a regression suite**: the harness and its ground truths are machine-readable and re-runnable in under five seconds, making it a cheap guard against future regressions in out-of-domain behaviour."));
bodyChildren.push(body(
  "Reproducibility: extract APEIRON-X_v14_complete.zip, install rdkit, run python3 scripts/apeiron_novel_disease_test.py (about five seconds), and optionally python3 apeiron_correspondence.py --query with any novel disease name (about 75 seconds). All engine files were used unmodified."));

/* ---------- Appendix A ---------- */
bodyChildren.push(h1("Appendix A. Tier A Encodings and Full Candidate Lists"));
bodyChildren.push(body(
  "Each novel disease was encoded as system / etiology / microbe / site / chronicity / pathway. The microbe channel is NONE and chronicity is CHRONIC except where listed. Candidate lists show the structure-verified set returned by the engine; channel-law flags were true for every rank-1 candidate."));
bodyChildren.push(tableTitle("Table A1. Tier A encodings (compact)"));
bodyChildren.push(makeTable(
  ["ID", "Encoding (system / etiology / microbe / site / chronicity / pathway)"],
  [
    ["A1", "CARDIOVASCULAR / VASCULAR_ATHEROTHROMBOTIC / NONE / BRAIN_CORTEX / CHRONIC / PW_PLATELET_AGGREGATION"],
    ["A2", "CARDIOVASCULAR / STRUCTURAL_MECHANICAL / NONE / VENOUS_CIRCULATION / ACUTE / PW_COAGULATION_CASCADE"],
    ["A3", "CARDIOVASCULAR / FUNCTIONAL_DYSREGULATION / NONE / MYOCARDIUM / CHRONIC / PW_NEUROHORMONAL_REMODELING"],
    ["A4", "GASTROINTESTINAL / TOXIC_EXPOSURE / NONE / ESOPHAGUS_STOMACH / CHRONIC / PW_GASTRIC_ACID_SECRETION"],
    ["A5", "NEUROLOGICAL / NEUROELECTRIC / NONE / MENINGEAL_TRIGEMINAL_SYSTEM / CHRONIC / PW_CORTICAL_HYPEREXCITABILITY"],
    ["A6", "NEUROLOGICAL / STRUCTURAL_MECHANICAL / NONE / MENINGEAL_TRIGEMINAL_SYSTEM / CHRONIC / PW_CORTICAL_HYPEREXCITABILITY"],
    ["A7", "PSYCHIATRIC / PSYCHIATRIC / NONE / CNS_MESOLIMBIC_SYSTEM / CHRONIC / PW_NORADRENERGIC_EXECUTIVE_DEFICIT"],
    ["A8", "CARDIOVASCULAR / FUNCTIONAL_DYSREGULATION / NONE / CORONARY_ARTERY / CHRONIC / PW_MYOCARDIAL_O2_BALANCE"],
  ], [8, 92]));
bodyChildren.push(tableTitle("Table A2. Candidate sets returned (top of ranked list)"));
bodyChildren.push(makeTable(
  ["ID", "Candidates in ranked order (tier)"],
  [
    ["A1", "aspirin (tier 1)"],
    ["A2", "apixaban (tier 1), rivaroxaban (tier 2), edoxaban (tier 2)"],
    ["A3", "ramipril (tier 1)"],
    ["A4", "omeprazole (tier 1), esomeprazole (tier 2), pantoprazole (tier 2)"],
    ["A5", "carbamazepine (tier 1), lamotrigine (tier 2), oxcarbazepine (tier 2)"],
    ["A6", "carbamazepine (tier 1), lamotrigine (tier 2), oxcarbazepine (tier 2)"],
    ["A7", "methylphenidate (tier 1)"],
    ["A8", "bisoprolol (tier 1)"],
  ], [8, 92]));

/* ---------- Appendix B ---------- */
bodyChildren.push(h1("Appendix B. Machine Artifacts and Reproducibility"));
bodyChildren.push(body(
  "The following artifacts accompany this report. The JSON file contains every verdict, candidate list, refusal reason and novelty assertion; the transcript contains the complete human-readable output of the battery; the harness contains the exact encodings and scoring logic."));
bodyChildren.push(tableTitle("Table B1. Artifacts"));
bodyChildren.push(makeTable(
  ["File", "Content"],
  [
    ["apeiron_novel_disease_results.json", "Machine-readable results of all 24 probes (tiers A, B, C and reverse path)"],
    ["apeiron_novel_disease_transcript.txt", "Full console transcript of the test battery"],
    ["scripts/apeiron_novel_disease_test.py", "The test harness (encodings, ground truths, scoring rubric)"],
    ["correspondence_out/correspondence_report.txt", "Engine self-report regenerated during the baseline run (all 10 C-theorems proved)"],
  ], [42, 58]));
bodyChildren.push(body(
  "Engine commands used: python3 apeiron_correspondence.py (full battery, baseline integrity check) and the same command with --query for the four name-level probes. The harness runs the generic path in-process without modifying any engine file, so the results are attributable to the delivered system as shipped."));

/* ------------------------------------------------------------------ */
/* Assembly                                                            */
/* ------------------------------------------------------------------ */
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimSun" }, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 32, bold: true, color: P.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: { ascii: "Times New Roman", eastAsia: "SimHei" }, size: 28, bold: true, color: P.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
    },
  },
  sections: [
    /* Section 1: cover, no page number, no footer */
    {
      properties: {
        page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1({
        title: "Novel-Disease Drug Prediction Test",
        subtitle: "Can APEIRON-X predict drugs for diseases outside its 60-disease knowledge base? An independent out-of-domain generalization evaluation.",
        englishLabel: "GENERALIZATION TEST",
        metaLines: [
          "System under test: APEIRON-X v14.0 (complete deliverable bundle)",
          "Method: 24 probes in 3 tiers + name-level and reverse-path probes",
          "Engine integrity: all 10 C-theorems re-proved before testing (exit 0)",
          "Verdict: conditional pass - 5 of 8 fair novel diseases correct at rank 1",
          "Test date: 24 November 2026",
        ],
        footerLeft: "Independent verification report",
        footerRight: "24 November 2026",
        palette: { bg: P.bg, titleColor: P.cover.titleColor, subtitleColor: P.cover.subtitleColor,
                   metaColor: P.cover.metaColor, accent: P.accent, footerColor: P.cover.footerColor },
      }),
    },
    /* Section 2: TOC, roman numerals */
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageNumFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 480, after: 360 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32,
            font: { ascii: "Times New Roman", eastAsia: "SimHei" } })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-2" }),
        new Paragraph({
          spacing: { before: 200 },
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: { ascii: "Times New Roman" } })],
        }),
      ],
    },
    /* Section 3: body, arabic from 1 */
    {
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: runningHeader() },
      footers: { default: pageNumFooter() },
      children: bodyChildren,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON-X_novel_disease_test_report.docx", buf);
  console.log("DOCX written:", buf.length, "bytes");
});
