"""Probe drugAndClinicalCandidates without/with args + row fields (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None, maxlen=1200):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 60, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:250])
            return None
        print(f"{name}: OK {json.dumps(p['data'])[:maxlen]}")
        return p["data"]
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:130]}")
    return None


d = run("cifd_fields", '{__type(name:"ClinicalIndicationFromDisease")'
        '{fields{name type{kind name ofType{kind name ofType{kind name}}}}}}')
if d and d["__type"]:
    for f in d["__type"]["fields"]:
        print("   ", f["name"], "->", json.dumps(f["type"])[:140])

run("dcc_noargs", '''query($efo:String!){
 disease(efoId:$efo){ id name
   drugAndClinicalCandidates{ count }
 } }''', {"efo": "MONDO_0005300"})

run("dcc_rows", '''query($efo:String!){
 disease(efoId:$efo){ drugAndClinicalCandidates{ count rows{
    drug{ id name maximumClinicalStage } } } }
 }''', {"efo": "MONDO_0005300"})
