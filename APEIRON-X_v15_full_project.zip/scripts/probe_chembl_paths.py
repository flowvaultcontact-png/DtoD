"""Probe ChEMBL API path variants (probe)."""
import json
import urllib.request

CANDIDATES = [
    "https://www.ebi.ac.uk/chembl/api/core/molecule/chembl429910.json",
    "https://www.ebi.ac.uk/chembl/api/data/molecule/CHEMBL429910.json",
    "https://www.ebi.ac.uk/chembl/api/core/molecule.json?molecule_chembl_id=CHEMBL429910",
    "https://www.ebi.ac.uk/chembl/api/data/molecule.json?molecule_chembl_id=CHEMBL429910",
    "https://www.ebi.ac.uk/chembl/api/core/molecule/CHEMBL429910.json?format=json",
    "https://www.ebi.ac.uk/chembl/api/core/chembl429910.json",
]

for url in CANDIDATES:
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json",
                                                   "User-Agent": "probe"})
        with urllib.request.urlopen(req, timeout=45) as r:
            head = r.read(400)
        print(f"OK  {url}\n    {head[:250]!r}")
    except Exception as exc:  # noqa: BLE001
        print(f"ERR {url} -> {type(exc).__name__}: {str(exc)[:80]}")
