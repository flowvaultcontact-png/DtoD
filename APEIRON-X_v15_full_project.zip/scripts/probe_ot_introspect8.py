"""List all Disease fields + introspect the indication row type (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 40, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:200])
            return None
        return p["data"]
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:120]}")
        return None


d = run("disefields_all", '{__type(name:"Disease"){fields{name}}}')
if d:
    names = [f["name"] for f in d["__type"]["fields"]]
    print("Disease fields:", ", ".join(names))

# indications rows element type: resolve from clinicalIndicationsFromDrugImp
c = run("clinind_rows", '{__type(name:"clinicalIndicationsFromDrugImp")'
        '{fields{name type{kind name ofType{kind name ofType{kind name '
        'ofType{kind name}}}}}}}')
if c:
    for f in c["__type"]["fields"]:
        print("clinInd.", f["name"], "->", json.dumps(f["type"]))
