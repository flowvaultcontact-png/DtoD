"""Probe clinicalIndicationsFromDiseaseImp (Disease.drugAndClinicalCandidates)
and a real dapagliflozin record (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None, maxlen=2400):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 60, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:250])
            return None
        print(f"{name}: OK {json.dumps(p['data'])[:maxlen]}")
        return p["data"]
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:130]}")
    return None


d = run("cid_fields", '{__type(name:"clinicalIndicationsFromDiseaseImp")'
        '{fields{name type{kind name ofType{kind name ofType{kind name '
        'ofType{kind name}}}}}}}')
if d and d["__type"]:
    for f in d["__type"]["fields"]:
        print("  ", f["name"], "->", json.dumps(f["type"])[:140])

run("cid_row", '{__type(name:"clinicalIndicationFromDisease"){fields{name '
    'type{kind name ofType{kind name}}}}}')

run("ckd_candidates", '''query($efo:String!,$size:Int!){
 disease(efoId:$efo){ id name
   drugAndClinicalCandidates(page:{size:$size,index:0}){ count rows{
     drug{ id name maximumClinicalStage }
   } }
 } }''', {"efo": "MONDO_0005300", "size": 5})

run("dapa_full", '''query($id:String!){
 drug(chemblId:$id){
   id name maximumClinicalStage
   mechanismsOfAction{ rows{ actionType mechanismOfAction targetName
     targets{ id approvedSymbol } } }
   indications{ count rows{ id maxClinicalStage disease{ id name } } }
 }
}''', {"id": "CHEMBL429910"}, maxlen=3200)
