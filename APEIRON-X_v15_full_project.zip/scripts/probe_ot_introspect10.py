"""Introspect ClinicalIndicationFromDrug / MOA row types, defensively."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 40, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:200])
            return None
        return p["data"]
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:120]}")
    return None


def show(t):
    d = run("t_" + t, '{__type(name:"%s"){fields{name '
            'type{kind name ofType{kind name ofType{kind name}}}}}}' % t)
    if not d or not d.get("__type"):
        print(t, "-> type NOT FOUND")
        return
    print(t, "fields:")
    for f in d["__type"]["fields"]:
        print("   ", f["name"], "->", json.dumps(f["type"])[:130])


for t in ("ClinicalIndicationFromDrug", "MechanismOfAction",
          "MechanismOfActionRow", "Mechanism", "ClinicalCandidate"):
    show(t)
