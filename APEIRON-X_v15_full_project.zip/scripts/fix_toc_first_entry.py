#!/usr/bin/env python3
"""Fix the TOC first-entry duplication left by add_toc_placeholders.py.

That tool merges its FIRST placeholder into the field-begin paragraph
(empty nested PAGEREF result -> renders with no page number) and ALSO
inserts a second, static placeholder for the same heading -> the first
TOC line renders twice. This script:
  1. finds the merged paragraph (contains the 'TOC ' instrText),
  2. finds the static TOC paragraph with the SAME visible text,
  3. deletes that static duplicate, reads its page-number text,
  4. inserts that number into the merged paragraph's empty nested
     PAGEREF result.
Result: 11 TOC lines, all numbered, no duplicate. Idempotent."""
import os
import re
import shutil
import sys
import zipfile

W_T = r'<w:t(?:\s[^>]*)?>(.*?)</w:t>'


def visible_text(p):
    return "".join(re.findall(W_T, p, flags=re.S))


def fix(path: str) -> str:
    tmp = path + ".tmpzip"
    shutil.copy(path, tmp)
    with zipfile.ZipFile(tmp) as z:
        xml = z.read("word/document.xml").decode("utf-8")
        names = z.namelist()
        others = {n: z.read(n) for n in names if n != "word/document.xml"}

    paras = []
    chunks = []
    pos = 0
    for m in re.finditer(r'<w:p\b.*?</w:p>', xml, flags=re.S):
        chunks.append(xml[pos:m.start()])
        paras.append((m.group(0), m.start()))
        pos = m.end()
    chunks.append(xml[pos:])

    merged_i = None
    for i, (p, _) in enumerate(paras):
        if re.search(r'<w:instrText[^>]*>\s*TOC\s', p):
            merged_i = i
            break
    if merged_i is None:
        os.remove(tmp)
        return "no TOC field found; nothing to do"

    merged = paras[merged_i][0]
    title = visible_text(merged.split('fldCharType="separate"', 1)[-1])
    title = re.sub(r'\d+$', '', title).strip()

    # locate the static duplicate (TOC style, no fldChar/instrText)
    dup_i, dup_number = None, "1"
    for i, (p, _) in enumerate(paras):
        if i == merged_i:
            continue
        if (re.search(r'w:pStyle w:val="TOC[1-3]"', p)
                and 'fldChar' not in p and 'instrText' not in p):
            t_visible = visible_text(p).strip()
            t_base = re.sub(r'\d+$', '', t_visible).strip()
            if t_base == title:
                nums = re.findall(W_T, p, flags=re.S)
                if nums and nums[-1].strip().isdigit():
                    dup_number = nums[-1].strip()
                dup_i = i
                break

    drop = set()
    note = []
    if dup_i is not None:
        drop.add(dup_i)
        note.append("removed static duplicate")
    # insert the number into the merged paragraph's empty PAGEREF result
    seg = merged.split('fldCharType="separate"', 1)
    if len(seg) == 2:
        head, tail = seg
        gap = '</w:r></w:hyperlink>'
        inject = ('<w:r><w:t xml:space="preserve">%s</w:t></w:r>'
                  % dup_number)
        if re.search(r'PAGEREF[^<]*</w:instrText><w:fldChar '
                     r'w:fldCharType="separate"/><w:fldChar '
                     r'w:fldCharType="end"/>', merged) and \
                f'<w:t xml:space="preserve">{dup_number}</w:t>' \
                not in merged.split('PAGEREF', 1)[-1]:
            new_tail = tail.replace('</w:hyperlink>', inject + '</w:hyperlink>', 1)
            merged = head + 'fldCharType="separate"' + new_tail
            note.append(f"inserted page number {dup_number}")
        paras[merged_i] = (merged, paras[merged_i][1])

    res = [chunks[0]]
    for i, (p, _) in enumerate(paras):
        if i not in drop:
            res.append(p)
        res.append(chunks[i + 1])
    new_xml = "".join(res)

    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for n in names:
            z.writestr(n, new_xml if n == "word/document.xml"
                       else others[n])
    os.remove(tmp)
    return "; ".join(note) if note else "nothing to do"


if __name__ == "__main__":
    for p in sys.argv[1:]:
        print(f"{p}: {fix(p)}")
