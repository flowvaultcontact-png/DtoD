// ---- 1 Executive Summary
B.push(body("This report closes Phase 6 of the APEIRON-X v15 program: the mathematical reasoning extensions (Module E). The phase adds a typed knowledge graph over the frozen corpora, eight new proof obligations, the fingerprint-portability gate and memoized coupling, again without weakening a single v14.1 constraint - all four hash-pinned corpus files kept their sha256, and the acceptance cascade now runs 15 of 15 stages at exit 0. The plan's acceptance clause is met on every item: the new theorems enter the battery (ten checks, all passing, with six negative controls), the exit-0 cascade is retained, and the one engine file that received the audit-planned performance patch carries a theorem proving its results bit-for-bit identical to recomputation."));
B.push(body("Two design decisions define the round. First, the P8 knowledge-graph section is an ADDITIVE frozen artifact - generated verbatim from the frozen inputs by a deterministic script, sha256-pinned with the same refusal-loader discipline as the Phase 2-5 packs - so the v14.1 axiom corpus (postulates_v14.json) is not touched at all; the freeze doctrine of P1-P6 extends to new knowledge without editing frozen history. Second, contradictions are refused at construction: the graph build gate rejects unknown relations, unknown tiers, uncited EVIDENCED edges and layer-order violations with an exception, so a contradictory graph cannot exist as an object of this class - the consistency theorem then verifies the frozen artifact against the same predicates plus a full DFS cycle scan."));

// ---- 2 Scope and doctrine
B.push(h2("Scope and doctrine"));
B.push(body("Module E is the reasoning spine that the discovery modules (B, C, D) will hang their chains on in Phase 8. It formalizes the platform's knowledge as a layered directed graph whose seven edge types run from disease to drug structure to rule-based property, each edge carrying an evidence tier from the five-value v15 claim lattice (PROVEN_MATH > EVIDENCED > COMPUTATIONAL > HYPOTHESIS > UNKNOWN), resolvable source identifiers (48 frozen provenance records) and explicit attributes (association scores with the ASSOCIATION_NOT_CAUSATION marker, action types, rule labels). The v14.1 engines are imported read-only; the derivation modules import no connector code (AST-checked in the battery); the graph loader refuses to serve data on a pin mismatch, exactly as the target and repurposing loaders do. Absent data is reported as absent: 73 lanes that could not be machine-verified are recorded in P8_ABSENCES with named reasons, never guessed."));

// ---- 3 P6-1 graph
B.push(h2("P6-1. The frozen P8 knowledge-graph section"));
B.push(body("The generator reads only frozen inputs - the v14.1 postulate corpus, the structure corpus, the mechanism table, the Phase 3 target table, the Phase 4 repurposing pack and the frozen Phase 3/4 cache payloads - and emits v15/kgraph_data.py verbatim: 1539 edges over 726 nodes on eight canonical layers. Every input file and cache payload is pinned inside the artifact itself (INPUT_PINS with sha256 and the RDKit version), so the graph is self-auditing. Re-running the generator under the original freeze timestamp reproduces the file byte-exactly (sha256 7d93e60415d02f92...), which the reproducibility theorem E8 machine-checks by driving the generator in a subprocess."));
B.push(dataTable([24, 12, 44, 20],
  ["Relation", "Edges", "Source lane (all frozen)", "Tier"],
  [
    ["disease->gene", "18", "Open Targets association rows (verbatim, score kept, marked ASSOCIATION_NOT_CAUSATION) + KB guideline evidence rows with citations", "EVIDENCED"],
    ["gene->protein", "73", "HGNC/UniProt verified identifier pairs (Phase 3 table + frozen resolve payloads, symbol cross-checked)", "EVIDENCED"],
    ["protein->pathway", "130", "Reactome cross-references read from the frozen UniProt entry payloads (pathway names kept)", "EVIDENCED"],
    ["target->mechanism", "63", "targets of the Phase 4 pack drugs realizing a KB mechanism class (action type and MoA string kept)", "EVIDENCED"],
    ["mechanism->drug", "28", "KB mechanism classes to member drugs, including the 12 NON_MOLECULAR excluded classes with their members", "EVIDENCED"],
    ["drug->structure", "207", "KB axiom A6 SMILES (191 molecules) + frozen ChEMBL canonical SMILES (17 pack drugs; one convergent edge: amlodipine KB = CHEMBL1491, sources unioned, conflict recorded)", "EVIDENCED"],
    ["structure->property", "1020", "frozen rule-based descriptor blocks computed under the pinned RDKit at generation time", "COMPUTATIONAL (PREDICTED_RULEBASED)"],
  ]));
B.push(body("Layer populations: 10 disease nodes (the machine-verified benchmark panel; the other 58 corpus diseases have no verified disease->gene rows yet - recorded absences, not guesses), 80 gene nodes, 73 protein nodes, 119 pathway nodes, 21 mechanism-class nodes, 214 drug nodes, 204 structure nodes and 5 property nodes. The provenance completeness pass at generation time resolves every cited source identifier against the record table before the artifact is written; a generation-time unresolved identifier is recorded as an absence instead of shipping silently."));

// ---- 4 P6-2 theorems
B.push(h2("P6-2. The eight new proof obligations"));
B.push(body("Each obligation is a theorem with the standard APEIRON-X shape (statement, proved flag, tier, counterexamples, stats, proof steps), registered in the emitted benchmark certificate and re-checked by the battery. All ten Phase 6 theorems - the eight obligations plus the two plan-item gates E9/E10 - are PROVEN_MATH on the encoded corpus with zero counterexamples."));
B.push(dataTable([8, 34, 58],
  ["#", "Obligation (theorem)", "What is machine-checked"],
  [
    ["E1", "theorem_graph_consistency", "layered DAG over the 7 relations: 0 layer-order violations, 0 duplicate (rel, src, dst) rows, 0 directed cycles in a full DFS scan, all relations present on their canonical layer pairs"],
    ["E2", "theorem_disease_identity_uniqueness", "normalized identity is a function: 69 identities (68 corpus diseases + the CF benchmark disease), unique keys and names, no external MONDO/HP id shared by two canonical keys, idempotent normalization, phi injective on the corpus (68 distinct six-channel tuples), 0 orphan disease nodes in the graph"],
    ["E3", "theorem_contradiction_detection", "opposing pharmacology exposed via the declared opposition lattice (0 pairs present; the injection lane proves 0 false negatives); the non-molecular remainder (8 diseases whose guideline class is structure-layer-exempt, e.g. insulin analogs) verified CONSISTENT - no excluded-class member carries a molecular structure edge"],
    ["E4", "theorem_evidence_provenance_completeness", "every EVIDENCED edge cites at least one source identifier resolving in the frozen record table; every COMPUTATIONAL edge cites the registered rule-based generator record; an uncited EVIDENCED edge cannot pass the build gate (negative control)"],
    ["E5", "theorem_rank_integrity", "rank order invariant under input-row order: 10 diseases x 5 deterministic edge permutations, graph rebuilt per permutation, ranking tables byte-identical (0 disagreements); aggregates labelled COMPUTATIONAL_RANK, never probabilities"],
    ["E6", "theorem_tier_propagation", "chain tier = lattice meet on the ordered 5-tier ladder: laws verified on all 25 pairs and 125 triples; fold equals an independent recomputation on all 233 enumerated chains; no chain propagates a tier stronger than its weakest edge"],
    ["E7", "theorem_out_of_domain_detection", "unknown graph identifiers return explicit absence objects (never invented links); a v15 profile with zero cited channel candidates keeps NOT_ENCODABLE and is refused by the v14.1 normalizer; an out-of-vocabulary candidate value raises instead of being coerced"],
    ["E8", "theorem_bit_for_bit_reproducibility", "two fresh in-memory graph builds serialize to identical hashes; regenerating the P8 artifact under the original freeze timestamp reproduces the pinned file byte-exactly (extends the C1/C8 doctrine to Module E)"],
  ]));

// ---- 5 negative controls
B.push(h2("Theorems that bite: the negative controls"));
B.push(body("A theorem that cannot fail proves nothing, so the battery plants faults and requires detection. Five controls run live: a tampered back-edge (gene->disease, the reversed layer order) is refused by the build gate with a ValueError; a conflicting external identifier (giving D01 the CF disease's MONDO id) makes the identity theorem report the conflict as a counterexample; a synthetic AGONIST row injected against ACE's established inhibitor/antagonist evidence is exposed by the contradiction detector within one scan; a source-less EVIDENCED edge cannot be constructed at all; and downgrading a single edge of a chain to HYPOTHESIS downgrades the propagated chain tier to HYPOTHESIS - the negative direction of the upgrade rule that no computation may strengthen a claim. The pin-discipline control swaps a tampered pin file in, requires the loader to refuse service, and restores the original bytes in a finally block."));

// ---- 6 P6-3
B.push(h2("P6-3. The fingerprint-portability gate (audit R4)"));
B.push(body("Risk R4 recorded that the frozen identity laws embed RDKit fingerprint bit indices, so an unpinned upgrade could silently break the corpus re-certification. The gate closes the risk with theorem E9: the live RDKit version must equal the requirements.txt pin (2026.09.2) and the version recorded in the frozen P8 input pins, and the full phase-5 round-trip must re-certify every proved law on freshly recomputed fingerprints - 191 molecules, zero chi mismatches, zero member violations, zero false positives. A version drift anywhere in that chain fails the theorem and the battery loudly, which is the designed behavior: the environment note from earlier phases repeats here, the sandbox had lost its RDKit install and it was restored from the pin before any verification ran."));

// ---- 7 P6-4
B.push(h2("P6-4. Performance with proofs intact (audit R5)"));
B.push(body("Risk R5 recorded the un-memoized per-pair RDKit parse and featurize work inside the correspondence engine's coupling function. The patch adds a per-instance memo cache keyed by (disease id, structure) - legitimate because the derived disease record is a deterministic function of the disease id over the same frozen postulates - and theorem E10 proves the property that matters: memoized and forced-recomputation sweeps agree exactly on all 12,144 (disease, molecule) pairs of the corpus, zero mismatches cold and zero warm. The measured speedup on the warm lane is about 3400x (33.955 seconds to 0.010 seconds per full sweep), reported honestly as a performance claim, never a proof claim. The effect on the acceptance cascade is visible in the same run: the v14.0 correspondence battery dropped from 78.5 to 46.1 seconds wall time while every C-theorem, including the C1 bit-for-bit re-derivation, still passed."));

// ---- 8 ranking
B.push(h2("The ranking demonstration"));
B.push(body("The typed graph turns frozen evidence into transparent, deterministic ranking tables: a drug is reachable from a disease when a chain disease->gene-(target acts on)->mechanism-(realized by)->drug exists in the frozen edges, and the axes (chain count, contributing genes, strongest association score on the chain, propagated evidence tier) are displayed individually. The aggregate is labelled COMPUTATIONAL_RANK - a rank hint over frozen evidence, never a probability, never a predicted activity. On the type 2 diabetes panel disease D08 the graph recapitulates the guideline mechanism classes from evidence chains alone: dapagliflozin and empagliflozin through SLC5A2 -> SGLT2_INHIBITOR (association score 0.6428 on the chain) and sitagliptin through DPP4 -> DPP4_INHIBITOR; on D05 it recapitulates HMGCR_INHIBITOR (atorvastatin, pravastatin). Equally important are the honest empties: D03, D33, D50, D51 and CF have verified gene lanes (F10, ACHE/APP/MAPT, ABL1, EGFR, CFTR) but their targets carry no mechanism-to-drug rows in the frozen packs, so their drug rankings are EMPTY - absence reported, not fabricated recommendations."));

// ---- 9 cascade
B.push(h2("Verification and cascade"));
B.push(body("The phase-6 battery passes 10 of 10 checks: the P8 pin discipline with the four build-gate refusal lanes; the E1-E4 theorem lanes; the four negative controls; the E5-E7 theorem lanes; the tier-downgrade control; the E8-E10 lanes including the pinned-RDKit gate and the memo sweep; ranking transparency (labels present, D08 recapitulation, unknown disease absent); frozen-file integrity against the baseline sha256 snapshot; AST isolation plus artifact integrity; and the claim-tier language scan. The full cascade runs 15 of 15 stages at exit 0 - the five v14.1 batteries, three demos, the novel-disease harness, the smoke test and the six v15 batteries - and the four hash-pinned v14.1 files keep their baseline sha256."));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/tests/test_v15_phase6.py               # 10/10 checks",
  "python3 v15/write_phase6_artifacts.py              # 10/10 theorems, exit 0",
  "python3 v15/run_full_regression.py                 # 15/15 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));

// ---- 10 honest limits
B.push(h2("Honest limits"));
B.push(body("The knowledge graph is a closed-corpus artifact: its disease/gene lane covers the ten machine-verified panel diseases, and the remaining 58 corpus diseases have no disease->gene edges yet - recorded absences, so chains and rankings simply do not exist for them in this round. The protein->pathway lane exists only for proteins with a frozen UniProt entry payload; proteins resolved but without an entry payload are listed as absences. The structure->property edges are rule-based triage values computed under the pinned RDKit and frozen verbatim - predictions of the rule layer, never measurements. Rankings are evidence-support hints over frozen edges: the SGLT2 chains on D02 and D08 say the evidence chain exists in the frozen corpora, nothing more - they claim no efficacy, no superiority, no clinical validity, and they are not treatment recommendations. The provenance alias records reference the frozen pack tables by name rather than duplicating their full records; the alias discipline is machine-checked for non-emptiness."));

// ---- 11 next steps
B.push(h2("Next steps (Phase 7)"));
B.push(body("Phase 7 turns to the experimental validation intelligence (Module F): per-candidate validation plans with tiered mechanism narratives, target-engagement assay classes, supporting and contradictory evidence with identifiers, model systems, control groups, measurable endpoints, failure mechanisms and stage gates from biochemical to human; external dataset hooks carrying metadata and accession records only; and the report discipline that every EVIDENCED-or-stronger candidate ships with a complete plan stating exactly which evidence would change its status."));

// ---- Appendix
B.push(h1("Appendix A. Reproduce This Round"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 scripts/gen_phase6_pack.py --utc 2026-11-25T06:04:16Z --out /tmp/repro.py",
  "sha256sum /tmp/repro.py v15/kgraph_data.py          # byte-identical",
  "python3 v15/kb_extensions/freeze_kgraph.py          # re-pin after edits",
  "python3 v15/write_phase6_artifacts.py               # benchmark + report files",
  "python3 v15/tests/test_v15_phase6.py                # 10/10 checks",
  "python3 v15/run_full_regression.py                  # 15/15 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));
B.push(body("Artifacts of this round: v15/kgraph_data.py (the frozen P8 knowledge-graph section, 1539 edges, sha256-pinned), v15/kgraph.py (Module E loader, typed graph with the build gate, ten theorems), v15/kb_extensions/freeze_kgraph.py with kgraph_pins.json, scripts/gen_phase6_pack.py (the deterministic generator), the coupling memo patch in apeiron_correspondence.py, v15/write_phase6_artifacts.py with v15/out/phase6_benchmark.json and phase6_benchmark.txt, the phase-6 test battery, the cascade extension to 15 stages, the changelog entry and this report. The change log (docs/CHANGELOG.md, entry v15 Phase 6) lists every file touched with reasons and reproduction commands.", { after: 200 }));
