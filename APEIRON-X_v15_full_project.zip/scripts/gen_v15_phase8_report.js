// APEIRON-X v15 — Phase 8 Full Integration & Benchmarks (deliverable docx)
// Skill-compliant: R1 cover recipe (DS-1), 3-section numbering, TOC field +
// refresh hint, three-line tables, postcheck-ready. Same architecture as the
// Phase 1-7 generators (validated), content replaced.
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, SectionType,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  TableLayoutType, TableOfContents,
} = require("docx");
const fs = require("fs");

// ---------------------------------------------------------------- palette (DS-1 Deep Sea)
const PAL = {
  bg: "0B1C2C", accent: "529286",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "529286", headerText: "FFFFFF", accentLine: "529286", innerLine: "BECFCC", surface: "E8ECEB" },
  primary: "0B1C2C", body: "000000", secondary: "5B6B7D",
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ------------------------------------------------------- title layout (English-aware width)
function textWidthTwips(text, pt) {
  let w = 0;
  for (const ch of text) w += /[\u4e00-\u9fff]/.test(ch) ? pt * 20 : pt * 11;
  return w;
}
function splitTitleLines(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const wd of words) {
    const cand = cur ? cur + " " + wd : wd;
    if (textWidthTwips(cand, pt) <= maxWidthTwips || !cur) cur = cand;
    else { lines.push(cur); cur = wd; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLines(title, maxWidthTwips, titlePt);
    if (lines.length <= 3 && lines.every(l => textWidthTwips(l, titlePt) <= maxWidthTwips)) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(p) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = p;
  const SAFETY = 1200;
  const usable = pageHeight - marginTop - marginBottom - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (12 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (10 * 23 + 100);
  const implicit = 3 * 300;
  const content = titleH + subH + engH + metaH + fixedHeight + implicit;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(remaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ------------------------------------------------------------------ cover recipe R1
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.cover.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.cover.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.cover.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        ", size: 16, color: P.cover.footerColor }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders, children,
      })],
    })],
  })];
}

// ------------------------------------------------------------------ body helpers
const F = { ascii: "Times New Roman", eastAsia: "SimSun" };
const FH = { ascii: "Times New Roman", eastAsia: "SimHei" };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: PAL.primary, font: FH })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: PAL.primary, font: FH })],
  });
}
function body(text, opts = {}) {
  const runs = Array.isArray(text) ? text : [new TextRun({ text, size: 24, color: PAL.body, font: F })];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: opts.after !== undefined ? opts.after : 120 },
    children: runs,
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      spacing: { line: 312 },
      children: [new TextRun({ text, size: opts.header ? 21 : 20,
        bold: !!opts.header, color: opts.header ? PAL.table.headerText : PAL.body,
        font: opts.header ? FH : F })],
    })],
    shading: opts.header ? { type: ShadingType.CLEAR, fill: PAL.table.headerBg }
      : (opts.zebra ? { type: ShadingType.CLEAR, fill: PAL.table.surface } : undefined),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
  });
}
function dataTable(widths, header, rows, zebra = true) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: header.map((t, i) => cell(t, { header: true, width: widths[i] })),
      }),
      ...rows.map((r, ri) => new TableRow({
        cantSplit: true,
        children: r.map((t, i) => cell(t, { width: widths[i], zebra: zebra && ri % 2 === 1 })),
      })),
    ],
  });
}
function codeBlock(lines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      left: { style: BorderStyle.SINGLE, size: 12, color: PAL.table.accentLine },
      right: NB, insideHorizontal: NB, insideVertical: NB,
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: "F4F7F6" },
        margins: { top: 120, bottom: 120, left: 200, right: 160 },
        children: lines.map(l => new Paragraph({
          spacing: { line: 312, after: 20 },
          children: [new TextRun({ text: l, size: 18, color: "24313B", font: { ascii: "Courier New", eastAsia: "SimSun" } })],
        })),
      })],
    })],
  });
}

// ------------------------------------------------------------------ footers/headers
function pageFooter() {
  return new Footer({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: F })],
  })] });
}
function bodyHeader() {
  return new Header({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine, space: 4 } },
    children: [new TextRun({ text: "APEIRON-X v15 Phase 8 Report", size: 18, color: "808080", font: F })],
  })] });
}

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

// ================================================================== BODY CONTENT
const B = [];

B.push(body("This report closes Phase 8 of the APEIRON-X v15 program - and with it the whole eight-phase plan: full integration. The round ships the end-to-end discover pipeline that runs the master prompt's twelve-step workflow over the v14.1 proof engine (read-only) and the v15 modules A-F, emitting a versioned eighteen-section structured discovery report; a versioned read-only REST API with a static research dashboard; the phase-8 test battery with temporal validation, negative controls and leakage checks; and the honest-limitation report generator. Nothing existing was weakened: the four hash-pinned corpus files kept their sha256, the claim-tier ladder and the absence doctrine carried through every new surface, and the acceptance cascade now runs 18 of 18 stages at exit 0. The plan's acceptance clause is met on all four items (P8-1 through P8-4), with 6 of 6 report theorems PROVEN_MATH and 19 of 19 battery checks passing."));

B.push(body("One design decision defines the round: integration without invention. The discover pipeline serves frozen, pin-checked content only - it adds no new biological claim of its own. A report for heart failure shows guideline first-line drugs (EVIDENCED, cited from the KB row), repurposing candidates with their Theta_d structure-law bridge findings (exposed, including conflicts), the P8 graph neighborhood, target hypotheses for panel diseases, the frozen Phase 5 molecules as class-pharmacophore candidates, and the Module F validation plans - and for a disease outside every lane it emits the honest empty world: nine explicit absence records, a NOT_ENCODABLE verdict, and nothing fabricated. Every fused ranking row is labelled COMPUTATIONAL_RANK, every absence carries its four fields, and two builds of the same input are byte-identical by theorem."));

// ---- 2 pipeline architecture
B.push(h2("P8-1. The twelve-step workflow, assembled"));
B.push(body("The pipeline (v15/discover.py, schema 15.8.0) chains twelve declared steps. Input normalization resolves a disease by did, exact case-insensitive name, or a cited six-channel encoding - exact matches only, no substring guessing; a genetic-profile supplement is allowed alongside the name. Module A builds the profile (a KB row round-trips with the row itself as citation; an out-of-domain input builds a fields-only profile). The six-channel identity step records the phi and the corpus injectivity context. The P8 graph neighborhood lists the disease-gene edges with their tiers and association scores and runs the graph's own transparent drug ranking. Module B ranks intervention points, the KB supplies the guideline first-line drugs with their verbatim (tier, priority, safety-penalty) tuples, Module C generates repurposing candidates with statuses and bridge findings, the frozen Phase 5 artifact supplies the generated molecules, the ADMET screen attaches the rule-layer descriptors with the empty-ML-registry statement, and the fusion step merges all lanes into one transparent table. Consistency checks re-validate the KB, re-run the injectivity report, confirm the graph build gate and scan the report text for forbidden claim tokens. Finally Module F attaches the validation plans and the report is assembled with its provenance ledger, honest limits and reproducibility block."));
B.push(dataTable([6, 34, 60],
  ["#", "Workflow step", "Served by / guarantee"],
  [
    ["1", "normalize input", "exact resolution only; every miss is a 4-field absence record (code, subject, reason, lane)"],
    ["2", "build disease profile", "Module A: KB round-trip for in-domain rows; fields-only profile for OOD inputs; uncited phi raises"],
    ["3", "resolve six-channel identity", "phi + injectivity context on the 68-disease corpus; NOT_ENCODABLE(v15) verdict when channels are not derivable"],
    ["4", "resolve graph neighborhood", "frozen P8 graph (1539 edges, build-gated): disease-gene edges + transparent drug ranking, or an explicit absence"],
    ["5", "rank intervention points", "Module B transparent axes (genetic, functional, tractability, safety, completeness); aggregate labelled COMPUTATIONAL_RANK"],
    ["6", "approved + investigational drugs", "v14.1 KB guideline rows carried verbatim; enriched from the P4 pack where covered; approval-year UNKNOWN recorded, never guessed"],
    ["7", "repurposing hypotheses", "Module C pre-ascertainment engine; statuses, channel support and Theta_d bridge findings; MECH_STRUCTURE_CONFLICT exposed, never dropped"],
    ["8", "novel candidate molecules", "frozen Phase 5 artifact (100 emitted structures, sha256 travels in the report); class-pharmacophore compatibility only"],
    ["9", "ADMET / toxicity screen", "rule-layer descriptors PREDICTED_RULEBASED; ADMET ML registry ships EMPTY; PREDICTED_ML requests refused; no docking claim"],
    ["10", "evidence-weighted ranking", "fusion over lanes: tier = strongest lane evidence (JOIN), best lane rank, name; every lane value displayed on the row"],
    ["11", "APEIRON-X consistency checks", "KB self-validation, phi injectivity, graph build gate, forbidden-language scan - all pass or the report says failed_loudly"],
    ["12", "attach validation plans", "Module F plans for prediction-panel diseases (top-3 ranked candidates); explicit absence elsewhere; APXD structural-absence lane noted"],
  ]));

// ---- 3 the 18-section report
B.push(h2("The eighteen-section report"));
B.push(body("The report is a versioned JSON document (REPORT_SECTIONS, schema 15.8.0) whose canonical sha256 is recorded in its own header and equals sha256_of_report - a self-verifying artifact. There are no wall-clock fields anywhere: the header records the schema and program versions and the as_of year, and two builds of the same input are byte-identical (theorem R2). The sections group into identity (header, claim-tier legend, input record, profile, encodability verdict, KB identity), evidence lanes (graph neighborhood, ranked targets, approved drugs, repurposing candidates, novel molecules, ADMET screen, fused ranking), assurance (consistency checks, validation plans), and accountability (provenance ledger, honest limits, reproducibility and non-goals). Every section carries a tier from the four-rung ladder, and the S18 block carries the twelve workflow steps with their per-step status and absence lists."));
B.push(dataTable([24, 30, 46],
  ["Section group", "Sections", "Accountability mechanism"],
  [
    ["Identity (S01-S06)", "header, tier legend, input record, profile, verdict, KB identity", "canonical sha256 in header; encodability verdict with reasons; cited phi or explicit NOT_ENCODABLE"],
    ["Evidence lanes (S07-S13)", "graph, targets, approved drugs, repurposing, molecules, ADMET, fused ranking", "per-row tier + sources; absences with lane names; COMPUTATIONAL_RANK labels; bridge conflicts exposed"],
    ["Assurance (S14-S15)", "consistency checks, validation plans", "live re-validation results; Module F plans with honest gate states and required-evidence-to-change-status"],
    ["Accountability (S16-S18)", "provenance ledger, honest limits, reproducibility + non-goals", "every cited source id resolved against a frozen ledger; per-lane coverage limits; the four non-goals restated"],
  ]));

// ---- 4 resolution discipline + OOD
B.push(h2("Resolution discipline: the honest empty world"));
B.push(body("The battery proves the negative path as thoroughly as the positive one. A ghost did returns the explicit absence DID_NOT_IN_FROZEN_KB and no row; a ghost name behaves the same; a six-channel phi without citations raises (an encoding must be cited guideline or mechanism evidence - the Tier-B refusal carries into v15); multi-selector and unknown-key specs are refused. The out-of-domain probe - a submitted Z-syndrome with a genetic profile - produces a report with the NOT_ENCODABLE verdict, HYPOTHESIS tiers, and nine explicit absences across the graph, target, drug, repurposing, molecule, ADMET, ranking and plan lanes; every absence carries exactly the four declared fields (theorem R3 counts 24 absence records across the seven probe reports, all conforming). The v14.1 doctrine that a novel disease is never silently guessed at extends here to the whole v15 stack: outside the frozen lanes, the pipeline's answer is the named absence, not an extrapolation - recreating the single-rule pathway collapse that the v14.1 fix removed is the specific defect this discipline refuses to repeat."));

// ---- 5 temporal + leakage
B.push(h2("The temporal lane and the leakage controls"));
B.push(body("The as_of parameter reuses the Phase 4 hermeticity machinery: a pre-2015 view of heart failure prunes the repurposing engine's candidate space exactly as the temporal benchmark does, marks drugs whose pack first-approval year is at or after the split as post-split knowledge, and excludes them from every ranked lane. Drugs outside the pack have no approval year here - they are recorded UNKNOWN with an absence note, never guessed. Theorem R4 machine-checks three leakage lanes across all probes: no APPROVED_INDICATION repurposing row carries a first-approval year at or after the as_of year; no post-split-excluded drug appears in the fused ranking; and no APXD-* generated molecule masquerades in the approved or repurposing lanes. The temporal lane is live, not decorative: the as-of-2015 report's canonical sha256 differs from the current report's, proving the view actually changes content."));

// ---- 6 theorems
B.push(h2("The six report theorems (all PROVEN_MATH)"));
B.push(dataTable([6, 38, 56],
  ["#", "Obligation (theorem)", "What is machine-checked"],
  [
    ["R1", "theorem_report_schema_completeness", "all 7 probe reports carry exactly the 18 declared sections and the 12 declared workflow steps; any missing or extra section is a counterexample"],
    ["R2", "theorem_report_determinism", "each probe built twice yields byte-identical canonical sha256 (no wall-clock, no nondeterministic iteration order); the header sha equals sha256_of_report"],
    ["R3", "theorem_report_absence_discipline", "24 absence records across the probes all carry the four declared fields; no absence is null or free-form"],
    ["R4", "theorem_report_leakage_control", "no post-split knowledge in an as_of view (status rows, ranked names); APXD-* never in approved/repurposing lanes"],
    ["R5", "theorem_report_claim_tier_discipline", "558 candidate rows across the probes all carry a tier from the ladder; fusion rows all labelled COMPUTATIONAL_RANK; the forbidden-language scan is clean in every report"],
    ["R6", "theorem_report_out_of_domain", "the OOD probes (Z-syndrome, CF as a non-KB panel disease) yield the honest empty world: no targets, no repurposing rows, no plans, no graph neighborhood - only explicit absences"],
  ]));

// ---- 7 API + dashboard
B.push(h2("P8-2. The versioned read-only API and the dashboard"));
B.push(body("The API (v15/api.py) serves eleven route families under /api/v1/ on the standard library's HTTP server: health, schemas, the disease index, per-disease profile, targets, repurposing (with an as_of query), the full discover report (memoized - the payload is deterministic, so the memo is a cache, never a source), molecules from the frozen Phase 5 store with its sha256, the Module F plan universe, a theorem inventory collected from the live modules by introspection, and the honest-limitation report. Read-only is enforced at the protocol level: every mutation verb answers 405 READ_ONLY_API; unknown routes, unknown API versions and unknown diseases answer explicit 404 error objects with the route table attached. Hermeticity is AST-gated: api.py imports no outbound-network machinery and no connector code, and the live-server check binds 127.0.0.1 on an ephemeral port only - GET 200 with the read-only and version headers, POST 405 over the wire. The research dashboard (v15/dashboard.py) renders the same facades as a static, self-contained HTML page: inline CSS, zero JavaScript, zero external assets, deterministic content - program KPIs, the target panel, the repurposing panel with bridge-conflict flags, the plan gate table, a worked fusion example, the condensed honest limitations and the non-goals."));
B.push(dataTable([32, 12, 56],
  ["Route (/api/v1/)", "Answer", "Payload"],
  [
    ["health, schemas", "200", "program status; schema versions of every served module (discover 15.8.0, Module B/C/F packs, molecule records, API envelope)"],
    ["diseases, diseases/<did>", "200", "68-disease pinned index; per-disease phi, ontology ids, guideline, KB drugs"],
    ["diseases/<did>/targets", "200/404", "Module B top-10 with transparent axes; explicit 404 outside the 10-disease panel"],
    ["diseases/<did>/repurposing", "200/404", "Module C rows with statuses + bridge findings (?as_of= supported); explicit 404 outside the prediction panel"],
    ["diseases/<did>/discover", "200", "the full 18-section report, memoized and byte-identical across calls"],
    ["molecules, validation-plans", "200", "frozen Phase 5 candidates (sha256 recorded); 20 Module F plans with honest gate states"],
    ["theorems, limits", "200", "theorem inventory (runtime introspection + v14.1 battery labels); the P8-4 honest-limitation report"],
    ["anything else / mutations", "404/405", "NO_SUCH_ROUTE or UNKNOWN_API_VERSION with the route list; READ_ONLY_API for POST/PUT/DELETE/PATCH"],
  ]));

// ---- 8 P8-3 battery + cascade
B.push(h2("P8-3. The battery and the cascade"));
B.push(body("The phase-8 battery passes 19 of 19 checks: the six report theorems over the seven probe reports (D02, type-2 diabetes by name, HFpEF by name, D05 hypercholesterolemia, CF as the non-KB panel disease, D02 as-of-2015, and the OOD Z-syndrome); temporal validation (no APPROVED_INDICATION row with first approval at or after 2015, post-split drugs never ranked, the as-of sha differs); APXD leakage; per-report consistency checks; the negative controls; API read-only and routing lanes including explicit 404s; the live ephemeral-port round trip; the AST hermeticity gate; module test-suite coverage (all eleven v15 modules are named in some battery, and the per-phase batteries exist for all eight phases); the cascade wiring; the limitation-report checks; the dashboard checks; artifact integrity; frozen-file integrity against the baseline sha256 snapshot; and the claim-tier language scan. The cascade grows from 16 to 18 stages - the artifacts writer and the battery join as their own stages - and runs 18 of 18 at exit 0 with all four hash-pinned v14.1 files unchanged."));
B.push(codeBlock([
  "phase-8 battery   : 19/19 checks passed",
  "report theorems   : R1-R6, all PROVEN_MATH, 0 counterexamples",
  "probes            : 7 reports (5 in-domain lanes + 2 out-of-domain), 24 absences, all 4-field",
  "api self-test     : 19 dispatcher checks (14 GET lanes incl. explicit 404s, 4 mutation refusals, memo determinism)",
  "dashboard         : static HTML, zero JavaScript, deterministic",
  "limitation report : achievements artifact-backed + 5 known-gap lanes + 4 non-goals",
  "cascade           : 18/18 stages exit 0 (grew from 16)",
  "frozen v14.1 files: sha256 unchanged (baseline snapshot verified)",
]));

// ---- 9 P8-4
B.push(h2("P8-4. The honest-limitation generator"));
B.push(body("The generator (v15/limitation_report.py) emits one versioned document that pairs achievements with gaps, per lane. Achievements are backed by frozen artifact values - the Module B benchmark macro recall, the Module C temporal benchmark recall, the Phase 5 round-trip and candidate counts, the Module E theorem count and graph size, the Module F plan and registry counts - each read from the corresponding frozen artifact at build time. Known gaps are collected per lane with their reasons: licences for DrugBank and BindingDB were not obtained, so interaction content from those resources is cited by absence, never by content; every connector serves frozen cache payloads only; the ADMET model registry ships EMPTY and PREDICTED_ML requests are refused; no docking run record exists in any round; Modules B, C and E cover their panels only; generated molecules are class-pharmacophore candidates and carry no disease-linked activity statement; solubility, permeability and synthetic-accessibility values are rule-layer estimates. The document restates the four non-goals and the absence doctrine, and it is served at /api/v1/limits and embedded in the dashboard - the first surface a reviewer sees is the same one that names the limits."));

// ---- 10 worked example
B.push(h2("Worked example: heart failure with reduced ejection fraction"));
B.push(body("The D02 report shows the integration working end to end. The identity block resolves D02 with the KB row as its own citation and the corpus injectivity context. The graph neighborhood lists the disease-gene edges (ACE, AGTR1 and the SLC5A2 axis among them) with tiers and sources. Module B ranks SLC5A2 and ACE as intervention points with their transparent axes. The approved-drugs lane carries the ESC 2021 guideline row verbatim - ramipril and bisoprolol at tier 1, dapagliflozin and spironolactone at tier 2 with their safety penalties - enriched from the Phase 4 pack where covered. The repurposing lane ranks eighteen pre-ascertainment candidates with their channel support, statuses and bridge findings, including the exposed MECH_STRUCTURE_CONFLICT on losartan. Module F attaches three plans for the top-ranked candidates. The fusion merges four lanes into twenty ranked rows: ramipril first (guideline lane, EVIDENCED), dapagliflozin third carrying three lanes (repurposing, graph, guideline) with fusion tier EVIDENCED, intervention points and graph-only drugs below with COMPUTATIONAL tiers - every lane value visible on its row, every row labelled COMPUTATIONAL_RANK."));
B.push(dataTable([10, 24, 26, 40],
  ["Rank", "Candidate", "Fusion tier", "Contributing lanes"],
  [
    ["1", "ramipril", "EVIDENCED", "kb_guideline_first_line"],
    ["2", "bisoprolol", "EVIDENCED", "kb_guideline_first_line"],
    ["3", "dapagliflozin", "EVIDENCED", "module_C_repurposing + module_E_graph + kb_guideline_first_line"],
    ["4", "SLC5A2 (intervention point)", "COMPUTATIONAL", "module_B_targets"],
    ["5", "spironolactone", "COMPUTATIONAL", "module_C_repurposing + kb_guideline_first_line"],
    ["6", "ACE (intervention point)", "COMPUTATIONAL", "module_B_targets"],
    ["7", "lisinopril", "COMPUTATIONAL", "module_C_repurposing + module_E_graph"],
  ]));
B.push(body("The as-of-2015 view of the same disease demonstrates the temporal discipline: the candidate space is the pre-2015 view, post-split knowledge is excluded by theorem, and the report's canonical sha256 differs from the current-era report - two different, internally consistent views of the same frozen world. The OOD contrast completes the picture: the Z-syndrome probe emits zero ranked rows and nine named absences, which is exactly what an honest engine owes a disease it knows nothing about."));

// ---- 11 verification
B.push(h2("Verification and program status"));
B.push(body("Every number in this report is reproducible from the repository in the appendix commands. The changelog entry (docs/CHANGELOG.md, v15 Phase 8) lists every file touched with reasons; the implementation plan's round table now marks all eight phases DONE. With Phase 8, the v15 program is complete as planned: Module A knowledge expansion, Module B target discovery, Module C repurposing, Module D novel molecules, Module E mathematical reasoning, Module F validation intelligence, and the integration layer that serves them all through one deterministic pipeline, one read-only API and one honest account of what the platform does not know. What remains is program maintenance, not construction: re-running the documented refresh scripts when newer external data is wanted (with the documented re-freeze and re-pin), and the explicitly out-of-scope items the limitation report names - obtaining the DrugBank and BindingDB licences, training validated ADMET ML models, and docking runs."));
B.push(h2("Honest limits"));
B.push(body("The discover pipeline serves frozen module content only: the novel-molecule lane is the frozen Phase 5 artifact (its sha256 travels in every report), not a live generation run, and lane coverage is exactly the frozen coverage - targets for the ten-disease panel, repurposing for the cardio-renal prediction panel, plans for the panel diseases and the APXD molecules; everything else is an explicit absence. The API adds no new claims; it serves the frozen knowledge and the deterministic pipeline, refuses mutations at the protocol level, and binds no external network. The fusion tier is the strongest lane evidence and every fused row is labelled COMPUTATIONAL_RANK - a rank hint, never a probability and never a predicted efficacy. The temporal lane prunes by the Phase 4 pack approval years where coverage exists; drugs outside the pack are recorded approval-year UNKNOWN, never guessed. And the R9 assessment is on the record: the v14.1 demos carry no hardcoded expectation constants to move (they are proof printers), the regression runner is data-driven, and the runner design already satisfied the staged-timeout, harness-path and subprocess-isolation items (R7, R8, R12)."));

// ---- Appendix
B.push(h1("Appendix A. Reproduce This Round"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/discover.py --disease D02                # worked example",
  "python3 v15/discover.py --disease D02 --as-of 2015   # temporal lane",
  "python3 v15/discover.py --json-spec '{\"name\":\"Z-syndrome\",\"genetic_profile\":[\"ZZZ1 GOF\"]}'",
  "python3 v15/api.py --routes                          # route table",
  "python3 v15/api.py --port 8765                       # read-only API",
  "python3 v15/dashboard.py                             # static dashboard",
  "python3 v15/limitation_report.py                     # honest-limitation report",
  "python3 v15/write_phase8_artifacts.py                # 6/6 theorems",
  "python3 v15/tests/test_v15_phase8.py                 # 19/19 checks",
  "python3 v15/run_full_regression.py                   # 18/18 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));
B.push(body("Artifacts of this round: v15/discover.py (the P8-1 pipeline and the six report theorems), v15/api.py (the versioned read-only API), v15/dashboard.py (the static research dashboard), v15/limitation_report.py (the P8-4 generator), v15/tests/test_v15_phase8.py (the 19-check battery), v15/write_phase8_artifacts.py with v15/out/phase8_benchmark.json, phase8_benchmark.txt and dashboard.html, the cascade extension to 18 stages, the regression evidence at docs/baseline/v15_phase8_regression.log, the changelog entry and this report. The change log (docs/CHANGELOG.md, entry v15 Phase 8) lists every file touched with reasons and reproduction commands.", { after: 200 }));
// ================================================================== DOCUMENT
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: F, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FH, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FH, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FH, size: 24, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 200, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: cover
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: buildCoverR1({
        title: "APEIRON-X v15 Full Integration",
        subtitle: "Phase 8: the twelve-step discover pipeline emitting the eighteen-section report, the versioned read-only API and dashboard, the phase-8 battery, and the honest-limitation generator",
        englishLabel: "APEIRON-X V15 PROGRAM",
        metaLines: [
          "Round: v15 Phase 8 (P8-1 pipeline, P8-2 API + dashboard, P8-3 battery, P8-4 limits)",
          "Evidence: 7 probe reports, 24 four-field absences, 11 API routes, 18-section schema 15.8.0",
          "Benchmark: 6/6 report theorems PROVEN_MATH; 19/19 battery checks",
          "Gate: full cascade 18/18 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],
        footerLeft: "APEIRON-X Computational Drug-Discovery Platform",
        footerRight: "v15 Phase 8 Report",
        palette: PAL,
      }),
    },
    { // Section 2: front matter (TOC) — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 240, after: 160 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FH, color: PAL.primary })],
        }),
        new Paragraph({
          spacing: { after: 80 },
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: F })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
      ],
    },
    { // Section 3: body — Arabic, restart at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: bodyHeader() },
      footers: { default: pageFooter() },
      children: B,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON-X_v15_Phase8_Integration.docx", buf);
  console.log("written: APEIRON-X_v15_Phase8_Integration.docx");
});
