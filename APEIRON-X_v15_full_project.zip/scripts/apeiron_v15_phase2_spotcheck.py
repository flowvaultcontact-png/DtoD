#!/usr/bin/env python3
"""Phase 2 acceptance spot-check: query the five newly merged diseases
(D64-D68) through the live v14.1 oracle, plus one NOVEL out-of-corpus
variant probe, and print verdicts. Read-only; writes nothing."""
import json
import os
import sys

ROOT = "/home/z/my-project/apeiron"
sys.path.insert(0, ROOT)

import disease_drug_kb as KB                          # noqa: E402
import apeiron_drug_discovery_proof as ENGINE         # noqa: E402

oracle = ENGINE.DrugOracle(KB.DISEASES)
oracle.learn()

results = []
for did in ("D64", "D65", "D66", "D67", "D68"):
    row = next(r for r in KB.DISEASES if r["did"] == did)
    res = oracle.query({c: row[c] for c in KB.CHANNELS})
    results.append({"did": did, "disease": row["name"],
                    "verdict": res["verdict"],
                    "class": res.get("mechanism_class", res.get("class", "")),
                    "first_line": res.get("first_line", "")})
    print(f"{did} {row['name'][:46]:<46} -> {res['verdict']:<14} "
          f"class={res.get('mechanism_class', res.get('class', '-')):<32} "
          f"rank-1={res.get('first_line', '-')}")

# novel variant: impetigo-like tuple, CHRONIC (not in corpus) — must fire
# a class law by 2-channel anchoring or refuse soundly (never inherit a
# wrong therapy class through a single shared channel)
probe = dict(system="DERMATOLOGIC", etiology="BACTERIAL",
             microbe="GRAM_POS_COCCI", site="SKIN_SOFT_TISSUE",
             chronicity="CHRONIC", pathway="PW_IMPETIGO_EPIDERMAL_INFECTION")
in_corpus = any(all(r[c] == probe[c] for c in KB.CHANNELS)
                for r in KB.DISEASES)
res = oracle.query(probe)
print(f"\nnovel variant probe (in_corpus={in_corpus}) -> {res['verdict']} "
      f"class={res.get('mechanism_class', res.get('class', '-'))} "
      f"rank-1={res.get('first_line', '-')}")
results.append({"did": "PROBE-D64-CHRONIC", "verdict": res["verdict"],
                "class": res.get("mechanism_class", res.get("class", "")),
                "first_line": res.get("first_line", "")})

out = "/home/z/my-project/download/apeiron_v15_phase2_spotcheck.json"
with open(out, "w", encoding="utf-8") as fh:
    json.dump({"monomials": None, "queries": results}, fh, indent=1)
print(f"\nwritten: {out}")
