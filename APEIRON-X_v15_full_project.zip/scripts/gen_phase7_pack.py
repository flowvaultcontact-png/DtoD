#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 7 frozen-pack generator (P7-2).

Reads the machine-verified values (v15/out/phase7_verified_values.json,
authored VERBATIM by refresh_phase7_cache.py --live) and emits:

    v15/validation_data.py                     — the frozen dataset
                                               registry (pure data)
    v15/kb_extensions/validation_pins.json     — its sha256 pin

Derivation in this generator is purely MECHANICAL over the verified
values: dedup by accession, deterministic token filters for the
candidate/disease dataset links, sorted keys, verbatim provenance. No
scientific content is authored here — the filters themselves are
recorded inside each link row so every link is auditable.

Usage:
    python3 scripts/gen_phase7_pack.py
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(os.path.dirname(HERE), "apeiron")   # apeiron/ repo root
sys.path.insert(0, ROOT)

VALUES_PATH = os.path.join(ROOT, "v15", "out", "phase7_verified_values.json")
MANIFEST_PATH = os.path.join(ROOT, "v15", "cache", "manifest.json")
OUT_PATH = os.path.join(ROOT, "v15", "validation_data.py")
PIN_PATH = os.path.join(ROOT, "v15", "kb_extensions",
                        "validation_pins.json")

PACK_SCHEMA_VERSION = "15.7.0"

# ------------------------------------------------------------------
# Deterministic token filters (recorded verbatim in the link rows)
# ------------------------------------------------------------------
# Panel-disease context tokens + their specificity class. HFREF/HFPEF
# share "heart failure": registry metadata alone cannot separate EF
# strata (eligibility criteria are not part of the whitelisted fields),
# so links for these two are CONDITION_LEVEL_ONLY and must never be
# presented as stratum-specific evidence.
DISEASE_TOKENS = {
    "CKD":   {"tokens": ["chronic kidney"],
              "specificity": "EXACT_DISEASE_CONTEXT"},
    "DKD":   {"tokens": ["diabetic kidney", "diabetic nephropathy"],
              "specificity": "EXACT_DISEASE_CONTEXT"},
    "HFREF": {"tokens": ["heart failure"],
              "specificity": "CONDITION_LEVEL_ONLY"},
    "HFPEF": {"tokens": ["heart failure"],
              "specificity": "CONDITION_LEVEL_ONLY"},
    "T2DM":  {"tokens": ["type 2 diabetes"],
              "specificity": "EXACT_DISEASE_CONTEXT"},
}

# The 10 queried drugs (deterministic panel; drug token = the name,
# matched case-insensitively inside intervention names / study title).
CT_DRUG_PANEL = [
    "dapagliflozin", "empagliflozin", "canagliflozin", "lisinopril",
    "losartan", "spironolactone", "metformin", "finerenone",
]

# GEO disease-context mapping (term level, recorded transparently):
# a query whose TERM names the disease context maps to that panel key.
GEO_DISEASE_LINK_RULES = {
    "GE01": {"term": "dapagliflozin kidney",
             "disease_keys": ["CKD"],
             "rationale": "term names the kidney context; dapagliflozin "
                          "is the queried intervention"},
    "GE02": {"term": "empagliflozin heart",
             "disease_keys": ["HFREF", "HFPEF"],
             "rationale": "term names the heart context; stratum not "
                          "resolvable from term -> CONDITION_LEVEL_ONLY"},
    "GE02_SPEC": "CONDITION_LEVEL_ONLY",
    "GE03": {"term": "SGLT2 inhibitor diabetic nephropathy",
             "disease_keys": ["DKD"],
             "rationale": "term names diabetic nephropathy (= DKD "
                          "synonym) and the SGLT2 mechanism class"},
    "GE04": {"term": "diabetic kidney disease glomerulus transcriptome",
             "disease_keys": ["DKD", "CKD"],
             "rationale": "term names the diabetic-kidney / kidney "
                          "transcriptome context"},
    "GE04_SPEC": "EXACT_DISEASE_CONTEXT",
    "GE05": {"term": "heart failure myocardium RNA",
             "disease_keys": ["HFREF", "HFPEF"],
             "rationale": "term names the heart-failure myocardium "
                          "context; stratum not resolvable from term"},
    "GE05_SPEC": "CONDITION_LEVEL_ONLY",
}

GEO_SPEC_DEFAULT = "DISEASE_CONTEXT_ONLY"

# Records absences that are STRUCTURAL (not fetch failures).
STRUCTURAL_ABSENCES = [
    {"absence_id": "ABS:APXD_NO_REGISTRY_RECORD",
     "lane": "both",
     "scope": "all Phase 5 generated molecules (APXD-*)",
     "reason": "GENERATED_MOLECULE_HAS_NO_REGISTRY_RECORD — a generated "
               "candidate is new, so no trial or dataset record can "
               "exist; plans record this absence instead of guessing."},
    {"absence_id": "ABS:RESULTS_SECTION_NEVER_FETCHED",
     "lane": "ctgov",
     "scope": "every query",
     "reason": "P7-2 metadata lane: the request pins fields to six "
               "whitelisted protocolSection modules, so results content "
               "is structurally absent; results are never synthesized."},
]

_FORBIDDEN_TOKENS = ("resultSection", "outcomeMeasure", "primaryOutcome",
                     "secondaryOutcome", "effectSize", "pValue")


def _token_hit(text, tokens):
    t = (text or "").lower()
    return any(tok in t for tok in tokens)


def build() -> dict:
    values = json.load(open(VALUES_PATH, encoding="utf-8"))
    manifest = json.load(open(MANIFEST_PATH, encoding="utf-8"))

    # -- CT.gov lane ---------------------------------------------------
    studies = {}
    ct_panel = []
    for q in sorted(values["ctgov"], key=lambda r: r["panel_id"]):
        ids = []
        for s in sorted(q["studies"], key=lambda r: r["nct_id"] or ""):
            nid = s["nct_id"]
            ids.append(nid)
            if nid not in studies:
                row = dict(s)
                row["query_panels"] = [q["panel_id"]]
                studies[nid] = row
            else:
                if q["panel_id"] not in studies[nid]["query_panels"]:
                    studies[nid]["query_panels"].append(q["panel_id"])
        man = manifest.get(q["logical_name"], {})
        ct_panel.append({
            "panel_id": q["panel_id"],
            "query": q["query"],
            "logical_name": q["logical_name"],
            "source_id": "SRC:P7_CT_" + q["panel_id"],
            "sha256": q["sha256"],
            "retrieval_utc": q["retrieval_utc"],
            "url": man.get("url"),
            "total_count": q["total_count"],
            "study_ids": ids,
        })

    # -- GEO lane -------------------------------------------------------
    # gds esearch returns mixed entry types (GSM samples, GPL platforms,
    # GSE/GDS series). P7-2 hooks are SERIES-level: keep GSE/GDS only,
    # count the drops (nothing silently discarded).
    dropped_non_series = 0
    series = {}
    geo_panel = []
    for q in sorted(values["geo"], key=lambda r: r["panel_id"]):
        ids = []
        for s in sorted(q["series"], key=lambda r: r["accession"] or ""):
            acc = s["accession"] or ""
            if not (acc.startswith("GSE") or acc.startswith("GDS")):
                dropped_non_series += 1
                continue
            ids.append(acc)
            if acc not in series:
                row = dict(s)
                row["query_panels"] = [q["panel_id"]]
                series[acc] = row
            else:
                if q["panel_id"] not in series[acc]["query_panels"]:
                    series[acc]["query_panels"].append(q["panel_id"])
        man = manifest.get(q["logical_name"], {})
        geo_panel.append({
            "panel_id": q["panel_id"],
            "query": q["query"],
            "logical_name": q["logical_name"],
            "source_id": "SRC:P7_GE_" + q["panel_id"],
            "sha256": q["sha256"],
            "retrieval_utc": q["retrieval_utc"],
            "url": man.get("url"),
            "series_ids": ids,
        })

    # -- candidate/disease links (mechanical token filter) --------------
    links = []
    for drug in CT_DRUG_PANEL:
        for dkey, spec in sorted(DISEASE_TOKENS.items()):
            matched = []
            for nid in sorted(studies):
                s = studies[nid]
                hay = " || ".join([s.get("brief_title") or "",
                                   " ; ".join(s.get("conditions") or []),
                                   " ; ".join(s.get("interventions") or [])])
                if _token_hit(hay, [drug]) and \
                        _token_hit(hay, spec["tokens"]):
                    matched.append(nid)
            links.append({
                "link_id": f"LNK:{drug.upper()}_{dkey}",
                "drug": drug,
                "disease_key": dkey,
                "specificity": spec["specificity"],
                "filter_recorded": {
                    "drug_token": drug,
                    "disease_tokens": spec["tokens"],
                    "fields_searched": ["brief_title", "conditions",
                                        "interventions"],
                    "expression": "drug_token in title/conditions/"
                                  "interventions AND any disease_token in "
                                  "title/conditions/interventions",
                },
                "study_ids": matched[:40],
                "matched_total": len(matched),
                "listed_note": ("first 40 lexicographic; full count in "
                                "matched_total" if len(matched) > 40 else
                                "complete list"),
            })

    # -- GEO disease-context links --------------------------------------
    geo_links = []
    for pid in sorted(GEO_DISEASE_LINK_RULES):
        if pid.endswith("_SPEC"):
            continue
        rule = GEO_DISEASE_LINK_RULES[pid]
        q = next((x for x in geo_panel if x["panel_id"] == pid), None)
        if q is None:
            continue
        for dkey in rule["disease_keys"]:
            spec_rule = GEO_DISEASE_LINK_RULES.get(pid + "_SPEC")
            specificity = (spec_rule if spec_rule else GEO_SPEC_DEFAULT)
            if specificity == "DISEASE_CONTEXT_ONLY" and \
                    dkey in ("HFREF", "HFPEF"):
                specificity = "CONDITION_LEVEL_ONLY"
            geo_links.append({
                "link_id": f"LNK:GEO_{dkey}_{pid}",
                "disease_key": dkey,
                "panel_id": pid,
                "specificity": specificity,
                "term": rule["term"],
                "rationale_recorded": rule["rationale"],
                "series_ids": q["series_ids"],
                "source_id": q["source_id"],
            })

    # -- absences --------------------------------------------------------
    absences = [dict(a) for a in STRUCTURAL_ABSENCES]
    if dropped_non_series:
        absences.append({
            "absence_id": "ABS:GEO_NON_SERIES_ROWS_DROPPED",
            "lane": "geo",
            "scope": f"{dropped_non_series} esummary rows",
            "reason": "NON_SERIES_ENTRY_TYPE — the gds esearch returns "
                      "GSM sample and GPL platform rows too; the P7-2 "
                      "hook is SERIES-level, so non-series rows are "
                      "dropped and the drop is recorded here.",
        })
    for a in values.get("absences", []):
        absences.append({
            "absence_id": "ABS:FETCH_" + a["panel_id"],
            "lane": a["lane"], "scope": a["logical_name"],
            "reason": a["kind"] + " — " + a["detail"],
        })
    neg = values.get("negative_control", {})
    if neg:
        absences.append({
            "absence_id": "ABS:NEGATIVE_CONTROL_APXD_0001",
            "lane": "both", "scope": neg.get("query", "APXD-0001"),
            "reason": neg.get("absence_reason",
                              "negative control (recorded)"),
        })

    # -- source records ---------------------------------------------------
    sources = {}
    for q in ct_panel:
        sources[q["source_id"]] = {
            "resource": "ClinicalTrials.gov API v2",
            "resource_version": "live schema (no machine-readable build "
                                "version; retrieval window recorded)",
            "retrieval_utc": q["retrieval_utc"],
            "url": q["url"],
            "license": "SEE_TERMS (ClinicalTrials.gov public registry "
                       "metadata)",
            "evidence_type": "registry_metadata",
            "confidence": "machine_fetched_whitelisted_metadata_fields",
            "sha256": q["sha256"],
            "limitations": "metadata + accession only; results section "
                           "structurally never fetched; no efficacy "
                           "claim is derivable from this lane",
            "query": q["query"],
        }
    for q in geo_panel:
        sources[q["source_id"]] = {
            "resource": "NCBI Gene Expression Omnibus (GEO, via "
                        "E-utilities esearch+esummary)",
            "resource_version": "live schema (retrieval window recorded)",
            "retrieval_utc": q["retrieval_utc"],
            "url": q["url"],
            "license": "SEE_TERMS (NCBI public data; vendor terms)",
            "evidence_type": "dataset_metadata",
            "confidence": "machine_fetched_summary_metadata_only",
            "sha256": q["sha256"],
            "limitations": "accession + summary metadata only; raw "
                           "expression data is NEVER fetched or stored "
                           "in this lane",
            "query": q["query"],
        }

    frozen_utc = max(
        [q["retrieval_utc"] for q in ct_panel + geo_panel] or
        ["1970-01-01T00:00:00Z"])

    return {
        "studies": studies, "series": series, "ct_panel": ct_panel,
        "geo_panel": geo_panel, "links": links, "geo_links": geo_links,
        "absences": absences, "sources": sources, "frozen_utc": frozen_utc,
        "disease_tokens": DISEASE_TOKENS,
    }


# ------------------------------------------------------------------
# module emitter
# ------------------------------------------------------------------

def emit(pack: dict) -> str:
    def lit(obj):
        """Canonical Python literal: recursively key-sorted dicts so the
        emitted module is deterministic."""
        def sort(o):
            if isinstance(o, dict):
                return {k: sort(o[k]) for k in sorted(o)}
            if isinstance(o, (list, tuple)):
                return [sort(x) for x in o]
            return o
        return repr(sort(obj))

    L = []
    A = L.append
    A("# =====================================================================")
    A("# APEIRON-X v15 - FROZEN VALIDATION DATASET REGISTRY (P7, Module F)")
    A("# ---------------------------------------------------------------------")
    A("# Phase 7 counterpart of v15/repurposing_data.py: a FROZEN, hash-")
    A("# pinned registry authored VERBATIM from machine-verified dataset")
    A("# metadata fetches (v15/connectors/refresh_phase7_cache.py --live;")
    A("# audit values in v15/out/phase7_verified_values.json; pack")
    A(f"# generated {pack['frozen_utc']}).")
    A("#")
    A("# DOCTRINE (V15_IMPLEMENTATION_PLAN section 8):")
    A("#   1. P7-2: metadata + accession records ONLY. Every record below")
    A("#      is public registry metadata (CT.gov study header fields /")
    A("#      GEO esummary fields). Results content is structurally never")
    A("#      fetched (CT.gov fields whitelist) and never synthesized.")
    A("#   2. Every query is byte-traceable to the frozen cache via the")
    A("#      sha256 + logical_name recorded here. Absent data is recorded")
    A("#      as absent (ABSENCES_P7) — nothing is invented.")
    A("#   3. Links are MECHANICAL token filters over the whitelisted")
    A("#      fields; every filter expression is recorded in the link row.")
    A("#      A CONDITION_LEVEL_ONLY link (HFREF/HFPEF) must never be")
    A("#      presented as stratum-specific evidence.")
    A("#   4. FROZEN: sha256 pinned in kb_extensions/validation_pins.json")
    A("#      via freeze_validation.py; the pin-checked facade refuses to")
    A("#      serve on a mismatch.")
    A("#   5. Pure data module: imports nothing (C0-style connector")
    A("#      isolation, machine-checked by the phase-7 battery).")
    A("# =====================================================================")
    A("")
    A(f"PACK_SCHEMA_VERSION = {PACK_SCHEMA_VERSION!r}")
    A(f"FROZEN_UTC = {pack['frozen_utc']!r}")
    A("")
    A("# ----------------------------------------------------------------")
    A("# ClinicalTrials.gov study metadata (accession-keyed; verbatim)")
    A("# ----------------------------------------------------------------")
    A("CT_STUDIES_P7 = " + lit(pack["studies"]))
    A("")
    A("# Query panel (deterministic; ids refer to CT_STUDIES_P7 keys)")
    A("CT_QUERY_PANEL_P7 = " + lit(pack["ct_panel"]))
    A("")
    A("# ----------------------------------------------------------------")
    A("# GEO series metadata (accession-keyed; verbatim esummary fields)")
    A("# ----------------------------------------------------------------")
    A("GEO_SERIES_P7 = " + lit(pack["series"]))
    A("")
    A("GEO_QUERY_PANEL_P7 = " + lit(pack["geo_panel"]))
    A("")
    A("# ----------------------------------------------------------------")
    A("# Mechanical candidate/disease dataset links (filters recorded)")
    A("# ----------------------------------------------------------------")
    A("CANDIDATE_DATASET_LINKS_P7 = " + lit(pack["links"]))
    A("")
    A("GEO_DISEASE_LINKS_P7 = " + lit(pack["geo_links"]))
    A("")
    A("DISEASE_TOKEN_SPECS_P7 = " + lit(pack["disease_tokens"]))
    A("")
    A("ABSENCES_P7 = " + lit(pack["absences"]))
    A("")
    A("SOURCE_RECORDS_P7 = " + lit(pack["sources"]))
    A("")
    A("HONEST_LIMITS_P7 = [")
    for lim in [
        "This registry carries registry METADATA only. No trial result, "
        "effect size, p-value or outcome measure is present anywhere in "
        "this pack (structurally impossible through the fields whitelist).",
        "HFREF/HFPEF links are CONDITION_LEVEL_ONLY: the whitelisted "
        "registry fields cannot separate ejection-fraction strata.",
        "Dataset links exist ONLY for the 10 queried drugs; other "
        "candidate molecules have NO queried datasets (absence recorded, "
        "not guessed).",
        "Generated molecules (APXD-*) cannot have registry records; "
        "their plans must cite this structural absence instead.",
        "Trial metadata (a phase-3 study EXISTS for a drug x condition) "
        "is evidence of RESEARCH ACTIVITY, never of efficacy.",
    ]:
        A(f"    {lim!r},")
    A("]")
    A("")
    A("# ----------------------------------------------------------------")
    A("# Self-validation (run by the pin-checked facade at load time)")
    A("# ----------------------------------------------------------------")
    A("_FORBIDDEN_TOKENS = " + repr(list(_FORBIDDEN_TOKENS)) + "")
    A("")
    A("def validate_validation_module():")
    A("    problems = []")
    A("    def _is_nct(s):")
    A("        return (s.startswith('NCT') and s[3:].isdigit()")
    A("                and len(s) > 3)")
    A("    def _is_gx(acc):")
    A("        return ((acc.startswith('GSE') or acc.startswith('GDS')")
    A("                or acc.startswith('GSX')) and acc[3:].isdigit())")
    A("    for nid, s in CT_STUDIES_P7.items():")
    A("        if nid != s.get('nct_id'):")
    A("            problems.append('study key/nct_id mismatch %s' % nid)")
    A("        if not _is_nct(nid):")
    A("            problems.append('study id malformed: %s' % nid)")
    A("        if not s.get('brief_title'):")
    A("            problems.append('study %s: no title' % nid)")
    A("    for acc, s in GEO_SERIES_P7.items():")
    A("        if acc != s.get('accession'):")
    A("            problems.append('series key/accession mismatch %s' % acc)")
    A("        if not _is_gx(acc):")
    A("            problems.append('series accession malformed: %s' % acc)")
    A("    for q in CT_QUERY_PANEL_P7:")
    A("        for nid in q['study_ids']:")
    A("            if nid not in CT_STUDIES_P7:")
    A("                problems.append('query %s: unresolvable %s'"
      " % (q['panel_id'], nid))")
    A("        if not q.get('url'):")
    A("            problems.append('query %s: no manifest url'"
      " % q['panel_id'])")
    A("    for q in GEO_QUERY_PANEL_P7:")
    A("        for acc in q['series_ids']:")
    A("            if acc not in GEO_SERIES_P7:")
    A("                problems.append('geo query %s: unresolvable %s'"
      " % (q['panel_id'], acc))")
    A("    for lnk in CANDIDATE_DATASET_LINKS_P7:")
    A("        for nid in lnk['study_ids']:")
    A("            if nid not in CT_STUDIES_P7:")
    A("                problems.append('link %s: unresolvable %s'"
      " % (lnk['link_id'], nid))")
    A("        if lnk['matched_total'] < len(lnk['study_ids']):")
    A("            problems.append('link %s: matched_total smaller than"
      " listed' % lnk['link_id'])")
    A("    for lnk in GEO_DISEASE_LINKS_P7:")
    A("        if lnk['source_id'] not in SOURCE_RECORDS_P7:")
    A("            problems.append('geo link %s: unknown source'"
      " % lnk['link_id'])")
    A("        for acc in lnk['series_ids']:")
    A("            if acc not in GEO_SERIES_P7:")
    A("                problems.append('geo link %s: unresolvable %s'"
      " % (lnk['link_id'], acc))")
    A("    for sid, rec in SOURCE_RECORDS_P7.items():")
    A("        for f in ('resource', 'retrieval_utc', 'url', 'license',")
    A("                  'evidence_type', 'sha256'):")
    A("            if not rec.get(f):")
    A("                problems.append('source %s: missing %s' % (sid, f))")
    A("    blob = repr({")
    A("        'studies': CT_STUDIES_P7, 'series': GEO_SERIES_P7,")
    A("        'links': CANDIDATE_DATASET_LINKS_P7,")
    A("        'geo_links': GEO_DISEASE_LINKS_P7,")
    A("        'sources': SOURCE_RECORDS_P7})")
    A("    for tok in _FORBIDDEN_TOKENS:")
    A("        if tok in blob:")
    A("            problems.append('forbidden results token %r present'"
      " % tok)")
    A("    return problems")
    A("")
    return "\n".join(L) + "\n"


def main() -> int:
    pack = build()
    n_studies = len(pack["studies"])
    n_series = len(pack["series"])
    n_links = sum(1 for x in pack["links"] if x["study_ids"])
    print(f"[gen] studies={n_studies} series={n_series} "
          f"ct_links={n_links}/{len(pack['links'])} "
          f"geo_links={len(pack['geo_links'])} "
          f"absences={len(pack['absences'])} sources={len(pack['sources'])}")
    src = emit(pack)
    ns = {}
    exec(compile(src, OUT_PATH, "exec"), ns)             # noqa: S102
    problems = ns["validate_validation_module"]()
    if problems:
        for p in problems[:20]:
            print("[validate] " + p)
        raise SystemExit("generated module failed self-validation")
    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        fh.write(src)
    import hashlib
    digest = hashlib.sha256(src.encode("utf-8")).hexdigest()
    os.makedirs(os.path.dirname(PIN_PATH), exist_ok=True)
    with open(PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump({"validation_data_sha256": digest,
                   "pack_schema_version": PACK_SCHEMA_VERSION,
                   "frozen_utc": pack["frozen_utc"]}, fh, indent=1)
    with open(PIN_PATH + ".pre", "w", encoding="utf-8") as fh:
        fh.write("")
    os.remove(PIN_PATH + ".pre")
    print(f"[write] {OUT_PATH} ({len(src)} bytes)")
    print(f"[write] {PIN_PATH} sha256={digest[:16]}…")
    print("[validate] self-validation PASSED (0 problems)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
