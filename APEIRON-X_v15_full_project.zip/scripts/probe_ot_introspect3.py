"""Print only Drug.mechanismsOfAction / indications type names, then the
fields of those nested types, then a sample indication row (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None, maxlen=1500):
    rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                     None, json.dumps({"query": query,
                                       "variables": variables or {}}).encode(),
                     {"Content-Type": "application/json"}, 40, 1, name)
    p = json.loads(rec[1])
    if p.get("errors"):
        print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:250])
        return None
    print(f"{name}: OK {json.dumps(p['data'])[:maxlen]}")
    return p["data"]


d = run("moa_type", '{__type(name:"Drug"){fields{name '
        'type{kind name ofType{kind name}}}}}')
if d:
    for f in d["__type"]["fields"]:
        if f["name"] in ("mechanismsOfAction", "indications",
                         "maximumClinicalStage"):
            print("  ", f["name"], "->", json.dumps(f["type"]))
