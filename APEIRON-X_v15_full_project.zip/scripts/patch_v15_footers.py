#!/usr/bin/env python3
"""Post-process the v15 Phase 1 report docx for WPS/Word page-number correctness.

Per docx skill toc.md:
1. Map each section's default footerReference -> footer XML part via rels.
2. Section 2 (front matter) footer: PAGE -> PAGE \\* ROMAN \\* MERGEFORMAT
   Section 3 (body) footer:         PAGE -> PAGE \\* arabic \\* MERGEFORMAT
3. Remove empty <w:pgNumType/> emitted for the cover section.
"""
import re
import shutil
import sys
import zipfile

DOCX = "/home/z/my-project/download/APEIRON-X_v15_Phase1_Audit_and_Plan.docx"
TMP = DOCX + ".tmp"

with zipfile.ZipFile(DOCX) as z:
    names = z.namelist()
    data = {n: z.read(n) for n in names}

doc = data["word/document.xml"].decode("utf-8")
rels = data["word/_rels/document.xml.rels"].decode("utf-8")

# rId -> footer target
rel_map = dict(re.findall(r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"', rels))

# default footerReference per section, in document order
sect_footers = []
for sect in re.findall(r"<w:sectPr[ >].*?</w:sectPr>", doc, flags=re.S):
    m = re.search(r'<w:footerReference w:type="default" r:id="([^"]+)"', sect)
    sect_footers.append(m.group(1) if m else None)
print("section default footers:", sect_footers)

def patch_footer(rid, fmt):
    if rid is None:
        return
    target = rel_map.get(rid)
    if not target:
        print("missing rel target for", rid)
        return
    part = "word/" + target.lstrip("/")
    xml = data[part].decode("utf-8")
    new = re.sub(r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
                 lambda m: m.group(1) + f" PAGE \\* {fmt} \\* MERGEFORMAT " + m.group(2),
                 xml)
    if new != xml:
        data[part] = new.encode("utf-8")
        print(f"patched {part} -> PAGE \\* {fmt}")
    else:
        print(f"no bare PAGE field found in {part} (may already be patched)")

assert len(sect_footers) >= 3, "expected 3 sections"
patch_footer(sect_footers[1], "ROMAN")
patch_footer(sect_footers[2], "arabic")

# strip empty pgNumType (cover section)
doc2 = doc.replace("<w:pgNumType/>", "")
if doc2 != doc:
    print("stripped empty <w:pgNumType/>")

# --- TOC cleanup: the placeholder injector leaves a field-style first entry
# whose nested PAGEREF has an empty cached result; LibreOffice renders it as a
# numberless duplicate line. Keep the field chars (begin/instr/separate) but
# drop the visible hyperlink content of that first field paragraph.
m = re.search(
    r'(<w:p><w:pPr><w:pStyle w:val="TOC1"/>.*?'
    r'<w:fldChar w:fldCharType="separate"/></w:r>)'
    r'(<w:hyperlink.*?</w:hyperlink>)',
    doc2, flags=re.S)
if m:
    doc2 = doc2[:m.start(2)] + doc2[m.end(2):]
    print("stripped empty-PAGEREF duplicate first TOC entry")

# tighten injected TOC entries: drop their extra before/after spacing so the
# 25-entry TOC + note fit on one front-matter page (no nearly-blank page 3)
doc3, n = re.subn(
    r'(<w:pPr><w:pStyle w:val="TOC[123]"/>(?:(?!</w:pPr>).)*?)<w:spacing[^/]*/>',
    r"\1", doc2, flags=re.S)
print(f"tightened spacing on {n} TOC entries")
data["word/document.xml"] = doc3.encode("utf-8")

with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED) as z:
    for n in names:
        z.writestr(n, data[n])
shutil.move(TMP, DOCX)
print("footer/pgNumType post-process complete")
