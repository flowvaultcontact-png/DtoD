"""Probe: build the v14.1 structure layer, derive laws, check Theta_d
satisfaction for the Phase 4 bridge candidates; measure runtime."""
import sys
import time

sys.path.insert(0, "/home/z/my-project/apeiron")

from apeiron_structure_proof import StructLayer, derive_structure_laws  # noqa: E402
from apeiron_direct_laws import derive_direct_laws, theta_satisfies_drug  # noqa: E402
from disease_mechanism_table import MECH_REQUIRED  # noqa: E402

t0 = time.time()
layer = StructLayer()
print(f"layer built in {time.time() - t0:.1f}s; "
      f"drugs={len(getattr(layer, 'drug_components', {}))}")

t0 = time.time()
laws, excluded = derive_structure_laws(layer, verbose=False)
print(f"structure laws: {len(laws)} classes ({len(excluded)} excluded) "
      f"in {time.time() - t0:.1f}s")

t0 = time.time()
theta = derive_direct_laws(layer, laws)
print(f"theta map: {len(theta)} diseases in {time.time() - t0:.1f}s")

for did in ("D02", "D61", "D08"):
    print(f"  {did} mechs={MECH_REQUIRED[did]}")

for did, drug in [("D02", "dapagliflozin"), ("D02", "empagliflozin"),
                  ("D02", "losartan"), ("D02", "canagliflozin"),
                  ("D61", "empagliflozin"), ("D08", "dapagliflozin"),
                  ("D08", "metformin")]:
    try:
        sat = theta_satisfies_drug(layer, theta[did], drug)
        print(f"  Theta[{did}]({drug}) = {sat}")
    except Exception as exc:  # noqa: BLE001 — probe
        print(f"  Theta[{did}]({drug}) ERROR {type(exc).__name__}: "
              f"{str(exc)[:100]}")
