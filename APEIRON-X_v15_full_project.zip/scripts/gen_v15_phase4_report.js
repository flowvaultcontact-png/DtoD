// APEIRON-X v15 — Phase 4 Drug Repurposing (deliverable docx)
// Skill-compliant: R1 cover recipe (DS-1), 3-section numbering, TOC field +
// refresh hint, three-line tables, postcheck-ready. Same architecture as the
// Phase 1/2 generators (validated), content replaced.
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, SectionType,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  TableLayoutType, TableOfContents,
} = require("docx");
const fs = require("fs");

// ---------------------------------------------------------------- palette (DS-1 Deep Sea)
const PAL = {
  bg: "0B1C2C", accent: "529286",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "529286", headerText: "FFFFFF", accentLine: "529286", innerLine: "BECFCC", surface: "E8ECEB" },
  primary: "0B1C2C", body: "000000", secondary: "5B6B7D",
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ------------------------------------------------------- title layout (English-aware width)
function textWidthTwips(text, pt) {
  let w = 0;
  for (const ch of text) w += /[\u4e00-\u9fff]/.test(ch) ? pt * 20 : pt * 11;
  return w;
}
function splitTitleLines(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const wd of words) {
    const cand = cur ? cur + " " + wd : wd;
    if (textWidthTwips(cand, pt) <= maxWidthTwips || !cur) cur = cand;
    else { lines.push(cur); cur = wd; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLines(title, maxWidthTwips, titlePt);
    if (lines.length <= 3 && lines.every(l => textWidthTwips(l, titlePt) <= maxWidthTwips)) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(p) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = p;
  const SAFETY = 1200;
  const usable = pageHeight - marginTop - marginBottom - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (12 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (10 * 23 + 100);
  const implicit = 3 * 300;
  const content = titleH + subH + engH + metaH + fixedHeight + implicit;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(remaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ------------------------------------------------------------------ cover recipe R1
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.cover.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.cover.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.cover.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        ", size: 16, color: P.cover.footerColor }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders, children,
      })],
    })],
  })];
}

// ------------------------------------------------------------------ body helpers
const F = { ascii: "Times New Roman", eastAsia: "SimSun" };
const FH = { ascii: "Times New Roman", eastAsia: "SimHei" };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: PAL.primary, font: FH })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: PAL.primary, font: FH })],
  });
}
function body(text, opts = {}) {
  const runs = Array.isArray(text) ? text : [new TextRun({ text, size: 24, color: PAL.body, font: F })];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: opts.after !== undefined ? opts.after : 120 },
    children: runs,
  });
}
function caption(text) {
  return new Paragraph({
    keepNext: true, spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: PAL.secondary, font: FH })],
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      spacing: { line: 312 },
      children: [new TextRun({ text, size: opts.header ? 21 : 20,
        bold: !!opts.header, color: opts.header ? PAL.table.headerText : PAL.body,
        font: opts.header ? FH : F })],
    })],
    shading: opts.header ? { type: ShadingType.CLEAR, fill: PAL.table.headerBg }
      : (opts.zebra ? { type: ShadingType.CLEAR, fill: PAL.table.surface } : undefined),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
  });
}
function dataTable(widths, header, rows, zebra = true) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: header.map((t, i) => cell(t, { header: true, width: widths[i] })),
      }),
      ...rows.map((r, ri) => new TableRow({
        cantSplit: true,
        children: r.map((t, i) => cell(t, { width: widths[i], zebra: zebra && ri % 2 === 1 })),
      })),
    ],
  });
}
function codeBlock(lines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      left: { style: BorderStyle.SINGLE, size: 12, color: PAL.table.accentLine },
      right: NB, insideHorizontal: NB, insideVertical: NB,
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: "F4F7F6" },
        margins: { top: 120, bottom: 120, left: 200, right: 160 },
        children: lines.map(l => new Paragraph({
          spacing: { line: 312, after: 20 },
          children: [new TextRun({ text: l, size: 18, color: "24313B", font: { ascii: "Courier New", eastAsia: "SimSun" } })],
        })),
      })],
    })],
  });
}

// ------------------------------------------------------------------ footers/headers
function pageFooter() {
  return new Footer({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: F })],
  })] });
}
function bodyHeader() {
  return new Header({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine, space: 4 } },
    children: [new TextRun({ text: "APEIRON-X v15 Phase 4 Report", size: 18, color: "808080", font: F })],
  })] });
}

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

// ================================================================== BODY CONTENT
const B = [];

// ---- 1 Executive Summary
B.push(body("This report closes Phase 4 of the APEIRON-X v15 program: the drug repurposing engine (Module C). The phase delivers a temporal repurposing benchmark in which predictions are built exclusively from pre-2015 knowledge and evaluated against the post-2015 repurposing outcomes that actually happened - the SGLT2-inhibitor era in heart failure and chronic kidney disease - and it does so without touching a single line of the proved v14.1 engine: all four hash-pinned corpus files kept their sha256, and the complete acceptance cascade now runs 13 of 13 stages at exit 0. Four things were delivered. First, the Phase 4 connector layer (P4-1): a ChEMBL connector (approval years, withdrawn flags, mechanism rows), Open Targets drug records and indication pages rebuilt for the platform's current live schema, and a UniProt function fetcher, all feeding the established frozen-response cache with retrieval metadata and zero absences. Second, the frozen repurposing pack (P4-1): eighteen verbatim drug records anchored by machine-fetched ChEMBL first-approval years, a curated target-channel law table with UniProt anchors, pre-2015 disease-channel profiles whose class-precedent rows cite the landmark trials by verified PMID, and six post-2015 ground-truth outcomes (DAPA-HF, DAPA-CKD, EMPEROR-Reduced, EMPA-KIDNEY, CREDENCE, DELIVER). Third, the Module C engine (P4-2/P4-3): candidate generation over a compatibility law channel with a cited cardiorenal adjacency bridge, exactly-one status per candidate, and the Theta_d consistency bridge that imports the v14.1 structure engines read-only and surfaces MECH_STRUCTURE_CONFLICT findings instead of dropping them. Fourth, the temporal benchmark with its hermeticity theorem (P4-4): macro recall@10 = 1.0 over four diseases and six outcomes, with every truth pair separated from zero-support candidates, the plan-named HFpEF case ranking dapagliflozin first from pre-2015 knowledge alone, and finerenone (2021) and semaglutide (2017) structurally absent from every pre-2015 candidate list."));
B.push(body("The scientific honesty of the result matters more than the number. In 2015, the evidence-backed first-line channels for heart failure were RAAS blockade and mineralocorticoid antagonism (CONSENSUS 1987, RALES 1999), and the benchmark ranks those drugs first - correctly for 2015. The SGLT2 inhibitors sit at ranks 7-8 in HFrEF: channel-supported through the cited cardiorenal bridge, but carrying no trial precedent - precisely where a disciplined system should have placed them before DAPA-HF read out. In HFpEF, where no therapy had precedent, the cardiorenal-adjacent SGLT2 candidates rank first, second and third - and that is where the outcomes actually landed. The divergence between the naive ranking and what happened is reported as examined false leads, not smoothed away; the hermeticity theorem proves the prediction is bit-for-bit identical when every post-2015 record is deleted from the pack."));

// ---- 2 Scope and doctrine
B.push(h2("Scope and doctrine"));
B.push(body("Module C consumes the frozen pack and the v14.1 engines read-only. The derivation modules import no connector code (machine-checked by AST scan in the phase-4 battery), and the pack itself is a pure-data module that imports nothing at all. Every emitted candidate carries exactly one status from the P4-2 vocabulary - APPROVED_INDICATION, INVESTIGATIONAL, EXPERIMENTALLY_VALIDATED or COMPUTATIONAL_HYPOTHESIS - and every EVIDENCED status cites machine-verified record ids. The Theta_d consistency bridge is a consistency check on outputs, never an input to the temporal prediction: the current hash-pinned knowledge base contains the post-2015 guideline-drift rows by design, so using its direct structure laws as prediction features would leak the answer. Ranking aggregates are labelled COMPUTATIONAL_RANK and are never probabilities; nothing in this round claims clinical validity or treatment advice."));

// ---- 3 P4-1 connectors
B.push(h2("P4-1. Live connectors and what the live schema had changed"));
B.push(body("The Phase 3 connector patterns were extended with a ChEMBL connector and two new Open Targets operations, and the freeze surfaced three breaking upstream changes that a hard-coded integration would have silently mishandled. The Open Targets Platform Drug type no longer carries isApproved, firstApproval, withdrawn or maximumClinicalTrialPhase; the live fields are maximumClinicalStage (an approval/phase string) and a paged indications block whose rows carry disease ids and stages. The disease-side knownDrugs field is gone entirely, replaced by drugAndClinicalCandidates. The ChEMBL REST base moved from /chembl/api/core/ to /chembl/api/data/ - the old path returns 404, including for the release-status probe. Each of these facts was established by introspection or probe before the freeze and is documented verbatim in the connector module and the pack's source records."));
B.push(body("Citation discipline was exercised hard in this round. The landmark-trial searches initially matched recent review articles mentioning the trial acronyms rather than the trials themselves; the fix constrains publication windows and pins exact title phrases, and a PMID hint path was added in which remembered identifiers serve only as search candidates - every admitted record still passes Europe PMC EXT_ID verification plus title-token filtering. The gate earned its keep: four of nine remembered PMIDs were wrong (one resolved to a proteomics methods paper, one to an article on collegiate athletics) and were rejected by the title filter exactly as designed. The final freeze verified thirteen citations with zero absences, including DAPA-HF (PMID 31535829), DAPA-CKD (32970396), EMPEROR-Reduced (32865377), EMPEROR-Preserved (34459213), EMPA-KIDNEY (36331190), DELIVER (36027570), CREDENCE (30990260), the RENAAL program paper (11967819), CONSENSUS (2883575), RALES (10471456), a pre-2015 cardiorenal-syndrome review (21253529), a pre-2015 dapagliflozin mechanism review (25525338) and UKPDS 33 (9742976)."));

// ---- 4 P4-1 pack
B.push(h2("P4-1. The frozen repurposing pack"));
B.push(body("The pack is generated by a dedicated script that copies machine fields verbatim from the verified-values freeze and adds only curated law-channel content, then pins the result by sha256. Its contents:"));
B.push(dataTable([46, 20, 34],
  ["Pack section", "Rows", "Provenance"],
  [
    ["Drug universe (18 drugs: 15 pre-2015 + finerenone/semaglutide as post-2015 controls)", "18", "Open Targets drug records + ChEMBL molecules (first_approval, withdrawn_flag), verbatim"],
    ["Landmark trial citations", "13", "Europe PMC EXT_ID-verified records with year, journal, DOI"],
    ["Target-channel law table", "13 symbols", "UniProt reviewed entries + action types verbatim from OT mechanism rows"],
    ["KB mechanism-class fallback channels", "10 classes", "v14.1 hash-pinned KB rows (read-only), SRC:KB_P4"],
    ["Pre-2015 disease-channel profiles (HFREF, HFPEF, CKD, DKD, T2DM)", "5 diseases", "Curated channels, each citing verified pre-2015 literature"],
    ["Indication-evidence rows (drug-side + disease-side)", "96", "Open Targets, verbatim stages"],
    ["Post-2015 ground truth (6 outcomes)", "6", "Curated rows, each citing verified trial PMIDs"],
  ]));
B.push(body("Approval years are served by ChEMBL exactly as fetched - dapagliflozin 2012, empagliflozin 2014, canagliflozin 2011, captopril 1981, spironolactone 1960 - with no hand correction; the benchmark's temporal split (first_approval before 2015) therefore rests entirely on machine-verified data. Where the platform did not serve an approval row that the verified trial supports - empagliflozin in HFrEF and dapagliflozin in HFpEF - the gap is recorded in the ground-truth notes rather than smoothed over."));

// ---- 5 law channel + statuses
B.push(h2("P4-2. The compatibility law channel and status discipline"));
B.push(body("A candidate is channel-supported when its mapped channels intersect the disease's pre-2015 profile channels directly; when the intersection is empty, the curated adjacency bridge may grant adjacent support - KIDNEY_TUBULE_GLUCOSE bridges to CARDIORENAL on the strength of the cited cardiorenal-syndrome literature, and GLUCOSE_HOMEOSTASIS bridges to HYPERGLYCEMIA on UKPDS 33. Class precedent - the track_record axis - is granted only when a directly matched channel carries a precedent_class anchored by a pre-2015 trial citation and the candidate maps to that mechanism class; the frontier channels (renal glucose handling, cardiorenal) deliberately carry no precedent class. Statuses come from machine-served rows and verified citations, exactly one per candidate:"));
B.push(dataTable([24, 18, 30, 28],
  ["Candidate pair", "Status", "Basis (machine-verified)", "Theta_d finding"],
  [
    ["dapagliflozin x HFrEF", "APPROVED INDICATION", "APPROVAL row served (drug side)", "THETA_SATISFIED (KB:D02)"],
    ["dapagliflozin x CKD", "APPROVED INDICATION", "APPROVAL row served (drug side)", "NO_DISEASE_ENCODING (CKD)"],
    ["empagliflozin x HFrEF", "EXPERIMENTALLY VALIDATED", "EMPEROR-Reduced PMID 32865377; approval row absent (recorded gap)", "THETA_SATISFIED (KB:D02)"],
    ["empagliflozin x CKD", "APPROVED INDICATION", "APPROVAL row served (drug side)", "NO_DISEASE_ENCODING (CKD)"],
    ["canagliflozin x DKD", "EXPERIMENTALLY VALIDATED", "CREDENCE PMID 30990260; PHASE_3 row served", "NOT_IN_CORPUS"],
    ["irbesartan x DKD", "APPROVED INDICATION", "APPROVAL row served (drug side)", "NO_DISEASE_ENCODING (DKD)"],
    ["glimepiride x HFrEF", "COMPUTATIONAL HYPOTHESIS", "law-channel only; no indication row", "MECH_STRUCTURE_CONFLICT (KB:D02)"],
  ]));
B.push(body("Statuses are the exact P4-2 vocabulary tokens (underscore spelled as a space in the table). The status-discipline theorem machine-checks the whole report: every status is in the vocabulary, every EVIDENCED status cites recorded source ids through the anti-fabrication gate, and no COMPUTATIONAL_HYPOTHESIS row wears approval language. The negative control in the test battery plants a hypothesis row that says approved and confirms the theorem fails."));

// ---- 6 Theta bridge
B.push(h2("P4-3. The Theta_d consistency bridge"));
B.push(body("The bridge derives the v14.1 direct structure laws once (about five seconds) and evaluates every candidate molecule against the law of the disease's encoding, importing apeiron_structure_proof and apeiron_direct_laws read-only. Nothing is silently dropped: every candidate resolves to one of five explicit findings, and conflict rows remain visible in the ranked output with a MECH_STRUCTURE_CONFLICT rank tier. The flagship case is losartan in HFrEF: the candidate is plausible on the law channel (RAAS is a precedent class for HFrEF), but the direct structure law Theta_D02 of the heart-failure encoding does not accept the losartan molecule, so the bridge flags the conflict and withholds the EVIDENCED tier - while dapagliflozin satisfies Theta_D02 and, carrying an approval row, ranks EVIDENCED. Canagliflozin, absent from the v14.1 structure corpus, is reported NOT_IN_CORPUS with no guesswork in between."));
B.push(body("The bridge-exposure theorem proves the discipline on the full report: findings are exposed on every row, conflicts surface in the tier field, and only Theta-satisfying approved candidates rank EVIDENCED. The test battery hides a conflict inside a tampered report and confirms the theorem fails."));

// ---- 7 benchmark
B.push(h2("P4-4. The temporal benchmark"));
B.push(body("Predictions are generated as if in 2015: only molecules with ChEMBL first_approval before 2015, only disease channels with pre-2015 citations, only precedent classes anchored by pre-2015 trials. The ground truth is the six post-2015 repurposing outcomes in the pack. Results per disease (k = 10; sixteen candidates per disease):"));
B.push(dataTable([14, 36, 14, 14, 22],
  ["Disease", "Truth pairs and pre-2015 ranks", "Recall@10", "Separated", "Signal"],
  [
    ["HFREF", "dapagliflozin #7, empagliflozin #8 (adjacent, no precedent; RAAS/MRA precedent drugs rank 1-5)", "1.0", "yes", "honest 2015 frontier"],
    ["HFPEF", "dapagliflozin #1, empagliflozin #2, canagliflozin #3 (adjacent via cardiorenal bridge)", "1.0", "yes", "plan-named case: top-1"],
    ["CKD", "dapagliflozin #6, empagliflozin #7 (direct renal-glucose channel, no precedent)", "1.0", "yes", "frontier beside RAAS"],
    ["DKD", "canagliflozin #8 (direct renal-glucose channel)", "1.0", "yes", "frontier beside RAAS"],
  ]));
B.push(body("Macro recall@10 = 1.0 with separation from zero-support candidates on all four diseases: every truth pair outranks every candidate with no channel evidence, which is the non-trivial claim - the law channel discriminates, it does not merely include. The false-lead sections name the top-ranked pre-2015 candidates that did not translate into post-2015 outcomes (for example the ARBs ranked above the gliflozins in HFrEF), because a benchmark that only reports its wins is marketing, not measurement. Finerenone (2021) and semaglutide (2017) serve as named negative controls for temporal hermeticity: both are absent from every candidate list, structurally, because the prediction pipeline can only see molecules with first_approval before 2015. The hermeticity theorem proves the stronger statement: deleting every post-2015 record from the pack - ground truth, evidence rows, molecules - and re-running the prediction reproduces the original rankings bit for bit."));
B.push(body("Four theorems run on every benchmark (all PROVEN_MATH, zero counterexamples): status discipline (P4-2), Theta_d bridge exposure (P4-3), temporal hermeticity (P4-4) and candidate determinism under input permutation."));

// ---- 8 cascade
B.push(h2("Verification and cascade"));
B.push(body("The phase-4 battery passes 9 of 9 checks: pin discipline with tamper refusal; the anti-fabrication source gate; a verbatim cross-check of every drug record, citation year and disease id in the pack against the machine-verified values file; the law channel and its axes; the status and bridge theorems with negative controls; hermeticity with named controls; benchmark acceptance; connector AST isolation plus the pure-data check on the pack plus the live-driver refusal; and the claim-tier language scan. The full cascade runs 13 of 13 stages at exit 0 and the four hash-pinned v14.1 files keep their baseline sha256. One environment note is recorded in the changelog: the sandbox had lost its RDKit install, which was restored from the Phase 1 pin (rdkit 2026.09.2, exact version match) because the structure engines need it at import time."));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/tests/test_v15_phase4.py               # 9/9 checks",
  "python3 v15/write_phase4_artifacts.py              # exit 0",
  "python3 v15/connectors/refresh_phase4_cache.py --live   # idempotent",
  "python3 v15/kb_extensions/freeze_repurposing.py    # re-pin after edits",
  "python3 v15/run_full_regression.py                 # 13/13 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));

// ---- 9 honest limits
B.push(h2("Honest limits"));
B.push(body("Indication membership rows are an undated 2026 snapshot; they drive current-era status labels only, never the pre-2015 prediction axes. The HFREF profile carries no beta-blocker channel because no pre-2015 beta-blocker citation was verified in this freeze - a channel without an anchor is not invented, and carvedilol therefore earns no direct support. The platform did not serve approval rows for two verified trial outcomes (empagliflozin in HFrEF, dapagliflozin in HFpEF); the gaps are recorded in the ground-truth notes and both pairs carry the EXPERIMENTALLY_VALIDATED status with the trial citations. UniProt function excerpts are current records and never support temporal claims. ChEMBL first-approval years are served as-is. Ranking aggregates are COMPUTATIONAL_RANK hints, not probabilities; statuses are data-derived labels, not efficacy claims; nothing in this round claims clinical validity."));

// ---- 10 next steps
B.push(h2("Next steps (Phase 5)"));
B.push(body("Phase 5 turns to novel molecule discovery (Module D): SMILES input validation and the fingerprint space over the corpus molecules, RDKit-based property prediction labelled PREDICTED_RULEBASED, the model registry with per-model provenance for ADMET outputs labelled PREDICTED_ML, and the law-scaffold-guided generation pipeline with the truth-in-labeling theorem requiring every emitted molecule to carry KNOWN_MOLECULE or GENERATED_CANDIDATE status. The repurposing engine's candidate list becomes one of its input channels; the contradiction scan extends to generated structures satisfying the same class laws."));

// ---- Appendix
B.push(h1("Appendix A. Reproduce This Round"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/tests/test_v15_phase4.py                 # 9/9 checks",
  "python3 v15/write_phase4_artifacts.py                # benchmark + report files",
  "python3 v15/connectors/refresh_phase4_cache.py --live  # idempotent freeze",
  "python3 v15/connectors/refresh_phase4_cache.py       # refuses without --live",
  "python3 v15/kb_extensions/freeze_repurposing.py      # re-pin after edits",
  "python3 v15/run_full_regression.py                   # 13/13 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));
B.push(body("Artifacts of this round: v15/repurposing_data.py (frozen, pinned), v15/repurposing.py (loader, law channel, statuses, Theta bridge, theorems, temporal benchmark), v15/connectors/chembl.py plus the Phase 4 additions to opentargets.py and uniprot.py and the live refresh driver, v15/kb_extensions/repurposing_pins.json with freeze_repurposing.py, v15/out/phase4_verified_values.json and phase4_benchmark.json and phase4_benchmark.txt, the phase-4 test battery, the changelog entry and this report. The change log (docs/CHANGELOG.md, entry v15 Phase 4) lists every file touched with reasons and reproduction commands.", { after: 200 }));

// ================================================================== DOCUMENT
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: F, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FH, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FH, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FH, size: 24, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 200, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: cover
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: buildCoverR1({
        title: "APEIRON-X v15 Drug Repurposing",
        subtitle: "Phase 4: Module C frozen repurposing pack, compatibility law channel, the Theta_d consistency bridge and the temporal hermeticity benchmark",
        englishLabel: "APEIRON-X V15 PROGRAM",
        metaLines: [
          "Round: v15 Phase 4 (P4-1 pack, P4-2 statuses, P4-3 Theta bridge, P4-4 temporal benchmark)",
          "Evidence: 18 verified drugs, 13 verified citations, 6 post-2015 outcomes",
          "Benchmark: macro recall@10 = 1.0 over 4 diseases / 6 outcomes (pre-2015 view)",
          "Gate: full cascade 13/13 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],
        footerLeft: "APEIRON-X Computational Drug-Discovery Platform",
        footerRight: "v15 Phase 4 Report",
        palette: PAL,
      }),
    },
    { // Section 2: front matter (TOC) — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 240, after: 160 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FH, color: PAL.primary })],
        }),
        new Paragraph({
          spacing: { after: 80 },
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: F })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
      ],
    },
    { // Section 3: body — Arabic, restart at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: bodyHeader() },
      footers: { default: pageFooter() },
      children: B,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON-X_v15_Phase4_Drug_Repurposing.docx", buf);
  console.log("written: APEIRON-X_v15_Phase4_Drug_Repurposing.docx");
});
