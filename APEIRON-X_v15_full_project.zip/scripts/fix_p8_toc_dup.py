#!/usr/bin/env python3
"""Remove the stray hyperlink+PAGEREF paragraph inside the TOC field of
the Phase 8 report docx.

The docx-js TableOfContents field, after the placeholder script's
split-run fix, carries one cached hyperlink entry (heading 1 with a
PAGEREF field that has no cached page number). The placeholder pass
already inserts the full 12-entry list with page numbers, so the cached
entry duplicates the first line in every renderer. This script deletes
that single paragraph, leaving the clean placeholder list (Word's
"Update Field" still regenerates live entries on demand).
"""
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

DOCX = sys.argv[1] if len(sys.argv) > 1 else \
    "/home/z/my-project/download/APEIRON-X_v15_Phase8_Integration.docx"

tmpdir = tempfile.mkdtemp()
with zipfile.ZipFile(DOCX) as z:
    z.extractall(tmpdir)

doc_path = Path(tmpdir) / "word" / "document.xml"
doc = doc_path.read_text(encoding="utf-8")

m = re.search(r"<w:hyperlink[^>]*>(?:(?!</w:hyperlink>).)*?PAGEREF"
              r"(?:(?!</w:hyperlink>).)*?</w:hyperlink>", doc, flags=re.S)
if not m:
    print("no hyperlink+PAGEREF entry found - nothing to do")
    sys.exit(0)

# surgical: remove ONLY the hyperlink element (which carries the nested
# PAGEREF field); the enclosing paragraph holds the OUTER TOC field runs
# (fldChar begin + instrText TOC + separate) and must stay intact.
seg = m.group(0)
doc = doc[:m.start()] + doc[m.end():]
doc_path.write_text(doc, encoding="utf-8")
assert 'fldCharType="begin"' in doc and "TOC" in doc, \
    "outer TOC field must survive"

out = Path(DOCX + ".tmp")
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zipf:
    for f in Path(tmpdir).rglob("*"):
        if f.is_file():
            zipf.write(f, f.relative_to(tmpdir))
Path(DOCX).unlink()
shutil.move(str(out), DOCX)
print(f"removed duplicate hyperlink entry ({len(seg)} bytes); "
      f"outer TOC field preserved; docx rewritten")
