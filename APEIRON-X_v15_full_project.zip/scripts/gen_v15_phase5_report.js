// APEIRON-X v15 — Phase 5 Novel Molecule Discovery (deliverable docx)
// Skill-compliant: R1 cover recipe (DS-1), 3-section numbering, TOC field +
// refresh hint, three-line tables, postcheck-ready. Same architecture as the
// Phase 1/2 generators (validated), content replaced.
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, SectionType,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  TableLayoutType, TableOfContents,
} = require("docx");
const fs = require("fs");

// ---------------------------------------------------------------- palette (DS-1 Deep Sea)
const PAL = {
  bg: "0B1C2C", accent: "529286",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "529286", headerText: "FFFFFF", accentLine: "529286", innerLine: "BECFCC", surface: "E8ECEB" },
  primary: "0B1C2C", body: "000000", secondary: "5B6B7D",
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ------------------------------------------------------- title layout (English-aware width)
function textWidthTwips(text, pt) {
  let w = 0;
  for (const ch of text) w += /[\u4e00-\u9fff]/.test(ch) ? pt * 20 : pt * 11;
  return w;
}
function splitTitleLines(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const wd of words) {
    const cand = cur ? cur + " " + wd : wd;
    if (textWidthTwips(cand, pt) <= maxWidthTwips || !cur) cur = cand;
    else { lines.push(cur); cur = wd; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLines(title, maxWidthTwips, titlePt);
    if (lines.length <= 3 && lines.every(l => textWidthTwips(l, titlePt) <= maxWidthTwips)) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(p) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = p;
  const SAFETY = 1200;
  const usable = pageHeight - marginTop - marginBottom - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (12 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (10 * 23 + 100);
  const implicit = 3 * 300;
  const content = titleH + subH + engH + metaH + fixedHeight + implicit;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(remaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ------------------------------------------------------------------ cover recipe R1
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.cover.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.cover.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.cover.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        ", size: 16, color: P.cover.footerColor }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders, children,
      })],
    })],
  })];
}

// ------------------------------------------------------------------ body helpers
const F = { ascii: "Times New Roman", eastAsia: "SimSun" };
const FH = { ascii: "Times New Roman", eastAsia: "SimHei" };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: PAL.primary, font: FH })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: PAL.primary, font: FH })],
  });
}
function body(text, opts = {}) {
  const runs = Array.isArray(text) ? text : [new TextRun({ text, size: 24, color: PAL.body, font: F })];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: opts.after !== undefined ? opts.after : 120 },
    children: runs,
  });
}
function caption(text) {
  return new Paragraph({
    keepNext: true, spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: PAL.secondary, font: FH })],
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      spacing: { line: 312 },
      children: [new TextRun({ text, size: opts.header ? 21 : 20,
        bold: !!opts.header, color: opts.header ? PAL.table.headerText : PAL.body,
        font: opts.header ? FH : F })],
    })],
    shading: opts.header ? { type: ShadingType.CLEAR, fill: PAL.table.headerBg }
      : (opts.zebra ? { type: ShadingType.CLEAR, fill: PAL.table.surface } : undefined),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
  });
}
function dataTable(widths, header, rows, zebra = true) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: header.map((t, i) => cell(t, { header: true, width: widths[i] })),
      }),
      ...rows.map((r, ri) => new TableRow({
        cantSplit: true,
        children: r.map((t, i) => cell(t, { width: widths[i], zebra: zebra && ri % 2 === 1 })),
      })),
    ],
  });
}
function codeBlock(lines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      left: { style: BorderStyle.SINGLE, size: 12, color: PAL.table.accentLine },
      right: NB, insideHorizontal: NB, insideVertical: NB,
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: "F4F7F6" },
        margins: { top: 120, bottom: 120, left: 200, right: 160 },
        children: lines.map(l => new Paragraph({
          spacing: { line: 312, after: 20 },
          children: [new TextRun({ text: l, size: 18, color: "24313B", font: { ascii: "Courier New", eastAsia: "SimSun" } })],
        })),
      })],
    })],
  });
}

// ------------------------------------------------------------------ footers/headers
function pageFooter() {
  return new Footer({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: F })],
  })] });
}
function bodyHeader() {
  return new Header({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine, space: 4 } },
    children: [new TextRun({ text: "APEIRON-X v15 Phase 5 Report", size: 18, color: "808080", font: F })],
  })] });
}

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

// ================================================================== BODY CONTENT
const B = [];

// ---- 1 Executive Summary
B.push(body("This report closes Phase 5 of the APEIRON-X v15 program: novel molecule discovery (Module D). The phase adds a chemistry layer and a generation pipeline to the platform without touching a single line of the proved v14.1 engine - all four hash-pinned corpus files kept their sha256, and the acceptance cascade now runs 14 of 14 stages at exit 0. The acceptance clause of the plan is met on both counts: the round-trip SMILES -> features -> laws check reproduces the v14.1 feature vectors and re-certifies every proved structure law on all 191 KB molecules unchanged (zero chi mismatches, 117 laws re-certified, zero member violations, zero false positives), and 100 generated molecules all pass the validity and labeling tests. Five theorems run on the emitted report, all PROVEN_MATH with zero counterexamples."));
B.push(body("The design principle of the round is visible refusal rather than silent invention. The ADMET model registry ships deliberately EMPTY - no validated machine-learning model exists in this round, so the PREDICTED_ML lane has zero entries and every prediction request is refused by name; rule-based triage values live in their own lane, labeled PREDICTED_RULEBASED on every block. No docking run record exists anywhere, so no structure carries a docking statement - the gate accepts only a complete record (structure identifier and source, software, version, protocol, run timestamp) and raises otherwise. Every generated molecule carries the claims block binding=NO_CLAIM / efficacy=NO_CLAIM / docking=NO_DOCKING_RUN_RECORD, and the new truth-in-labeling theorem (P5-5) scans every text field of every record for claim language; four negative controls in the test battery confirm the theorem fails when a fabricated claim, a smuggled note, an illegal status or a docking claim is planted."));

// ---- 2 Scope and doctrine
B.push(h2("Scope and doctrine"));
B.push(body("Module D consumes the v14.1 engines read-only. The structure feature space (118 SMARTS patterns, 26 descriptor features, 33 negation features) and the proved structure laws L_c are imported from the hash-pinned v12.1 engine and are never redefined in v15; what v15 adds is a versioned manifest (APEIRON-FEATSPACE-P1-v15, tables sha256 recorded), an additive Tanimoto similarity lane, and the query machinery. The derivation modules import no connector code (machine-checked by AST scan in the phase-5 battery); the ChEMBL novelty lane reads the FROZEN Phase 4 cache payload files directly from disk. Generation is deterministic by construction - no random search, a doctrine carried from the v14.1 core: the seed list is sorted, the substituent library is fixed and ordered, reaction products are enumerated in deterministic order, and the generation-determinism theorem proves that two independent runs agree bit for bit. Ranking aggregates are labeled COMPUTATIONAL_RANK - a rank hint, never a probability, never a predicted activity."));

// ---- 3 chem package
B.push(h2("P5-1 to P5-3. The chem package"));
B.push(body("The phase ships a four-module chemistry package under v15/chem/ with an explicit honesty lane on every output:"));
B.push(dataTable([16, 46, 20, 18],
  ["Module", "Content", "Output labels", "Plan item"],
  [
    ["mol_io", "SMILES sanitize/validate + canonicalisation with visible refusal reasons; frozen feature-space manifest (118+26+33 features, tables sha256 af1c95aa5e993fef...); Tanimoto lane; substructure search; law queries re-evaluating proved L_c certificates on freshly computed features", "deterministic computations", "P5-1"],
    ["props", "Exact RDKit descriptors (MW, cLogP, TPSA, HBD/HBA, rotatable bonds, rings, Fsp3); Lipinski 1997 and Veber 2002 rule-of-thumb windows with named threshold sources; coarse solubility/permeability buckets with the rule text inlined", "PREDICTED_RULEBASED (never measured)", "P5-2"],
    ["admet", "Model registry schema requiring per-model version, training provenance and a validation sheet - shipped EMPTY (zero models, absence reported); PAINS/Brenk structural alerts via RDKit filter catalogs with version recorded; the hard docking gate", "PREDICTED_ML lane: zero entries; alerts: PREDICTED_RULEBASED flags", "P5-3"],
    ["generate", "Deterministic law-guided enumeration with recorded rejections and transparent five-axis ranking", "COMPUTATIONAL_RANK aggregate", "P5-4"],
  ]));
B.push(body("The law queries deserve one precise sentence: a generated molecule satisfies a law L_c when one DNF term of the already-proved certificate is fully contained in the molecule's freshly recomputed feature set. That is a class-pharmacophore compatibility statement on the closed KB corpus - it is never a target-activity claim, and the emitted records carry exactly that qualification."));

// ---- 4 P5-4 pipeline
B.push(h2("P5-4. The generation pipeline"));
B.push(body("Seeds are the law-satisfying scaffolds: KB molecules whose recomputed feature set satisfies at least one proved structure law. The edit is a single-site aromatic-CH substitution from a fixed ordered substituent library (F, Cl, CH3, OH, OCH3, CN, NH2, CF3) applied through reaction SMARTS - standard matched-analog enumeration, one site per candidate, products sanitized and canonical-round-tripped. Four gates then run, and every rejection is RECORDED with its reason and seed - nothing is silently dropped: chemical validity (sanitize, single fragment, heavy-atom cap), novelty against the frozen reference corpus, PAINS/Brenk alerts, and law plausibility (satisfies at least one proved law after the edit). The reference corpus is the 191-molecule frozen KB corpus plus the 17 ChEMBL structures frozen in the Phase 4 cache; the one ChEMBL molecule whose frozen record carries no structure (CHEMBL2108724) is listed as a recorded absence, not guessed."));
B.push(dataTable([30, 12, 58],
  ["Gate outcome", "Count", "Meaning"],
  [
    ["Emitted candidates", "100", "valid, single-component, novel vs the corpus, alert-free, law-plausible"],
    ["Rejected: toxicity_alert", "168", "PAINS/Brenk rule hit; kept visible with the alert text (the catalogs are conservative: aspirin itself carries a Brenk phenol-ester flag)"],
    ["Rejected: no_law_plausibility", "10", "satisfies no proved law after the edit; kept visible"],
    ["Rejected: validity/novelty/other", "0", "no invalid products survived sanitization; every product was novel"],
    ["Products evaluated", "278", "over 13 law-satisfying seeds scanned before the quota filled"],
  ]));
B.push(body("One consequence of the deterministic ordering is documented rather than hidden: the quota fills from the alphabetically first seeds, so this run's 100 candidates derive from five seeds (allopurinol, anastrozole, amoxicillin, apixaban, aprepitant) with all eight substituents represented. The run is reproducible bit for bit (config sha256 93f4a84fce0c6918...); a different quota or seed ordering is a one-line configuration change, not a code change."));
B.push(dataTable([12, 40, 16, 18, 14],
  ["Rank", "Candidate (canonical SMILES, truncated)", "Seed", "Laws satisfied (top 2)", "Aggregate"],
  [
    ["APXD-0001", "Nc1nc2[nH]ncc2c(=O)[nH]1", "allopurinol", "SODIUM_CHANNEL_BLOCKER_AED, XANTHINE_OXIDASE_INHIBITOR", "0.6895"],
    ["APXD-0002", "CC(C)(C#N)c1cc(Cn2cnc(N)n2)cc(C(C)(C)C#N)c1", "anastrozole", "AROMATASE_INHIBITOR, NRTI_REVERSE_TRANSCRIPTASE", "0.6891"],
    ["APXD-0003", "Nc1n[nH]c2nc[nH]c(=O)c12", "allopurinol", "SODIUM_CHANNEL_BLOCKER_AED, XANTHINE_OXIDASE_INHIBITOR", "0.6874"],
    ["APXD-0004", "CC(C)(C#N)c1cc(Cn2cncn2)cc(C(C)(C)C#N)c1O", "anastrozole", "AROMATASE_INHIBITOR, HIV_INTEGRASE_INHIBITOR", "0.6869"],
    ["APXD-0008", "CC1(C)SC2C(NC(=O)C(N)c3ccc(O)c(C(F)(F)F)c3)C(=O)N2C1C(=O)O", "amoxicillin", "BETA_LACTAM_CELLWALL, NPC1L1_INHIBITOR", "0.6686"],
    ["APXD-0010", "COc1cc(C(N)C(=O)NC2C(=O)N3C2SC(C)(C)C3C(=O)O)ccc1O", "amoxicillin", "ACETYLCHOLINESTERASE_INHIBITOR, BETA_LACTAM_CELLWALL", "0.6329"],
  ]));
B.push(body("Properties of the emitted set (all PREDICTED_RULEBASED computations, reported as computed): 86 of 100 pass at least three of the four Lipinski windows; mean synthetic-accessibility estimate 3.37 on the 1-10 Ertl-Schuffenhauer scale; mean nearest-corpus Tanimoto distance 0.147 (the analogs are deliberately close to their law-satisfying seeds); mean number of satisfied laws 1.11; every emitted molecule carries zero structural alerts, five transparent axes and the full claims block. The axes are novelty distance, drug-likeness windows, synthetic-accessibility estimate, law plausibility and seed conservation - each displayed individually on every record; the aggregate is their arithmetic mean, labeled COMPUTATIONAL_RANK."));

// ---- 5 round trip
B.push(h2("The round-trip theorem (acceptance clause 1)"));
B.push(body("The plan requires the SMILES -> features -> laws round-trip on all 191 KB molecules to be unchanged. The theorem recomputes every component feature vector independently from the frozen tables (fresh parse, fresh SMARTS matching, fresh de Morgan negations) and requires exact equality with the cached v14.1 layer vectors; it then re-runs every proved law over the fresh vectors with the v14.1 semantics (same-molecule and component-split) and requires every class member to satisfy its law and every covered non-sibling KB drug to fail it. Result: 191 of 191 molecules identical, 117 proved laws re-certified, zero member violations, zero false positives. The generation pipeline then relies on the same machinery at run time, and the test battery re-verifies each emitted candidate's claimed laws by recomputation - a planted false law claim fails the battery."));

// ---- 6 P5-5
B.push(h2("P5-5. Truth-in-labeling"));
B.push(body("The new S-class obligation is machine-checked on the whole report: every molecule record (100 emitted + 178 rejected + 208 KNOWN_MOLECULE reference rows) carries exactly one status from the two-value vocabulary {KNOWN_MOLECULE, GENERATED_CANDIDATE}; every generated record carries the claims block binding=NO_CLAIM / efficacy=NO_CLAIM; and every string leaf of every record - SMILES, notes, rule texts, alert descriptions - is scanned for claim language (a ten-token banned list including binding-affinity and effectiveness phrasing). Four negative controls confirm the theorem bites: a record with claims.binding=BINDS_TARGET_X fails; a note carrying a fabricated effectiveness statement fails; an illegal status WONDER_DRUG fails; and a docking claim without a run record fails the docking theorem. The no-docking-claims theorem additionally proves that all 278 molecule records carry the NO_DOCKING_RUN_RECORD sentinel, since no docking run record exists in this round."));

// ---- 7 cascade
B.push(h2("Verification and cascade"));
B.push(body("The phase-5 battery passes 9 of 9 checks: the feature-space manifest (118+26+33 features with a stable sha256) and the mol_io gates; the round-trip theorem; the property labels with a cross-check against the v14.1 layer's own component info; the registry, docking and alert discipline; the generation pipeline including per-record recomputation; truth-in-labeling with the four negative controls; frozen-file integrity against the baseline sha256 snapshot; derivation/connector AST isolation plus artifact integrity; and the claim-tier language scan. The full cascade runs 14 of 14 stages at exit 0 - the five v14.1 batteries, three demos, the novel-disease harness, the smoke test and the five v15 batteries - and the four hash-pinned v14.1 files keep their baseline sha256. The environment note from Phase 4 repeats: the sandbox had lost its RDKit install, which was restored from the Phase 1 pin (rdkit 2026.09.2, exact version match) and recorded in the changelog."));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/tests/test_v15_phase5.py               # 9/9 checks",
  "python3 v15/write_phase5_artifacts.py              # exit 0",
  "python3 v15/run_full_regression.py                 # 14/14 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));

// ---- 8 honest limits
B.push(h2("Honest limits"));
B.push(body("Generated molecules are COMPUTATIONAL-tier research candidates; no binding, activity or clinical statement is made for any structure, and none may be inferred from a law match. The ADMET registry is deliberately empty; solubility and permeability classes are coarse binned rules, not measured or mechanistic values; the synthetic-accessibility axis is a heuristic estimate, not a synthesis plan. Novelty is checked against the frozen 208-structure reference corpus, not against a live global database - a structure identical to a molecule outside the corpus would not be detected. PAINS/Brenk alerts are conservative rule flags that also trigger on established market drugs, which is why alert-bearing rejections are recorded rather than treated as verdicts. The law-plausibility axis is class-pharmacophore compatibility on the closed KB corpus. The alphabetically seeded quota fill concentrates this run's candidates on five scaffolds - a documented consequence of deterministic ordering, reproducible and configurable."));

// ---- 9 next steps
B.push(h2("Next steps (Phase 6)"));
B.push(body("Phase 6 turns to the mathematical reasoning extensions (Module E): typed knowledge-graph edges with evidence tiers and sha256 provenance, the new proof obligations (graph consistency, provenance completeness, uncertainty propagation, out-of-domain detection for v15 profiles), the fingerprint-portability gate that pins the frozen identity laws to rdkit 2026.09.2, and memoized coupling with a determinism theorem. The chem package's manifest and the generation config hash from this round become inputs to the reproducibility obligations."));

// ---- Appendix
B.push(h1("Appendix A. Reproduce This Round"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/tests/test_v15_phase5.py                 # 9/9 checks",
  "python3 v15/write_phase5_artifacts.py                # benchmark + report files",
  "python3 v15/run_full_regression.py                   # 14/14 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));
B.push(body("Artifacts of this round: v15/chem/ (mol_io.py, props.py, admet.py, generate.py - the P5-1..P5-4 package), v15/molecular.py (Module D facade: reference corpus, five theorems, module run), v15/write_phase5_artifacts.py with v15/out/phase5_benchmark.json and phase5_benchmark.txt, the phase-5 test battery, the cascade extension to 14 stages, the changelog entry and this report. The change log (docs/CHANGELOG.md, entry v15 Phase 5) lists every file touched with reasons and reproduction commands.", { after: 200 }));
// ================================================================== DOCUMENT
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: F, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FH, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FH, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FH, size: 24, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 200, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: cover
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: buildCoverR1({
        title: "APEIRON-X v15 Molecular Discovery",
        subtitle: "Phase 5: Module D chem package, deterministic law-guided generation, the round-trip theorem on 191 molecules and the truth-in-labeling obligation",
        englishLabel: "APEIRON-X V15 PROGRAM",
        metaLines: [
          "Round: v15 Phase 5 (P5-1 chem IO, P5-2 properties, P5-3 registry, P5-4 generation, P5-5 labeling)",
          "Evidence: 191 KB molecules unchanged, 117 laws re-certified, 100 candidates emitted",
          "Benchmark: 100/100 valid + labeled; 178 rejections recorded, 0 silent drops",
          "Gate: full cascade 14/14 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],
        footerLeft: "APEIRON-X Computational Drug-Discovery Platform",
        footerRight: "v15 Phase 5 Report",
        palette: PAL,
      }),
    },
    { // Section 2: front matter (TOC) — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 240, after: 160 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FH, color: PAL.primary })],
        }),
        new Paragraph({
          spacing: { after: 80 },
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: F })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
      ],
    },
    { // Section 3: body — Arabic, restart at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: bodyHeader() },
      footers: { default: pageFooter() },
      children: B,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON-X_v15_Phase5_Molecular_Discovery.docx", buf);
  console.log("written: APEIRON-X_v15_Phase5_Molecular_Discovery.docx");
});
