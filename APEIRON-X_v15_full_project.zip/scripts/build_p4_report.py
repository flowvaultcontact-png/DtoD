#!/usr/bin/env python3
"""Build scripts/gen_v15_phase4_report.js from the validated Phase 3
generator (same R1-cover architecture), replacing the content block,
cover config and output path. Keeps every skill-compliant structural
decision intact."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "gen_v15_phase3_report.js")
CONTENT = os.path.join(HERE, "p4_content.js")
OUT = os.path.join(HERE, "gen_v15_phase4_report.js")

src = open(SRC, encoding="utf-8").read()
content = open(CONTENT, encoding="utf-8").read()
if not content.endswith("\n"):
    content += "\n"

# 1. header comment
src = src.replace(
    "// APEIRON-X v15 — Phase 3 Biological Target Discovery (deliverable docx)",
    "// APEIRON-X v15 — Phase 4 Drug Repurposing (deliverable docx)", 1)

# 2. content region replacement (from first content marker to the DOCUMENT banner)
start_marker = "// ---- 1 Executive Summary"
end_marker = "// ================================================================== DOCUMENT"
i = src.index(start_marker)
j = src.index(end_marker)
src = src[:i] + content + src[j:]

# 3. running header + cover config
src = src.replace('text: "APEIRON-X v15 Phase 3 Report"',
                  'text: "APEIRON-X v15 Phase 4 Report"', 1)
src = src.replace('title: "APEIRON-X v15 Target Discovery"',
                  'title: "APEIRON-X v15 Drug Repurposing"', 1)
src = src.replace(
    'subtitle: "Phase 3: Module B frozen evidence table, frozen-response '
    'connectors, transparent ranking and the anti-causal-illusion theorem"',
    'subtitle: "Phase 4: Module C frozen repurposing pack, compatibility '
    'law channel, the Theta_d consistency bridge and the temporal '
    'hermeticity benchmark"', 1)
old_meta = '''        metaLines: [
          "Round: v15 Phase 3 (P3-1 table, P3-2 scoring, P3-3 theorem, P3-4 connectors)",
          "Evidence: 16 verified targets, 11 verified citations, 117 frozen responses",
          "Benchmark: macro recall@10 = 1.0 over 10 diseases / 16 guideline targets",
          "Gate: full cascade 12/12 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
new_meta = '''        metaLines: [
          "Round: v15 Phase 4 (P4-1 pack, P4-2 statuses, P4-3 Theta bridge, P4-4 temporal benchmark)",
          "Evidence: 18 verified drugs, 13 verified citations, 6 post-2015 outcomes",
          "Benchmark: macro recall@10 = 1.0 over 4 diseases / 6 outcomes (pre-2015 view)",
          "Gate: full cascade 13/13 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
assert old_meta in src, "metaLines block not found"
src = src.replace(old_meta, new_meta, 1)
src = src.replace('footerRight: "v15 Phase 3 Report"',
                  'footerRight: "v15 Phase 4 Report"', 1)
src = src.replace(
    '"/home/z/my-project/download/APEIRON-X_v15_Phase3_Target_Discovery.docx"',
    '"/home/z/my-project/download/APEIRON-X_v15_Phase4_Drug_Repurposing.docx"', 1)
src = src.replace('console.log("written: APEIRON-X_v15_Phase3_Target_Discovery.docx")',
                  'console.log("written: APEIRON-X_v15_Phase4_Drug_Repurposing.docx")', 1)

# sanity: no Phase 3 content markers survived
for leftover in ("P3-1 frozen target", "anti-causal-illusion theorem",
                 "Phase 3: Module B", "Phase3_Target_Discovery"):
    assert leftover not in src, leftover
assert src.count("// ---- 1 Executive Summary") == 1
assert "recall@10" in src and "Theta_d" in src

open(OUT, "w", encoding="utf-8").write(src)
print(f"wrote {OUT} ({len(src)} chars)")
