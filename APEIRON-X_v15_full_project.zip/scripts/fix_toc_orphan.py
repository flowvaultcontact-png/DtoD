#!/usr/bin/env python3
"""Remove ONLY the orphan static TOC placeholder paragraph(s) that sit
OUTSIDE the TOC field region (field depth 0, no fldChar/instrText/
PAGEREF). Field-internal placeholders are left alone: Word/LibreOffice
re-render the field result wholesale, so they never display twice.
Idempotent; rebuilds document.xml by clean chunk interleaving."""
import os
import re
import shutil
import sys
import zipfile


def fix(path: str) -> int:
    tmp = path + ".tmpzip"
    shutil.copy(path, tmp)
    with zipfile.ZipFile(tmp) as z:
        xml = z.read("word/document.xml").decode("utf-8")
        names = z.namelist()
        others = {n: z.read(n) for n in names if n != "word/document.xml"}

    paras = []
    chunks = []
    pos = 0
    for m in re.finditer(r'<w:p\b.*?</w:p>', xml, flags=re.S):
        chunks.append(xml[pos:m.start()])
        paras.append(m.group(0))
        pos = m.end()
    chunks.append(xml[pos:])
    assert len(chunks) == len(paras) + 1

    field_depth = 0
    keep = []
    removed = 0
    for p in paras:
        is_static_toc = (re.search(r'w:pStyle w:val="TOC[1-3]"', p)
                         and 'fldChar' not in p
                         and 'instrText' not in p
                         and 'PAGEREF' not in p)
        if is_static_toc and field_depth == 0:
            keep.append(False)
            removed += 1
        else:
            keep.append(True)
        field_depth += p.count('w:fldCharType="begin"')
        field_depth -= p.count('w:fldCharType="end"')
        field_depth = max(0, field_depth)

    if removed:
        res = [chunks[0]]
        for p, k, c in zip(paras, keep, chunks[1:]):
            if k:
                res.append(p)
            res.append(c)
        new_xml = "".join(res)
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            for n in names:
                if n == "word/document.xml":
                    z.writestr(n, new_xml)
                else:
                    z.writestr(n, others[n])
    os.remove(tmp)
    return removed


if __name__ == "__main__":
    for p in sys.argv[1:]:
        n = fix(p)
        print(f"{p}: removed {n} orphan TOC paragraph(s)")
