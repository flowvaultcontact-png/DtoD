#!/usr/bin/env python3
"""v14.1 smoke test: anti-collapse laws + guideline-drift rows."""
import sys
sys.path.insert(0, "/home/z/my-project/apeiron")

import disease_drug_kb as KB
from apeiron_drug_discovery_proof import DrugOracle, mech_of, phi_dict, classify_by_laws
from apeiron_structure_proof import (
    StructLayer, derive_structure_laws, derive_drug_laws,
    derive_drug_channel_laws, GenericOracle,
)

from collections import Counter

print("validate_kb:", KB.validate_kb() or "OK")
print("n_diseases:", len(KB.DISEASES))

o = DrugOracle(KB.DISEASES)
o.learn()  # raises on non-injective encoding

depth_hist = Counter()
degen = 0
for cls, law in o.class_laws.items():
    for t in law["terms_detail"]:
        depth_hist[len(t["channels"])] += 1
    degen += law.get("degenerate_terms", 0)
print("class-law term depth histogram:", dict(depth_hist), "| degenerate:", degen)
print("SGLT2 class law present:", "SGLT2_INHIBITOR" in o.class_laws)
print("SGLT2 law terms:", o.class_laws["SGLT2_INHIBITOR"]["terms_detail"])
print("AMPHETAMINE law terms:", o.class_laws["AMPHETAMINE_RELEASER"]["terms_detail"])
print("ACEI law terms:", o.class_laws["ACEI_RAAS"]["terms_detail"])

# exclusivity on D: exactly one class fires per row (T1-style check)
bad = []
for r in KB.DISEASES:
    fired = classify_by_laws(o.class_laws, phi_dict(r))
    if fired != [mech_of(r)]:
        bad.append((r["did"], fired))
print("T1 exclusivity violations:", bad or "none")

print("\nbuilding structure layer (RDKit)...")
layer = StructLayer()
laws, excluded = derive_structure_laws(layer, verbose=False)
chem_groups, drug_laws = derive_drug_laws(layer, verbose=False)
dcl = derive_drug_channel_laws(KB.DISEASES)
gen = GenericOracle(KB.DISEASES, o, layer, laws,
                    drug_channel_laws=dcl, drug_laws=drug_laws)
print("structure laws:", len(laws), "| drug-channel laws:", len(dcl))
sg = laws.get("SGLT2_INHIBITOR")
print("SGLT2 structure law proved:", sg and sg["proved"], "| features:", sg["law_features"][:4] if sg else None)

# drug-channel law depth check
dh = Counter()
dg = 0
for g, cert in dcl.items():
    for t in cert["terms"]:
        dh[len(t)] += 1
    dg += 1 if cert.get("degenerate") else 0
print("drug-channel term depth histogram:", dict(dh), "| degenerate laws:", dg)

# previously-failing novel encodings (now in-domain via drift round)
A3 = {"system": "CARDIOVASCULAR", "etiology": "FUNCTIONAL_DYSREGULATION",
      "microbe": "NONE", "site": "MYOCARDIUM", "chronicity": "CHRONIC",
      "pathway": "PW_NEUROHORMONAL_REMODELING"}
A7 = {"system": "PSYCHIATRIC", "etiology": "PSYCHIATRIC", "microbe": "NONE",
      "site": "CNS_MESOLIMBIC_SYSTEM", "chronicity": "CHRONIC",
      "pathway": "PW_NORADRENERGIC_EXECUTIVE_DEFICIT"}
A8 = {"system": "CARDIOVASCULAR", "etiology": "FUNCTIONAL_DYSREGULATION",
      "microbe": "NONE", "site": "CORONARY_ARTERY", "chronicity": "CHRONIC",
      "pathway": "PW_MYOCARDIAL_O2_BALANCE"}
# genuinely novel probes (still outside the 63-row KB)
A1 = {"system": "CARDIOVASCULAR", "etiology": "VASCULAR_ATHEROTHROMBOTIC",
      "microbe": "NONE", "site": "BRAIN_CORTEX", "chronicity": "CHRONIC",
      "pathway": "PW_PLATELET_AGGREGATION"}
A2 = {"system": "CARDIOVASCULAR", "etiology": "STRUCTURAL_MECHANICAL",
      "microbe": "NONE", "site": "VENOUS_CIRCULATION", "chronicity": "ACUTE",
      "pathway": "PW_COAGULATION_CASCADE"}
A4 = {"system": "GASTROINTESTINAL", "etiology": "TOXIC_EXPOSURE",
      "microbe": "NONE", "site": "ESOPHAGUS_STOMACH", "chronicity": "CHRONIC",
      "pathway": "PW_GASTRIC_ACID_SECRETION"}
A5 = {"system": "NEUROLOGICAL", "etiology": "NEUROELECTRIC", "microbe": "NONE",
      "site": "MENINGEAL_TRIGEMINAL_SYSTEM", "chronicity": "CHRONIC",
      "pathway": "PW_CORTICAL_HYPEREXCITABILITY"}
TAKO = {"system": "CARDIOVASCULAR", "etiology": "FUNCTIONAL_DYSREGULATION",
        "microbe": "NONE", "site": "MYOCARDIUM", "chronicity": "ACUTE",
        "pathway": "PW_NEUROHORMONAL_REMODELING"}

for label, e, want in [
    ("A3 HFpEF", A3, "empagliflozin"),
    ("A7 BED", A7, "lisdexamfetamine"),
    ("A8 vasospastic", A8, "amlodipine"),
    ("A1 stroke 2nd prev", A1, "aspirin"),
    ("A2 VTE prophylaxis", A2, "apixaban"),
    ("A4 NSAID-ulcer proph", A4, "omeprazole"),
    ("A5 trigeminal neuralgia", A5, "carbamazepine"),
    ("Takotsubo (novel acute)", TAKO, "NOT ACEI (ramipril)"),
]:
    res = gen.query(e)
    fl = res.get("first_line")
    cls = res.get("mechanism_class")
    ok = "OK" if (want.startswith("NOT") and fl != "ramipril") or fl == want else "??"
    print(f"{ok:>3} {label:<26} -> {res['verdict']:<22} class={cls} first-line={fl}")
