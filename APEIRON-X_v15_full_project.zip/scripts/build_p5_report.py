#!/usr/bin/env python3
"""Build scripts/gen_v15_phase5_report.js from the validated Phase 4
generator (same R1-cover architecture), replacing the content block,
cover config and output path. Keeps every skill-compliant structural
decision intact."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "gen_v15_phase4_report.js")
CONTENT = os.path.join(HERE, "p5_content.js")
OUT = os.path.join(HERE, "gen_v15_phase5_report.js")

src = open(SRC, encoding="utf-8").read()
content = open(CONTENT, encoding="utf-8").read()
if not content.endswith("\n"):
    content += "\n"

# 1. header comment
src = src.replace(
    "// APEIRON-X v15 — Phase 4 Drug Repurposing (deliverable docx)",
    "// APEIRON-X v15 — Phase 5 Novel Molecule Discovery (deliverable docx)", 1)

# 2. content region replacement (from first content marker to the DOCUMENT banner)
start_marker = "// ---- 1 Executive Summary"
end_marker = "// ================================================================== DOCUMENT"
i = src.index(start_marker)
j = src.index(end_marker)
src = src[:i] + content + src[j:]

# 3. running header + cover config
src = src.replace('text: "APEIRON-X v15 Phase 4 Report"',
                  'text: "APEIRON-X v15 Phase 5 Report"', 1)
src = src.replace('title: "APEIRON-X v15 Drug Repurposing"',
                  'title: "APEIRON-X v15 Molecular Discovery"', 1)
src = src.replace(
    'subtitle: "Phase 4: Module C frozen repurposing pack, compatibility '
    'law channel, the Theta_d consistency bridge and the temporal '
    'hermeticity benchmark"',
    'subtitle: "Phase 5: Module D chem package, deterministic law-guided '
    'generation, the round-trip theorem on 191 molecules and the '
    'truth-in-labeling obligation"', 1)
old_meta = '''        metaLines: [
          "Round: v15 Phase 4 (P4-1 pack, P4-2 statuses, P4-3 Theta bridge, P4-4 temporal benchmark)",
          "Evidence: 18 verified drugs, 13 verified citations, 6 post-2015 outcomes",
          "Benchmark: macro recall@10 = 1.0 over 4 diseases / 6 outcomes (pre-2015 view)",
          "Gate: full cascade 13/13 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
new_meta = '''        metaLines: [
          "Round: v15 Phase 5 (P5-1 chem IO, P5-2 properties, P5-3 registry, P5-4 generation, P5-5 labeling)",
          "Evidence: 191 KB molecules unchanged, 117 laws re-certified, 100 candidates emitted",
          "Benchmark: 100/100 valid + labeled; 178 rejections recorded, 0 silent drops",
          "Gate: full cascade 14/14 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
assert old_meta in src, "metaLines block not found"
src = src.replace(old_meta, new_meta, 1)
src = src.replace('footerRight: "v15 Phase 4 Report"',
                  'footerRight: "v15 Phase 5 Report"', 1)
src = src.replace(
    '"/home/z/my-project/download/APEIRON-X_v15_Phase4_Drug_Repurposing.docx"',
    '"/home/z/my-project/download/APEIRON-X_v15_Phase5_Molecular_Discovery.docx"', 1)
src = src.replace('console.log("written: APEIRON-X_v15_Phase4_Drug_Repurposing.docx")',
                  'console.log("written: APEIRON-X_v15_Phase5_Molecular_Discovery.docx")', 1)

# sanity: no Phase 4 content markers survived
for leftover in ("P4-1 frozen repurposing", "Theta_d consistency bridge and the temporal",
                 "Phase 4: Module C", "Phase4_Drug_Repurposing"):
    assert leftover not in src, leftover
assert src.count("// ---- 1 Executive Summary") == 1
assert "round-trip" in src and "truth-in-labeling" in src

open(OUT, "w", encoding="utf-8").write(src)
print(f"wrote {OUT} ({len(src)} chars)")
