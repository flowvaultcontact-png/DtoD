#!/usr/bin/env python3
"""Remove the docx-js stub TOC entry (hyperlink with empty PAGEREF) from the
TOC field paragraph, so the field result contains only the 15 injected
placeholder entries. Prevents the duplicate '1. Executive Summary' line."""
import re
import os
import shutil
import sys
import zipfile
import tempfile

path = sys.argv[1]
tmpdir = tempfile.mkdtemp()
with zipfile.ZipFile(path) as z:
    z.extractall(tmpdir)

doc_path = os.path.join(tmpdir, "word", "document.xml")
with open(doc_path, encoding="utf-8") as fh:
    doc = fh.read()

# locate the TOC field paragraph: contains instrText starting with TOC
m = re.search(r'<w:p>(?:(?!</w:p>).)*?TOC \\h(?:(?!</w:p>).)*?</w:p>', doc, re.S)
if not m:
    print("TOC field paragraph not found - no change")
    sys.exit(0)
para = m.group(0)
para2, n = re.subn(r"<w:hyperlink[^>]*>.*?</w:hyperlink>", "", para, flags=re.S)
if n:
    doc = doc.replace(para, para2)
    print(f"removed {n} stub hyperlink entry from TOC field paragraph")
with open(doc_path, "w", encoding="utf-8") as fh:
    fh.write(doc)

newpath = path + ".tmp"
with zipfile.ZipFile(newpath, "w", zipfile.ZIP_DEFLATED) as z:
    for root, _, files in os.walk(tmpdir):
        for f in files:
            full = os.path.join(root, f)
            z.write(full, os.path.relpath(full, tmpdir))
shutil.move(newpath, path)
shutil.rmtree(tmpdir)
print("toc stub fix done")
