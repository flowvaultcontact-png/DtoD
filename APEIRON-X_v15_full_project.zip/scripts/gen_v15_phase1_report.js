// APEIRON-X v15 — Phase 1 Foundation Audit & Implementation Plan (deliverable docx)
// Skill-compliant: R1 cover recipe (DS-1), 3-section numbering (cover/roman/arabic),
// TOC field + refresh hint + page break, three-line tables, postcheck-ready.
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  PageBreak, Header, Footer, PageNumber, NumberFormat, SectionType,
  AlignmentType, HeadingLevel, WidthType, BorderStyle, ShadingType,
  TableLayoutType, TableOfContents,
} = require("docx");
const fs = require("fs");

// ---------------------------------------------------------------- palette (DS-1 Deep Sea)
const PAL = {
  bg: "0B1C2C", accent: "529286",
  cover: { titleColor: "FFFFFF", subtitleColor: "B0B8C0", metaColor: "90989F", footerColor: "687078" },
  table: { headerBg: "529286", headerText: "FFFFFF", accentLine: "529286", innerLine: "BECFCC", surface: "E8ECEB" },
  primary: "0B1C2C", body: "000000", secondary: "5B6B7D",
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB, insideHorizontal: NB, insideVertical: NB };

// ------------------------------------------------------- title layout (English-aware width)
function textWidthTwips(text, pt) {
  // CJK char ~= pt*20 twips; ASCII char ~= pt*11 twips (conservative)
  let w = 0;
  for (const ch of text) w += /[\u4e00-\u9fff]/.test(ch) ? pt * 20 : pt * 11;
  return w;
}
function splitTitleLines(title, maxWidthTwips, pt) {
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const wd of words) {
    const cand = cur ? cur + " " + wd : wd;
    if (textWidthTwips(cand, pt) <= maxWidthTwips || !cur) cur = cand;
    else { lines.push(cur); cur = wd; }
  }
  if (cur) lines.push(cur);
  if (lines.length > 1 && lines[lines.length - 1].length <= 2) {
    const last = lines.pop();
    lines[lines.length - 1] += " " + last;
  }
  return lines;
}
function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt, lines;
  while (titlePt >= minPt) {
    lines = splitTitleLines(title, maxWidthTwips, titlePt);
    if (lines.length <= 3 && lines.every(l => textWidthTwips(l, titlePt) <= maxWidthTwips)) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) { lines = splitTitleLines(title, maxWidthTwips, minPt); titlePt = minPt; }
  return { titlePt, titleLines: lines };
}
function calcCoverSpacing(p) {
  const { titleLineCount = 1, titlePt = 36, hasSubtitle = false, hasEnglishLabel = false,
          metaLineCount = 0, fixedHeight = 800, pageHeight = 16838,
          marginTop = 0, marginBottom = 0 } = p;
  const SAFETY = 1200;
  const usable = pageHeight - marginTop - marginBottom - SAFETY;
  const titleH = titleLineCount * (titlePt * 23 + 200);
  const subH = hasSubtitle ? (12 * 23 + 600) : 0;
  const engH = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaH = metaLineCount * (10 * 23 + 100);
  const implicit = 3 * 300;
  const content = titleH + subH + engH + metaH + fixedHeight + implicit;
  const remaining = Math.max(usable - content, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(remaining * 0.45), rawBottom = Math.floor(remaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(remaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ------------------------------------------------------------------ cover recipe R1
function buildCoverR1(config) {
  const P = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length, fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: P.accent, space: 12 };
  const children = [];
  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));
  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: P.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: P.accent, font: { ascii: "Calibri", eastAsia: "SimHei" }, characterSpacing: 40 })],
    }));
  }
  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300, line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: P.cover.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }
  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24, color: P.cover.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: P.cover.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }
  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));
  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: P.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        ", size: 16, color: P.cover.footerColor }),
      new TextRun({ text: config.footerRight || "", size: 16, color: P.cover.footerColor, font: { ascii: "Arial" } }),
    ],
  }));
  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: P.bg }, borders: noBorders, children,
      })],
    })],
  })];
}

// ------------------------------------------------------------------ body helpers
const F = { ascii: "Times New Roman", eastAsia: "SimSun" };
const FH = { ascii: "Times New Roman", eastAsia: "SimHei" };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: PAL.primary, font: FH })],
  });
}
function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: PAL.primary, font: FH })],
  });
}
function body(text, opts = {}) {
  const runs = Array.isArray(text) ? text : [new TextRun({ text, size: 24, color: PAL.body, font: F })];
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: opts.after !== undefined ? opts.after : 120 },
    children: runs,
  });
}
function run(text, extra = {}) { return new TextRun({ text, size: 24, color: PAL.body, font: F, ...extra }); }
function bullet(text) {
  return new Paragraph({
    bullet: { level: 0 },
    spacing: { line: 312, after: 60 },
    children: [new TextRun({ text, size: 24, color: PAL.body, font: F })],
  });
}
function caption(text) {
  return new Paragraph({
    keepNext: true, spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: PAL.secondary, font: FH })],
  });
}
function cell(text, opts = {}) {
  return new TableCell({
    children: [new Paragraph({
      alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
      spacing: { line: 312 },
      children: [new TextRun({ text, size: opts.header ? 21 : 20,
        bold: !!opts.header, color: opts.header ? PAL.table.headerText : PAL.body,
        font: opts.header ? FH : F })],
    })],
    shading: opts.header ? { type: ShadingType.CLEAR, fill: PAL.table.headerBg }
      : (opts.zebra ? { type: ShadingType.CLEAR, fill: PAL.table.surface } : undefined),
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    width: opts.width ? { size: opts.width, type: WidthType.PERCENTAGE } : undefined,
  });
}
function dataTable(widths, header, rows, zebra = true) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 8, color: PAL.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      insideVertical: NB,
    },
    rows: [
      new TableRow({
        tableHeader: true, cantSplit: true,
        children: header.map((t, i) => cell(t, { header: true, width: widths[i] })),
      }),
      ...rows.map((r, ri) => new TableRow({
        cantSplit: true,
        children: r.map((t, i) => cell(t, { width: widths[i], zebra: zebra && ri % 2 === 1 })),
      })),
    ],
  });
}
function codeBlock(lines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine },
      left: { style: BorderStyle.SINGLE, size: 12, color: PAL.table.accentLine },
      right: NB, insideHorizontal: NB, insideVertical: NB,
    },
    rows: [new TableRow({
      cantSplit: true,
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: "F4F7F6" },
        margins: { top: 120, bottom: 120, left: 200, right: 160 },
        children: lines.map(l => new Paragraph({
          spacing: { line: 312, after: 20 },
          children: [new TextRun({ text: l, size: 18, color: "24313B", font: { ascii: "Courier New", eastAsia: "SimSun" } })],
        })),
      })],
    })],
  });
}

// ------------------------------------------------------------------ footers/headers
function pageFooter() {
  return new Footer({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ children: [PageNumber.CURRENT], size: 18, color: "808080", font: F })],
  })] });
}
function bodyHeader() {
  return new Header({ children: [new Paragraph({
    alignment: AlignmentType.CENTER,
    border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: PAL.table.innerLine, space: 4 } },
    children: [new TextRun({ text: "APEIRON-X v15 Phase 1 Report", size: 18, color: "808080", font: F })],
  })] });
}

const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

// ================================================================== BODY CONTENT
const B = [];

// ---- 1 Executive Summary
B.push(h1("1. Executive Summary"));
B.push(body("This report closes Phase 1 of the APEIRON-X v15 program: a full foundation audit of the v14.1 disease-to-drug proof engine, a reproduced execution baseline, an engineering-hygiene round, and the first additive v15 scaffold. It also fixes, in writing, the binding eight-phase implementation plan that will carry the platform toward the master objective: disease, then biological mechanism, then molecular target, then existing drug, then novel molecule, then computational evaluation, then experimental validation."));
B.push(body("Three findings matter most. First, the engine is healthy: all nine baseline entries of the proof cascade exit 0, including the seven-theorem core battery, the seven structure theorems, the six direct-law theorems, the eight equation theorems, and the ten hermetic correspondence theorems, with the sha256 axiom lock verified intact (2e95f0f7...ccb0). Second, the three defects reported against v14.0 are verifiably fixed in code, not only in documentation: every learned monomial now anchors on at least two channels (528 of 528 monomials at depth exactly 2, zero degenerate), the guideline-drift rows D61 to D63 exist with guideline citations, and the previously missing SGLT2 class law exists on both the channel and the chemical-structure side. Third, the audit surfaced twelve engineering debts, of which the sha256 freeze-and-repin coupling, the hand-curated sibling map, and the unpinned RDKit dependency are the ones the plan attacks first."));
B.push(body("Delivered with this round: the full audit document (docs/V15_AUDIT.md), the binding implementation plan (docs/V15_IMPLEMENTATION_PLAN.md), a change log (docs/CHANGELOG.md), corrected stale narrative counts in six engine files with zero changes to laws or knowledge data, a requirements.txt pinning the exact RDKit version, the additive v15/ scaffold package with five passing unit checks, and a one-command regression runner that re-proves the entire v14.1 cascade plus frozen-file integrity. The full cascade re-ran green after every change: nine of nine stages exit 0."));

// ---- 2 Background and Objectives
B.push(h1("2. Background and Objectives"));
B.push(h1("2.1 The v14.1 system as found"));
B.push(body("APEIRON-X v14.1 is a proof-only mathematical engine that maps an encoded disease to a therapy class and then to a first-line drug, over a closed, guideline-labelled knowledge base of 63 diseases, 203 drugs in 129 mechanism classes, 191 PubChem molecules, 56 channel laws, 117 structure laws and 183 identity laws. Its claimed guarantees are relative to its own encoded corpus: exact universal theorems with zero counterexamples on that corpus, sound refusal outside it, and a hermetic derivation layer that machine-checks that no knowledge table leaked into the axioms. The engine deliberately separates mathematical proof about encoded data from any claim about biology; this separation is preserved by everything in this round."));
B.push(h1("2.2 The v15 mission and the Phase 1 objective"));
B.push(body("The v15 master prompt expands the platform toward six modules: universal disease intelligence, biological target discovery, drug repurposing, novel molecule discovery, an extended mathematical reasoning engine, and experimental-validation intelligence. It also imposes development discipline: audit before building, baseline before change, preserve the proof engine, never weaken a constraint, never edit a law to pass a test, and demonstrate every claimed improvement with reproducible tests. Phase 1 is therefore exactly two things: a complete audit of the existing source, and a detailed implementation plan. Code changes in this round are restricted to hygiene and additive scaffolding."));

// ---- 3 Audit scope, method, baseline
B.push(h1("3. Audit Scope, Method and Baseline Evidence"));
B.push(body("The audit read approximately ten thousand lines of Python across eleven modules, the frozen axiom corpus, four demos and two test harnesses, in full rather than by sampling. Every headline count was independently recomputed (channel vocabularies, law counts, monomial depth histograms, matrix sizes, sha256 locks) instead of being trusted from the certificate text. The baseline was then re-executed end to end in the current environment: Python 3.12.16 and RDKit 2026.09.2, the latter now pinned in requirements.txt. The engine proved deterministic: certificates regenerate bit for bit, and the correspondence layer re-derives its own results twice and diffs them (theorem C1)."));
B.push(caption("Table 1: Baseline cascade, reproduced 2026-11-24"));
B.push(dataTable([8, 44, 12, 36],
  ["No.", "Entry point (layer, theorem battery)", "Exit", "Key evidence"],
  [
    ["1", "apeiron_drug_discovery_proof.py (v11.1, T0-T4, C1)", "0", "63/63 domain sweep; 8,703 CEGIS probes, 0 false outputs"],
    ["2", "apeiron_structure_proof.py (v12.1, S0-S5)", "0", "117 class laws, 183 identity laws, full bipartite matrix clean"],
    ["3", "apeiron_direct_laws.py (v13.0, D0-D5)", "0", "63 direct laws; 18 held-out pairs + 11 refusals, 0 errors"],
    ["4", "apeiron_equations.py (v13.1, E0-E7)", "0", "EQ1-EQ7 evaluated for every disease; indication-free derivation"],
    ["5", "apeiron_correspondence.py (v14.0, C0-C8 + REG)", "0", "all_proved true; hermetic_derivation true"],
    ["6", "demo_full_mapping.py", "0", "every disease maps to guideline rank-1 on both paths"],
    ["7", "extension_stress_demo.py", "0", "synthetic worlds up to 75 rows, all checks pass"],
    ["8", "scripts/apeiron_novel_disease_test.py", "0", "Tier A 8/8; Tier D 4/4 no collapse; corpus gate holds"],
    ["9", "scripts/smoke_test_fix.py", "0", "SGLT2 law present; exclusivity and 8 predictions confirmed"],
  ]));
B.push(body("The axiom corpus lock was verified separately: the sha256 of postulates_v14.json equals the value pinned in the correspondence engine, so the frozen axioms are exactly the ones the engine refuses to run without.", { after: 200 }));

// ---- 4 Architecture findings
B.push(h1("4. Architecture Findings"));
B.push(h1("4.1 The layered proof cascade"));
B.push(body("The engine is a layered cascade in which each layer re-proves its parent battery as a regression gate and exits non-zero unless every theorem is an exact universal proof. The shared idiom is exact Boolean law learning over a feature space, certified by Reed-Muller algebraic normal forms over GF(2), then attacked by adversarial counterexample-guided falsification batteries. The v14 correspondence layer imports only NumPy, RDKit and the frozen JSON corpus, and machine-checks absence of every knowledge module from the import table before derivation (C0)."));
B.push(caption("Table 2: Module map (condensed; full file:line references in docs/V15_AUDIT.md)"));
B.push(dataTable([26, 14, 34, 26],
  ["Module", "Layer", "Role", "Battery and outputs"],
  [
    ["apeiron_drug_discovery_proof.py", "v11.1 core", "6-channel encoding phi, class law DNF, ranking embed K = 100*tier - 10*eff + pen, sound refusal", "T0-T4, C1; proof_certificate.json"],
    ["disease_drug_kb.py", "v11.1 KB", "63 diseases D01-D63, 203 drugs, guideline citations; hash-pinned", "T0 validation"],
    ["apeiron_structure_proof.py", "v12.1", "SMARTS + descriptor feature space, structure and identity laws, reverse and generic paths", "S0-S5; structure_certificate.json"],
    ["drug_structures.py", "v12.1 KB", "191 PubChem molecules, 184 covered drugs, 19 explicit exclusions; hash-pinned", "S0 validation"],
    ["apeiron_direct_laws.py", "v13.0", "indication-free derivation; drug-name field locked behind guard", "D0-D5; direct_laws_certificate.json"],
    ["disease_mechanism_table.py", "v13 KB", "drug-name-free mechanism profiles; 18 held-out pairs, 11 refusals; hash-pinned", "D0 validation"],
    ["apeiron_equations.py", "v13.1", "symbolic + evaluated equation chain EQ1-EQ7", "E0-E7; equations_certificate.json"],
    ["build_postulates.py + postulates_v14.json", "v14.0", "one-time axiom freeze P1-P6, sha256-locked", "freeze print + pin"],
    ["apeiron_correspondence.py", "v14.0", "hermetic structure-structure correspondence EQ-A..EQ-F", "C0-C8 + REG subprocess"],
  ]));
B.push(h1("4.2 Data shapes, verified live"));
B.push(body("Channel vocabulary sizes are: system 13, etiology 19, microbe 9, site 38, chronicity 2, pathway 57 (implicit in the rows). The mechanism table covers all 63 diseases with 56 distinct primary classes. The v14.1 corpus gate counts 528 learned monomials across class, regimen and drug-channel laws, every one at depth exactly 2 with zero degenerate fallbacks. The discrimination matrices, which earlier documents quoted as fixed numbers, are dynamic: 11,224 checks in the correspondence matrix (61 molecular diseases times 184 covered drugs) and 11,592 in the equation-layer matrix (184 times 63); certificates carry the live values."));

// ---- 5 verification of the v14.1 fixes
B.push(h1("5. Verification of the v14.1 Defect Fixes"));
B.push(h1("5.1 Class-law collapse on the pathway channel"));
B.push(body("Pre-v14.1, most learned terms had depth 1, and 48 of 60 collapsed to the pathway channel alone, so diseases sharing a pathway value inherited the same therapy class. The fix is a doctrine constant MIN_TERM_DEPTH = 2 enforced in two mirrored ladders: separating_term_family in the core engine emits the whole family of separating channel subsets at the first feasible level (pathway-anchored depth 2 or more first), and derive_channel_dnf in the structure layer uses the same ladder with maximum-coverage selection, which feeds every v13 and v14 channel law. Depth-1 terms survive only as an explicitly flagged degenerate fallback. The invariant is machine-checked in three places: the corpus gate walks every learned monomial (528 of 528 at depth 2), the Tier D battery challenges four encodings that share exactly one channel with a knowledge-base row and demands the shared class is not returned (4/4 clean), and the stress demo injects a pathway-saturation row and requires the law to re-anchor rather than collapse."));
B.push(h1("5.2 Guideline-era drift"));
B.push(body("Three guideline-current diseases were absent from the knowledge base, so the engine could only return pre-guideline answers for them. The drift round added D61 heart failure with preserved ejection fraction (empagliflozin first line, ESC 2023 class I, EMPEROR-Preserved and DELIVER), D62 binge-eating disorder (lisdexamfetamine, FDA 2015, NICE NG69) and D63 vasospastic angina (amlodipine first line, ACC/AHA 2023), each with mechanism profiles consistent with the guideline drug lists, and the encoding remained injective with all validation rules passing. Because the knowledge base is hash-pinned, this round verified the pinned hashes instead of touching the file."));
B.push(h1("5.3 The SGLT2 class law"));
B.push(body("The SGLT2 inhibitor class now exists as a learned law on both sides of the correspondence. On the channel side the law is etiology = FUNCTIONAL_DYSREGULATION and pathway = PW_NEUROHORMONAL_REMODELING, born from D61 and exactly depth 2, so it does not collapse onto the pathway channel it shares with reduced-ejection-fraction heart failure. On the chemical side the structure law is the conjunction diaryl_sp3_carbon AND primary_alcohol, satisfied by empagliflozin (CID 11949646) and dapagliflozin (CID 9887712), with containment rho equal to 1.000 on D61 and below 1 on every non-pair checked in the C4 matrix."));
B.push(h1("5.4 Generalization posture after the fix"));
B.push(body("The novel-disease harness distinguishes four honest outcomes. Tier A diseases encodable from the vocabulary resolve to guideline rank-1 therapy (8/8). Tier B diseases the vocabulary cannot serve, such as neurocysticercosis (no helminth etiology value) or multiple sclerosis, are refused or documented as not encodable, never guessed. Tier C adversarial probes (out-of-vocabulary pathways, incomplete encodings, mis-encoded diseases, non-corpus molecules) produce sound refusals or non-claims. Tier D guards specifically against recurrence of the collapse. This posture is the honesty baseline v15 inherits: prediction inside the encoded domain, refusal outside it, and explicit labels for everything in between."));

// ---- 6 risk register
B.push(h1("6. Risk and Debt Register"));
B.push(body("Twelve engineering debts were logged, each with a location and a planned owner phase. None is a correctness defect today; all nine baseline entries pass. They are debts because they either couple future growth to manual steps or hide a single point of failure."));
B.push(caption("Table 3: Debt register (condensed)"));
B.push(dataTable([10, 48, 42],
  ["ID", "Risk", "Planned remediation"],
  [
    ["R1", "sha256 tamper lock couples every knowledge-base edit to a manual re-freeze and code edit", "Phase 2 growth-pack tooling automates freeze, pin and cascade"],
    ["R2", "stale narrative counts in engine docstrings and printers (fixed this round)", "done in Phase 1; remaining PDF-source strings in Phase 2"],
    ["R3", "hand-curated 12-entry sibling map is completeness-critical", "Phase 3 sibling-derivation theorem + audit"],
    ["R4", "RDKit version unpinned; frozen fingerprint-bit laws break on upgrade", "Phase 1 requirements.txt; Phase 6 portability theorem"],
    ["R5", "un-memoized per-pair RDKit sweeps in C2/C4 dominate runtime", "Phase 6 memoization with determinism theorem"],
    ["R6", "law solver can silently fall back to greedy as feature space grows", "Phase 6 budget telemetry theorem"],
    ["R7", "parent-regression subprocess hard timeout 2400 s", "Phase 8 staged CI timeouts"],
    ["R8", "test scripts write outside the repository", "Phase 8 harness refactor"],
    ["R9", "demos with brittle hard-coded expectations", "Phase 8 test-data separation"],
    ["R10", "depth-2 doctrine degrades if a future channel has cardinality 1", "Phase 2 vocabulary admission guard"],
    ["R11", "no requirements file", "Phase 1 requirements.txt (done)"],
    ["R12", "stress demo mutates knowledge-base globals in-process", "Phase 8 subprocess isolation rule"],
  ]));
B.push(body("The four that shape the plan most are R1, because every Phase 2 knowledge expansion hits it; R3, because any new drug class with an unrecorded pharmacophore sibling would fail the discrimination theorems loudly (safe, but blocking); R4, because frozen identity laws embed RDKit fingerprint bit indices; and R5, because the correspondence layer re-parses and re-featurizes molecules per pair, which will scale quadratically with corpus growth.", { after: 200 }));

// ---- 7 the plan
B.push(h1("7. The v15 Implementation Plan"));
B.push(h1("7.1 Principles and target end state"));
B.push(body("Six principles bind every round. The v14.1 cascade must exit 0 after every change. No mathematical constraint is weakened and no law is edited to make a test pass. The four-tier claim separation is mandatory in every output: proven mathematics on the encoded corpus, cited experimental or guideline evidence, computational inference, and speculative hypothesis. Missing data is reported as missing, never fabricated or silently substituted. Every knowledge-base growth follows the audited checklist and ends with a full cascade run. Every new data module is appended to the hermeticity audit list, or hermeticity silently stops covering it."));
B.push(caption("Table 4: Phase plan and status"));
B.push(dataTable([12, 54, 18, 16],
  ["Phase", "Content", "Key outputs", "Status"],
  [
    ["0", "v14.1 fix: anti-collapse doctrine, drift rows D61-D63, SGLT2 class law", "re-verified this round", "done (prior round)"],
    ["1", "foundation audit + baseline + hygiene + scaffold + dependency pin", "audit, plan, changelog, v15/ scaffold, regression runner", "done (this round)"],
    ["2", "Module A: ontology/gene/protein/pathway vocabularies, disease profiles, growth packs", "frozen knowledge packs, phi converter, cardinality guard theorem", "next"],
    ["3", "Module B: target discovery with evidence-tiered transparent scoring", "target engine, connectors (frozen-response), benchmark on 10 diseases", "planned"],
    ["4", "Module C: repurposing engine with status discipline and temporal benchmark", "candidate engine, mechanism-structure consistency bridge", "planned"],
    ["5", "Module D: molecule screening, property and ADMET prediction, generation", "chem layer, truth-in-labeling theorem", "planned"],
    ["6", "Module E: knowledge-graph postulates, eight new proof obligations, performance", "P8 corpus section, portability and memoization theorems", "planned"],
    ["7", "Module F: experimental-validation intelligence", "validation-plan generator, schema test", "planned"],
    ["8", "integration: end-to-end pipeline, API, dashboards, full benchmark suite, CI", "18-section discovery report, leakage checks, staged timeouts", "planned"],
  ]));
B.push(h1("7.2 Module notes"));
B.push(body("Module A extends disease representation without breaking the six-channel spine: a DiseaseProfile carries evidence-layered biological fields (ontology identifiers, genetics, expression, protein, metabolic, immune, cellular, tissue, pathway, progression, environmental), and a converter derives the six-channel encoding only when the vocabulary can serve it, with citations; otherwise the profile is marked not encodable, extending the Tier B honesty doctrine to v15. Knowledge growth arrives as versioned data packs applied by one audited script, which is what turns the freeze-and-repin debt R1 from a manual hazard into a routine gate."));
B.push(body("Module B ranks targets on five transparent axes (genetic evidence, functional evidence, pharmacological tractability, safety penalty, evidence completeness) displayed individually, with any aggregate explicitly labelled as a computational rank and never a probability. Association-only evidence keeps an association-is-not-causation flag that computation can never clear. Module C joins targets to drugs through known interactions, checks pharmacological compatibility against the mechanism profiles, scans for contradictory biology, and stamps every candidate with exactly one status: approved indication, investigational, computational hypothesis, or experimentally validated. A consistency bridge requires repurposing candidates for encoded diseases to also satisfy the proved direct structure law, surfacing violations as named findings rather than silent drops."));
B.push(body("Module D wraps the existing SMARTS feature space with molecular input and output: validation, fingerprints, similarity, pharmacophore queries derived from structure laws, rule-based property estimates labelled as such, model-based ADMET labelled with model version and provenance, and law-guided analog generation filtered by chemical validity, synthetic accessibility, novelty and toxicity alerts. A truth-in-labeling theorem will guarantee no emitted molecule record claims binding or efficacy. Module E freezes the new knowledge graph as postulate section P8 with the same sha256 discipline, and adds the eight new proof obligations (consistency, uniqueness, contradiction detection, provenance completeness, ranking integrity, uncertainty propagation, out-of-domain detection, reproducibility) in the standard theorem shape, so they join the exit-code gate and propagate upward through the regression nesting. Module F converts every evidenced candidate into a testable hypothesis: mechanism narrative, target-engagement assay class, supporting and contradictory evidence, model systems, controls, endpoints, failure mechanisms and stage gates, plus an explicit section listing what evidence would change the candidate's status."));
B.push(h1("7.3 Testing and ranking discipline"));
B.push(body("Every module gets an independent suite in the existing style: exit code zero only when everything proved. The Phase 8 benchmark set adds the v14.1 regression suites, disease-representation tests, repurposing benchmarks with temporal validation (pre-2015 evidence predicting post-2015 successes, the SGLT2 heart-failure class being the canonical case), molecular-structure validation, interaction benchmarks, negative controls, out-of-domain tests, provenance tests, reproducibility tests and end-to-end discovery tests, with explicit leakage checks between training and evaluation packs. The candidate-ranking architecture is deliberately not a single hidden score: dimensions are displayed with supporting evidence, missing information and uncertainty, and the report states that a high computational rank is not a probability of clinical success."));

// ---- 8 Phase 1 changes delivered
B.push(h1("8. Phase 1 Changes Delivered This Round"));
B.push(h1("8.1 Documentation"));
B.push(body("Three documents were added to the repository: the full audit (docs/V15_AUDIT.md) with architecture map, live data shapes, extension points, the debt register and honest limits; the binding plan (docs/V15_IMPLEMENTATION_PLAN.md), whose content Chapter 7 summarizes; and a change log (docs/CHANGELOG.md) recording every file changed in this round with the reason and the reproduction commands. The README gained a v15 pointer block annotating that counts quoted in older sections were historical values of their rounds."));
B.push(h1("8.2 Narrative hygiene (engines only; no knowledge data touched)"));
B.push(body("Six engine files carried stale narrative counts that contradicted the live corpus even though the mathematics was correct. Corrections: the core-engine header now states 63 indications; the correspondence engine prints the matrix check count, external-pair count and refusal count dynamically from theorem statistics instead of the hard-coded 11,040; the equation-layer header states 63 of 63; the direct-law report now computes the non-molecular remainder list from the live tables (D09 and D58, correcting the stale list that included D24, which is molecular); both demos annotate corpus size; and the stress demo computes its world labels from live row counts. The three hash-pinned knowledge files and the axiom corpus were not modified; their sha256 values are verified identical before and after the round by the regression runner."));
B.push(h1("8.3 Additive v15 scaffold"));
B.push(body("The new apeiron/v15/ package contains: a claim-tier model whose ladder can be weakened by code but never strengthened without new evidence, and which refuses an evidenced claim without a citation; a provenance ledger where every external source record carries identifier, resource version, retrieval timestamp, license, evidence type and an optional frozen payload hash, with an anti-fabrication gate that refuses any citation that has no record; a DiseaseProfile data model with layered evidence fields and a checked converter into the v14.1 encoding that never coerces an out-of-vocabulary profile; a target-scoring skeleton implementing the transparent five-axis discipline with the association flag; a full-cascade regression runner that executes the nine baseline stages as subprocesses with stage timeouts and verifies frozen-file hashes; and five passing unit checks covering all of the above plus read-only coupling to the v14.1 knowledge base. A requirements.txt pins numpy and RDKit 2026.09.2."));
B.push(h1("8.4 Verification evidence"));
B.push(body("After the changes, the full cascade re-ran green: nine of nine stages exit 0 (core 0.4 s, structure 7.9 s, direct laws 6.2 s, equations 8.9 s, correspondence 74.0 s including the nested parent regression, mapping demo 4.7 s, stress demo 4.0 s, novel-disease harness 4.5 s, smoke test 4.6 s), and the four frozen files matched their baseline hashes. The scaffold tests pass 5 of 5. Any future round can reproduce all of it with one command."));
B.push(caption("Table 4b: One-command acceptance gate"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/run_full_regression.py        # 9 stages + frozen-file integrity",
  "python3 v15/tests/test_v15_scaffold.py    # 5/5 checks",
  "# exit 0 on both <=> round accepted",
]));

// ---- 9 honest limits
B.push(h1("9. Honest Limits and Next Steps"));
B.push(body("Nothing in this round, and nothing planned, converts a mathematical proof about encoded data into a claim of biological efficacy. The engine proves statements about its own closed corpus; it refuses diseases outside its vocabulary rather than guessing; ranking outputs are computational ranks, not probabilities of clinical success; and every later module must keep its outputs labelled with the four-tier claim discipline. Licensing review (KEGG, DrugBank, DisGeNET) precedes the corresponding connectors in Phase 3 and 4; where a license cannot be obtained, the connector is reported as unavailable rather than substituted."));
B.push(body("Next steps, in order: Phase 2 delivers the first additive vocabulary module and disease-profile store, the growth-pack tooling that automates the freeze-and-repin cycle, the first knowledge pack (five diseases spanning systems the current corpus lacks), and the vocabulary-cardinality guard theorem. Each subsequent phase lands only with the acceptance gate green: full cascade exit 0, frozen hashes intact or documented re-freeze, claim-tier scan clean, changelog updated."));

// ---- Appendix
B.push(h1("Appendix A. Frozen-File Hashes (verified this round)"));
B.push(caption("Table 5: sha256 of hash-pinned files, unchanged through the round"));
B.push(dataTable([40, 60],
  ["File", "sha256 (first 16 hex shown in runner; full value logged)"],
  [
    ["disease_drug_kb.py", "507fb67636479746...  (full: docs/baseline/frozen_files_sha256_before.txt)"],
    ["drug_structures.py", "7dc763c480443789..."],
    ["disease_mechanism_table.py", "e21f4f153ee2c2c5..."],
    ["postulates_v14.json", "2e95f0f79c5eed35..."],
  ]));
B.push(body("Full-length hashes are committed in docs/baseline/frozen_files_sha256_before.txt and re-verified by v15/run_full_regression.py on every run. The pinned axiom-corpus value 2e95f0f79c5eed35b89a117bf71c0785648c3313e87b41cb211e8b78b3f2ccb0 is byte-identical to the live file.", { after: 200 }));

// ================================================================== DOCUMENT
const doc = new Document({
  styles: {
    default: {
      document: {
        run: { font: F, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: FH, size: 32, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: FH, size: 28, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
      heading3: {
        run: { font: FH, size: 24, bold: true, color: PAL.primary },
        paragraph: { spacing: { before: 200, after: 100, line: 312 }, outlineLevel: 2 },
      },
    },
  },
  sections: [
    { // Section 1: cover — margin 0, no footer, no page numbers
      properties: { page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } } },
      children: buildCoverR1({
        title: "APEIRON-X v15 Foundation Audit",
        subtitle: "Phase 1 evidence and the binding implementation plan",
        englishLabel: "APEIRON-X V15 PROGRAM",
        metaLines: [
          "Round: v15 Phase 1 (audit, baseline, hygiene, scaffold)",
          "Baseline: v14.1 cascade 9/9 exit 0, axiom lock intact",
          "Scope: ~10,000 LOC audited in full; all counts re-verified",
          "Date: 2026-11-24",
        ],
        footerLeft: "APEIRON-X Computational Drug-Discovery Platform",
        footerRight: "v15 Phase 1 Report",
        palette: PAL,
      }),
    },
    { // Section 2: front matter (TOC) — Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 240, after: 160 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32, font: FH, color: PAL.primary })],
        }),
        new Paragraph({
          spacing: { after: 80 },
          alignment: AlignmentType.CENTER,
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: F })],
        }),
        new TableOfContents("Table of Contents", { hyperlink: true, headingStyleRange: "1-3" }),
        // NOTE: no trailing PageBreak here — section 3 uses SectionType.NEXT_PAGE,
        // and a PageBreak at section end would create a blank page (postcheck rule).
      ],
    },
    { // Section 3: body — Arabic, restart at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: bodyHeader() },
      footers: { default: pageFooter() },
      children: B,
    },
  ],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON-X_v15_Phase1_Audit_and_Plan.docx", buf);
  console.log("written: APEIRON-X_v15_Phase1_Audit_and_Plan.docx");
});
