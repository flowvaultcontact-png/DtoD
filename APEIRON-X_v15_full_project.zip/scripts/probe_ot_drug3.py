"""Probe drugAndClinicalCandidates shape + full drug record sample (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None, maxlen=2600):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 60, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:250])
            return None
        print(f"{name}: OK {json.dumps(p['data'])[:maxlen]}")
        return p["data"]
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:130]}")
    return None


d = run("dcc_fields", '{__type(name:"Disease"){fields{name '
        'type{kind name ofType{kind name ofType{kind name}}}}}}')
if d:
    for f in d["__type"]["fields"]:
        if f["name"] == "drugAndClinicalCandidates":
            print("drugAndClinicalCandidates ->", json.dumps(f["type"]))

run("search_dapa", 'query{search(queryString:"dapagliflozin")'
    '{hits{id name entity}}}', maxlen=500)

run("full_dapa", '''query($id:String!){
 drug(chemblId:$id){
   id name maximumClinicalStage
   mechanismsOfAction{ rows{ actionType mechanismOfAction targetName
     targets{ id approvedSymbol } } }
   indications{ count rows{ id maxClinicalStage disease{ id name } } }
 }
}''', {"id": "CHEMBL1201549"}, maxlen=3000)
