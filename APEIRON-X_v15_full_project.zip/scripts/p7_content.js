// ---- 1 Executive Summary
B.push(body("This report closes Phase 7 of the APEIRON-X v15 program: the experimental-validation intelligence (Module F). The phase adds a frozen dataset registry over ClinicalTrials.gov and GEO, a validation-plan engine that ships a complete, machine-checked plan per candidate, and the P7-3 status discipline that names exactly which evidence would change a candidate's status - again without weakening a single v14.1 constraint. All four hash-pinned corpus files kept their sha256, and the acceptance cascade now runs 16 of 16 stages at exit 0. The plan's acceptance clause is met on both items: every EVIDENCED-or-stronger candidate in the plan universe ships with a complete plan (10 of 10), and every plan passes the schema gate (20 of 20, with a 16-lane refusal battery proving the gate actually refuses)."));

B.push(body("Two design decisions define the round. First, the P7-2 registry carries metadata and accession records ONLY, and this is structural, not a convention: the ClinicalTrials.gov request pins its fields parameter to exactly six whitelisted protocolSection modules, so outcome and results content is never even fetched - the payload physically cannot carry an effect size, a p-value or an outcome measure, and theorem F4 machine-checks this at three layers (connector AST, registry self-validation, plan build gate). Second, a validation plan is a falsifiable proposal, not a claim: the assay classes, model systems, controls and endpoints are transparent authored rule tables labelled COMPUTATIONAL, the stage gates start honestly at PROPOSED (only the HUMAN lane may carry a registry-activity state, and that state means trials exist, never that a drug worked), and the only permitted status movements are DECLARED transitions that name cited evidence classes - the code path that would upgrade a status always raises."));

// ---- 2 Scope and doctrine
B.push(h2("Scope and doctrine"));
B.push(body("Module F is the platform's answer to the question every downstream reviewer asks: what experiment would test this prediction, and what would falsify it. Per candidate the engine emits a plan with fifteen required sections - candidate identity, disease context, a tiered mechanism narrative, the target-engagement hypothesis with a named assay class, supporting and contradictory evidence with resolvable identifiers, proposed model systems, control groups, measurable and assay-annotated endpoints, failure mechanisms, the five stage gates, linked datasets, the P7-3 required-evidence-to-change-status section, and honest limits. The doctrine carries the Phase 3-6 disciplines forward unchanged: v14.1 engines are imported read-only; the derivation modules import no connector code (AST-checked); the registry loader refuses to serve on a sha256-pin mismatch and runs a self-validation at load; absent data is recorded as an absence (four absences in this registry, including the structural truth that a generated molecule cannot have registry records); and the claim-ladder rule means no computation ever strengthens a claim."));

// ---- 3 P7-2 registry
B.push(h2("P7-2. The frozen dataset registry (metadata + accession only)"));
B.push(body("The live refresh tool (the only sanctioned network path) runs a deterministic panel: ten ClinicalTrials.gov intervention-by-condition queries over the Phase 4 candidate universe (dapagliflozin, empagliflozin, canagliflozin, lisinopril, losartan, spironolactone, metformin, finerenone against the cardio-renal-metabolic conditions), five GEO term queries over the mechanism and disease contexts, and one negative-control query for the generated molecule APXD-0001, which cannot have registry records. The fetch froze 180 study-metadata rows and 40 series-metadata rows under sha256-keyed payloads; the deterministic generator then deduplicated them verbatim into the frozen module: 158 unique studies, 35 unique series (5 non-series rows - GSM samples and GPL platforms - dropped with the drop recorded as an absence), 15 provenance records, and 4 recorded absences."));
B.push(dataTable([22, 40, 38],
  ["Registry lane", "Content (all frozen, sha256-traceable)", "Guarantee"],
  [
    ["CT.gov studies (158)", "registry header fields only: NCT id, title, overall status, phases, study type, start date, conditions, intervention names, arm-group labels, lead sponsor, enrollment count", "fields whitelist makes results content structurally absent; a whitelist + forbidden-token check re-verifies every row at connector level"],
    ["GEO series (35)", "accession, series type, title, summary (truncated verbatim), organism, sample count, platform, update date", "accession + summary metadata only; raw expression data is never fetched or stored; non-series rows dropped and the drop recorded"],
    ["Candidate/disease links (40)", "mechanical token filter over title/conditions/interventions; 33 links with hits; every filter expression recorded inside the link row", "a CONDITION_LEVEL_ONLY link (HFREF/HFPEF) must never be presented as stratum-specific evidence; T2DM and other unqueried pairs are recorded absences"],
    ["GEO disease-context links (8)", "term-level mapping recorded with its rationale", "context datasets only - never candidate-specific evidence"],
    ["Absences (4)", "APXD generated molecules have no registry records; the results lane is never fetched; GSM/GPL rows dropped; each with a named reason", "nothing silently empty, nothing guessed"],
  ]));

// ---- 4 P7-1 engine
B.push(h2("P7-1. The validation-plan engine"));
B.push(body("The engine consumes three frozen sources - the Phase 4 repurposing pack (candidates, statuses, mechanism rows, bridge findings), the Phase 7 registry (datasets), and the frozen Phase 5 artifact (generated molecules) - and builds the plan universe deterministically: per panel disease, the top three ranked candidates plus every ground-truth drug (17 drug-by-disease pairs), then the top three emitted molecules APXD-0001 to APXD-0003 (the structural-absence lane). Each plan is assembled through a build gate that refuses anything violating the P7 discipline, and the same discipline is exposed as validate_loaded_plan, the artifact-layer validator that re-checks any plan loaded from a certificate or API payload - a tampered plan cannot pass unnoticed."));
B.push(body("The plan content is honestly sourced. The mechanism narrative quotes the frozen Open Targets mechanism rows (action type and target symbols) and carries the status row's tier; the target-engagement hypothesis applies a transparent authored rule table from the primary target symbol to an assay class - recombinant-human-SLC5A2 transporter glucose-uptake for the SGLT2 inhibitors, human-AGTR1 binding competition for the ARBs, human-NR3C2 ligand-binding plus transactivation for the mineralocorticoid antagonists, and so on - and every rule application records its basis and the COMPUTATIONAL tier. A drug whose mechanism resolves to no rule-table entry gets an explicit UNRESOLVED assay class; a proposal is never invented to fill a gap. The stage gates run biochemical, cellular, tissue, animal, human - in that fixed order, with completion states forming a prefix chain - and start at PROPOSED everywhere except the HUMAN lane of candidates whose token filter links registry studies: those carry REGISTRY_ACTIVITY_PRESENT with the linked accession list and a basis string that says metadata only, never efficacy."));

// ---- 5 theorems table
B.push(h2("The seven proof obligations (all PROVEN_MATH)"));
B.push(dataTable([8, 34, 58],
  ["#", "Obligation (theorem)", "What is machine-checked"],
  [
    ["F1", "theorem_plan_schema_completeness", "all 20 plans carry the 15 required sections (contradictory-evidence honestly exempt when empty); the EVIDENCED+ subset (10 plans) all carry complete evidence rows; a null-section plan and an unannotated-endpoint plan are refused at construction"],
    ["F2", "theorem_stage_gate_ordering", "the canonical 5-gate ladder in fixed order; completion states form a prefix chain; an out-of-order completion and an uncited completion are refused (injection lanes)"],
    ["F3", "theorem_evidence_citation_completeness", "131 evidence identifiers across the 20 plans all resolve against the three frozen ledgers (P4 pack, P7 registry, P8 graph); an unknown identifier is refused at build (injection detected)"],
    ["F4", "theorem_no_results_synthesis", "zero results tokens in any plan, zero in the registry tables, the connector whitelist AST-verified (fields built from the 6-module whitelist); a results-token endpoint injection is refused by the build gate"],
    ["F5", "theorem_status_transition_discipline", "every plan declares from/to/evidence-classes with never_by_computation true and no declared transition weaker than the current status; attempt_status_upgrade raises on every plan (no code path upgrades a status)"],
    ["F6", "theorem_plan_determinism", "two independent builds of all 20 plans hash identically (canonical JSON sha256 abe8daaf5af8f18a...); a key scan proves no wall-clock field exists in any plan payload"],
    ["F7", "theorem_out_of_domain_detection", "a ghost drug returns no dataset link, a ghost disease returns no GEO series, an unknown drug raises on the pack - explicit absences everywhere, zero fabrications"],
  ]));

// ---- 6 negative controls
B.push(h2("The battery that bites: sixteen refusal lanes"));
B.push(body("A gate that cannot refuse proves nothing, so the battery plants sixteen faults. Thirteen run through the constructor: a null section, an unknown candidate status (WONDERDRUG), an unknown candidate tier, an unknown gate state, a REGISTRY state below the HUMAN lane, an out-of-prefix completion, an uncited completion, an unresolvable evidence identifier, results-token content (a hazard-ratio string in an endpoint), an unresolvable CT.gov accession, an unresolvable dataset source identifier, empty honest limits, and a datasets section that is empty without an absence note. Three run through the artifact-layer validator: a status/transition mismatch (the transition declaring INVESTIGATIONAL for an APPROVED_INDICATION candidate), a transition section with never_by_computation tampered to false, and an unknown status on load. The honest path closes the loop: all twenty artifact plans re-pass the loaded-plan gate unchanged. The registry pin-discipline control swaps a tampered pin file in, requires the loader to refuse service, and restores the original bytes in a finally block."));

// ---- 7 plan universe table
B.push(h2("The twenty plans"));
B.push(body("Ten plans are EVIDENCED-tier (APPROVED_INDICATION status rows served by the frozen pack) and ten are COMPUTATIONAL_HYPOTHESIS (the pre-2015 repurposing predictions and the generated molecules). The dataset links follow the recorded token filters: dapagliflozin x CKD links 14 studies (the cardio-renal era is densely covered by the registry), canagliflozin x DKD links 3 (the query returned ten registry hits but only three carry both tokens in their whitelisted fields), and captopril x CKD links none - an honest absence, since no registered trial names captopril in a chronic-kidney-disease context. The link specificity discipline is visible in the table: HFREF/HFPEF rows are CONDITION_LEVEL_ONLY wherever they inherit heart-failure queries, because registry metadata cannot separate ejection-fraction strata."));
B.push(dataTable([30, 24, 12, 12, 22],
  ["Plan", "Candidate status", "Tier", "CT links", "HUMAN gate"],
  [
    ["PLAN:DAPAGLIFLOZIN@CKD", "APPROVED_INDICATION", "EVIDENCED", "14", "REGISTRY (14 studies)"],
    ["PLAN:EMPAGLIFLOZIN@CKD", "APPROVED_INDICATION", "EVIDENCED", "10", "REGISTRY (10 studies)"],
    ["PLAN:CANAGLIFLOZIN@DKD", "APPROVED_INDICATION", "EVIDENCED", "3", "REGISTRY (3 studies)"],
    ["PLAN:DAPAGLIFLOZIN@HFREF", "APPROVED_INDICATION", "EVIDENCED", "17", "REGISTRY (17 studies)"],
    ["PLAN:LISINOPRIL@HFREF", "COMPUTATIONAL_HYPOTHESIS", "COMPUTATIONAL", "8", "REGISTRY (8 studies)"],
    ["PLAN:SPIRONOLACTONE@HFREF", "COMPUTATIONAL_HYPOTHESIS", "COMPUTATIONAL", "16", "REGISTRY (16 studies)"],
    ["PLAN:LOSARTAN@HFREF", "COMPUTATIONAL_HYPOTHESIS", "COMPUTATIONAL", "0", "PROPOSED"],
    ["PLAN:CAPTOPRIL@CKD", "APPROVED_INDICATION", "EVIDENCED", "0", "PROPOSED"],
    ["PLAN:APXD-0001..0003", "COMPUTATIONAL_HYPOTHESIS", "COMPUTATIONAL", "0 (structural absence)", "PROPOSED"],
  ]));
B.push(body("One plan carries contradictory evidence: PLAN:LOSARTAN@HFREF inherits the Phase 4 MECH_STRUCTURE_CONFLICT finding (the candidate contradicts the direct structure law of its KB encoding and was kept visible but excluded from EVIDENCED ranking there). The plan layer keeps that conflict on the record and names it in the failure-mechanisms section: an unadjudicated MECH_STRUCTURE_CONFLICT caps the candidate below EVIDENCED ranking - the contradiction is a validation target, not a silent drop."));

// ---- 8 example plans
B.push(h2("Two complete plans, rendered"));
B.push(body("The first example is the strongest plan in the round. PLAN:DAPAGLIFLOZIN@CKD: candidate dapagliflozin, APPROVED_INDICATION, EVIDENCED; disease chronic kidney disease, EXACT_DISEASE_CONTEXT; mechanism narrative (EVIDENCED) SGLT2_INHIBITOR, inhibitor of SLC5A2 citing the frozen OT mechanism row; engagement proposal (COMPUTATIONAL) recombinant-human-SLC5A2 transporter glucose-uptake assay with direction inhibit; three evidence rows (status row, channel support, mechanism-of-action rows) with resolvable identifiers; zero contradictory rows; datasets 14 CT.gov accessions plus 16 GEO context series with the query-panel source identifiers; gates PROPOSED on the four laboratory lanes and REGISTRY_ACTIVITY_PRESENT on the HUMAN lane (14 studies, metadata only); and the P7-3 section declares APPROVED_INDICATION to APPROVED_INDICATION with no evidence classes - already at the registry-derivable ceiling, and any stronger claim (efficacy) requires results content that APEIRON-X never synthesizes: a researcher must fetch and adjudicate the trial results behind the listed accessions."));
B.push(body("The second example is the structural-absence lane. PLAN:APXD-0001: candidate APXD-0001, GENERATED_MOLECULE, COMPUTATIONAL_HYPOTHESIS; disease context NONE with the explicit note that disease mapping is not claimed for a structure-only candidate; mechanism narrative (COMPUTATIONAL) structure-law consistency with SODIUM_CHANNEL_BLOCKER_AED and XANTHINE_OXIDASE_INHIBITOR, no target claim; the engagement section states the honest absence - a generated candidate has NO cited target and the hypothesis is not invented; model systems: none proposed, because without a target hypothesis every model choice would be invented; datasets: the recorded structural absence ABS:APXD_NO_REGISTRY_RECORD; all five gates PROPOSED; and the P7-3 section declares the real path: from COMPUTATIONAL_HYPOTHESIS to EXPERIMENTALLY_VALIDATED through cited biochemical and cellular records, never by computation."));

// ---- 9 cascade
B.push(h2("Verification and cascade"));
B.push(body("The phase-7 battery passes 14 of 14 checks: registry pin discipline with tamper-refusal and the structural results absence; the sixteen refusal lanes; F1 through F7; gate-state honesty (REGISTRY states only on the HUMAN lane and always metadata-labelled; generated molecules all-PROPOSED); dataset panel spot-checks (link filters, specificity discipline, GEO metadata shape); AST isolation and artifact integrity; frozen-file integrity against the baseline sha256 snapshot; and the claim-tier language scan. The full cascade runs 16 of 16 stages at exit 0 - the five v14.1 batteries, three demos, the novel-disease harness, the smoke test and the seven v15 batteries - and the four hash-pinned v14.1 files keep their baseline sha256."));
B.push(codeBlock([
  "phase-7 battery   : 14/14 checks passed",
  "theorems          : F1-F7, all PROVEN_MATH, 0 counterexamples",
  "plans             : 20 built (10 EVIDENCED+), 131 evidence ids, all resolved",
  "registry          : 158 studies + 35 series, 15 provenance records, 4 absences",
  "results content   : 0 tokens anywhere (structural, AST-verified, injection-refused)",
  "cascade           : 16/16 stages exit 0",
  "frozen v14.1 files: sha256 unchanged (baseline snapshot verified)",
]));

// ---- 10 honest limits
B.push(h2("Honest limits"));
B.push(body("The registry is a metadata registry: no trial result, effect size, p-value or outcome measure exists anywhere in the P7 pack or in any plan - structurally impossible through the fields whitelist, and that is the point: the platform identifies and cites the trials, and the adjudication of their results belongs to a researcher with database access, not to a code path. HFREF and HFPEF links are CONDITION_LEVEL_ONLY because the whitelisted fields cannot separate ejection-fraction strata; presenting them as stratum-specific would be fabrication, so the specificity is part of every link row and every plan. The assay classes, model systems, controls and endpoints are proposals from an authored rule table - they must be protocol-reviewed before any experiment, and they say nothing about what the experiment will find. A REGISTRY_ACTIVITY_PRESENT gate state means trials exist, never that a drug worked. Generated molecules have no registry records by construction, and their plans record that absence instead of inventing analogies. Dataset links exist only for the ten queried drugs; every other candidate carries an explicit recorded absence."));

// ---- 11 next steps
B.push(h2("Next steps (Phase 8)"));
B.push(body("Phase 8 closes the program: the end-to-end discover pipeline implementing the twelve-step workflow, the read-only versioned REST API and the research dashboard, the full per-module test-suite program with temporal validation, negative controls and leakage checks, staged CI timeouts, and the honest-limitation report generator that emits known gaps (licences not obtained, models not validated, endpoints refused) alongside achievements. The natural integration points already exist: Module F consumes Module C rankings and the Phase 5 artifact today, and the P7-3 discipline gives the API layer its honesty contract - any served plan must re-pass validate_loaded_plan."));

// ---- Appendix
B.push(h1("Appendix A. Reproduce This Round"));
B.push(codeBlock([
  "cd /home/z/my-project/apeiron",
  "python3 v15/connectors/refresh_phase7_cache.py --check   # offline audit",
  "python3 v15/connectors/refresh_phase7_cache.py --live    # only network path",
  "python3 scripts/gen_phase7_pack.py                       # regenerate pack",
  "python3 v15/kb_extensions/freeze_validation.py           # re-pin after edits",
  "python3 v15/write_phase7_artifacts.py                    # 7/7 theorems",
  "python3 v15/tests/test_v15_phase7.py                     # 14/14 checks",
  "python3 v15/run_full_regression.py                       # 16/16 exit 0",
  "sha256sum -c docs/baseline/frozen_files_sha256_before.txt",
]));
B.push(body("Artifacts of this round: v15/validation_data.py (the frozen P7 registry: 158 studies, 35 series, 40 recorded-filter links, 8 GEO context links, 15 provenance records, 4 absences; sha256-pinned), v15/connectors/clinicaltrials.py and geo.py (metadata-only connectors with the structural results guarantee), v15/connectors/refresh_phase7_cache.py (the deterministic live panel), v15/kb_extensions/freeze_validation.py with validation_pins.json, v15/validation_plan.py (Module F: registry facade, build gate, validate_loaded_plan, rule tables, theorems F1-F7), v15/write_phase7_artifacts.py with v15/out/phase7_benchmark.json and phase7_benchmark.txt, the phase-7 test battery, the cascade extension to 16 stages, the changelog entry and this report. The change log (docs/CHANGELOG.md, entry v15 Phase 7) lists every file touched with reasons and reproduction commands.", { after: 200 }));
