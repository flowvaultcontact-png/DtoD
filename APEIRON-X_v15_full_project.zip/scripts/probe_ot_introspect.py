"""Introspect OT Drug + Disease.knownDrugs field shapes (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 40, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:250])
        else:
            print(f"{name}: OK {json.dumps(p['data'])[:600]}")
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:150]}")


run("drug_fields", '{__type(name:"Drug"){fields{ name }}}')
run("moa_fields", '{__type(name:"MechanismOfAction"){fields{ name }}}')
run("kd_fields", '{__type(name:"KnownDrug"){fields{ name }}}')
