#!/usr/bin/env python3
"""Phase 2 identifier verification: fetch MONDO term records via the EBI OLS4
API and print the label + ICD/MeSH cross-references. Used to author the
frozen v15 vocabulary tables with machine-verified provenance (nothing is
hand-invented). Output: JSON report + console table."""
import json
import sys
import urllib.request
from datetime import datetime, timezone

IDS = {
    "MONDO:0004592": "impetigo (pack D64)",
    "MONDO:0001031": "purulent acute otitis media (pack D65)",
    "MONDO:0005316": "bacterial vaginosis (pack D66)",
    "MONDO:0006989": "periapical abscess (pack D67)",
    "MONDO:0005081": "preeclampsia (pack D68)",
    "MONDO:0005148": "type 2 diabetes mellitus (existing D08)",
    "MONDO:0005044": "hypertensive disorder (existing D01)",
    "MONDO:0004979": "asthma (existing D15/D16)",
    "MONDO:0005152": "rheumatoid arthritis (existing D54)",
}

def fetch(mondo_id: str) -> dict:
    num = mondo_id.split(":")[1]
    url = ("https://www.ebi.ac.uk/ols4/api/ontologies/mondo/terms?iri="
           f"http%3A%2F%2Fpurl.obolibrary.org%2Fobo%2FMONDO_{num}")
    req = urllib.request.Request(url, headers={"Accept": "application/json",
                                               "User-Agent": "apeiron-v15-audit"})
    with urllib.request.urlopen(req, timeout=30) as r:
        data = json.load(r)
    terms = data.get("_embedded", {}).get("terms", [])
    if not terms:
        return {"ok": False, "reason": "no term"}
    t = terms[0]
    xrefs = t.get("annotation", {}).get("database_cross_reference", []) or []
    keep = [x for x in xrefs if x.startswith(("ICD10", "MESH:", "OMIM:",
                                              "ICD9"))]
    return {"ok": True, "label": t.get("label"), "iri": t.get("iri"),
            "xrefs_icd_mesh_omim": sorted(keep),
            "definition": (t.get("description") or [""])[0][:180]}

def main() -> int:
    out = {"retrieval_utc": datetime.now(timezone.utc)
           .strftime("%Y-%m-%dT%H:%M:%SZ"), "source": "EBI OLS4 API (mondo)",
           "url_template": "https://www.ebi.ac.uk/ols4/api/ontologies/mondo/terms?iri=",
           "terms": {}}
    for mid, role in sorted(IDS.items()):
        try:
            rec = fetch(mid)
        except Exception as exc:                     # noqa: BLE001 — audit tool
            rec = {"ok": False, "reason": repr(exc)}
        rec["used_for"] = role
        out["terms"][mid] = rec
        status = "OK " if rec["ok"] else "FAIL"
        label = rec.get("label", rec.get("reason", "?"))
        print(f"[{status}] {mid:<16} {label}")
        if rec["ok"]:
            print(f"      xrefs: {', '.join(rec['xrefs_icd_mesh_omim'])}")
    with open("/home/z/my-project/scripts/ols_verification_report.json",
              "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=1, sort_keys=True)
    n_ok = sum(1 for r in out["terms"].values() if r["ok"])
    print(f"\n{n_ok}/{len(IDS)} MONDO ids verified against OLS")
    return 0 if n_ok == len(IDS) else 1

if __name__ == "__main__":
    sys.exit(main())
