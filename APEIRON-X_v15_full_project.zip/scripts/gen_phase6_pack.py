#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 6 pack generator (P6-1, Module E).

Reads ONLY frozen inputs (read-only) and the frozen Phase 3/4 cache
payloads, then emits `v15/kgraph_data.py` — the frozen P8 knowledge-
graph section — VERBATIM: every edge carries one of the 7 formal
relation types, an evidence tier, resolvable source ids and explicit
attributes. Nothing is invented; every lane that could not be verified
is recorded in P8_ABSENCES.

Formal relations (plan §7 P6-1, in canonical layer order):
  1. disease->gene       Open Targets association rows + KB evidence rows
  2. gene->protein       HGNC/UniProt verified identifiers
  3. protein->pathway    Reactome cross-refs inside frozen UniProt entries
  4. target->mechanism   targets of drugs realizing a mechanism class
  5. mechanism->drug     KB mechanism classes -> member drugs, incl.
                         NON_MOLECULAR excluded classes
  6. drug->structure     KB axiom A6 SMILES + frozen ChEMBL canonical SMILES
  7. structure->property frozen rule-based descriptor block, labelled
                         PREDICTED_RULEBASED / COMPUTATIONAL (never measured)

Input pins (sha256 of every consumed frozen file + cache payload + the
pinned RDKit version) are embedded so the artifact is self-auditing.
The module is then sha256-pinned by `v15/kb_extensions/freeze_kgraph.py`.

Determinism: rows are produced by sorted iteration only; re-running the
generator on unchanged inputs must be byte-identical (P6-2 reproducibility
theorem machine-checks this).
"""

import hashlib
import json
import os
import pprint
import sys
from datetime import datetime, timezone

ROOT = "/home/z/my-project/apeiron"
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "v15"))

OUT_PATH = os.path.join(ROOT, "v15", "kgraph_data.py")
CACHE_DIR = os.path.join(ROOT, "v15", "cache")
MANIFEST_PATH = os.path.join(CACHE_DIR, "manifest.json")

KG_SCHEMA_VERSION = "15.6.0"
FROZEN_UTC = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

RELS = ("disease->gene", "gene->protein", "protein->pathway",
        "target->mechanism", "mechanism->drug", "drug->structure",
        "structure->property")
LAYERS = {"disease": 0, "gene": 1, "protein": 2, "pathway": 3,
          "mechanism": 4, "drug": 5, "structure": 6, "property": 7}


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def pylit(obj) -> str:
    """Valid deterministic Python literal block (pprint, sorted dicts)."""
    return pprint.pformat(obj, indent=1, width=96, sort_dicts=True)


def rel_order(rel: str):
    a, b = rel.split("->")
    kind = {"target": "gene"}        # target nodes live on the gene layer
    return (LAYERS[kind.get(a, a)], LAYERS[kind.get(b, b)])


def main() -> int:
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--utc", default=None,
                    help="freeze timestamp override (reproducibility "
                         "theorem re-runs generation with the original "
                         "utc and expects a byte-identical artifact)")
    ap.add_argument("--out", default=None,
                    help="output path override (default v15/kgraph_data.py; "
                         "the reproducibility theorem writes to a temp "
                         "path and byte-compares)")
    args = ap.parse_args()
    global FROZEN_UTC
    if args.utc:
        FROZEN_UTC = args.utc
    out_path = args.out or OUT_PATH

    import rdkit
    import v15.target_data as td
    import v15.repurposing_data as rd
    import drug_structures as DS
    from v15.chem import mol_io, props

    with open(os.path.join(ROOT, "postulates_v14.json"), "rb") as fh:
        post_raw = fh.read()
    post = json.loads(post_raw.decode("utf-8"))

    with open(MANIFEST_PATH, encoding="utf-8") as fh:
        man = json.load(fh)

    def payload(key):
        path = os.path.join(CACHE_DIR, man[key]["sha256"] + ".json")
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)["payload"]

    edges = {}      # (rel, src, dst) -> edge dict (merged)
    absences = []

    def add(rel, src, dst, tier, sources, attrs):
        key = (rel, src, dst)
        e = edges.get(key)
        if e is None:
            edges[key] = {"rel": rel, "src": src, "dst": dst,
                          "tier": tier, "sources": sorted(set(sources)),
                          "attrs": attrs}
            return
        e["sources"] = sorted(set(e["sources"]) | set(sources))
        for k, v in attrs.items():
            cur = e["attrs"].get(k)
            if cur is None:
                e["attrs"][k] = v
            elif isinstance(cur, list) and isinstance(v, (list, tuple)):
                e["attrs"][k] = sorted(set(cur) | set(v))
            elif isinstance(cur, float) and isinstance(v, (int, float)):
                e["attrs"][k] = max(cur, float(v))
            elif cur != v:
                # first-wins, deterministic under sorted iteration; the
                # conflicting value is recorded, never silently dropped
                e["attrs"].setdefault(k + "_conflicts", [])
                if v not in e["attrs"][k + "_conflicts"]:
                    e["attrs"][k + "_conflicts"] = \
                        sorted(e["attrs"][k + "_conflicts"] + [v])
        if tier == "EVIDENCED":
            e["tier"] = "EVIDENCED"

    # ------------------------------------------------ 1. disease->gene
    for did_key, row in sorted(td.OT_ASSOCIATIONS.items()):
        for sym, r in sorted(row["rows"].items()):
            score = r.get("score")
            dts = r.get("datatypeScores") or []
            attrs = {"ot_datatypes": sorted(dt for dt, _ in dts),
                     "association_kind": "ASSOCIATION_NOT_CAUSATION",
                     "disease_id_external": row["efo_id"]}
            if score is not None:
                attrs["association_score"] = float(score)
            else:
                attrs["association_score"] = "ABSENT_IN_SOURCE_ROW"
            if not dts:
                attrs["ot_datatypes"] = ["ABSENT_IN_SOURCE_ROW"]
            add("disease->gene", did_key, sym, "EVIDENCED",
                list(row["sources"]), attrs)
    for r in td.EVIDENCE_ROWS:
        add("disease->gene", r["did"], r["symbol"], "EVIDENCED",
            list(r["sources"]),
            {"kinds": sorted(r["kinds"]), "direction": r["direction"]})

    # ------------------------------------------------ 2. gene->protein
    resolved_sym_acc = {}
    for gene, rec in sorted(td.GENE_TARGETS.items()):
        add("gene->protein", gene, rec["uniprot"], "EVIDENCED",
            list(rec["sources"]),
            {"hgnc_id": rec["hgnc_id"], "ensembl": rec["ensembl"],
             "protein_kind": rec["target_kind"]})
        resolved_sym_acc[gene] = rec["uniprot"]
    for key in sorted(k for k in man if k.startswith("uniprot.resolve.")):
        sym = key.split(".", 2)[2].upper()
        pl = payload(key)
        results = pl.get("results") or []
        if not results:
            absences.append({"lane": "gene->protein", "gene": sym,
                             "absence": "RESOLVE_EMPTY",
                             "detail": "frozen UniProt resolve payload "
                                       "carries no results"})
            continue
        acc = results[0].get("primaryAccession")
        names = {g["geneName"]["value"].upper()
                 for g in (results[0].get("genes") or [])
                 if g.get("geneName")}
        if sym not in names:
            absences.append({"lane": "gene->protein", "gene": sym,
                             "absence": "SYMBOL_MISMATCH_IN_RESOLVE",
                             "detail": f"payload genes {sorted(names)} do "
                                       "not contain the queried symbol; "
                                       "edge NOT emitted"})
            continue
        if not acc:
            absences.append({"lane": "gene->protein", "gene": sym,
                             "absence": "NO_ACCESSION_IN_RESOLVE",
                             "detail": "payload lacks primaryAccession"})
            continue
        prev = resolved_sym_acc.get(sym)
        if prev and prev != acc:
            absences.append({"lane": "gene->protein", "gene": sym,
                             "absence": "ACCESSION_CONFLICT",
                             "detail": f"table says {prev}, resolve says "
                                       f"{acc}; table edge kept, conflict "
                                       "recorded"})
            continue
        resolved_sym_acc[sym] = acc
        add("gene->protein", sym, acc, "EVIDENCED", ["SRC:UNIPROT_P3"],
            {"resolve_key": key})

    # ------------------------------------------------ 3. protein->pathway
    entry_accs = set()
    for key in sorted(k for k in man if k.startswith("uniprot.entry.")):
        acc = key.split(".", 2)[2]
        entry_accs.add(acc)
        pl = payload(key)
        xrefs = [x for x in (pl.get("uniProtKBCrossReferences") or [])
                 if x.get("database") == "Reactome"]
        if not xrefs:
            absences.append({"lane": "protein->pathway", "protein": acc,
                             "absence": "NO_REACTOME_XREF_IN_ENTRY",
                             "detail": "frozen UniProt entry has no "
                                       "Reactome cross-reference"})
            continue
        for x in xrefs:
            name = ""
            for pr in x.get("properties") or []:
                if pr.get("key") == "PathwayName":
                    name = pr.get("value", "")
            add("protein->pathway", acc, x["id"], "EVIDENCED",
                ["SRC:UNIPROT_P3"], {"pathway_name": name})
    for sym, acc in sorted(resolved_sym_acc.items()):
        if acc not in entry_accs:
            absences.append({"lane": "protein->pathway", "protein": acc,
                             "gene": sym,
                             "absence": "NO_FROZEN_ENTRY_PAYLOAD",
                             "detail": "no uniprot.entry.<acc> payload in "
                                       "the frozen cache; Reactome lane "
                                       "left empty for this protein"})

    # ------------------------------------------------ 4./5. mechanism lanes
    for drug, rec in sorted(rd.DRUGS_P4.items()):
        cls = rec.get("kb_mech_class")
        if not cls:
            absences.append({"lane": "mechanism->drug", "drug": drug,
                             "absence": "NO_KB_MECH_CLASS",
                             "detail": "pack record carries no "
                                       "kb_mech_class; mechanism lanes "
                                       "left empty for this drug"})
        for m in rec["moa_rows"]:
            for sym in sorted(m["target_symbols"]):
                if cls:
                    add("target->mechanism", sym, cls, "EVIDENCED",
                        list(rec["sources"]),
                        {"action_type": m["action_type"],
                         "mechanism_of_action": m["mechanism_of_action"],
                         "via_drugs": [drug]})
        if cls:
            add("mechanism->drug", cls, drug, "EVIDENCED",
                list(rec["sources"]),
                {"kb_member": bool(rec.get("kb_member")),
                 "maximum_clinical_stage": rec.get(
                     "maximum_clinical_stage", "UNKNOWN")})
    for cls, rec in sorted(post["excluded_classes"].items()):
        for member in sorted(rec.get("members") or []):
            add("mechanism->drug", cls, member, "EVIDENCED",
                ["KB:POSTULATES_V14"],
                {"kb_member": False,
                 "class_status": "NON_MOLECULAR_CLASS_EXCLUDED"})

    # ------------------------------------------------ 6. drug->structure
    struct_props = {}
    for name in sorted(DS.SMILES):
        smi = DS.SMILES[name]
        canon = mol_io.canonical_smiles(smi)
        if not canon:
            absences.append({"lane": "drug->structure", "drug": name,
                             "absence": "CANONICALISATION_FAILED",
                             "detail": "KB SMILES did not canonicalise"})
            continue
        add("drug->structure", name, canon, "EVIDENCED", ["KB:AXIOM_A6"],
            {"lane": "KB (v14.1 axiom A6, PubChem CID-anchored)"})
        struct_props[canon] = props.full_property_block(canon)
    chembl_struct = 0
    for drug, rec in sorted(rd.DRUGS_P4.items()):
        cid = rec.get("chembl_id")
        key = "chembl.molecule." + cid
        if key not in man:
            absences.append({"lane": "drug->structure", "drug": drug,
                             "absence": "NO_FROZEN_CHEMBL_PAYLOAD",
                             "detail": cid + " not in frozen cache"})
            continue
        struct = payload(key).get("molecule_structures") or {}
        smi = struct.get("canonical_smiles")
        if not smi:
            absences.append({"lane": "drug->structure", "drug": drug,
                             "absence": "NO_STRUCTURE_IN_FROZEN_RECORD",
                             "detail": cid + " record has no canonical_smiles"})
            continue
        canon = mol_io.canonical_smiles(smi)
        if not canon:
            absences.append({"lane": "drug->structure", "drug": drug,
                             "absence": "CANONICALISATION_FAILED",
                             "detail": cid + " SMILES did not canonicalise"})
            continue
        add("drug->structure", drug, canon, "EVIDENCED",
            ["ChEMBL:" + cid, "SRC:CHEMBL_P4"],
            {"lane": "ChEMBL frozen cache (Phase 4 payload)",
             "chembl_id": cid})
        chembl_struct += 1
        struct_props.setdefault(canon, props.full_property_block(canon))

    # ------------------------------------------------ 7. structure->property
    for canon, block in sorted(struct_props.items()):
        add("structure->property", canon, "PROP:LIPINSKI",
            "COMPUTATIONAL", ["GEN:P6_RULEBASED_PROPS"],
            {"value": str(block["lipinski"]["passes_n"]) + "/4",
             "violations": list(block["lipinski"]["violations"]),
             "label": props.LABEL})
        add("structure->property", canon, "PROP:VEBER",
            "COMPUTATIONAL", ["GEN:P6_RULEBASED_PROPS"],
            {"value": str(block["veber"]["passes_n"]) + "/2",
             "violations": list(block["veber"]["violations"]),
             "label": props.LABEL})
        add("structure->property", canon, "PROP:SOLUBILITY_CLASS",
            "COMPUTATIONAL", ["GEN:P6_RULEBASED_PROPS"],
            {"value": block["solubility_class"]["class"],
             "label": props.LABEL})
        add("structure->property", canon, "PROP:PERMEABILITY_CLASS",
            "COMPUTATIONAL", ["GEN:P6_RULEBASED_PROPS"],
            {"value": block["permeability_class"]["class"],
             "label": props.LABEL})
        desc = block["descriptors"]
        add("structure->property", canon, "PROP:DESCRIPTORS",
            "COMPUTATIONAL", ["GEN:P6_RULEBASED_PROPS"],
            {"mw": round(float(desc["mw"]), 2),
             "clogp": round(float(desc["clogp"]), 2),
             "tpsa": round(float(desc["tpsa"]), 2),
             "hbd": int(desc["hbd"]), "hba": int(desc["hba"]),
             "rotb": int(desc["rotatable_bonds"]), "label": props.LABEL})

    edge_list = [edges[k] for k in
                 sorted(edges, key=lambda k: (rel_order(k[0]), k[1], k[2]))]
    stats = {r: sum(1 for e in edge_list if e["rel"] == r) for r in RELS}

    pins = {
        "postulates_v14.json": hashlib.sha256(post_raw).hexdigest(),
        "drug_structures.py": sha256_file(
            os.path.join(ROOT, "drug_structures.py")),
        "disease_mechanism_table.py": sha256_file(
            os.path.join(ROOT, "disease_mechanism_table.py")),
        "v15/target_data.py": sha256_file(
            os.path.join(ROOT, "v15", "target_data.py")),
        "v15/repurposing_data.py": sha256_file(
            os.path.join(ROOT, "v15", "repurposing_data.py")),
        "v15/cache/manifest.json": sha256_file(MANIFEST_PATH),
        "cache_payloads": {k: man[k]["sha256"] for k in sorted(man)
                           if k.startswith(("uniprot.", "chembl.molecule."))},
        "rdkit_version": rdkit.__version__,
        "rdkit_pin": "rdkit==2026.09.2 (requirements.txt, audit R4)",
    }

    source_records = {
        "KB:AXIOM_A6": {
            "resource": "APEIRON-X v14.1 hash-pinned corpus "
                        "(drug_structures.py)",
            "resource_version": "sha256 " + pins["drug_structures.py"],
            "retrieval_utc": FROZEN_UTC,
            "url": "file:drug_structures.py",
            "license": "internal (PubChem CID-anchored axiom A6)",
            "evidence_type": "annotation",
            "confidence": "hash_pinned_corpus",
            "limitations": "component-level ground truth only",
        },
        "KB:POSTULATES_V14": {
            "resource": "APEIRON-X v14.1 axiom corpus "
                        "(postulates_v14.json)",
            "resource_version": "sha256 " + pins["postulates_v14.json"],
            "retrieval_utc": FROZEN_UTC,
            "url": "file:postulates_v14.json",
            "license": "internal",
            "evidence_type": "annotation",
            "confidence": "hash_pinned_corpus",
            "limitations": "excluded-class members only",
        },
        "SRC:OT_P3": {
            "alias_of": "v15/target_data.py SOURCE_RECORDS SRC:OT_P3 "
                        "(machine-verified fetch " + td.FROZEN_UTC + ")"},
        "SRC:HGNC_P3": {
            "alias_of": "v15/target_data.py SOURCE_RECORDS SRC:HGNC_P3 ("
                        + td.FROZEN_UTC + ")"},
        "SRC:UNIPROT_P3": {
            "alias_of": "v15/target_data.py SOURCE_RECORDS SRC:UNIPROT_P3 ("
                        + td.FROZEN_UTC + ")"},
        "SRC:REACTOME_P3": {
            "alias_of": "v15/target_data.py SOURCE_RECORDS SRC:REACTOME_P3 ("
                        + td.FROZEN_UTC + ")"},
        "SRC:OT_P4": {
            "alias_of": "v15/repurposing_data.py SOURCE_RECORDS SRC:OT_P4 ("
                        + rd.FROZEN_UTC + ")"},
        "SRC:CHEMBL_P4": {
            "alias_of": "v15/repurposing_data.py SOURCE_RECORDS "
                        "SRC:CHEMBL_P4 (" + rd.FROZEN_UTC + ")"},
        "SRC:KB_P4": {
            "alias_of": "v15/repurposing_data.py SOURCE_RECORDS SRC:KB_P4"},
        "GEN:P6_RULEBASED_PROPS": {
            "resource": "APEIRON-X v15 rule-based descriptor layer "
                        "(RDKit " + rdkit.__version__ + ", pinned)",
            "resource_version": "props schema " + props.PROPS_SCHEMA_VERSION,
            "retrieval_utc": FROZEN_UTC,
            "url": "file:v15/chem/props.py",
            "license": "internal",
            "evidence_type": "computational_rule",
            "confidence": "deterministic_rule_layer",
            "limitations": "rule-based triage values, NEVER measurements; "
                           "frozen verbatim into this module at generation "
                           "time",
        },
    }

    # -- completeness pass: EVERY cited source id must resolve -----------
    for e in edge_list:
        for sid in e["sources"]:
            if sid in source_records:
                continue
            if sid.startswith("ChEMBL:"):
                cid = sid.split(":", 1)[1]
                key = "chembl.molecule." + cid
                sha = man[key]["sha256"] if key in man else "UNKNOWN"
                source_records[sid] = {
                    "resource": "ChEMBL frozen cache payload (Phase 4)",
                    "resource_version": "payload sha256 " + sha,
                    "retrieval_utc": rd.FROZEN_UTC,
                    "url": "https://www.ebi.ac.uk/chembl/compound_report_card/" + cid,
                    "license": "CC-BY-4.0",
                    "evidence_type": "annotation",
                    "confidence": "machine_fetched_verbatim",
                    "limitations": "structure record only",
                }
            elif sid.startswith("EPMC:PMID-") and sid in td.LITERATURE:
                meta = td.LITERATURE[sid]
                source_records[sid] = {
                    "resource": "Europe PMC (via v15/target_data.py "
                                "LITERATURE table)",
                    "resource_version": "EXT_ID verified " + td.FROZEN_UTC,
                    "retrieval_utc": td.FROZEN_UTC,
                    "url": "https://europepmc.org/article/MED/" + meta["pmid"],
                    "license": "SEE_TERMS",
                    "evidence_type": "literature",
                    "confidence": "machine_verified_citation_metadata",
                    "limitations": "metadata-level citation",
                }
            elif sid.startswith("KB:D"):
                source_records[sid] = {
                    "resource": "APEIRON-X v14.1 KB disease row (hash-pinned "
                                "disease_drug_kb.py)",
                    "resource_version": "sha256 "
                                        + pins["disease_mechanism_table.py"]
                                        + " / disease_drug_kb.py corpus",
                    "retrieval_utc": FROZEN_UTC,
                    "url": "file:disease_drug_kb.py#" + sid,
                    "license": "internal",
                    "evidence_type": "guideline_row",
                    "confidence": "hash_pinned_corpus",
                    "limitations": "internal corpus citation",
                }
            elif sid.startswith("SRC:"):
                source_records[sid] = {
                    "alias_of": sid + " (frozen pack SOURCE_RECORDS: "
                                "v15/target_data.py or "
                                "v15/repurposing_data.py)"}
            else:
                absences.append({"lane": "provenance", "source_id": sid,
                                 "absence": "UNRESOLVABLE_SOURCE_ID",
                                 "detail": "edge cites a source id with no "
                                           "record; completeness theorem "
                                           "would fail — recorded at "
                                           "generation time"})

    header = """# =====================================================================
# APEIRON-X v15 - FROZEN KNOWLEDGE GRAPH / P8 POSTULATE SECTION (P6-1)
# ---------------------------------------------------------------------
# GENERATED artifact - do not hand-edit. Generator:
#   scripts/gen_phase6_pack.py (this run: {utc})
# After ANY intentional regeneration, re-pin:
#   python3 v15/kb_extensions/freeze_kgraph.py
#
# DOCTRINE (V15_IMPLEMENTATION_PLAN section 7):
#   1. Edges are emitted VERBATIM from the frozen inputs listed in
#      INPUT_PINS (all sha256-embedded). Nothing is hand-invented;
#      unverifiable lanes are recorded in P8_ABSENCES, never guessed.
#   2. FROZEN: the sha256 of THIS file is pinned in
#      v15/kb_extensions/kgraph_pins.json; v15.kgraph.load_kgraph()
#      refuses to serve on a mismatch.
#   3. The v14.1 axiom corpus (postulates_v14.json) is NOT touched:
#      P8 is an ADDITIVE v15 postulate section under the same freeze
#      discipline (audit R1 automated by the phase-2 tooling pattern).
#   4. Claim tiers: structure->property edges are COMPUTATIONAL and
#      labelled {lbl} (rule-based RDKit descriptors, never
#      measured). All other edges are EVIDENCED and cite resolvable
#      source ids (machine-checked by
#      theorem_evidence_provenance_completeness).
#   5. v15-only: no v14.1 derivation engine imports this module
#      (C0 hermeticity untouched).
# =====================================================================

KG_SCHEMA_VERSION = "{schema}"
FROZEN_UTC = "{utc}"

RELATIONS = {rels}

NODE_LAYERS = {layers}

INPUT_PINS = {pins}

P8_ABSENCES = {absences}

SOURCE_RECORDS_P8 = {records}

P8_EDGES = {edges}

P8_STATS = {stats}
""".format(utc=FROZEN_UTC, lbl=props.LABEL, schema=KG_SCHEMA_VERSION,
           rels=repr(RELS), layers=pylit(LAYERS), pins=pylit(pins),
           absences=pylit(absences), records=pylit(source_records),
           edges=pylit(edge_list), stats=pylit(stats))

    with open(out_path, "w", encoding="utf-8") as fh:
        fh.write(header)
    print("[gen] wrote " + out_path)
    print("[gen] edges: %d  " % len(edge_list) +
          " ".join("%s=%d" % (r, stats[r]) for r in RELS))
    print("[gen] absences recorded: %d" % len(absences))
    print("[gen] structures with property blocks: %d "
          "(KB lane + %d ChEMBL)" % (len(struct_props), chembl_struct))
    return 0


if __name__ == "__main__":
    sys.exit(main())
