#!/usr/bin/env python3
"""Build scripts/gen_v15_phase6_report.js from the validated Phase 5
generator (same R1-cover architecture), replacing the content block,
cover config and output path. Keeps every skill-compliant structural
decision intact."""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "gen_v15_phase5_report.js")
CONTENT = os.path.join(HERE, "p6_content.js")
OUT = os.path.join(HERE, "gen_v15_phase6_report.js")

src = open(SRC, encoding="utf-8").read()
content = open(CONTENT, encoding="utf-8").read()
if not content.endswith("\n"):
    content += "\n"

# 1. header comment
src = src.replace(
    "// APEIRON-X v15 — Phase 5 Novel Molecule Discovery (deliverable docx)",
    "// APEIRON-X v15 — Phase 6 Mathematical Reasoning (deliverable docx)", 1)

# 2. content region replacement (from first content marker to the DOCUMENT banner)
start_marker = "// ---- 1 Executive Summary"
end_marker = "// ================================================================== DOCUMENT"
i = src.index(start_marker)
j = src.index(end_marker)
src = src[:i] + content + src[j:]

# 3. running header + cover config
src = src.replace('text: "APEIRON-X v15 Phase 5 Report"',
                  'text: "APEIRON-X v15 Phase 6 Report"', 1)
src = src.replace('title: "APEIRON-X v15 Molecular Discovery"',
                  'title: "APEIRON-X v15 Mathematical Reasoning"', 1)
src = src.replace(
    'subtitle: "Phase 5: Module D chem package, deterministic law-guided '
    'generation, the round-trip theorem on 191 molecules and the '
    'truth-in-labeling obligation"',
    'subtitle: "Phase 6: Module E frozen P8 knowledge graph, eight new '
    'proof obligations, the fingerprint-portability gate and memoized '
    'coupling with a determinism theorem"', 1)
old_meta = '''        metaLines: [
          "Round: v15 Phase 5 (P5-1 chem IO, P5-2 properties, P5-3 registry, P5-4 generation, P5-5 labeling)",
          "Evidence: 191 KB molecules unchanged, 117 laws re-certified, 100 candidates emitted",
          "Benchmark: 100/100 valid + labeled; 178 rejections recorded, 0 silent drops",
          "Gate: full cascade 14/14 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
new_meta = '''        metaLines: [
          "Round: v15 Phase 6 (P6-1 P8 graph, P6-2 eight obligations, P6-3 fingerprint gate, P6-4 memo)",
          "Evidence: 1539 typed edges / 726 nodes, 48 provenance records, 73 recorded absences",
          "Benchmark: 10/10 theorems PROVEN_MATH; 10/10 battery checks; byte-identical regeneration",
          "Gate: full cascade 15/15 exit 0; v14.1 pinned hashes unchanged",
          "Date: 2026-11-25",
        ],'''
assert old_meta in src, "metaLines block not found"
src = src.replace(old_meta, new_meta, 1)
src = src.replace('footerRight: "v15 Phase 5 Report"',
                  'footerRight: "v15 Phase 6 Report"', 1)
src = src.replace(
    '"/home/z/my-project/download/APEIRON-X_v15_Phase5_Molecular_Discovery.docx"',
    '"/home/z/my-project/download/APEIRON-X_v15_Phase6_Mathematical_Reasoning.docx"', 1)
src = src.replace('console.log("written: APEIRON-X_v15_Phase5_Molecular_Discovery.docx")',
                  'console.log("written: APEIRON-X_v15_Phase6_Mathematical_Reasoning.docx")', 1)

# sanity: no Phase 5 content markers survived
for leftover in ("P5-1 chem", "truth-in-labeling obligation",
                 "Phase 5: Module D", "Phase5_Molecular_Discovery",
                 "APXD-0001"):
    assert leftover not in src, leftover
assert src.count("// ---- 1 Executive Summary") == 1
assert "fingerprint-portability" in src and "memo" in src

open(OUT, "w", encoding="utf-8").write(src)
print(f"wrote {OUT} ({len(src)} chars)")
