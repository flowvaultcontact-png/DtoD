"""Introspect MechanismsOfAction + clinicalIndicationsFromDrugImp fields
and sample one real drug record end-to-end (probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None, maxlen=2000):
    rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                     None, json.dumps({"query": query,
                                       "variables": variables or {}}).encode(),
                     {"Content-Type": "application/json"}, 40, 1, name)
    p = json.loads(rec[1])
    if p.get("errors"):
        print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:250])
        return None
    print(f"{name}: OK {json.dumps(p['data'])[:maxlen]}")
    return p["data"]


run("moa_fields", '{__type(name:"MechanismsOfAction"){fields{name '
    'type{kind name ofType{kind name ofType{kind name}}}}}}')
run("clinind_fields", '{__type(name:"clinicalIndicationsFromDrugImp")'
    '{fields{name type{kind name ofType{kind name ofType{kind name}}}}}}')
