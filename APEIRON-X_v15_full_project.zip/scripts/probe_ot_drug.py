"""One-shot probe: does the live OT GraphQL Drug.mechanismsOfAction expose
per-row targets with approvedSymbol? Decides the rich vs plain drug-record
query used by the Phase 4 connector (not part of the frozen flow)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")

from v15.connectors import base  # noqa: E402

Q_RICH = '''query($id:String!){
  drug(chemblId:$id){
    id name isApproved withdrawn maximumClinicalTrialPhase firstApproval
    approvedIndications
    mechanismsOfAction{ rows{ actionType mechanismOfAction targetId
      targets{ id approvedSymbol } } }
  }
}'''

req = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                 None, json.dumps({"query": Q_RICH,
                                   "variables": {"id": "CHEMBL1201595"}}).encode(),
                 {"Content-Type": "application/json"}, 40, 1, "probe")
payload = json.loads(req[1])
if payload.get("errors"):
    print("RICH-FAIL", json.dumps(payload["errors"])[:300])
else:
    d = payload["data"]["drug"]
    rows = d["mechanismsOfAction"]["rows"]
    print("RICH-OK name=", d["name"], "firstApproval=", d.get("firstApproval"),
          "n_moa=", len(rows))
    for r in rows[:4]:
        syms = [t.get("approvedSymbol") for t in (r.get("targets") or [])]
        print("   ", r["actionType"], r["targetId"], syms)
    print("approvedIndications sample:", (d.get("approvedIndications") or [])[:6])
