"""Resolve nested type names (non-raising probe)."""
import json
import sys

sys.path.insert(0, "/home/z/my-project/apeiron")
from v15.connectors import base  # noqa: E402


def run(name, query, variables=None):
    try:
        rec = base._http("POST", "https://api.platform.opentargets.org/api/v4/graphql",
                         None, json.dumps({"query": query,
                                           "variables": variables or {}}).encode(),
                         {"Content-Type": "application/json"}, 40, 1, name)
        p = json.loads(rec[1])
        if p.get("errors"):
            print(f"{name}: GRAPHQL-ERR", json.dumps(p["errors"])[:200])
            return None
        return p["data"]
    except Exception as exc:  # noqa: BLE001
        print(f"{name}: FAIL {str(exc)[:120]}")
        return None


d = run("drugtypes", '{__type(name:"Drug"){fields{name '
        'type{kind name ofType{kind name ofType{kind name ofType{kind name '
        'ofType{kind name}}}}}}}}')
if d:
    for f in d["__type"]["fields"]:
        if f["name"] in ("indications", "mechanismsOfAction"):
            print(f["name"], "->", json.dumps(f["type"]))

d2 = run("disefields", '{__type(name:"Disease"){fields{name '
         'type{kind name ofType{kind name ofType{kind name}}}}}}')
if d2:
    for f in d2["__type"]["fields"]:
        if "nown" in f["name"].lower() or "ndic" in f["name"].lower():
            print("Disease.", f["name"], "->", json.dumps(f["type"]))
