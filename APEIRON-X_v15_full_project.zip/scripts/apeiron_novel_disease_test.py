#!/usr/bin/env python3
"""
APEIRON-X v14.1 — out-of-domain (novel disease) generalization test battery.

Question under test: can the system predict drugs for diseases that are NOT
in the project (the disease knowledge base)?

History: the v14.0 round (8 Tier-A cases) found 3 FAILs whose verified root
cause was:
  (1) every learned class law collapsed to a single rule on the pathway
      channel, so diseases sharing a pathway value inherited the same
      therapy class (HFpEF->ACEI, BED->methylphenidate, vasospastic
      angina->beta-blocker);
  (2) guideline-era drift (three current-standard indications missing);
  (3) no SGLT2 class law existed (no KB row led with an SGLT2 inhibitor).

The v14.1 fix (all layers re-proved, exit 0):
  * anti-collapse channel laws: every learned monomial is pathway-anchored
    with depth >= 2 (MIN_TERM_DEPTH=2; separating_term_family ladder) —
    a single shared channel can never transmit a class any more;
  * guideline-drift round: D61 HFpEF (SGLT2i first-line, ESC 2023),
    D62 binge-eating disorder (lisdexamfetamine, FDA/NICE), D63 vasospastic
    angina (CCB first-line, ACC/AHA 2023) — D61 creates the missing
    SGLT2_INHIBITOR class law.

This harness:
  Tier A: the 8 novel diseases of the v14.0 round (3 now in-domain via the
          drift round, 5 still genuinely novel) -> score rank-1 predictions.
  Tier B: diseases the KB vocabulary cannot molecularly serve (honest
          refusal / documented non-encodability expected).
  Tier C: adversarial probes (out-of-vocabulary values, malformed
          encodings, mis-encoded diseases, non-KB molecules).
  Tier D: ANTI-COLLAPSE REGRESSION — encodings that share ONLY the pathway
          with a KB disease (the exact pre-v14.1 failure mode) must never
          inherit that disease's therapy class; plus a corpus-level check
          that every learned monomial has depth >= 2.

Outputs: JSON results + human-readable transcript.
"""

import json
import os
import sys
import time

HERE = "/home/z/my-project/apeiron"
sys.path.insert(0, HERE)

import disease_drug_kb as KB
from apeiron_drug_discovery_proof import DrugOracle
from apeiron_structure_proof import (
    StructLayer, derive_structure_laws, derive_drug_laws,
    derive_drug_channel_laws, GenericOracle, reverse_class_match,
)

OUT_JSON = "/home/z/my-project/download/apeiron_novel_disease_results.json"
OUT_TXT = "/home/z/my-project/download/apeiron_novel_disease_transcript.txt"

log_lines = []


def log(s=""):
    print(s)
    log_lines.append(s)


# ---------------------------------------------------------------------
# 0. Build the proved machinery (no S-battery, only the derivation parts)
# ---------------------------------------------------------------------
t0 = time.time()
log("=" * 78)
log("APEIRON-X v14.1 — NOVEL-DISEASE GENERALIZATION TEST (post-fix re-run)")
log("  root cause fixed: pathway-channel collapse + guideline drift +")
log("  missing SGLT2 class law. All proof layers re-proved exit 0.")
log("=" * 78)
log(f"[build] t={time.time()-t0:5.1f}s constructing structure layer (RDKit)...")
layer = StructLayer()
oracle = DrugOracle(KB.DISEASES)
oracle.learn()
laws, excluded = derive_structure_laws(layer, verbose=False)
chem_groups, drug_laws = derive_drug_laws(layer, verbose=False)
drug_channel_laws = derive_drug_channel_laws(KB.DISEASES)
gen = GenericOracle(KB.DISEASES, oracle, layer, laws,
                    drug_channel_laws=drug_channel_laws, drug_laws=drug_laws)
log(f"[build] t={time.time()-t0:5.1f}s ready: {len(oracle.class_laws)} class "
    f"laws, {len(laws)} structure laws, {len(drug_channel_laws)} drug-channel laws")

# ---------------------------------------------------------------------
# 0b. CORPUS-LEVEL ANTI-COLLAPSE CHECK (Tier D gate)
#     every learned monomial (class laws + drug-channel laws + regimen)
#     must have depth >= 2 — a single channel can never fire a law.
# ---------------------------------------------------------------------
depth_hist = {}
min_depth_seen = 99
n_terms = 0
for cls_law in list(oracle.class_laws.values()) + [oracle.regimen_law]:
    for t in cls_law["terms_detail"]:
        d = len(t["channels"])
        n_terms += 1
        min_depth_seen = min(min_depth_seen, d)
        depth_hist[d] = depth_hist.get(d, 0) + 1
for cert in drug_channel_laws.values():
    for t in cert["terms"]:
        d = len(t)
        n_terms += 1
        min_depth_seen = min(min_depth_seen, d)
        depth_hist[d] = depth_hist.get(d, 0) + 1
corpus_ok = min_depth_seen >= 2
log(f"[corpus] {n_terms} learned monomials: depth histogram {depth_hist} "
    f"(min depth {min_depth_seen}) -> anti-collapse invariant "
    f"{'HOLDS' if corpus_ok else 'VIOLATED'}")

# index of the known encodings
known = {}
for r in KB.DISEASES:
    known[tuple(r[c] for c in KB.CHANNELS)] = r["did"] + " " + r["name"]


def novelty(e):
    if set(e.keys()) != set(KB.CHANNELS):
        return "MALFORMED (channels missing/extra)"
    k = tuple(e[c] for c in KB.CHANNELS)
    return "KNOWN (" + known[k] + ")" if k in known else "NOVEL (not among the 63)"


# ---------------------------------------------------------------------
# Tier A — the 8 diseases of the v14.0 round with guideline ground truth
# ---------------------------------------------------------------------
TIER_A = [
    {
        "id": "A1",
        "disease": "Secondary prevention of ischaemic stroke (non-cardioembolic)",
        "encoding": {"system": "CARDIOVASCULAR", "etiology": "VASCULAR_ATHEROTHROMBOTIC",
                     "microbe": "NONE", "site": "BRAIN_CORTEX", "chronicity": "CHRONIC",
                     "pathway": "PW_PLATELET_AGGREGATION"},
        "ground_truth_class": "COX1_PLATELET_INHIBITOR / P2Y12_INHIBITOR (antiplatelet)",
        "ground_truth_drugs": ["aspirin", "clopidogrel"],
        "gt_source": "AHA/ASA 2021 secondary stroke prevention guideline: antiplatelet "
                     "therapy (aspirin 75-100 mg or clopidogrel) class I",
    },
    {
        "id": "A2",
        "disease": "VTE prophylaxis after major orthopaedic surgery (hip replacement)",
        "encoding": {"system": "CARDIOVASCULAR", "etiology": "STRUCTURAL_MECHANICAL",
                     "microbe": "NONE", "site": "VENOUS_CIRCULATION", "chronicity": "ACUTE",
                     "pathway": "PW_COAGULATION_CASCADE"},
        "ground_truth_class": "FACTOR_XA_INHIBITOR / DIRECT_THROMBIN_INHIBITOR / LMWH",
        "ground_truth_drugs": ["apixaban", "rivaroxaban", "dabigatran"],
        "gt_source": "CHEST 2022 VTE prophylaxis guideline: DOAC (apixaban/rivaroxaban) "
                     "suggested over VKA/LMWH after THA/TKA",
    },
    {
        "id": "A3",
        "disease": "Heart failure with preserved ejection fraction (HFpEF)",
        "encoding": {"system": "CARDIOVASCULAR", "etiology": "FUNCTIONAL_DYSREGULATION",
                     "microbe": "NONE", "site": "MYOCARDIUM", "chronicity": "CHRONIC",
                     "pathway": "PW_NEUROHORMONAL_REMODELING"},
        "ground_truth_class": "SGLT2_INHIBITOR (ESC 2023 class I); MRA/ARNI class II",
        "ground_truth_drugs": ["empagliflozin", "dapagliflozin"],
        "gt_source": "ESC 2023 HF guideline: SGLT2 inhibitor recommended in HFpEF "
                     "(class I) to reduce HF hospitalisation/death. v14.0 verdict: "
                     "FAIL (inherited ACEI_RAAS/ramipril via pathway-only law). "
                     "v14.1: drift round added HFpEF as D61 -> SGLT2 class law born.",
    },
    {
        "id": "A4",
        "disease": "NSAID-induced peptic ulcer / gastropathy prophylaxis",
        "encoding": {"system": "GASTROINTESTINAL", "etiology": "TOXIC_EXPOSURE",
                     "microbe": "NONE", "site": "ESOPHAGUS_STOMACH", "chronicity": "CHRONIC",
                     "pathway": "PW_GASTRIC_ACID_SECRETION"},
        "ground_truth_class": "PROTON_PUMP_INHIBITOR",
        "ground_truth_drugs": ["omeprazole", "pantoprazole", "esomeprazole"],
        "gt_source": "ACG/standard practice: PPI co-therapy for NSAID gastroprotection "
                     "in high-risk patients",
    },
    {
        "id": "A5",
        "disease": "Trigeminal neuralgia (encoding via NEUROELECTRIC etiology)",
        "encoding": {"system": "NEUROLOGICAL", "etiology": "NEUROELECTRIC",
                     "microbe": "NONE", "site": "MENINGEAL_TRIGEMINAL_SYSTEM",
                     "chronicity": "CHRONIC", "pathway": "PW_CORTICAL_HYPEREXCITABILITY"},
        "ground_truth_class": "SODIUM_CHANNEL_BLOCKER_AED",
        "ground_truth_drugs": ["carbamazepine"],
        "gt_source": "AAN/EFNS: carbamazepine first-line for classic trigeminal neuralgia",
    },
    {
        "id": "A6",
        "disease": "Trigeminal neuralgia (encoding via STRUCTURAL_MECHANICAL etiology)",
        "encoding": {"system": "NEUROLOGICAL", "etiology": "STRUCTURAL_MECHANICAL",
                     "microbe": "NONE", "site": "MENINGEAL_TRIGEMINAL_SYSTEM",
                     "chronicity": "CHRONIC", "pathway": "PW_CORTICAL_HYPEREXCITABILITY"},
        "ground_truth_class": "SODIUM_CHANNEL_BLOCKER_AED",
        "ground_truth_drugs": ["carbamazepine"],
        "gt_source": "same as A5 (encoding-sensitivity variant)",
    },
    {
        "id": "A7",
        "disease": "Binge-eating disorder (moderate-severe)",
        "encoding": {"system": "PSYCHIATRIC", "etiology": "PSYCHIATRIC",
                     "microbe": "NONE", "site": "CNS_MESOLIMBIC_SYSTEM", "chronicity": "CHRONIC",
                     "pathway": "PW_NORADRENERGIC_EXECUTIVE_DEFICIT"},
        "ground_truth_class": "AMPHETAMINE_RELEASER (lisdexamfetamine licensed)",
        "ground_truth_drugs": ["lisdexamfetamine"],
        "gt_source": "FDA/NICE: lisdexamfetamine is the licensed pharmacotherapy "
                     "for moderate-severe BED. v14.0 verdict: FAIL (inherited "
                     "DOPAMINE_TRANSPORTER_INHIBITOR via pathway-only law). "
                     "v14.1: drift round added BED as D62 -> AMPHETAMINE_RELEASER law.",
    },
    {
        "id": "A8",
        "disease": "Vasospastic (Prinzmetal) angina",
        "encoding": {"system": "CARDIOVASCULAR", "etiology": "FUNCTIONAL_DYSREGULATION",
                     "microbe": "NONE", "site": "CORONARY_ARTERY", "chronicity": "CHRONIC",
                     "pathway": "PW_MYOCARDIAL_O2_BALANCE"},
        "ground_truth_class": "CCB_DHP / NITRATE_NO_DONOR",
        "ground_truth_drugs": ["amlodipine", "isosorbide mononitrate"],
        "gt_source": "ACC/AHA: calcium channel blockers first-line in vasospastic angina "
                     "(beta-blockers may worsen vasospasm). v14.0 verdict: FAIL "
                     "(inherited BETA1_BLOCKER/bisoprolol — a class that can worsen "
                     "vasospasm). v14.1: drift round added vasospastic angina as D63.",
    },
]

# ---------------------------------------------------------------------
# Tier B — diseases that the KB vocabulary cannot molecularly serve
#         (honest refusal / non-encodability is the expected outcome)
# ---------------------------------------------------------------------
TIER_B = [
    {
        "id": "B1",
        "disease": "Neurocysticercosis / schistosomiasis (helminth infection)",
        "why_unencodable": "microbe channel vocabulary has no HELMINTH value "
                           "(only NONE/GRAM_POS_COCCI/GRAM_NEG_ROD/ATYPICAL/MYCOBACTERIUM/"
                           "SPIROCHETE/PROTOZOAN/VIRUS/MIXED_RESPIRATORY); ground-truth "
                           "drugs (praziquantel, albendazole) are not in the drug KB either",
        "probe_encoding": {"system": "INFECTIOUS", "etiology": "PARASITIC",
                           "microbe": "PROTOZOAN", "site": "BRAIN_CORTEX", "chronicity": "ACUTE",
                           "pathway": "PW_PLASMODIUM_ERYTHROCYTIC_CYCLE"},
        "probe_label": "forced PROTOZOAN encoding (clinically a MIS-ENCODING)",
    },
    {
        "id": "B2",
        "disease": "Relapsing-remitting multiple sclerosis",
        "why_unencodable": "disease-modifying drugs (interferon beta, fingolimod, "
                           "ocrelizumab) absent from drug KB; no demyelination pathway "
                           "in vocabulary",
        "probe_encoding": {"system": "NEUROLOGICAL", "etiology": "AUTOIMMUNE",
                           "microbe": "NONE", "site": "BRAIN_CORTEX", "chronicity": "CHRONIC",
                           "pathway": "PW_TYPE1_IFN_IMMUNE_COMPLEX"},
        "probe_label": "closest in-vocabulary encoding (autoimmune brain)",
    },
    {
        "id": "B3",
        "disease": "Chronic insomnia disorder",
        "why_unencodable": "first-line is CBT-I (non-drug); z-drugs absent from KB; "
                           "no sleep pathway in vocabulary",
        "probe_encoding": {"system": "NEUROLOGICAL", "etiology": "FUNCTIONAL_DYSREGULATION",
                           "microbe": "NONE", "site": "BRAIN_CORTEX", "chronicity": "CHRONIC",
                           "pathway": "PW_CHOLINERGIC_DEFICIT"},
        "probe_label": "forced pathway (clinically WRONG model) — must not be trusted",
    },
    {
        "id": "B4",
        "disease": "Hereditary haemochromatosis (iron overload)",
        "why_unencodable": "ground truth is phlebotomy (non-drug) or chelators "
                           "(deferasirox absent from KB); no iron-overload pathway",
    },
    {
        "id": "B5",
        "disease": "Idiopathic pulmonary fibrosis",
        "why_unencodable": "antifibrotics (pirfenidone, nintedanib) absent from KB; "
                           "no fibrosis pathway in vocabulary",
    },
    {
        "id": "B6",
        "disease": "Pulmonary arterial hypertension",
        "why_unencodable": "PAH-specific agents (bosentan, ambrisentan, sildenafil, "
                           "prostacyclins) absent from KB; no vascular-remodelling pathway",
    },
]

# ---------------------------------------------------------------------
# Tier C — adversarial / robustness probes
# ---------------------------------------------------------------------
TIER_C_ENC = [
    {"id": "C1", "label": "out-of-vocabulary pathway value",
     "encoding": {"system": "CARDIOVASCULAR", "etiology": "VASCULAR_ATHEROTHROMBOTIC",
                  "microbe": "NONE", "site": "ARTERIAL_TREE", "chronicity": "CHRONIC",
                  "pathway": "PW_FOREIGN_UNKNOWN"}},
    {"id": "C2", "label": "incomplete encoding (2 of 6 channels)",
     "encoding": {"system": "CARDIOVASCULAR", "etiology": "VASCULAR_ATHEROTHROMBOTIC"}},
    {"id": "C3", "label": "empty channel value",
     "encoding": {"system": "", "etiology": "VASCULAR_ATHEROTHROMBOTIC", "microbe": "NONE",
                  "site": "ARTERIAL_TREE", "chronicity": "CHRONIC", "pathway": "PW_VASCULAR_TONE"}},
    {"id": "C4", "label": "giant cell arteritis forced through RA pathway (mis-encoding)",
     "encoding": {"system": "RHEUMATOLOGIC", "etiology": "INFLAMMATORY_IMMUNE",
                  "microbe": "NONE", "site": "ARTERIAL_TREE", "chronicity": "ACUTE",
                  "pathway": "PW_AUTOREACTIVE_CYTOKINE_CASCADE"},
     "note": "ground truth: high-dose glucocorticoid (prednisolone) urgently — "
             "methotrexate/DMARD rank-1 would be a dangerous prediction. This is a "
             "MIS-ENCODING probe: the system cannot know the site encoding is wrong; "
             "documented limitation of any closed-formulary encoder."},
    {"id": "C5", "label": "stress cardiomyopathy (Takotsubo) forced through HFrEF pathway",
     "encoding": {"system": "CARDIOVASCULAR", "etiology": "FUNCTIONAL_DYSREGULATION",
                  "microbe": "NONE", "site": "MYOCARDIUM", "chronicity": "ACUTE",
                  "pathway": "PW_NEUROHORMONAL_REMODELING"},
     "note": "ground truth: supportive guideline-directed HF therapy during the acute "
             "phase. v14.0 fired ACEI_RAAS/ramipril via the pathway-only collapse; "
             "v14.1 fires the HFpEF SGLT2 law via {etiology=FUNCTIONAL_DYSREGULATION, "
             "pathway} — a plausible guideline-spectrum HF class, and NO LONGER an "
             "inheritance through the pathway channel alone."},
]

TIER_C_SMILES = [
    {"id": "S1", "label": "paracetamol (non-KB molecule)",
     "smiles": "CC(=O)NC1=CC=C(C=C1)O"},
    {"id": "S2", "label": "ibuprofen (KB molecule — positive control #2)",
     "smiles": "CC(C)Cc1ccc(cc1)C(C)C(=O)O"},
    {"id": "S3", "label": "caffeine (non-KB molecule)",
     "smiles": "Cn1cnc2c1c(=O)n(C)c(=O)n2C"},
    {"id": "S4", "label": "metformin (KB molecule — positive control)",
     "smiles": "CN(C)C(=N)N=C(N)N"},
    {"id": "S5", "label": "malformed SMILES",
     "smiles": "not-a-smiles"},
]

# ---------------------------------------------------------------------
# Tier D — ANTI-COLLAPSE REGRESSION (the pre-v14.1 failure mode)
#   Encodings that share ONLY the pathway channel with a KB disease must
#   never inherit that disease's therapy class through the pathway alone.
# ---------------------------------------------------------------------
TIER_D = [
    {"id": "D1", "label": "chronic structural cardiomyopathy (HFrEF pathway, "
                          "structural etiology — NOT the ACEI row's etiology)",
     "encoding": {"system": "CARDIOVASCULAR", "etiology": "STRUCTURAL_MECHANICAL",
                  "microbe": "NONE", "site": "MYOCARDIUM", "chronicity": "CHRONIC",
                  "pathway": "PW_NEUROHORMONAL_REMODELING"},
     "must_not_return": ["ramipril"],
     "pre_v14_behavior": "fired ACEI_RAAS via {pathway} alone -> ramipril"},
    {"id": "D2", "label": "substance-use disorder of the mesolimbic noradrenergic "
                          "circuit (ADHD pathway, different site AND etiology)",
     "encoding": {"system": "PSYCHIATRIC", "etiology": "SUBSTANCE_USE",
                  "microbe": "NONE", "site": "CNS_MESOLIMBIC_SYSTEM",
                  "chronicity": "CHRONIC",
                  "pathway": "PW_NORADRENERGIC_EXECUTIVE_DEFICIT"},
     "must_not_return": ["methylphenidate"],
     "pre_v14_behavior": "fired DOPAMINE_TRANSPORTER_INHIBITOR via {pathway} alone"},
    {"id": "D3", "label": "variant angina at rest with structural etiology "
                          "(stable-angina pathway, not the atherothrombotic row)",
     "encoding": {"system": "CARDIOVASCULAR", "etiology": "STRUCTURAL_MECHANICAL",
                  "microbe": "NONE", "site": "CORONARY_ARTERY", "chronicity": "CHRONIC",
                  "pathway": "PW_MYOCARDIAL_O2_BALANCE"},
     "must_not_return": ["bisoprolol"],
     "pre_v14_behavior": "fired BETA1_BLOCKER via {pathway} alone -> bisoprolol"},
    {"id": "D4", "label": "acute neurohormonal cardiomyopathy in a metabolic "
                          "etiology (HFpEF pathway, ACUTE — the D61 row is CHRONIC)",
     "encoding": {"system": "CARDIOVASCULAR", "etiology": "METABOLIC",
                  "microbe": "NONE", "site": "MYOCARDIUM", "chronicity": "ACUTE",
                  "pathway": "PW_NEUROHORMONAL_REMODELING"},
     "must_not_return": ["ramipril"],
     "pre_v14_behavior": "fired ACEI_RAAS via {pathway} alone"},
]

# ---------------------------------------------------------------------
# run corpus gate
# ---------------------------------------------------------------------
results = {"corpus_gate": {}, "tier_A": [], "tier_B": [], "tier_C": [],
           "tier_D": [], "reverse": []}
results["corpus_gate"] = {
    "monomials_checked": n_terms,
    "depth_histogram": {str(k): v for k, v in sorted(depth_hist.items())},
    "min_term_depth": min_depth_seen if n_terms else None,
    "anti_collapse_invariant_holds": bool(corpus_ok),
}

# ---------------------------------------------------------------------
# run Tier A
# ---------------------------------------------------------------------
log("\n" + "-" * 78)
log("TIER A — the 8 diseases of the v14.0 round (3 now in-domain after the")
log("          guideline-drift round, 5 still genuinely novel). Prediction")
log("          = generic path (S4 doctrine) over the v14.1 anti-collapse laws.")
log("-" * 78)
for case in TIER_A:
    e = case["encoding"]
    nov = novelty(e)
    res = gen.query(e)
    rec = dict(case)
    rec["novelty"] = nov
    rec["verdict"] = res["verdict"]
    rec["mechanism_class"] = res.get("mechanism_class")
    rec["predicted_first_line"] = res.get("first_line")
    rec["candidates"] = [
        {k: c[k] for k in ("drug", "tier", "efficacy", "rank_key",
                           "channel_law_fired", "structure_verified")}
        for c in (res.get("candidate_set") or [])[:6]
    ]
    rec["refusal_reason"] = res.get("reason")
    if res.get("verdict") == "PROVEN_CLASS_THERAPY":
        fl = res["first_line"]
        gt_drugs = case["ground_truth_drugs"]
        gt_class = case["ground_truth_class"]
        pred_class = KB.DRUGS[fl][1]
        top3 = [c["drug"] for c in res["candidate_set"][:3]]
        if fl in gt_drugs:
            score = "PASS (rank-1 is guideline first-line)"
        elif any(g in top3 for g in gt_drugs):
            score = f"PARTIAL (ground-truth drug at rank 2-3: rank-1={fl})"
        elif pred_class in gt_class:
            score = f"CORRECT CLASS (rank-1 {fl} [{pred_class}] is guideline-class)"
        elif any(KB.DRUGS[c["drug"]][1] in gt_class
                 for c in res["candidate_set"]):
            score = "CLASS PRESENT in candidate set (rank-1 not guideline class)"
        else:
            score = f"FAIL (predicted {pred_class}, expected {gt_class})"
        rec["score"] = score
    else:
        rec["score"] = "REFUSAL (system declines to predict)"
    results["tier_A"].append(rec)

    log(f"\n{case['id']}  {case['disease']}")
    log(f"    encoding novelty      : {nov}")
    for c in KB.CHANNELS:
        log(f"      {c:<11}= {e[c]}")
    if res.get("verdict") == "PROVEN_CLASS_THERAPY":
        log(f"    verdict               : {res['verdict']}  class = {rec['mechanism_class']}")
        for i, c in enumerate(rec["candidates"], 1):
            log(f"      {i}. {c['drug']:<22} tier={c['tier']} eff={c['efficacy']} "
                f"K={c['rank_key']} channel-law={c['channel_law_fired']} "
                f"struct-verified={c['structure_verified']}")
        log(f"    predicted first-line  : {rec['predicted_first_line']}")
    else:
        log(f"    verdict               : {res['verdict']}  ({rec['refusal_reason']})")
    log(f"    ground truth          : {case['ground_truth_drugs']} "
        f"[{case['ground_truth_class']}]")
    log(f"    score                 : {rec['score']}")

# ---------------------------------------------------------------------
# run Tier B
# ---------------------------------------------------------------------
log("\n" + "-" * 78)
log("TIER B — diseases the KB cannot serve; expected: honest refusal or")
log("          documented non-encodability")
log("-" * 78)
for case in TIER_B:
    rec = dict(case)
    if "probe_encoding" in case:
        e = case["probe_encoding"]
        res = gen.query(e)
        rec["probe_label"] = case.get("probe_label")
        rec["encoding_novelty"] = novelty(e)
        rec["verdict"] = res["verdict"]
        rec["mechanism_class"] = res.get("mechanism_class")
        rec["predicted_first_line"] = res.get("first_line")
        rec["candidates"] = [
            {k: c[k] for k in ("drug", "tier", "channel_law_fired")}
            for c in (res.get("candidate_set") or [])[:4]
        ]
        rec["refusal_reason"] = res.get("reason")
        log(f"\n{case['id']}  {case['disease']}")
        log(f"    unencodable because   : {case['why_unencodable']}")
        log(f"    probe ({rec['probe_label']}, {rec['encoding_novelty']}):")
        log(f"      verdict = {res['verdict']}  class = {rec['mechanism_class']}")
        if rec["candidates"]:
            log(f"      rank-1 = {rec['predicted_first_line']}")
        if rec["refusal_reason"]:
            log(f"      refusal: {rec['refusal_reason']}")
    else:
        rec["verdict"] = "NOT ENCODABLE (no in-vocabulary representation exists)"
        log(f"\n{case['id']}  {case['disease']}")
        log(f"    unencodable because   : {case['why_unencodable']}")
    results["tier_B"].append(rec)

# ---------------------------------------------------------------------
# run Tier C
# ---------------------------------------------------------------------
log("\n" + "-" * 78)
log("TIER C — adversarial and robustness probes")
log("-" * 78)
for case in TIER_C_ENC:
    e = case["encoding"]
    try:
        res = gen.query(e)
    except Exception as exc:
        res = {"verdict": "REFUSED", "reason": f"raised: {type(exc).__name__}: {exc}"}
    rec = dict(case)
    rec["encoding_novelty"] = novelty(e)
    rec["verdict"] = res["verdict"]
    rec["mechanism_class"] = res.get("mechanism_class")
    rec["predicted_first_line"] = res.get("first_line")
    rec["refusal_reason"] = res.get("reason")
    rec["candidates"] = [
        {k: c[k] for k in ("drug", "tier", "channel_law_fired")}
        for c in (res.get("candidate_set") or [])[:4]
    ]
    results["tier_C"].append(rec)
    log(f"\n{case['id']}  {case['label']}  [{rec['encoding_novelty']}]")
    if res.get("verdict") == "PROVEN_CLASS_THERAPY":
        log(f"    verdict = {res['verdict']}  class = {rec['mechanism_class']}  "
            f"rank-1 = {rec['predicted_first_line']}")
        if case.get("note"):
            log(f"    note: {case['note']}")
    else:
        log(f"    verdict = {res['verdict']}  ({rec['refusal_reason']})")

# ---------------------------------------------------------------------
# run Tier D — anti-collapse regression
# ---------------------------------------------------------------------
log("\n" + "-" * 78)
log("TIER D — ANTI-COLLAPSE REGRESSION (pre-v14.1 failure mode): encodings")
log("          sharing ONLY the pathway with a KB disease must never inherit")
log("          that disease's therapy class through the pathway alone")
log("-" * 78)
n_d_viol = 0
for case in TIER_D:
    e = case["encoding"]
    res = gen.query(e)
    rec = dict(case)
    rec["encoding_novelty"] = novelty(e)
    rec["verdict"] = res["verdict"]
    rec["mechanism_class"] = res.get("mechanism_class")
    rec["predicted_first_line"] = res.get("first_line")
    rec["refusal_reason"] = res.get("reason")
    inherited = (res.get("verdict") == "PROVEN_CLASS_THERAPY"
                 and res.get("first_line") in case["must_not_return"])
    rec["collapse_recurred"] = bool(inherited)
    n_d_viol += 1 if inherited else 0
    results["tier_D"].append(rec)
    verdict = "NO COLLAPSE" if not inherited else "COLLAPSE RECURRED !!"
    log(f"\n{case['id']}  {case['label']}  [{rec['encoding_novelty']}]")
    log(f"    pre-v14.1 behaviour   : {case['pre_v14_behavior']}")
    if res.get("verdict") == "PROVEN_CLASS_THERAPY":
        log(f"    v14.1 verdict         : {res['verdict']}  class = "
            f"{rec['mechanism_class']}  rank-1 = {rec['predicted_first_line']}")
        log(f"    anti-collapse check   : {verdict}")
    else:
        log(f"    v14.1 verdict         : {res['verdict']}  ({rec['refusal_reason']})")
        log(f"    anti-collapse check   : {verdict} (sound refusal)")

# reverse path: molecules
log("\nReverse path (SMILES -> drug/disease identity claims):")
for case in TIER_C_SMILES:
    try:
        res = reverse_class_match(layer, laws, case["smiles"],
                                  drug_laws=drug_laws,
                                  drug_channel_laws=drug_channel_laws)
    except Exception as exc:  # malformed inputs raise
        res = {"verdict": "REFUSED", "reason": f"raised: {type(exc).__name__}"}
    rec = dict(case)
    rec["verdict"] = res.get("verdict")
    rec["exact_drug_matches"] = res.get("exact_drug_matches")
    rec["class_matches"] = res.get("class_matches") or res.get("mechanism_classes")
    rec["reason"] = res.get("reason")
    results["reverse"].append(rec)
    claim = "NO KB-identity claim (sound)" if not res.get("exact_drug_matches") \
        else f"!! IDENTITY CLAIMED: {res.get('exact_drug_matches')}"
    log(f"  {case['id']} {case['label']:<38} -> {res.get('verdict')}  [{claim}]")

# ---------------------------------------------------------------------
# summary
# ---------------------------------------------------------------------
n_pass = sum(1 for r in results["tier_A"] if r["score"].startswith("PASS"))
n_partial = sum(1 for r in results["tier_A"] if r["score"].startswith(("PARTIAL", "CORRECT")))
n_class = sum(1 for r in results["tier_A"] if r["score"].startswith("CLASS PRESENT"))
n_fail = sum(1 for r in results["tier_A"] if r["score"].startswith("FAIL"))
n_ref = sum(1 for r in results["tier_A"] if r["score"].startswith("REFUSAL"))
n_d_clean = len(results["tier_D"]) - n_d_viol
log("\n" + "=" * 78)
log(f"TIER A SUMMARY: {len(results['tier_A'])} diseases tested — "
    f"PASS {n_pass}, PARTIAL/CORRECT-CLASS {n_partial}, CLASS-PRESENT {n_class}, "
    f"FAIL {n_fail}, REFUSAL {n_ref}")
log(f"TIER D SUMMARY: {len(results['tier_D'])} anti-collapse probes — "
    f"{n_d_clean} clean, {n_d_viol} collapse-recurred; corpus gate "
    f"({'HOLDS' if corpus_ok else 'VIOLATED'}, "
    f"min monomial depth {min_depth_seen}, {n_terms} monomials)")
log("=" * 78)

results["summary"] = {
    "tier_A": {"pass": n_pass, "partial_correct": n_partial, "class_present": n_class,
               "fail": n_fail, "refusal": n_ref, "total": len(results["tier_A"])},
    "tier_D": {"clean": n_d_clean, "collapse_recurred": n_d_viol,
               "total": len(results["tier_D"])},
    "corpus_gate_holds": bool(corpus_ok),
    "min_monomial_depth": min_depth_seen if n_terms else None,
}

os.makedirs(os.path.dirname(OUT_JSON), exist_ok=True)
with open(OUT_JSON, "w", encoding="utf-8") as fh:
    json.dump(results, fh, indent=1, default=str)
with open(OUT_TXT, "w", encoding="utf-8") as fh:
    fh.write("\n".join(log_lines) + "\n")
log(f"\nsaved: {OUT_JSON}")
log(f"saved: {OUT_TXT}")
log(f"total wall time: {time.time()-t0:.1f}s")
sys.exit(0 if (n_fail == 0 and n_d_viol == 0 and corpus_ok) else 1)
