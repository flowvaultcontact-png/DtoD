# =====================================================================
# DISEASE -> REQUIRED THERAPY MECHANISM TABLE (module:
# disease_mechanism_table.py) for the APEIRON-X v13.0 Direct-Law Layer
# ---------------------------------------------------------------------
# This table REPLACES the disease->drug indication lists as the
# disease-side training data of the engine. It is DRUG-NAME-FREE: each
# disease is annotated only with the mechanism classes its guideline
# therapy must act through, in anchor order (element 0 = primary
# mechanism = the class of the guideline first-line strategy).
#
#   * MECH_REQUIRED: did -> [mechanism class, ...]   (drug names: NONE)
#   * The mechanism classes are exactly the guideline-anchored therapy
#     mechanism profile of each disease (e.g. "H. pylori eradication
#     requires acid suppression AND antibacterial action").
#   * The disease->drug NAME table (KB.DISEASES[*]["drugs"]) is used by
#     v13.0 ONLY as a held-out TEST oracle, never to derive a law.
#
# HELD_OUT_* are external validation pairs: (disease, drug) pairs that
# are guideline-recommended and ATC-verifiable but deliberately NOT in
# the KB indication lists, used to test the direct laws out-of-sample.
# Each carries its guideline source.
# =====================================================================

MECH_REQUIRED = {
    "D01": ["CCB_DHP", "ACEI_RAAS", "ARB_RAAS", "THIAZIDE_LIKE_DIURETIC"],
    "D02": ["ACEI_RAAS", "BETA1_BLOCKER", "SGLT2_INHIBITOR",
            "MINERALOCORTICOID_ANTAGONIST"],
    "D03": ["FACTOR_XA_INHIBITOR", "DIRECT_THROMBIN_INHIBITOR",
            "VITAMIN_K_ANTAGONIST"],
    "D04": ["BETA1_BLOCKER", "CCB_DHP", "NITRATE_NO_DONOR",
            "LATE_SODIUM_CURRENT_INHIBITOR"],
    "D05": ["HMGCR_INHIBITOR", "NPC1L1_INHIBITOR"],
    "D06": ["COX1_PLATELET_INHIBITOR", "P2Y12_INHIBITOR"],
    "D07": ["FACTOR_XA_INHIBITOR", "VITAMIN_K_ANTAGONIST"],
    "D08": ["BIGUANIDE_HEPATIC_GLUCOSE", "SGLT2_INHIBITOR",
            "DPP4_INHIBITOR", "SULFONYLUREA"],
    "D09": ["BASAL_INSULIN_ANALOG", "RAPID_INSULIN_ANALOG",
            "NPH_BASAL_INSULIN"],
    "D10": ["THYROID_HORMONE_REPLACE"],
    "D11": ["THYROID_PEROXIDASE_INHIBITOR", "NONSELECTIVE_BETA_BLOCKER"],
    "D12": ["BISPHOSPHONATE", "SERM_BONE"],
    "D13": ["MICROTUBULE_INHIBITOR_ANTIINFLAMMATORY", "NSAID",
            "GLUCOCORTICOID"],
    "D14": ["XANTHINE_OXIDASE_INHIBITOR", "URICOSURIC"],
    "D15": ["ICS_LABA_COMBINATION", "LEUKOTRIENE_RECEPTOR_ANTAGONIST"],
    "D16": ["SHORT_ACTING_BETA2_AGONIST", "GLUCOCORTICOID",
            "SHORT_ACTING_MUSCARINIC_ANTAGONIST"],
    "D17": ["LONG_ACTING_MUSCARINIC_ANTAGONIST", "LONG_ACTING_BETA2_AGONIST"],
    "D18": ["BETA_LACTAM_CELLWALL", "TETRACYCLINE_RIBOSOMAL_30S",
            "MACROLIDE_RIBOSOMAL_50S"],
    "D19": ["ANTI_MYCOBACTERIAL_MYCOLIC_ACID",
            "ANTI_MYCOBACTERIAL_RNA_POLYMERASE",
            "ANTI_MYCOBACTERIAL_STERILIZING",
            "ANTI_MYCOBACTERIAL_ARABINAN",
            "FLUOROQUINOLONE_DNA_GYRASE"],
    "D20": ["INTRANASAL_CORTICOSTEROID", "H1_ANTIHISTAMINE",
            "LEUKOTRIENE_RECEPTOR_ANTAGONIST"],
    "D21": ["PROTON_PUMP_INHIBITOR", "H2_RECEPTOR_ANTAGONIST"],
    "D22": ["PROTON_PUMP_INHIBITOR", "BETA_LACTAM_CELLWALL",
            "MACROLIDE_RIBOSOMAL_50S", "NITROIMIDAZOLE_DNA_DAMAGE",
            "TETRACYCLINE_RIBOSOMAL_30S"],
    "D23": ["AMINOSALICYLATE_5ASA", "GLUCOCORTICOID"],
    "D24": ["OSMOTIC_LAXATIVE", "STIMULANT_LAXATIVE"],
    "D25": ["HCV_NS5B_NS5A_INHIBITOR", "HCV_NS3_NS5A_INHIBITOR"],
    "D26": ["SEROTONIN_5HT3_ANTAGONIST", "NK1_ANTAGONIST",
            "GLUCOCORTICOID", "D2_ANTAGONIST_PROKINETIC"],
    "D27": ["SODIUM_CHANNEL_BLOCKER_AED", "SV2A_MODULATOR"],
    "D28": ["BROAD_SPECTRUM_GABA_MODULATOR", "SODIUM_CHANNEL_BLOCKER_AED",
            "SV2A_MODULATOR", "MULTIMODAL_AED"],
    "D29": ["BENZODIAZEPINE_GABAA", "SODIUM_CHANNEL_BLOCKER_AED"],
    "D30": ["TRIPTAN_5HT1B1D_AGONIST", "NSAID"],
    "D31": ["NONSELECTIVE_BETA_BLOCKER", "TRICYCLIC_MONOAMINE_MODULATOR",
            "MULTIMODAL_AED", "ARB_RAAS"],
    "D32": ["DOPAMINE_PRECURSOR", "DOPAMINE_RECEPTOR_AGONIST",
            "MAOB_INHIBITOR", "NMDA_ANTAGONIST_DOPAMINERGIC"],
    "D33": ["ACETYLCHOLINESTERASE_INHIBITOR", "NMDA_RECEPTOR_ANTAGONIST"],
    "D34": ["SSRI", "ALPHA2_NORADRENERGIC_ANTAGONIST"],
    "D35": ["SSRI", "SNRI", "ALPHA2DELTA_CALCIUM_LIGAND"],
    "D36": ["D2_5HT2_ANTAGONIST_ANTIPSYCHOTIC", "D2_PARTIAL_AGONIST"],
    "D37": ["LITHIUM_MOOD_STABILIZER", "BROAD_SPECTRUM_GABA_MODULATOR",
            "SODIUM_CHANNEL_BLOCKER_AED", "D2_5HT2_ANTAGONIST_ANTIPSYCHOTIC"],
    "D38": ["DOPAMINE_TRANSPORTER_INHIBITOR", "AMPHETAMINE_RELEASER",
            "NORADRENALINE_TRANSPORTER_INHIBITOR",
            "ALPHA2A_ADRENERGIC_AGONIST"],
    "D39": ["FULL_MU_OPIOID_AGONIST", "PARTIAL_MU_OPIOID_AGONIST",
            "MU_OPIOID_RECEPTOR_ANTAGONIST"],
    "D40": ["MU_OPIOID_RECEPTOR_ANTAGONIST",
            "GLUTAMATE_NMDA_ALLOSTERIC_MODULATOR",
            "ALDEHYDE_DEHYDROGENASE_INHIBITOR"],
    "D41": ["NITROFURAN_INTRACELLULAR_DNA_DAMAGE",
            "PHOSPHONATE_CELLWALL_INHIBITOR", "BETA_LACTAM_CELLWALL",
            "DIHYDROFOLATE_REDUCTASE_INHIBITOR"],
    "D42": ["BETA_LACTAM_CELLWALL", "MACROLIDE_RIBOSOMAL_50S"],
    "D43": ["BETA_LACTAM_CELLWALL", "LINCOSAMIDE_RIBOSOMAL_50S",
            "TETRACYCLINE_RIBOSOMAL_30S"],
    "D44": ["NEURAMINIDASE_INHIBITOR", "CAP_DEPENDENT_ENDONUCLEASE_INHIBITOR"],
    "D45": ["NRTI_REVERSE_TRANSCRIPTASE", "HIV_INTEGRASE_INHIBITOR"],
    "D46": ["ARTEMISININ_COMBINATION_THERAPY"],
    "D47": ["TETRACYCLINE_RIBOSOMAL_30S", "MACROLIDE_RIBOSOMAL_50S",
            "BETA_LACTAM_CELLWALL"],
    "D48": ["BETA_LACTAM_CELLWALL", "TETRACYCLINE_RIBOSOMAL_30S"],
    "D49": ["AROMATASE_INHIBITOR", "SERM_ANTIOESTROGEN",
            "SERD_ESTROGEN_DOWNREGULATOR"],
    "D50": ["BCR_ABL_TYROSINE_KINASE_INHIBITOR"],
    "D51": ["EGFR_TYROSINE_KINASE_INHIBITOR"],
    "D52": ["CYTOTOXIC_ANTHRACYCLINE", "CYTOTOXIC_ALKYLATING_AGENT",
            "CYTOTOXIC_GLYCOPEPTIDE", "CYTOTOXIC_VINCA_ALKALOID",
            "ANTIBODY_DRUG_CONJUGATE_CD30", "PD1_IMMUNE_CHECKPOINT_INHIBITOR"],
    "D53": ["GNRH_AGONIST", "CYP17A_INHIBITOR",
            "ANDROGEN_RECEPTOR_ANTAGONIST"],
    "D54": ["FOLATE_ANTIMETABOLITE_DMARD", "PYRIMIDINE_SYNTHESIS_INHIBITOR",
            "AMINOSALICYLATE_5ASA", "ANTIMALARIAL_IMMUNOMODULATOR",
            "TNF_ALPHA_ANTAGONIST"],
    "D55": ["ANTIMALARIAL_IMMUNOMODULATOR", "IMPDH_INHIBITOR",
            "GLUCOCORTICOID", "BAFF_ANTAGONIST"],
    "D56": ["NSAID", "TNF_ALPHA_ANTAGONIST", "IL17A_ANTAGONIST"],
    "D57": ["ADRENERGIC_CATECHOLAMINE", "H1_ANTIHISTAMINE",
            "GLUCOCORTICOID"],
    "D58": ["ORAL_IRON_SALT", "IV_IRON_COMPLEX"],
    "D59": ["PROSTAGLANDIN_FP_ANALOG", "OCULAR_BETA_BLOCKER",
            "ALPHA2_AGONIST_OCULAR", "CARBONIC_ANHYDRASE_INHIBITOR_OCULAR"],
    "D60": ["ALPHA1A_ADRENOCEPTOR_ANTAGONIST", "ALPHA1_ADRENOCEPTOR_ANTAGONIST",
            "5_ALPHA_REDUCTASE_INHIBITOR", "PDE5_INHIBITOR"],
}

# ---------------------------------------------------------------------
# EXTERNAL VALIDATION (held-out) KNOWN PAIRS.
# Positives: guideline-recommended, ATC-verifiable pairs that are NOT in
# the KB indication lists. The direct law must PREDICT them (True).
# Negatives: pairs whose mechanism is outside the disease's anchored
# profile; the direct law must REFUSE them (False), matching guideline
# truth. Sources quoted per pair.
# ---------------------------------------------------------------------
HELD_OUT_POSITIVE = [
    ("D01", "ramipril",       "ESH/ESC 2023 hypertension: ACE inhibitor first-line"),
    ("D01", "candesartan",    "ESH/ESC 2023 hypertension: ARB first-line"),
    ("D02", "empagliflozin",  "EMPEROR-Reduced 2020; ESC 2021 HFrEF: SGLT2i cornerstone"),
    ("D02", "lisinopril",     "ESC 2021 HFrEF: ACE inhibitor cornerstone (ATLAS)"),
    ("D03", "edoxaban",       "ENGAGE AF; ESC 2020 AF: DOAC for stroke prophylaxis"),
    ("D08", "dapagliflozin",  "ADA/EASD 2022: SGLT2i for type 2 diabetes"),
    ("D13", "ibuprofen",      "EULAR 2016 / ACR 2020: NSAID first-line acute gout"),
    ("D13", "diclofenac",     "EULAR 2016 / ACR 2020: NSAID first-line acute gout"),
    ("D16", "dexamethasone",  "acute asthma: systemic corticosteroid (GINA)"),
    ("D16", "hydrocortisone", "acute severe asthma: IV corticosteroid (GINA)"),
    ("D22", "esomeprazole",   "Maastricht VI: any PPI in H. pylori eradication"),
    ("D30", "diclofenac",     "migraine attack: NSAID (diclofenac-K, EHF)"),
    ("D37", "olanzapine",     "olanzapine, FDA-approved bipolar I maintenance"),
    ("D42", "clarithromycin", "IDSA strep pharyngitis: macrolide if penicillin-allergic"),
    ("D47", "erythromycin",   "CDC chlamydia: macrolide alternative (pregnancy)"),
    ("D48", "tetracycline",   "CDC legacy regimen: tetracycline if penicillin-allergic"),
    ("D56", "ibuprofen",      "ASAS-EULAR axSpA: NSAID first-line"),
    ("D56", "indomethacin",   "ASAS-EULAR axSpA: indomethacin classic first-choice"),
]

HELD_OUT_NEGATIVE = [
    ("D01", "bisoprolol",   "ESH/ESC 2023: beta-blockers demoted, not first-line HTN"),
    ("D02", "losartan",     "ARB not cornerstone HFrEF (ESC 2021)"),
    ("D09", "metformin",    "biguanide never therapy of type 1 diabetes"),
    ("D07", "dabigatran",   "outside the KB-anchored D07 mechanism profile (closed world)"),
    ("D15", "salbutamol",   "SABA monotherapy is not asthma maintenance (GINA)"),
    ("D31", "sumatriptan",  "triptans are not migraine prophylaxis"),
    ("D27", "valproate",    "outside focal-onset anchor profile (valproate = generalized)"),
    ("D34", "pregabalin",   "alpha2delta ligand is not an antidepressant"),
    ("D35", "mirtazapine",  "alpha2 antagonist not GAD therapy (NICE)"),
    ("D41", "moxifloxacin", "fluoroquinolone not for uncomplicated cystitis; poor urinary levels"),
    ("D56", "prednisolone", "glucocorticoid not standard axSpA therapy (ASAS-EULAR)"),
]


def validate_mech_table():
    """TEST-LABELLED validation (reads the IND oracle; never used for
    law derivation): (i) every mechanism class exists in the drug table;
    (ii) primary mechanism == class of the guideline first-line drug;
    (iii) the mechanism set exactly equals the class set of the
    guideline drug list (lossless compression check)."""
    import disease_drug_kb as KB
    problems = []
    kb_classes = {c for a, c in KB.DRUGS.values()}
    for did, mechs in sorted(MECH_REQUIRED.items()):
        for c in mechs:
            if c not in kb_classes:
                problems.append(f"{did}: unknown mechanism class {c}")
        row = next(r for r in KB.DISEASES if r["did"] == did)
        ind_classes = [KB.DRUGS[g][1] for (g, t, e, p) in row["drugs"]]
        if ind_classes[0] != mechs[0]:
            problems.append(f"{did}: primary {mechs[0]} != first guideline "
                            f"drug class {ind_classes[0]}")
        if set(mechs) != set(ind_classes):
            problems.append(f"{did}: mechanism set != guideline class set "
                            f"({sorted(set(ind_classes) - set(mechs))} / "
                            f"{sorted(set(mechs) - set(ind_classes))})")
    for did, _, _ in HELD_OUT_POSITIVE + HELD_OUT_NEGATIVE:
        if did not in MECH_REQUIRED:
            problems.append(f"held-out pair references unknown disease {did}")
    return problems
