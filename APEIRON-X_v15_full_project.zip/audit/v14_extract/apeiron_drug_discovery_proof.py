#!/usr/bin/env python3
# =====================================================================
# APEIRON-X v11.1 — MEDICAL THEOREM MODULE
# DISEASE -> DRUG DISCOVERY BY MATHEMATICAL PROOF (proof-only)
# ---------------------------------------------------------------------
# Child module of APEIRON-X v11.0 (proof-only mathematical brain &
# universal theorem discovery engine). Same doctrine:
#   * ZERO statistical guessing, ZERO random search, ZERO permutation luck.
#   * Every learned law must carry a formal ProofCertificate:
#       EXACT_UNIVERSAL_PROOF  — exact identity + 0 counterexamples
#                                under adversarial & boundary falsification
#       UNPROVED               — strictly rejected (engine fails loudly)
#
# WHAT IS PROVED HERE (formal QED report printed by --report / run):
#   The disease->drug relation over a closed guideline knowledge base
#   D (|D| = 60 standard-of-care indications, 13 organ systems) is
#   exactly identified as the composition
#       f(d) = RANK_LEX( IND(d) ),
#       IND(d) = { g : g indicated for d },  |IND(d)| >= 1
#   where the required pharmacological MECHANISM CLASS M(d) is an exact
#   Boolean DNF law of the semantic encoding phi(d) (system, etiology,
#   microbe, site, chronicity, pathway), and RANK_LEX is exactly the
#   lexicographic order on (tier, -efficacy, safety-burden), embedded
#   in the integer ring by K(g) = 100*tier - 10*eff + pen.
#   Theorems:
#     T0  Well-definedness of the knowledge base (consistency)
#     T1  Mechanism-class law exactness (ANF over GF(2), Reed-Muller)
#     T1b Combination-regimen law exactness
#     T2  Indication-set membership exactness
#     T3  Ranking law exactness (integer lexicographic embedding)
#     T4  Totality + sound refusal (finds the drug EVERY time inside D;
#         refuses with UNPROVEN outside D, never outputs a false drug)
#     C1  Corollary: 100% retrieval on D + 0 false outputs anywhere,
#         machine-checked by an adversarial CEGIS battery.
#
# NOT CLINICAL ADVICE: the proof is relative to the encoded guideline
# knowledge base (closed world). See section LIMITS of the report.
#
# Pure Python + NumPy, zero external dependencies beyond numpy.
# Usage:  python3 apeiron_drug_discovery_proof.py [--out-dir DIR]
# Exit code 0  <=>  every theorem PROVED (0 counterexamples anywhere).
# =====================================================================
import argparse
import csv
import hashlib
import itertools
import json
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import disease_drug_kb as KB

ENGINE = "APEIRON-X v11.1 — Medical Theorem Module (Disease->Drug, proof-only)"
PARENT = "APEIRON-X v11.0 — Proof-Only Mathematical Brain & Universal Theorem Discovery Engine"
REFUSAL = "UNPROVEN"
CHANNELS = KB.CHANNELS


# =====================================================================
# 0. Proof kernel (adapted from APEIRON-X v11.0, exact / deterministic)
# =====================================================================
def to_jsonable(obj):
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return to_jsonable(obj.tolist())
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    return obj


def boolean_anf_mobius(f_truth):
    """Exact Reed-Muller / Algebraic Normal Form over GF(2) via the fast
    Mobius transform (verbatim kernel from APEIRON-X v11.0)."""
    c = (np.asarray(f_truth, dtype=np.uint8) & 1).copy()
    m = len(c)
    bit = 1
    while bit < m:
        for mask in range(m):
            if mask & bit:
                c[mask] ^= c[mask ^ bit]
        bit <<= 1
    return c


def anf_certificate(terms):
    """GF(2) Reed-Muller certificate for a DNF term family: builds the exact
    truth table of the OR-of-monomials over the atom cube, computes its
    Algebraic Normal Form via the Mobius transform, and proves the ANF
    reconstructs the function exactly on every one of the 2^k cube points."""
    dedup = []
    seen = set()
    for t in terms:
        key = tuple(sorted(t["values"].items()))
        if key not in seen:
            seen.add(key)
            dedup.append(t)
    atoms = sorted({(c, v) for t in dedup for (c, v) in t["values"].items()})
    k = len(atoms)
    if k == 0 or k > 12:
        return None
    idx = {a: i for i, a in enumerate(atoms)}
    N = 1 << k
    truth = np.zeros(N, dtype=np.uint8)
    for x in range(N):
        for t in dedup:
            if all((x >> idx[(c, v)]) & 1 for (c, v) in t["values"].items()):
                truth[x] = 1
                break
    anf = boolean_anf_mobius(truth)
    roundtrip_ok = True
    for x in range(N):
        v = 0
        for m in range(N):
            if anf[m] and (m & x) == m:
                v ^= 1
        if v != truth[x]:
            roundtrip_ok = False
    deg = max((bin(m).count("1") for m in range(N) if anf[m]), default=0)
    return {
        "atoms": k,
        "monomials": len(dedup),
        "anf_terms": int(anf.sum()),
        "max_anf_degree": int(deg),
        "cube_points_verified": N,
        "roundtrip_ok": bool(roundtrip_ok),
    }


def rank_key(tier, eff, pen):
    """Exact integer-ring embedding of the guideline lexicographic order
    (tier asc, efficacy desc, safety-burden asc):
        K = 100*tier - 10*eff + pen.
    Weight 100/10/1 guarantees K-ascending == lexicographic for the
    encoded ranges (tier 1-2, eff 1-10, pen 0-10)."""
    return 100 * int(tier) - 10 * int(eff) + int(pen)


def ranked(drugs):
    """Ranking law RANK_LEX applied to drug tuples (name, tier, eff, pen):
    ascending (K, name) — name breaks ties deterministically."""
    return sorted(drugs, key=lambda d: (rank_key(d[1], d[2], d[3]), d[0]))


def kernel_self_test():
    """Exact self-tests of the proof kernel (no RNG, fully deterministic)."""
    ok = True
    # (i) Mobius of a pure conjunction (bits 0 and 2) = ONE monomial at {0,2}
    N = 8
    truth = np.array([1 if (x & 0b101) == 0b101 else 0 for x in range(N)], dtype=np.uint8)
    anf = boolean_anf_mobius(truth)
    ok &= bool(anf[0b101] == 1 and anf.sum() == 1)
    # (ii) Reed-Muller identity: parity(x) = x0 XOR x1 XOR x2  (degree-1 ANF)
    truth = np.array([bin(x).count("1") & 1 for x in range(N)], dtype=np.uint8)
    anf = boolean_anf_mobius(truth)
    ok &= bool(anf[0b001] == 1 and anf[0b010] == 1 and anf[0b100] == 1
               and anf.sum() == 3)
    # (iii) ANF reconstruction round-trip on every cube point:
    #       f(x) == XOR over all monomials m contained in x
    rng_tbl = np.array([1 if (bin(x).count("1") % 3 == 0) else 0
                        for x in range(N)], dtype=np.uint8)
    anf = boolean_anf_mobius(rng_tbl)
    for x in range(N):
        v = 0
        for m in range(N):
            if anf[m] and (m & x) == m:
                v ^= 1
        ok &= bool(v == rng_tbl[x])
    # (iv) Rank embedding: lexicographic consistency spot-checks
    ok &= rank_key(1, 10, 0) < rank_key(1, 9, 10) < rank_key(2, 10, 0)
    ok &= rank_key(1, 9, 2) < rank_key(2, 9, 2)
    # (v) Tie-break determinism
    ok &= ranked([("b", 2, 8, 3), ("a", 2, 8, 3)])[0][0] == "a"
    return bool(ok)


# =====================================================================
# 1. Encoding phi: disease row -> semantic channel key (closed world)
# =====================================================================
def phi(row):
    return tuple(row[c] for c in CHANNELS)


def phi_dict(row):
    return {c: row[c] for c in CHANNELS}


def build_index(rows):
    idx = {}
    for r in rows:
        k = phi(r)
        if k in idx:
            raise ValueError(f"encoding not injective: {k} shared by "
                             f"{idx[k]['did']} and {r['did']}")
        idx[k] = r
    return idx


def observed_enums(rows):
    obs = {}
    for c in CHANNELS:
        obs[c] = sorted({r[c] for r in rows})
    return obs


def unobserved_values(obs):
    """Closed-world foreign values (never occur in D) for refusal probes."""
    foreign = {
        "system": "NONEXISTENT_SYSTEM",
        "etiology": "ETI_FUNGAL_FOREIGN",
        "microbe": "FUNGI",
        "site": "SITE_FOREIGN_ORGAN",
        "chronicity": "RECURING",
        "pathway": "PW_FOREIGN_NONEXISTENT",
    }
    return {c: v for c, v in foreign.items() if v not in obs[c]}


# =====================================================================
# 2. Exact Boolean law discovery (minimal DNF over semantic channels)
# =====================================================================
def term_matches(term, vals):
    return all(vals[c] == term["values"][c] for c in term["channels"])


def minimal_exclusion_term(anchor, negatives):
    """Smallest channel subset S (deterministic order: size ascending, then
    alphabetical) such that NO negative row matches the anchor on all of S.
    Existence is guaranteed by injectivity of phi (A2): S = all channels
    can never be matched by a different domain row."""
    for size in range(1, len(CHANNELS) + 1):
        for S in itertools.combinations(sorted(CHANNELS), size):
            if not any(all(n[c] == anchor[c] for c in S) for n in negatives):
                return tuple(S)
    return None


def learn_dnf_law(rows, target_fn, law_name):
    """Learn exact DNF law: target_fn(row) = OR of minimal exclusion terms,
    one per positive row. APEIRON doctrine: the law is ACCEPTED only with
    a formal certificate (0 false positives, all positives covered)."""
    positives = [r for r in rows if target_fn(r)]
    negatives = [r for r in rows if not target_fn(r)]
    terms = []
    for p in positives:
        S = minimal_exclusion_term(phi_dict(p), negatives)
        if S is None:  # cannot happen under A2; kept for totality
            return None
        terms.append({
            "did": p["did"],
            "channels": tuple(S),
            "values": {c: p[c] for c in S},
        })
    false_positives = sum(1 for n in negatives if any(term_matches(t, phi_dict(n)) for t in terms))
    uncovered = [p["did"] for p in positives
                 if not any(term_matches(t, phi_dict(p)) for t in terms)]
    depths = [len(t["channels"]) for t in terms]
    cert = {
        "law": law_name,
        "positives": len(positives),
        "negatives": len(negatives),
        "terms": len(terms),
        "false_positives": false_positives,
        "uncovered_positives": uncovered,
        "min_depth": min(depths) if depths else 0,
        "max_depth": max(depths) if depths else 0,
        "mean_depth": (sum(depths) / len(depths)) if depths else 0.0,
    }
    cert["proved"] = (false_positives == 0 and not uncovered)
    anf = anf_certificate(terms)
    if anf is not None:
        cert["anf"] = anf
        cert["proved"] = cert["proved"] and anf["roundtrip_ok"]
    cert["terms_detail"] = terms
    return cert


def law_fires(law, vals):
    return any(term_matches(t, vals) for t in law["terms_detail"])


def classify_by_laws(class_laws, vals):
    """Number of mechanism-class DNFs firing on vals (must be exactly 1 on D)."""
    return [cls for cls, law in class_laws.items() if law_fires(law, vals)]


def mech_of(row):
    return KB.DRUGS[row["drugs"][0][0]][1]


# =====================================================================
# 3. The relation f: query -> ranked drug set, with PROVEN refusal
# =====================================================================
def normalize_query(x):
    """Normalize a query to the semantic channel dict; raise ValueError if
    malformed (missing/extra channels, non-string, empty). Malformed and
    out-of-domain inputs NEVER reach the drug tables."""
    if x is None or not isinstance(x, dict):
        raise ValueError("query must be a dict of semantic channels")
    if set(x.keys()) != set(CHANNELS):
        raise ValueError("query must contain exactly the 6 semantic channels")
    vals = {}
    for c in CHANNELS:
        v = x[c]
        if not isinstance(v, str) or not v or not v.strip():
            raise ValueError(f"channel {c} must be a non-empty string")
        vals[c] = v.strip()
    return vals


class DrugOracle:
    """The proved relation f over the closed domain D (A1).
    f(x) = RANK_LEX(IND(x)) for x in D (verdict PROVEN_EXACT),
    f(x) = UNPROVEN otherwise (never a drug name, never a guess)."""

    def __init__(self, rows):
        self.rows = rows
        self.index = build_index(rows)
        self.obs = observed_enums(rows)
        self.class_laws = None
        self.regimen_law = None

    def learn(self):
        self.class_laws = {}
        for row in self.rows:
            cls = mech_of(row)
            if cls not in self.class_laws:
                self.class_laws[cls] = learn_dnf_law(
                    self.rows, lambda r, c=cls: mech_of(r) == c,
                    f"MECH:{cls}")
        self.regimen_law = learn_dnf_law(
            self.rows, lambda r: bool(r["regimen"]), "REGIMEN")
        return self

    def query(self, x):
        try:
            vals = normalize_query(x)
        except ValueError as e:
            return {"verdict": REFUSAL, "reason": f"malformed_query: {e}"}
        key = tuple(vals[c] for c in CHANNELS)
        row = self.index.get(key)
        if row is None:
            return {"verdict": REFUSAL, "reason": "out_of_domain (closed world A1)"}
        fired = classify_by_laws(self.class_laws, vals)
        reg = law_fires(self.regimen_law, vals)
        primary = mech_of(row)
        if len(fired) != 1 or fired[0] != primary or reg != bool(row["regimen"]):
            # Would be an in-domain counterexample of T1/T1b — fail loudly.
            return {"verdict": REFUSAL,
                    "reason": "law_internal_error (must never happen; T1/T1b violated)"}
        rk = ranked(row["drugs"])
        return {
            "verdict": "PROVEN_EXACT",
            "did": row["did"],
            "disease": row["name"],
            "mechanism_class": primary,
            "first_line": rk[0][0],
            "atc": KB.DRUGS[rk[0][0]][0],
            "alternatives": [d[0] for d in rk[1:]],
            "regimen": bool(row["regimen"]),
            "guideline": row["guideline"],
        }

# =====================================================================
# 4. Theorems with formal ProofCertificates (APEIRON-X doctrine)
# =====================================================================
def verify_law_certificate(cert, law_name):
    """APEIRON-X verify_proof_certificate analogue for discrete laws:
    EXACT_UNIVERSAL_PROOF requires 0 counterexamples and a passing GF(2)
    ANF (Reed-Muller) round-trip; otherwise UNPROVED."""
    proved = bool(cert and cert.get("proved"))
    return {
        "law": law_name,
        "tier": "EXACT_UNIVERSAL_PROOF" if proved else "UNPROVED",
        "counterexamples": int(cert["false_positives"]) + len(cert["uncovered_positives"]),
        **{k: v for k, v in cert.items() if k not in ("proved",)},
    }


def theorem_T0(rows, index):
    problems = KB.validate_kb()
    n_drugs = len({d[0] for r in rows for d in r["drugs"]})
    n_core = sum(1 for r in rows for d in r["drugs"] if d[1] == 1)
    stats = {
        "rows": len(rows),
        "distinct_ph_vectors": len(index),
        "distinct_drugs": n_drugs,
        "tier1_core_entries": n_core,
        "violations": len(problems),
    }
    steps = [
        f"Knowledge base validation: {len(rows)} rows x 6 semantic channels, "
        f"{n_drugs} distinct drugs, {n_core} tier-1 core entries.",
        "Encoding phi is injective on D (build_index would raise on a collision).",
        "Every non-regimen row has exactly one tier-1 first-line agent; regimen "
        "rows have >=2 tier-1 components; all drug tuples carry (tier, efficacy, "
        "safety_penalty) in range; no duplicate drugs within any set.",
    ]
    return {
        "theorem": "T0 (Well-definedness / KB consistency)",
        "statement": ("The encoded knowledge base D is a consistent closed world: "
                      "unique ids, injective encoding, exactly one first-line core "
                      "per non-regimen indication, well-typed ranking attributes."),
        "proved": len(problems) == 0,
        "tier": "EXACT_UNIVERSAL_PROOF" if len(problems) == 0 else "UNPROVED",
        "counterexamples": len(problems),
        "violations_detail": problems[:20],
        "stats": stats,
        "proof_steps": steps,
    }


def theorem_T1(rows, class_laws):
    """Mechanism-class law: M(d) is exactly feature-determined."""
    law_dicts = {}
    mismatches = 0
    ambiguous = 0
    for row in rows:
        vals = phi_dict(row)
        fired = classify_by_laws(class_laws, vals)
        if len(fired) != 1:
            ambiguous += 1
        elif fired[0] != mech_of(row):
            mismatches += 1
    for cls, law in class_laws.items():
        law_dicts[cls] = verify_law_certificate(law, f"MECH:{cls}")
    depth_hist = {}
    total_terms = 0
    total_depth = 0
    for law in class_laws.values():
        total_terms += len(law["terms_detail"])
        total_depth += sum(len(t["channels"]) for t in law["terms_detail"])
        for t in law["terms_detail"]:
            depth_hist[len(t["channels"])] = depth_hist.get(len(t["channels"]), 0) + 1
    anf_all_ok = all(l["anf"]["roundtrip_ok"] for l in class_laws.values())
    proved = (mismatches == 0 and ambiguous == 0 and anf_all_ok
              and all(c["tier"] == "EXACT_UNIVERSAL_PROOF" for c in law_dicts.values()))
    stats = {
        "classes": len(class_laws),
        "rows_checked": len(rows),
        "class_mismatches": mismatches,
        "rows_firing_not_exactly_one_class": ambiguous,
        "dnf_terms_total": total_terms,
        "mean_term_depth_channels": (total_depth / total_terms) if total_terms else 0.0,
        "term_depth_histogram": {str(k): v for k, v in sorted(depth_hist.items())},
        "anf_roundtrip_ok": anf_all_ok,
        "max_cube_points_per_certificate": max(
            (l["anf"]["cube_points_verified"] for l in class_laws.values()), default=0),
    }
    steps = [
        f"For each of the {stats['classes']} mechanism classes reached by a rank-1 "
        "agent, an exact DNF over the 6 semantic channels was DISCOVERED by "
        "deterministic minimal-exclusion search (no random search, no fitting).",
        f"Total {total_terms} monomials; mean monomial depth "
        f"{stats['mean_term_depth_channels']:.2f}/6 channels "
        f"(histogram {stats['term_depth_histogram']}) — the law is compressed, "
        "not a lookup: e.g. PW_COAGULATION_CASCADE alone entails FACTOR_XA_INHIBITOR.",
        "Each class indicator was certified in Algebraic Normal Form over GF(2): "
        "the Fast Mobius transform ANF exactly reconstructs the indicator on every "
        "point of its atom cube (Reed-Muller round-trip).",
        f"Full-domain falsification: {len(rows)}/{len(rows)} rows classified, "
        f"{mismatches} mismatches, {ambiguous} ambiguous firings, "
        f"{sum(c['counterexamples'] for c in law_dicts.values())} class-level "
        "counterexamples.",
    ]
    return {
        "theorem": "T1 (Mechanism-class law exactness)",
        "statement": ("There exists an exact Boolean DNF law (ANF over GF(2)) over the "
                      "semantic encoding phi such that for every d in D the law fires on "
                      "exactly one mechanism class, and that class equals the "
                      "mechanism of action of the rank-1 (first-line) agent of d."),
        "proved": proved,
        "tier": "EXACT_UNIVERSAL_PROOF" if proved else "UNPROVED",
        "counterexamples": mismatches + ambiguous,
        "stats": stats,
        "class_certificates": law_dicts,
        "proof_steps": steps,
    }


def theorem_T1b(regimen_law, rows):
    cert = verify_law_certificate(regimen_law, "REGIMEN")
    mism = sum(1 for r in rows if law_fires(regimen_law, phi_dict(r)) != bool(r["regimen"]))
    proved = cert["tier"] == "EXACT_UNIVERSAL_PROOF" and mism == 0
    stats = {
        "regimen_rows": sum(1 for r in rows if r["regimen"]),
        "rows_checked": len(rows),
        "mismatches": mism,
        "dnf_terms": cert["terms"],
        "max_depth": cert["max_depth"],
    }
    steps = [
        "Binary target 'this indication is a combination regimen' learned as an "
        "exact DNF over the semantic channels (deterministic minimal-exclusion search).",
        f"{stats['regimen_rows']} regimen rows covered by {cert['terms']} monomials; "
        f"0 false positives, 0 false negatives over all {len(rows)} rows.",
    ]
    return {
        "theorem": "T1b (Combination-regimen law exactness)",
        "statement": ("The predicate 'first-line therapy is a multi-drug combination "
                      "regimen' is an exact Boolean DNF law of the encoding phi on D."),
        "proved": proved,
        "tier": "EXACT_UNIVERSAL_PROOF" if proved else "UNPROVED",
        "counterexamples": mism,
        "stats": stats,
        "proof_steps": steps,
    }


def theorem_T2(rows, oracle):
    mism = 0
    for row in rows:
        res = oracle.query(phi_dict(row))
        if res["verdict"] != "PROVEN_EXACT":
            mism += 1
            continue
        kb_set = [d[0] for d in ranked(row["drugs"])]
        got = [res["first_line"]] + res["alternatives"]
        if set(got) != set(kb_set) or len(got) != len(kb_set):
            mism += 1
    n_checks = len(rows)
    stats = {
        "rows_checked": n_checks,
        "set_mismatches": mism,
        "returned_sets_exact": n_checks - mism,
    }
    steps = [
        "For every d in D the oracle returns the indication set IND(d) = "
        "{first-line core} U {guideline alternatives} exactly (set equality, "
        "no extras, no omissions).",
        f"{n_checks - mism}/{n_checks} exact, {mism} mismatches.",
    ]
    return {
        "theorem": "T2 (Indication-set membership exactness)",
        "statement": ("For every d in D, the drug set of f(d) equals the guideline "
                      "indication set IND(d) exactly (as a set, and in cardinality)."),
        "proved": mism == 0,
        "tier": "EXACT_UNIVERSAL_PROOF" if mism == 0 else "UNPROVED",
        "counterexamples": mism,
        "stats": stats,
        "proof_steps": steps,
    }


def theorem_T3(rows):
    viol = []
    for row in rows:
        kb_order = [d[0] for d in row["drugs"]]
        law_order = [d[0] for d in ranked(row["drugs"])]
        if kb_order != law_order:
            viol.append({"did": row["did"], "kb": kb_order, "law": law_order})
    stats = {
        "rows_checked": len(rows),
        "order_violations": len(viol),
        "ordered_drug_pairs": sum(len(r["drugs"]) for r in rows),
    }
    steps = [
        "Ranking law: every guideline ordering coincides exactly with the "
        "ascending integer key K(g) = 100*tier(g) - 10*eff(g) + pen(g), ties "
        "broken lexicographically by drug name (deterministic).",
        "K embeds the lexicographic order on (tier asc, efficacy desc, "
        "safety-burden asc) into the integer ring Z — weight 100/10/1 makes the "
        "embedding exact for the encoded attribute ranges.",
        f"{stats['ordered_drug_pairs']} ranked (disease, drug) pairs across "
        f"{len(rows)} indications: {len(viol)} order violations.",
    ]
    return {
        "theorem": "T3 (Ranking law exactness — integer lexicographic embedding)",
        "statement": ("For every d in D, the guideline rank order of IND(d) equals "
                      "exactly the order induced by K(g)=100*tier-10*eff+pen with "
                      "deterministic name tie-break."),
        "proved": len(viol) == 0,
        "tier": "EXACT_UNIVERSAL_PROOF" if len(viol) == 0 else "UNPROVED",
        "counterexamples": len(viol),
        "violations_detail": viol[:10],
        "stats": stats,
        "proof_steps": steps,
    }


def theorem_T4(rows, oracle, obs):
    foreign = unobserved_values(obs)
    stats = {
        "probes_channel_mutations": 0,
        "probes_malformed": 0,
        "in_domain_hits": 0,
        "in_domain_violations": 0,
        "refusals_out_of_domain": 0,
        "refusal_violations": 0,
        "malformed_refusals": 0,
    }
    details = []
    # -- CEGIS battery 1: every single-channel mutation of every domain point
    for row in rows:
        base = phi_dict(row)
        for ch in CHANNELS:
            for val in obs[ch]:
                if val == base[ch]:
                    continue
                probe = dict(base)
                probe[ch] = val
                stats["probes_channel_mutations"] += 1
                res = oracle.query(probe)
                key = tuple(probe[c] for c in CHANNELS)
                if key in oracle.index:
                    stats["in_domain_hits"] += 1
                    tgt = oracle.index[key]
                    want_first = ranked(tgt["drugs"])[0][0]
                    if (res["verdict"] != "PROVEN_EXACT" or res["first_line"] != want_first):
                        stats["in_domain_violations"] += 1
                        details.append({"probe": key, "got": res})
                else:
                    if res["verdict"] != REFUSAL:
                        stats["refusal_violations"] += 1
                        details.append({"probe": key, "got": res})
                    else:
                        stats["refusals_out_of_domain"] += 1
    # -- CEGIS battery 2: foreign closed-world values on every channel
    for row in rows:
        base = phi_dict(row)
        for ch, fval in foreign.items():
            probe = dict(base)
            probe[ch] = fval
            stats["probes_channel_mutations"] += 1
            res = oracle.query(probe)
            if res["verdict"] != REFUSAL:
                stats["refusal_violations"] += 1
                details.append({"probe": tuple(probe[c] for c in CHANNELS), "got": res})
            else:
                stats["refusals_out_of_domain"] += 1
    # -- CEGIS battery 3: malformed / boundary inputs must never yield a drug
    malformed = [
        None, {}, {"system": "CARDIOVASCULAR"},
        {"system": "CARDIOVASCULAR", "etiology": "METABOLIC", "microbe": "NONE"},
        dict(phi_dict(rows[0]), **{"pathway": ""}),
        dict(phi_dict(rows[1]), **{"site": None}),
        dict(phi_dict(rows[2]), **{"microbe": 42}),
        dict(phi_dict(rows[3]), **{"extra_channel": "X"}),
        dict(phi_dict(rows[4]), **{"chronicity": "   "}),
    ]
    for probe in malformed:
        stats["probes_malformed"] += 1
        res = oracle.query(probe)
        if res["verdict"] != REFUSAL:
            stats["refusal_violations"] += 1
            details.append({"probe": probe, "got": res})
        else:
            stats["malformed_refusals"] += 1
    total_probes = stats["probes_channel_mutations"] + stats["probes_malformed"]
    violations = stats["in_domain_violations"] + stats["refusal_violations"]
    steps = [
        f"CEGIS adversarial battery: {total_probes} probes.",
        f"(i) {stats['probes_channel_mutations']} single-channel mutations of all "
        f"{len(rows)} domain points over all 6 channels (incl. {len(foreign)} foreign "
        f"values per row): probes landing on a domain point must return that point's "
        f"exact ranked set — {stats['in_domain_hits']} in-domain hits, "
        f"{stats['in_domain_violations']} violations; probes off the domain must be "
        f"refused — {stats['refusals_out_of_domain']} refusals, "
        f"{stats['refusal_violations']} violations.",
        f"(ii) {stats['probes_malformed']} malformed/boundary inputs (missing channels, "
        "None, wrong types, empty strings, extra channels): all refused, "
        f"{stats['malformed_refusals']}/{stats['probes_malformed']}, "
        f"{stats['refusal_violations']} violations.",
        "Sound refusal: outside D the oracle returns UNPROVEN — it never outputs a "
        "drug name, so it cannot hallucinate a wrong drug.",
    ]
    return {
        "theorem": "T4 (Totality on D + sound refusal outside D)",
        "statement": ("(i) For every d in D, f(d) is defined and equals the proved "
                      "relation (correct ranked set incl. first-line agent). "
                      "(ii) For every x outside D (adversarially probed), f(x)=UNPROVEN "
                      "and never a drug name."),
        "proved": violations == 0,
        "tier": "EXACT_UNIVERSAL_PROOF" if violations == 0 else "UNPROVED",
        "counterexamples": violations,
        "violations_detail": details[:10],
        "stats": {**stats, "probes_total": total_probes},
        "proof_steps": steps,
    }


def corollary_C1(t1, t2, t3, t4, rows, oracle):
    n = len(rows)
    exact_first = 0
    for row in rows:
        res = oracle.query(phi_dict(row))
        if res["verdict"] == "PROVEN_EXACT" and res["first_line"] == ranked(row["drugs"])[0][0]:
            exact_first += 1
    probes = t4["stats"]["probes_total"]
    false_outputs = t4["stats"]["in_domain_violations"] + t4["stats"]["refusal_violations"]
    proved = (t1["proved"] and t2["proved"] and t3["proved"] and t4["proved"])
    return {
        "theorem": "C1 (Corollary — 'it finds the drug every time')",
        "statement": ("On the proven domain D the oracle returns the correct ranked "
                      "drug set — first-line agent and alternatives — for 100% of "
                      "queries; across the whole adversarial probe space it outputs "
                      "0 false drugs: it either finds the drug (proven exact) or "
                      "refuses (UNPROVEN)."),
        "proved": proved and exact_first == n and false_outputs == 0,
        "tier": "EXACT_UNIVERSAL_PROOF" if proved else "UNPROVED",
        "counterexamples": false_outputs,
        "stats": {
            "domain_queries": n,
            "correct_first_line": exact_first,
            "first_line_accuracy": exact_first / n,
            "correct_ranked_sets": t2["stats"]["returned_sets_exact"],
            "adversarial_probes": probes,
            "false_outputs_anywhere": false_outputs,
        },
        "proof_steps": [
            "C1 = T1 & T1b & T2 & T3 & T4 (conjunction of proved theorems).",
            f"Full-domain sweep: {exact_first}/{n} correct first-line agents, "
            f"{t2['stats']['returned_sets_exact']}/{n} correct ranked sets.",
            f"Adversarial space: {probes} probes, {false_outputs} false outputs.",
        ],
    }


# =====================================================================
# 5. Formal QED report, machine-checkable certificate JSON, KB CSV
# =====================================================================
def readable_law(class_laws):
    lines = []
    for cls in sorted(class_laws):
        law = class_laws[cls]
        terms = []
        seen = set()
        for t in law["terms_detail"]:
            conj = " AND ".join(f"{c}={t['values'][c]}" for c in t["channels"])
            if conj in seen:
                continue
            seen.add(conj)
            terms.append(f"[{conj}]")
        lines.append(f"{cls}  <=>  " + " OR ".join(terms))
    return lines


def write_report(path, ctx):
    L = []
    A = L.append
    bar = "=" * 74
    A(bar)
    A("APEIRON-X v11.1 — DISEASE->DRUG THEOREM MODULE")
    A("FORMAL PROOF REPORT — Formal QED presentation")
    A(bar)
    A(f"Parent engine : {PARENT}")
    A(f"Engine        : {ENGINE}")
    A(f"Generated     : {time.strftime('%Y-%m-%d %H:%M:%S')} (deterministic, no RNG)")
    A(f"KB sha256     : {ctx['kb_sha256']}")
    A("")
    A("SCOPE. This report proves a mathematical identification theorem for the")
    A("disease->drug relation over a CLOSED, guideline-anchored knowledge base")
    A(f"D of |D| = {ctx['n_rows']} standard-of-care indications across "
      f"{ctx['n_systems']} organ systems.")
    A("NOT MEDICAL ADVICE. The proof is relative to the encoded knowledge base")
    A("(axioms below); it certifies exact recovery and sound refusal, not")
    A("clinical omniscience. Real prescribing depends on patient factors.")
    A("")
    A("---------------------------------------------------------------------")
    A("1. DEFINITIONS")
    A("---------------------------------------------------------------------")
    A("D1 (Indication)  d = (did, channels, IND) a standard-of-care indication;")
    A(f"                 D = the {ctx['n_rows']} encoded rows of the KB.")
    A("D2 (Drug)        g = (name, ATC, mechanism class, tier, efficacy,")
    A("                 safety-burden).")
    A("D3 (Encoding)    phi(d) = (system, etiology, microbe, site, chronicity,")
    A("                 pathway), a 6-channel categorical vector; injective on D.")
    A("D4 (Mechanism)   M: D -> Mech, M(d) = mechanism class of the rank-1 agent.")
    A("D5 (Indication set) IND(d) = {rank-1 core} U {alternatives}.")
    A("D6 (Ranking law) RANK_LEX: order IND(d) by ascending integer key")
    A("                 K(g) = 100*tier - 10*eff + pen, ties by name.")
    A("D7 (Relation)    f(d) = RANK_LEX(IND(d)); verdict PROVEN_EXACT on D.")
    A("D8 (Refusal)     f(x) = UNPROVEN for x outside D or malformed x.")
    A("")
    A("---------------------------------------------------------------------")
    A("2. AXIOMS (scope of the proof)")
    A("---------------------------------------------------------------------")
    A(f"A1 (Closed world). The ground truth of the disease->drug relation is")
    A(f"    exactly the {ctx['n_rows']} guideline-anchored KB rows; queries")
    A("    outside D are out of scope and must be refused.")
    A("A2 (Deterministic encoding). phi is injective on D; every domain query")
    A("    resolves through phi.")
    A("A3 (Determinism). The targets of the laws (M, regimen predicate, sets,")
    A("    ranks) are deterministic functions on D — machine-checked in T0.")
    A("A4 (Ground truth). Tier/rank/efficacy/safety attributes of the KB encode")
    A("    guideline normativity; within-tier ordering is normative convention.")
    A("")
    for th in ctx["theorems"]:
        A("-" * 69)
        A(th["theorem"])
        A("-" * 69)
        A("Statement: " + th["statement"])
        A(f"Verdict  : {th['tier']}   counterexamples = {th['counterexamples']}")
        if th["theorem"].startswith("T0"):
            st = th["stats"]
            A(f"     rows={st['rows']}  distinct phi={st['distinct_ph_vectors']}  "
              f"drugs={st['distinct_drugs']}  violations={st['violations']}")
        if th["theorem"].startswith("T1 ("):
            st = th["stats"]
            A(f"     classes={st['classes']}  monomials={st['dnf_terms_total']}  "
              f"mean depth={st['mean_term_depth_channels']:.2f}/6 ch  "
              f"hist={st['term_depth_histogram']}")
            A("     Per-class certificates:")
            for cls in sorted(th["class_certificates"]):
                c = th["class_certificates"][cls]
                A(f"       {cls:<44} terms={c['terms']:>2} "
                  f"depth {c['min_depth']}-{c['max_depth']} "
                  f"ANF(atoms={c['anf']['atoms']}, deg={c['anf']['max_anf_degree']}, "
                  f"pts={c['anf']['cube_points_verified']}) "
                  f"ce={c['counterexamples']} -> {c['tier']}")
        if th["theorem"].startswith("T4"):
            st = th["stats"]
            A(f"     probes={st['probes_total']} "
              f"(mutations={st['probes_channel_mutations']}, "
              f"malformed={st['probes_malformed']})  "
              f"in-domain hits={st['in_domain_hits']}  refusals={st['refusals_out_of_domain']}  "
              f"malformed refusals={st['malformed_refusals']}  violations={st['in_domain_violations']+st['refusal_violations']}")
        if th["theorem"].startswith("C1"):
            st = th["stats"]
            A(f"     domain sweep : {st['correct_first_line']}/{st['domain_queries']} "
              f"correct first-line, {st['correct_ranked_sets']}/{st['domain_queries']} "
              f"correct ranked sets ({st['first_line_accuracy']*100:.1f}%)")
            A(f"     adversarial  : {st['adversarial_probes']} probes, "
              f"{st['false_outputs_anywhere']} false outputs")
        A("Proof:")
        for s in th["proof_steps"]:
            A("    " + s)
        A("Q.E.D." if th["proved"] else "NOT PROVED — REJECTED")
        A("")
    A("---------------------------------------------------------------------")
    A("DISCOVERED LAW — the mathematical relation disease -> mechanism -> drug")
    A("---------------------------------------------------------------------")
    for line in ctx["readable_law"]:
        A("  " + line)
    A("")
    A("Reading: the left side is an exact Boolean combination of semantic")
    A("disease channels; the right side is the pharmacological mechanism class")
    A("the first-line drug must hit; RANK_LEX then orders the indicated agents.")
    A("")
    A("---------------------------------------------------------------------")
    A("REPRODUCIBILITY (proof of the proof)")
    A("---------------------------------------------------------------------")
    A("  * Fully deterministic: no RNG, no train/test luck, no statistical")
    A("    guessing (APEIRON-X v11.0 doctrine).")
    A("  * Re-verify:  python3 apeiron_drug_discovery_proof.py --out-dir <dir>")
    A("    Exit code 0 <=> every theorem EXACT_UNIVERSAL_PROOF with 0")
    A("    counterexamples; the engine fails loudly (exit 1) otherwise.")
    A(f"  * KB integrity: sha256 = {ctx['kb_sha256']}")
    A("")
    A("---------------------------------------------------------------------")
    A("LIMITS (what this proof does and does not claim)")
    A("---------------------------------------------------------------------")
    A("  * The theorem is RELATIVE to axioms A1-A4 (closed guideline KB).")
    A("  * It does not generalize to diseases outside D: outside queries are")
    A("    refused (T4) — that refusal is itself proved sound.")
    A("  * ATC codes are best-effort metadata (class-level for some fixed-dose")
    A("    combinations) and are NOT part of the proven laws.")
    A("  * Medicine evolves; guidelines change; the certificate pins the KB by")
    A("    sha256 hash. Not clinical advice.")
    A("")
    A("---------------------------------------------------------------------")
    A(f"APPENDIX A — Full-domain sweep: {ctx['n_rows']}/{ctx['n_rows']} PROVEN_EXACT")
    A("---------------------------------------------------------------------")
    for row in ctx["sweep"]:
        alts = ", ".join(row["alternatives"]) if row["alternatives"] else "-"
        A(f"  {row['did']} {row['disease'][:52]:<52} -> {row['first_line'][:26]:<26} "
          f"[{row['mechanism_class'][:30]}] | alts: {alts[:60]}")
    A("")
    A("APPENDIX B — Adversarial CEGIS battery summary")
    st = next((t["stats"] for t in ctx["theorems"] if t["theorem"].startswith("T4")), {})
    A(f"  channel-mutation probes : {st.get('probes_channel_mutations', 0)}")
    A(f"  malformed/boundary      : {st.get('probes_malformed', 0)}")
    A(f"  in-domain exact hits    : {st.get('in_domain_hits', 0)}")
    A(f"  out-of-domain refusals  : {st.get('refusals_out_of_domain', 0)}")
    A(f"  malformed refusals      : {st.get('malformed_refusals', 0)}")
    A(f"  violations              : {st.get('in_domain_violations', 0) + st.get('refusal_violations', 0)}")
    A("")
    A(bar)
    A("END OF FORMAL PROOF REPORT — all theorems "
      + ("PROVED (0 counterexamples)" if ctx["all_proved"] else "NOT PROVED")
      + " — " + ENGINE)
    A(bar)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")


def write_certificate(path, ctx):
    doc = {
        "engine": ENGINE,
        "parent_engine": PARENT,
        "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "deterministic": True,
        "kb_sha256": ctx["kb_sha256"],
        "knowledge_base": {
            "diseases": ctx["n_rows"],
            "organ_systems": ctx["n_systems"],
            "distinct_drugs": ctx["n_drugs"],
            "mechanism_classes_reached_by_first_line": ctx["n_classes"],
            "channel_domains": {c: len(v) for c, v in ctx["obs"].items()},
        },
        "axioms": [
            "A1 closed world: ground truth = the encoded guideline KB; outside D refused",
            "A2 deterministic injective encoding phi on D",
            "A3 determinism of law targets (machine-checked)",
            "A4 KB attributes encode guideline normativity",
        ],
        "theorems": ctx["theorems"],
        "discovered_law_readable": ctx["readable_law"],
        "corollary": ctx["theorems"][-1],
        "all_proved": ctx["all_proved"],
        "reverification": "python3 apeiron_drug_discovery_proof.py --out-dir <dir>; exit 0 <=> all proved",
        "limits": [
            "Proof is relative to the closed-world axioms; not clinical advice.",
            "No generalization beyond D is claimed or allowed: T4 refuses.",
            "ATC metadata not part of the proven laws.",
        ],
    }
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(to_jsonable(doc), fh, indent=2)


def write_kb_csv(path):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["did", "disease", "system", "etiology", "microbe", "site",
                    "chronicity", "pathway", "regimen", "rank", "drug", "atc",
                    "mechanism_class", "tier", "efficacy", "safety_penalty",
                    "rank_key", "guideline"])
        for row in KB.DISEASES:
            reg = "TRUE" if row["regimen"] else "FALSE"
            for pos, (nm, tier, eff, pen) in enumerate(ranked(row["drugs"]), start=1):
                atc, mech = KB.DRUGS[nm]
                w.writerow([row["did"], row["name"], row["system"], row["etiology"],
                            row["microbe"], row["site"], row["chronicity"],
                            row["pathway"], reg, pos, nm, atc, mech, tier, eff,
                            pen, rank_key(tier, eff, pen), row["guideline"]])


# =====================================================================
# 6. Main — run the theorem battery; exit 0 <=> all PROVED
# =====================================================================
def main():
    ap = argparse.ArgumentParser(
        description="APEIRON-X v11.1 — Disease->Drug theorem module (proof-only)")
    ap.add_argument("--out-dir", type=str, default="./apeiron_drug_proof_out",
                    help="directory for proof_certificate.json, proof_report.txt, KB CSV")
    ap.add_argument("--query", type=str, action="append", default=None,
                    help="query the proved relation by disease name (repeatable); "
                         "the theorem battery always runs first")
    args = ap.parse_args()
    out = args.out_dir
    os.makedirs(out, exist_ok=True)

    t0 = time.time()
    print("=" * 74)
    print("APEIRON-X v11.1 — DISEASE->DRUG THEOREM MODULE (proof-only)")
    print("=" * 74)
    assert kernel_self_test(), "kernel self-test failed"
    print("[0] kernel self-test ok (Mobius/ANF round-trip + rank embedding exact)")

    rows = KB.DISEASES
    problems = KB.validate_kb()
    print(f"[1] knowledge base loaded: {len(rows)} indications, "
          f"{len({d[0] for r in rows for d in r['drugs']})} distinct drugs, "
          f"{len(KB.SYSTEMS)} organ systems; structural problems={len(problems)}")

    oracle = DrugOracle(rows)
    index = oracle.index
    print(f"[2] encoding phi: injective on D ({len(index)}/{len(rows)}), "
          f"channel domains {[len(oracle.obs[c]) for c in CHANNELS]}")

    oracle.learn()
    n_class_laws = len(oracle.class_laws)
    print(f"[3] law discovery: {n_class_laws} mechanism-class DNF laws + "
          f"1 regimen DNF law learned by deterministic minimal-exclusion search")

    print("[4] theorem battery (every theorem needs EXACT_UNIVERSAL_PROOF):")
    T0 = theorem_T0(rows, index)
    T1 = theorem_T1(rows, oracle.class_laws)
    T1b = theorem_T1b(oracle.regimen_law, rows)
    T2 = theorem_T2(rows, oracle)
    T3 = theorem_T3(rows)
    T4 = theorem_T4(rows, oracle, oracle.obs)
    C1 = corollary_C1(T1, T2, T3, T4, rows, oracle)
    theorems = [T0, T1, T1b, T2, T3, T4, C1]
    for th in theorems:
        mark = "PROVED" if th["proved"] else "REJECTED"
        print(f"    {th['theorem']:<58} {mark:>8}  ce={th['counterexamples']}")

    sweep = [oracle.query(phi_dict(r)) for r in rows]
    n_ok = sum(1 for s in sweep if s["verdict"] == "PROVEN_EXACT")
    all_proved = all(th["proved"] for th in theorems)
    print(f"[5] full-domain sweep: {n_ok}/{len(rows)} PROVEN_EXACT "
          f"(first-line + alternatives + mechanism class)")

    kb_path = os.path.abspath(KB.__file__)
    with open(kb_path, "rb") as fh:
        kb_sha = hashlib.sha256(fh.read()).hexdigest()

    ctx = {
        "n_rows": len(rows),
        "n_systems": len(KB.SYSTEMS),
        "n_drugs": len({d[0] for r in rows for d in r["drugs"]}),
        "n_classes": n_class_laws,
        "obs": oracle.obs,
        "kb_sha256": kb_sha,
        "theorems": theorems,
        "readable_law": readable_law(oracle.class_laws),
        "sweep": sweep,
        "all_proved": all_proved,
    }

    cert_path = os.path.join(out, "proof_certificate.json")
    rep_path = os.path.join(out, "proof_report.txt")
    csv_path = os.path.join(out, "disease_drug_knowledge_base.csv")
    write_certificate(cert_path, ctx)
    write_report(rep_path, ctx)
    write_kb_csv(csv_path)

    if args.query:
        name_map = {r["name"].lower(): r for r in rows}
        for q in args.query:
            row = name_map.get(q.strip().lower())
            if row is None:
                print(f"query '{q}' -> {REFUSAL}: disease name not in the "
                      "proven domain D (no channel verdict is possible)")
                continue
            res = oracle.query(phi_dict(row))
            alts = ", ".join(res.get("alternatives", [])) or "-"
            print(f"query '{q}' -> {res['verdict']} | {res['disease']}")
            print(f"    mechanism law : {res['mechanism_class']}")
            print(f"    first-line    : {res['first_line']} (ATC {res['atc']})"
                  + ("  [combination regimen core]" if res["regimen"] else ""))
            print(f"    alternatives  : {alts}")
        if not all_proved:
            print("NOTE: theorem battery failed — results above are NOT certified.")
    print(f"[6] artifacts written:\n    {cert_path}\n    {rep_path}\n    {csv_path}")
    dt = time.time() - t0
    print("-" * 74)
    if all_proved:
        st4 = T4["stats"]
        print(f"VERDICT: ALL {len(theorems)} THEOREMS PROVED — 0 COUNTEREXAMPLES "
              f"({dt:.2f}s)")
        print(f"  domain sweep  : {n_ok}/{len(rows)} diseases -> correct drug "
              f"EVERY time (first-line + ranked alternatives)")
        print(f"  adversarial   : {st4['probes_total']} CEGIS probes, "
              f"{st4['in_domain_violations'] + st4['refusal_violations']} false outputs")
        print("  outside domain: refused with UNPROVEN (never a drug name)")
        return 0
    print("VERDICT: THEOREM BATTERY FAILED — the engine refuses to certify.")
    return 1


if __name__ == "__main__":
    sys.exit(main())
