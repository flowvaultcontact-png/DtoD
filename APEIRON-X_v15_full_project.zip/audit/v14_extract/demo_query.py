#!/usr/bin/env python3
# =====================================================================
# APEIRON-X v11.1 - RUNNABLE DEMO / EVALUATION RUNNER
# Reproduces every claim of the evaluation, end to end:
#   1. kernel self-test + full theorem battery (7 theorems must be PROVED)
#   2. full-domain sweep: 60/60 PROVEN_EXACT
#   3. example in-domain queries (by exact KB name and by channel dict)
#   4. refusal checks: unknown diseases (even with plausible channels),
#      a novel disease reusing a real KB pathway, name-only malformed input
#   5. adversarial CEGIS battery probe count
# Exit code 0  <=>  every expected result reproduced.
# Usage: python3 demo_query.py [--query "Type 2 diabetes mellitus"]
# =====================================================================
import argparse
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import disease_drug_kb as KB
import apeiron_drug_discovery_proof as P

CHANNELS = P.CHANNELS
REFUSAL = P.REFUSAL

# plausible 6-channel encodings for diseases NOT in the KB
OUT_OF_DOMAIN = {
    "Ebola virus disease": dict(system="INFECTIOUS", etiology="VIRAL",
        microbe="VIRUS", site="SYSTEMIC_BLOOD", chronicity="ACUTE",
        pathway="PW_VIRAL_GLYCOPROTEIN_ENTRY"),
    "Sickle cell disease": dict(system="HEMATOLOGIC", etiology="GENETIC",
        microbe="NONE", site="RED_CELL_COMPARTMENT", chronicity="CHRONIC",
        pathway="PW_HBS_POLYMERIZATION"),
    "Endometriosis": dict(system="REPRODUCTIVE_GYNECOLOGIC",
        etiology="INFLAMMATORY_IMMUNE", microbe="NONE",
        site="PELVIC_PERITONEUM", chronicity="CHRONIC",
        pathway="PW_ESTROGEN_DEPENDENT_PROLIFERATION"),
    # real KB pathway (coagulation cascade) + a site no KB row uses
    "Novel disease reusing coagulation pathway": dict(system="CARDIOVASCULAR",
        etiology="VASCULAR_ATHEROTHROMBOTIC", microbe="NONE",
        site="SPLEEN_RED_PULP", chronicity="ACUTE",
        pathway="PW_COAGULATION_CASCADE"),
}

IN_DOMAIN_EXAMPLES = [
    ("Type 2 diabetes mellitus", dict(system="ENDOCRINE_METABOLIC",
        etiology="METABOLIC", microbe="NONE", site="ENDOCRINE_PANCREAS",
        chronicity="CHRONIC", pathway="PW_GLUCOSE_HOMEOSTASIS"),
     "metformin", ["empagliflozin", "sitagliptin", "glimepiride"]),
    ("Atrial fibrillation - stroke prophylaxis", dict(system="CARDIOVASCULAR",
        etiology="NEUROELECTRIC", microbe="NONE", site="CARDIAC_ATRIUM",
        chronicity="CHRONIC", pathway="PW_COAGULATION_CASCADE"),
     "apixaban", ["rivaroxaban", "dabigatran", "warfarin"]),
]


def show(name, res):
    if res["verdict"] == "PROVEN_EXACT":
        print(f"    {name:<44} -> PROVEN_EXACT  first_line={res['first_line']}  "
              f"alts={res['alternatives']}")
    else:
        print(f"    {name:<44} -> {res['verdict']}  ({res['reason']})")


def main():
    ap = argparse.ArgumentParser(description="APEIRON-X v11.1 demo/evaluation "
                                             "runner")
    ap.add_argument("--query", type=str, action="append", default=None,
                    help="additional queries by exact KB disease name")
    args = ap.parse_args()

    t0 = time.time()
    ok_all = True
    print("=" * 74)
    print("APEIRON-X v11.1 - RUNNABLE DEMO / EVALUATION RUNNER")
    print("=" * 74)
    assert P.kernel_self_test(), "kernel self-test failed"
    rows = KB.DISEASES
    oracle = P.DrugOracle(rows).learn()

    print("[1] theorem battery (all 7 must be PROVED):")
    T0 = P.theorem_T0(rows, oracle.index)
    T1 = P.theorem_T1(rows, oracle.class_laws)
    T1b = P.theorem_T1b(oracle.regimen_law, rows)
    T2 = P.theorem_T2(rows, oracle)
    T3 = P.theorem_T3(rows)
    T4 = P.theorem_T4(rows, oracle, oracle.obs)
    C1 = P.corollary_C1(T1, T2, T3, T4, rows, oracle)
    for th in (T0, T1, T1b, T2, T3, T4, C1):
        mark = "PROVED" if th["proved"] else "REJECTED"
        ok_all &= th["proved"]
        print(f"    {th['theorem']:<58} {mark:>8}  ce={th['counterexamples']}")
    print(f"    adversarial CEGIS probes: {T4['stats']['probes_total']} "
          f"({T4['stats']['refusals_out_of_domain']} refused, "
          f"{T4['stats']['in_domain_hits']} in-domain hits, "
          f"{T4['stats']['malformed_refusals']} malformed refused, "
          f"violations={T4['stats']['in_domain_violations'] + T4['stats']['refusal_violations']})")

    print("[2] full-domain sweep:")
    sweep = [oracle.query(P.phi_dict(r)) for r in rows]
    n_ok = sum(1 for s in sweep if s["verdict"] == "PROVEN_EXACT")
    ok_all &= (n_ok == len(rows))
    print(f"    {n_ok}/{len(rows)} PROVEN_EXACT (first-line + ranked alternatives)")

    print("[3] in-domain example queries:")
    for name, chans, want_first, want_alts in IN_DOMAIN_EXAMPLES:
        res = oracle.query(chans)
        show(name + " (by channels)", res)
        ok_all &= (res["verdict"] == "PROVEN_EXACT"
                   and res["first_line"] == want_first
                   and res["alternatives"] == want_alts)
    # by exact KB name (the --query interface path)
    name_map = {r["name"]: r for r in rows}
    for name, _, want_first, _ in IN_DOMAIN_EXAMPLES:
        row = name_map[name]
        res = oracle.query(P.phi_dict(row))
        show(f'"{name}" (by exact name)', res)
        ok_all &= (res["verdict"] == "PROVEN_EXACT"
                   and res["first_line"] == want_first)

    print("[4] refusal checks (closed world A1 / T4 sound refusal):")
    for name, q in OUT_OF_DOMAIN.items():
        res = oracle.query(q)
        show(name, res)
        ok_all &= (res["verdict"] == REFUSAL)
    res = oracle.query({"name": "Ebola"})
    show("name-only malformed input", res)
    ok_all &= (res["verdict"] == REFUSAL)
    res = oracle.query(None)
    show("None query", res)
    ok_all &= (res["verdict"] == REFUSAL)

    if args.query:
        print("[5] requested name queries:")
        low = {r["name"].lower(): r for r in rows}
        for q in args.query:
            row = low.get(q.lower())
            if row is None:
                print(f"    '{q}' -> UNPROVEN (not an exact KB disease name; "
                      f"name queries must match the KB exactly)")
                continue
            res = oracle.query(P.phi_dict(row))
            show(f'"{q}"', res)

    dt = time.time() - t0
    print("=" * 74)
    print(f"RESULT: {'ALL EXPECTED RESULTS REPRODUCED' if ok_all else 'MISMATCH'}"
          f"  ({dt:.2f}s)")
    print("=" * 74)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
