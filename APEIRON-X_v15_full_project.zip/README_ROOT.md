# APEIRON-X v15 — Full Project Package

Single-file archive of the complete APEIRON-X v15 project (proof-engine v14.1
plus the eight-phase v15 program, Phases 1-8 all implemented). All text in
this package is in English.

## Package layout

| Directory | Contents |
| --- | --- |
| `apeiron/` | The APEIRON-X project itself: proof engine (v11.1-v14.1), knowledge base (63 diseases / 223 pairs), learned-law corpora, certificates, docs, and the `v15/` module tree (Modules A-F, connectors, tests, REST API, dashboards, frozen external-data caches) |
| `audit/` | Phase 1 baseline: verbatim `v14_extract/` copy of the v14.1 tree used for the audit, SHA-256 provenance |
| `download/` | All deliverable reports produced during the program: Phase 1-8 reports (DOCX + PDF), benchmark JSON/TXT artifacts, novel-disease test reports, dashboard HTML |
| `scripts/` | Utility and test scripts used during development (e.g. `apeiron_novel_disease_test.py`) |

Not included (by design): `__pycache__/` and `*.pyc` (regenerable bytecode),
`.env` (local environment file, contains only a local database path),
sandbox-internal folders (`skills/`, `tool-results/`, `upload/`).

## Quick start

```bash
cd apeiron
pip install -r requirements.txt

# v14.1 proof chain (each exits 0 on success)
python3 apeiron_drug_discovery_proof.py      # 7 theorems, 63/63 disease sweep
python3 apeiron_structure_proof.py           # 7 S-theorems
python3 apeiron_direct_laws.py               # 6 D-theorems, 63 laws
python3 apeiron_equations.py                 # 8 E-theorems
python3 apeiron_correspondence.py            # 10 C-theorems (~75 s, hermetic)

# v15 regression across all phases
python3 v15/run_full_regression.py

# v15 REST API (Phase 8 integration)
uvicorn v15.api:app --reload                 # http://127.0.0.1:8000/docs
```

## Key documents

- `apeiron/README.md` — project overview, fix-round history, version ledger
- `apeiron/docs/V15_AUDIT.md` — v14.1 baseline audit with live counts
- `apeiron/docs/V15_IMPLEMENTATION_PLAN.md` — binding 8-phase plan
- `apeiron/docs/CHANGELOG.md` — per-change records for every phase
- `apeiron/postulates_v14.json` — SHA-256-locked axiom corpus

## Integrity

The axiom corpus is locked: postulates sha256
`2e95f0f79c5eed35b89a117bf71c0785648c3313e87b41cb211e8b78b3f2ccb0`
(frozen in `apeiron/apeiron_correspondence.py`). No learned law was deleted
or weakened during the v15 program; all fixes (anti-collapse channel laws,
guideline-drift round D61-D63, SGLT2 class law) re-proved the full chain.
