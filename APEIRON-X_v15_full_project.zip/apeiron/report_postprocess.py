#!/usr/bin/env python3
"""Post-process the evaluation report docx for WPS/MS Office compatibility:
1. Remove empty <w:pgNumType/> from section properties (cover section).
2. Patch footer PAGE fields with explicit format switches:
   - sections with pgNumType fmt=upperRoman -> PAGE \\* ROMAN \\* MERGEFORMAT
   - sections with fmt=decimal (or no fmt but start=1 body) -> PAGE \\* arabic \\* MERGEFORMAT
"""
import re
import shutil
import sys
import zipfile

path = sys.argv[1]
zin = zipfile.ZipFile(path)
contents = {n: zin.read(n) for n in zin.namelist()}
zin.close()

doc = contents["word/document.xml"].decode("utf-8")

# 1. remove empty pgNumType tags
removed = doc.count("<w:pgNumType/>")
doc = doc.replace("<w:pgNumType/>", "")

# 1a. strip dirty flags so static renderers show the cached field results
#     (settings.xml updateFields=true still makes Word refresh on open)
n_dirty = doc.count(' w:dirty="true"')
doc = doc.replace(' w:dirty="true"', "")

# 1b. normalize updateFields to explicit w:val="true" (WPS/postcheck friendly)
settings = contents["word/settings.xml"].decode("utf-8")
settings = settings.replace("<w:updateFields/>", '<w:updateFields w:val="true"/>')
contents["word/settings.xml"] = settings.encode("utf-8")

# 2b. Inject cached page numbers into TOC PAGEREF fields so the static
#     (pre-field-update) view shows real page numbers. Word recomputes them
#     on open via updateFields; the numbers here come from the rendered PDF.
TOC_PAGES = {
    "1. Executive Summary": 1,
    "2. System Under Evaluation, Scope and Method": 1,
    "3. Verified Capabilities: Theorem Battery and Full-Domain Sweep": 2,
    "4. Verified Refusal Behaviour Outside the Knowledge Base": 4,
    "5. The Honest Boundary: Exact Retrieval and Consistency, Not Discovery": 5,
    "6. Extension Experiment: Adding Guideline-Anchored Indications D61-D63": 5,
    "6.1 Design of the extension": 5,
    "6.2 Results: refusal-to-proof transition": 6,
    "7. Stress Tests: Injectivity Failure and Law-Compression Limits": 7,
    "7.1 Channel-collision failure (loud, by design)": 7,
    "7.2 One-channel look-alikes: linear law growth, correctness unchanged": 7,
    "7.3 Pathway saturation: the law compensates with deeper terms": 7,
    "8. Conclusions, Expansion Protocol and Recommendations": 8,
}

def _inject_pageref(html_block):
    """Replace a TOC hyperlink's nested PAGEREF field with a plain cached
    page number (LibreOffice re-evaluates nested PAGEREF to empty; Word
    rebuilds the whole TOC field on update, so the cached view is static)."""
    m_text = re.search(r'<w:t[^>]*>([^<]+)</w:t>', html_block)
    if not m_text or "PAGEREF" not in html_block:
        return html_block
    entry_text = re.sub(r"\s+", " ", m_text.group(1)).strip()
    page = TOC_PAGES.get(entry_text)
    if page is None:
        return html_block
    return re.sub(
        r'<w:r><w:fldChar w:fldCharType="begin"[^>]*/>'
        r'<w:instrText[^>]*>\s*PAGEREF _Toc\d+ \\h\s*</w:instrText>'
        r'<w:fldChar w:fldCharType="separate"/>.*?'
        r'<w:fldChar w:fldCharType="end"/></w:r>',
        '<w:r><w:rPr><w:rStyle w:val="Hyperlink"/></w:rPr>'
        f'<w:t xml:space="preserve">{page}</w:t></w:r>',
        html_block, count=1, flags=re.S)

n_patched = 0

def _hyperlink_repl(m):
    global n_patched
    new_block = _inject_pageref(m.group(0))
    if new_block != m.group(0):
        n_patched += 1
    return new_block

doc = re.sub(r"<w:hyperlink[^>]*w:anchor=\"_Toc[^\"]*\"[^>]*>.*?</w:hyperlink>",
             _hyperlink_repl, doc, flags=re.S)
contents["word/document.xml"] = doc.encode("utf-8")

# 2. map footer files -> format by section pgNumType fmt
rels = contents["word/_rels/document.xml.rels"].decode("utf-8")
rid2target = dict(re.findall(
    r'<Relationship[^>]*Id="([^"]+)"[^>]*Target="([^"]+)"', rels))

roman_footers, arabic_footers = set(), set()
for m in re.finditer(r"<w:sectPr(?:\s[^>]*)?>.*?</w:sectPr>", doc, re.S):
    block = m.group(0)
    fmt = re.search(r'<w:pgNumType[^>]*w:fmt="([^"]+)"', block)
    refs = re.findall(r'<w:footerReference[^>]*r:id="([^"]+)"', block)
    for rid in refs:
        target = rid2target.get(rid, "")
        fname = target if target.startswith("word/") else "word/" + target.lstrip("/")
        if fmt and fmt.group(1) == "upperRoman":
            roman_footers.add(fname)
        else:
            arabic_footers.add(fname)
arabic_footers -= roman_footers

def patch_footer(fname, switch):
    xml = contents[fname].decode("utf-8")
    new_xml, n = re.subn(
        r"(<w:instrText[^>]*>)\s*PAGE\s*(</w:instrText>)",
        r"\g<1> PAGE \\* " + switch + r" \\* MERGEFORMAT \g<2>",
        xml)
    if n:
        contents[fname] = new_xml.encode("utf-8")
    return n

n_roman = sum(patch_footer(f, "ROMAN") for f in sorted(roman_footers))
n_arabic = sum(patch_footer(f, "arabic") for f in sorted(arabic_footers))

tmp = path + ".tmp"
with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
    for name, data in contents.items():
        zout.writestr(name, data)
shutil.move(tmp, path)

print(f"pgNumType removed: {removed}; ROMAN footers patched: {n_roman} "
      f"({sorted(roman_footers)}); arabic footers patched: {n_arabic} "
      f"({sorted(arabic_footers)})")
