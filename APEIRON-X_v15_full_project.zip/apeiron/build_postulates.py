#!/usr/bin/env python3
# =====================================================================
# APEIRON-X v14.0 — POSTULATE BUILDER (one-time axiom freeze)
# ---------------------------------------------------------------------
# This script is the AXIOM AUTHORING step of v14.0. It runs the v13
# deterministic law machinery ONCE and freezes its output into a
# single, hash-locked axiom corpus: postulates_v14.json.
#
# The RUNTIME proof core (apeiron_correspondence.py) NEVER imports any
# KB dataset (disease->drug indications, drug->class table, mechanism
# table, structure table) during derivation. It reads ONLY:
#   * postulates_v14.json  — the frozen axiom corpus (this file's output)
#   * RDKit                — pure chemistry (SMILES -> structure)
#   * its own GF(2) kernel — pure mathematics
# The KB is imported exclusively inside the TEST battery of the core,
# where it acts as the examiner (ground truth of known pairs).
#
# POSTULATE SET (frozen here):
#   P1  Molecular atom space: feature vocabulary chi — SMARTS fragment
#       axioms + deterministic descriptor axioms + de-Morgan negations.
#   P2  Disease domain: the 60 diseases of D with their six-channel
#       semantic encodings phi(d) (disease DESCRIPTION only — no drug
#       information of any kind is embedded here).
#   P3  Therapy-mechanism bridge: Mech(d) — drug-name-free pharmacology
#       postulate (which therapy mechanism the pathophysiology demands).
#   P4  Mechanism->structure laws: L_c(chi) — the exact separating DNF
#       over chi for every molecular mechanism class (the chemical
#       structure a drug of mechanism c MUST have).
#   P5  Molecular identity laws: L_G(chi) — the exact law pinning each
#       distinct 2D molecule of the closed chemical universe.
#   P6  Sibling doctrine: documented pharmacophore-family overlaps.
#   P7  The correspondence law is stated IN THE CORE (definition of
#       cure by structure containment) — see apeiron_correspondence.py.
#
# Deterministic: no RNG, sorted keys everywhere; the sha256 of the
# emitted JSON is printed and is stable across runs.
# =====================================================================
import hashlib
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import disease_drug_kb as KB
import drug_structures as DS
import disease_mechanism_table as MT
from apeiron_drug_discovery_proof import CHANNELS, phi_dict
from apeiron_structure_proof import (
    SMARTS_FEATURES, NEGATION_OF, DESCRIPTOR_FEATURES, SIBLINGS,
    StructLayer, derive_structure_laws, derive_drug_laws,
)
from apeiron_direct_laws import (
    training_rows, derive_primary_class_laws, exclusive_firing_violations,
)
from apeiron_drug_discovery_proof import to_jsonable

OUT = os.path.join(HERE, "postulates_v14.json")


def sha256_of(path):
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def main():
    print("=" * 74)
    print("APEIRON-X v14.0 — POSTULATE BUILDER (axiom freeze)")
    print("=" * 74)

    # ---- P2: disease domain (description only) -----------------------
    diseases = []
    for r in KB.DISEASES:
        diseases.append({
            "did": r["did"],
            "name": r["name"],
            "channels": {c: r[c] for c in CHANNELS},
        })
    diseases.sort(key=lambda x: x["did"])
    print(f"[P2] {len(diseases)} disease encodings frozen (6 channels each, "
          "no therapeutic fields)")

    # ---- P3: therapy-mechanism bridge (drug-name-free) ---------------
    mech_required = {did: sorted(mechs)
                     for did, mechs in MT.MECH_REQUIRED.items()}
    print(f"[P3] therapy-mechanism postulate frozen: {len(mech_required)} "
          f"diseases, {sum(len(v) for v in mech_required.values())} entries")

    # ---- P4: channel->mechanism laws C_c ------------------------------
    grows = training_rows()
    c_laws = derive_primary_class_laws(grows)
    viol = exclusive_firing_violations(grows, c_laws)
    assert not viol, f"channel laws not exclusive: {viol[:3]}"
    channel_laws = {
        cls: {"terms": law["terms"], "anf": law["anf"],
              "members": law["members"]}
        for cls, law in sorted(c_laws.items())
    }
    print(f"[P4a] {len(channel_laws)} channel->mechanism laws C_c frozen "
          "(exclusive firing verified)")

    # ---- P4b: mechanism->structure laws L_c ---------------------------
    layer = StructLayer()
    struct_laws, excluded = derive_structure_laws(layer, verbose=False)
    structure_laws = {}
    for cls, cert in sorted(struct_laws.items()):
        structure_laws[cls] = {
            "law_class": cert["law_class"],
            "law_form": cert["law_form"],
            "law_terms": cert["law_terms"],
            "law_features": cert["law_features"],
            "uses_extended": cert["uses_extended"],
            "semantics": cert["semantics"],
            "siblings": cert["siblings"],
            "anf": cert["anf"],
            "proved": cert["proved"],
        }
    excluded_classes = {
        cls: {"reason": exc["reason"], "members": exc["members"],
              "semantics": exc["semantics"], "siblings": exc["siblings"]}
        for cls, exc in sorted(excluded.items())
    }
    n_ok = sum(1 for c in structure_laws.values() if c["proved"])
    print(f"[P4b] {len(structure_laws)} mechanism->structure laws L_c frozen "
          f"({n_ok} proved), {len(excluded_classes)} non-molecular classes "
          "explicitly excluded")

    # ---- P5: molecular identity laws L_G ------------------------------
    chem_groups, drug_laws = derive_drug_laws(layer, verbose=False)
    identity_laws = []
    for ck, cert in sorted(drug_laws.items()):
        identity_laws.append({
            "chem_key": list(ck),
            "drugs": sorted(cert["drugs"]),
            "mechanism_classes": cert["mechanism_classes"],
            "law_form": cert["law_form"],
            "law_terms": cert["law_terms"],
            "law_features": cert.get("law_features", []),
            "uses_extended": cert["uses_extended"],
            "semantics": cert["semantics"],
            "anf": cert["anf"],
        })
    print(f"[P5] {len(identity_laws)} molecular identity laws L_G frozen")

    # ---- P1: feature space --------------------------------------------
    feature_space = {
        "smarts": dict(sorted(SMARTS_FEATURES.items())),
        "negation_of": dict(sorted(NEGATION_OF.items())),
        "descriptor_features": sorted(DESCRIPTOR_FEATURES),
    }
    print(f"[P1] feature vocabulary frozen: {len(feature_space['smarts'])} "
          f"SMARTS axioms, {len(feature_space['negation_of'])} de-Morgan "
          f"negations, {len(feature_space['descriptor_features'])} descriptor "
          "axioms")

    # ---- P6: sibling doctrine -----------------------------------------
    sibling_pairs = {a: sorted(bs) for a, bs in sorted(SIBLINGS.items())}

    # ---- provenance of the build (hashes of the AUTHORING inputs) ------
    provenance = {
        "kb_sha256": sha256_of(os.path.abspath(KB.__file__)),
        "structure_kb_sha256": sha256_of(os.path.abspath(DS.__file__)),
        "mechanism_table_sha256": sha256_of(os.path.abspath(MT.__file__)),
        "component_molecules": len(DS.SMILES),
        "covered_drugs": len(layer.drug_components),
        "excluded_drugs": len(layer.excluded),
    }

    doc = {
        "format": "APEIRON-X v14.0 postulate corpus",
        "feature_space": feature_space,
        "diseases": diseases,
        "mech_required": mech_required,
        "channel_laws": channel_laws,
        "structure_laws": structure_laws,
        "excluded_classes": excluded_classes,
        "identity_laws": identity_laws,
        "sibling_pairs": sibling_pairs,
        "provenance": provenance,
    }
    with open(OUT, "w", encoding="utf-8") as fh:
        json.dump(to_jsonable(doc), fh, indent=1, sort_keys=True)
    sha = sha256_of(OUT)
    size = os.path.getsize(OUT)
    print("-" * 74)
    print(f"written: {OUT}  ({size} bytes)")
    print(f"POSTULATES_SHA256 = {sha}")
    print("Freeze this hash into apeiron_correspondence.py "
          "(EXPECTED_POSTULATES_SHA256).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
