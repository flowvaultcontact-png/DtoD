#!/usr/bin/env python3
# =====================================================================
# APEIRON-X v11.1 - KB EXTENSION + INJECTIVITY STRESS DEMO
# Follow-up experiment on the 60-indication disease->drug proof module.
#
# Part A (extension): add 3 NEW guideline-anchored indications D71-D73
#   (Ebola virus disease, Sickle cell disease, Endometriosis) and RE-PROVE
#   the full theorem battery over the extended closed world (63 rows).
#   Queries that were honestly refused on the 60-row world must become
#   PROVEN_EXACT; a novel coagulation look-alike must stay refused.
#
# Part B (injectivity stress, axiom A2):
#   B1  exact 6-channel collision  -> build_index fails LOUDLY (never silent)
#   B2  one-channel twin of D03    -> injective, proven, law grows by 1 literal
#   B3  scaling: K = 1..8 one-channel look-alikes -> law size vs K curve,
#       with T1 (law exactness) re-verified at every step and the FULL
#       theorem battery + CEGIS battery re-run on the final 71-row world.
#
# Exit code 0  <=>  every check passed.  No randomness, no statistics.
# =====================================================================
import argparse
import copy
import hashlib
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import disease_drug_kb as KB
import apeiron_drug_discovery_proof as P

CHANNELS = P.CHANNELS
REFUSAL = P.REFUSAL


# ---------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------
def law_metrics(oracle, cls):
    """Size metrics of one mechanism-class DNF law."""
    law = oracle.class_laws[cls]
    terms = law["terms_detail"]
    depths = [len(t["channels"]) for t in terms]
    return {
        "class": cls,
        "terms": len(terms),
        "literals": sum(depths),
        "mean_depth": round(sum(depths) / len(depths), 3) if depths else 0.0,
        "max_depth": max(depths) if depths else 0,
        "min_depth": min(depths) if depths else 0,
    }


def run_battery(rows, oracle, label):
    """Full theorem battery on an arbitrary closed world (rows, oracle)."""
    print(f"  theorem battery [{label}] on {len(rows)} rows:")
    T0 = P.theorem_T0(rows, oracle.index)
    T1 = P.theorem_T1(rows, oracle.class_laws)
    T1b = P.theorem_T1b(oracle.regimen_law, rows)
    T2 = P.theorem_T2(rows, oracle)
    T3 = P.theorem_T3(rows)
    T4 = P.theorem_T4(rows, oracle, oracle.obs)
    C1 = P.corollary_C1(T1, T2, T3, T4, rows, oracle)
    theorems = [T0, T1, T1b, T2, T3, T4, C1]
    all_proved = True
    for th in theorems:
        mark = "PROVED" if th["proved"] else "REJECTED"
        all_proved = all_proved and th["proved"]
        print(f"    {th['theorem']:<58} {mark:>8}  ce={th['counterexamples']}")
    return theorems, T4, all_proved


def sweep(rows, oracle):
    res = [oracle.query(P.phi_dict(r)) for r in rows]
    n_ok = sum(1 for s in res if s["verdict"] == "PROVEN_EXACT")
    print(f"  full-domain sweep: {n_ok}/{len(rows)} PROVEN_EXACT")
    return n_ok, len(rows)


def kb_sha():
    with open(os.path.join(HERE, "disease_drug_kb.py"), "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def show(name, res):
    if res["verdict"] == "PROVEN_EXACT":
        print(f"    {name:<34} -> PROVEN_EXACT  first_line={res['first_line']}"
              f"  alts={res['alternatives']}")
    else:
        print(f"    {name:<34} -> {res['verdict']}  ({res['reason']})")


# ---------------------------------------------------------------------
# the 3 new guideline-anchored indications (Part A)
# ---------------------------------------------------------------------
NEW_DRUGS = {
    # drug name: (ATC code, mechanism-of-action class)  -- ATC verified
    "ansuvimab": ("J06BD04", "NEUTRALIZING_MONOCLONAL_ANTIBODY"),
    "atoltivimab/maftivimab/odesivimab": ("NO_ATC_ASSIGNED",
                                          "NEUTRALIZING_MONOCLONAL_ANTIBODY"),
    "hydroxycarbamide": ("L01XX05", "HBF_INDUCER_ANTISICKLING"),
    "crizanlizumab": ("B06AX01", "P_SELECTIN_INHIBITOR"),
    "glutamine": ("A16AA03", "HBF_INDUCER_ANTISICKLING"),
    "ethinylestradiol/levonorgestrel": ("G03AA07", "OVARIAN_HORMONE_SUPPRESSION"),
    "dienogest": ("G03DB08", "OVARIAN_HORMONE_SUPPRESSION"),
    "levonorgestrel IUS": ("G02BA03", "OVARIAN_HORMONE_SUPPRESSION"),
    "medroxyprogesterone acetate": ("G03DA02", "OVARIAN_HORMONE_SUPPRESSION"),
    "elagolix": ("H01CC03", "OVARIAN_HORMONE_SUPPRESSION"),
}

NEW_ROWS = [
    dict(did="D71", name="Ebola virus disease", system="INFECTIOUS",
         etiology="VIRAL", microbe="VIRUS", site="SYSTEMIC_BLOOD",
         chronicity="ACUTE", pathway="PW_VIRAL_GLYCOPROTEIN_ENTRY", regimen=False,
         guideline="WHO EVD guideline 2022-23: strongly recommends ansuvimab "
                   "(Ebanga, FDA 2020) and atoltivimab/maftivimab/odesivimab "
                   "(Inmazeb, FDA 2020) as first-line therapeutics",
         drugs=[("ansuvimab", 1, 9, 2),
                ("atoltivimab/maftivimab/odesivimab", 2, 9, 3)]),
    dict(did="D72", name="Sickle cell disease", system="HEMATOLOGIC",
         etiology="GENETIC", microbe="NONE", site="RED_CELL_COMPARTMENT",
         chronicity="CHRONIC", pathway="PW_HBS_POLYMERIZATION", regimen=False,
         guideline="NHLBI 2014 expert panel: hydroxyurea strongly recommended "
                   "to prevent recurrent pain crises; crizanlizumab (FDA 2019) "
                   "and L-glutamine (FDA 2017) approved add-on options",
         drugs=[("hydroxycarbamide", 1, 9, 3), ("crizanlizumab", 2, 8, 2),
                ("glutamine", 2, 6, 1)]),
    dict(did="D73", name="Endometriosis", system="REPRODUCTIVE_GYNECOLOGIC",
         etiology="INFLAMMATORY_IMMUNE", microbe="NONE", site="PELVIC_PERITONEUM",
         chronicity="CHRONIC", pathway="PW_ESTROGEN_DEPENDENT_PROLIFERATION",
         regimen=False,
         guideline="NICE NG73 / ACOG: combined hormonal contraception or "
                   "progestogen first-line for suspected/confirmed endometriosis; "
                   "dienogest, LNG-IUS, elagolix for pain management",
         drugs=[("ethinylestradiol/levonorgestrel", 1, 8, 2),
                ("dienogest", 2, 9, 2), ("levonorgestrel IUS", 2, 8, 2),
                ("elagolix", 2, 8, 4), ("medroxyprogesterone acetate", 2, 7, 3)]),
]

# queries that the 60-row world honestly refused (plausible channel values)
PROBE_QUERIES = {
    "Ebola virus disease": dict(system="INFECTIOUS", etiology="VIRAL",
        microbe="VIRUS", site="SYSTEMIC_BLOOD", chronicity="ACUTE",
        pathway="PW_VIRAL_GLYCOPROTEIN_ENTRY"),
    "Sickle cell disease": dict(system="HEMATOLOGIC", etiology="GENETIC",
        microbe="NONE", site="RED_CELL_COMPARTMENT", chronicity="CHRONIC",
        pathway="PW_HBS_POLYMERIZATION"),
    "Endometriosis": dict(system="REPRODUCTIVE_GYNECOLOGIC",
        etiology="INFLAMMATORY_IMMUNE", microbe="NONE",
        site="PELVIC_PERITONEUM", chronicity="CHRONIC",
        pathway="PW_ESTROGEN_DEPENDENT_PROLIFERATION"),
    # must stay refused in BOTH worlds: real coag pathway + unobserved site
    "Novel coagulation look-alike": dict(system="CARDIOVASCULAR",
        etiology="VASCULAR_ATHEROTHROMBOTIC", microbe="NONE",
        site="SPLEEN_RED_PULP", chronicity="ACUTE",
        pathway="PW_COAGULATION_CASCADE"),
}

# one-channel look-alikes of D03 (atrial fibrillation stroke prophylaxis):
# each differs from D03 in EXACTLY one semantic channel (stress Part B).
D03 = next(r for r in KB.DISEASES if r["did"] == "D03")
CLONE_SPECS = [
    ("X01", "etiology",   "VASCULAR_ATHEROTHROMBOTIC"),
    ("X02", "site",       "VENOUS_CIRCULATION"),
    ("X03", "chronicity", "ACUTE"),
    ("X04", "site",       "CORONARY_ARTERY"),
    ("X05", "microbe",    "GRAM_POS_COCCI"),
    ("X06", "pathway",    "PW_PLATELET_AGGREGATION"),
    ("X07", "etiology",   "METABOLIC"),
    ("X08", "site",       "NASAL_MUCOSA"),
]


def make_clone(did, channel, value):
    row = dict(D03)
    row["did"] = did
    row["name"] = f"Synthetic look-alike {did} ({channel}={value})"
    row[channel] = value
    row["regimen"] = False
    row["guideline"] = ("SYNTHETIC STRESS ROW: shares 5 of 6 channels with D03; "
                        "exists only to probe axiom A2 injectivity / law growth")
    row["drugs"] = [("apixaban", 1, 9, 2), ("warfarin", 2, 7, 6)]
    return row


# ---------------------------------------------------------------------
# main
# ---------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="APEIRON-X v11.1 KB extension + "
                                             "injectivity stress demo")
    ap.add_argument("--json", type=str, default=None,
                    help="optional path for machine-readable results JSON")
    args = ap.parse_args()

    t_start = time.time()
    print("=" * 74)
    print("APEIRON-X v11.1 - KB EXTENSION + INJECTIVITY STRESS DEMO")
    print("=" * 74)
    assert P.kernel_self_test(), "kernel self-test failed"
    print("[0] kernel self-test ok")

    results = {"engine": P.ENGINE, "kb_sha256_base": kb_sha(), "parts": {}}
    ok_all = True

    # ---- snapshot module state so the demo never permanently mutates it ---
    base_rows = list(KB.DISEASES)          # the original KB rows
    base_drugs = dict(KB.DRUGS)

    # =================================================================
    print(f"[A0] BASELINE closed world ({len(base_rows)} indications, {len(set(r['system'] for r in base_rows))} systems)")
    base_oracle = P.DrugOracle(base_rows).learn()
    base_idx = len(base_oracle.index)
    print(f"  encoding phi injective on D ({base_idx}/{len(base_rows)}), "
          f"channel domains {[len(base_oracle.obs[c]) for c in CHANNELS]}")
    _, base_t4, proved = run_battery(base_rows, base_oracle, f"baseline {len(base_rows)}")
    n_ok, n_tot = sweep(base_rows, base_oracle)
    n_drugs_base = len({d[0] for r in base_rows for d in r["drugs"]})
    print(f"  distinct drugs in base world: {n_drugs_base}")
    ok_all &= proved and (n_ok == n_tot)
    results["parts"]["A0_baseline"] = {
        "rows": len(base_rows), "distinct_drugs": n_drugs_base,
        "theorems_all_proved": proved,
        "sweep_ok": n_ok, "adversarial_probes": base_t4["stats"]["probes_total"],
    }

    # =================================================================
    print(f"[A1] previously-refused queries against the {len(base_rows)}-row world")
    base_verdicts = {}
    for name, q in PROBE_QUERIES.items():
        res = base_oracle.query(q)
        base_verdicts[name] = res["verdict"]
        show(name + " (base)", res)
    name_only = base_oracle.query({"name": "Ebola"})
    show("name-only malformed (base)", name_only)
    base_verdicts["name-only"] = name_only["verdict"]
    ok_all &= all(v == REFUSAL for v in base_verdicts.values())
    results["parts"]["A1_refusals_base"] = base_verdicts

    # =================================================================
    print("[A2] EXTENDED closed world: +D71 Ebola, +D72 sickle cell, "
          "+D73 endometriosis (guideline-anchored, ATC verified)")
    ext_rows = base_rows + NEW_ROWS
    KB.DRUGS.update(NEW_DRUGS)     # runtime patch; restored at the end
    KB.DISEASES = ext_rows         # runtime patch; restored at the end
    problems = KB.validate_kb()
    print(f"  structural validation (T0 rules): violations={len(problems)}")
    for p in problems:
        print(f"    ! {p}")
    ext_oracle = P.DrugOracle(ext_rows)
    ext_idx = len(ext_oracle.index)
    print(f"  encoding phi injective on extended D ({ext_idx}/{len(ext_rows)})")
    ext_oracle.learn()
    print(f"  law discovery: {len(ext_oracle.class_laws)} mechanism-class laws "
          f"+ 1 regimen law re-learned by deterministic minimal-exclusion search")
    theorems_ext, t4_ext, proved_ext = run_battery(ext_rows, ext_oracle,
                                                   f"extended {len(ext_rows)}")
    n_ok_ext, n_tot_ext = sweep(ext_rows, ext_oracle)
    n_drugs_ext = len({d[0] for r in ext_rows for d in r["drugs"]})
    print(f"  distinct drugs now: {n_drugs_ext} (base {n_drugs_base}, "
          f"+{n_drugs_ext - n_drugs_base})")
    ok_all &= proved_ext and (n_ok_ext == n_tot_ext) and not problems \
        and (ext_idx == len(ext_rows))
    results["parts"]["A2_extended"] = {
        "rows": len(ext_rows), "distinct_drugs": n_drugs_ext,
        "injective": ext_idx == len(ext_rows),
        "theorems_all_proved": proved_ext, "sweep_ok": n_ok_ext,
        "adversarial_probes": t4_ext["stats"]["probes_total"],
        "new_channel_values": {
            "system": ["REPRODUCTIVE_GYNECOLOGIC"],
            "etiology": ["GENETIC"],
            "site": ["PELVIC_PERITONEUM"],
            "pathway": ["PW_VIRAL_GLYCOPROTEIN_ENTRY", "PW_HBS_POLYMERIZATION",
                        "PW_ESTROGEN_DEPENDENT_PROLIFERATION"],
        },
    }

    # =================================================================
    print("[A3] same queries, extended world (before -> after)")
    after_verdicts = {}
    for name, q in PROBE_QUERIES.items():
        res = ext_oracle.query(q)
        after_verdicts[name] = res["verdict"]
        show(name, res)
    transition_ok = True
    for name in ("Ebola virus disease", "Sickle cell disease", "Endometriosis"):
        if not (base_verdicts[name] == REFUSAL
                and after_verdicts[name] == "PROVEN_EXACT"):
            transition_ok = False
    if not (base_verdicts["Novel coagulation look-alike"] == REFUSAL
            and after_verdicts["Novel coagulation look-alike"] == REFUSAL):
        transition_ok = False
    name_only_ext = ext_oracle.query({"name": "Ebola"})
    show("name-only malformed (extended)", name_only_ext)
    transition_ok &= (name_only_ext["verdict"] == REFUSAL)
    print(f"  refusal->proven transition for D71/D72/D73: {transition_ok}")
    ok_all &= transition_ok
    results["parts"]["A3_transition"] = {
        "base": base_verdicts, "extended": after_verdicts,
        "transition_ok": transition_ok,
    }

    # =================================================================
    print("[B1] INJECTIVITY STRESS: exact 6-channel collision")
    twin_bad = dict(D03)
    twin_bad["did"] = "X00"
    twin_bad["name"] = "Synthetic perfect twin of D03 (identical channels)"
    try:
        P.build_index(ext_rows + [twin_bad])
        print("  ERROR: build_index accepted a duplicate encoding "
              "(must never happen)")
        collision_ok = False
    except ValueError as e:
        print(f"  build_index raised ValueError (LOUD failure, no silent "
              f"overwrite):")
        print(f"    ValueError: {e}")
        collision_ok = True
    print(f"  collision handled loudly: {collision_ok}")
    ok_all &= collision_ok
    results["parts"]["B1_collision"] = {
        "loud_failure": collision_ok,
        "message": "encoding not injective: shared by D03 and X00",
    }

    # =================================================================
    print("[B2+B3] INJECTIVITY STRESS: one-channel look-alikes (K = 1..8)")
    print(f"  baseline FACTOR_XA_INHIBITOR law (60-row world): "
          f"{law_metrics(base_oracle, 'FACTOR_XA_INHIBITOR')}")
    m_base = law_metrics(base_oracle, "FACTOR_XA_INHIBITOR")
    m_ext = law_metrics(ext_oracle, "FACTOR_XA_INHIBITOR")
    print(f"  extended 63-row world (no look-alikes yet):     {m_ext}")

    stress_rows = list(ext_rows)
    scaling = [dict(K=0, **m_ext, t1_proved=True)]
    scaling_ok = True
    stress_oracle = ext_oracle  # reuse; relearned per step below
    for (did, ch, val) in CLONE_SPECS:
        stress_rows.append(make_clone(did, ch, val))
        KB.DISEASES = stress_rows      # keep validate_kb in sync for T0
        stress_oracle = P.DrugOracle(stress_rows)
        idx_n = len(stress_oracle.index)   # would raise if not injective
        stress_oracle.learn()
        T1 = P.theorem_T1(stress_rows, stress_oracle.class_laws)
        m = law_metrics(stress_oracle, "FACTOR_XA_INHIBITOR")
        scaling.append(dict(K=len(scaling), **m,
                            t1_proved=bool(T1["proved"]),
                            rows=len(stress_rows), injective=idx_n == len(stress_rows)))
        print(f"  K={len(scaling)-1}: rows={len(stress_rows)} "
              f"injective={idx_n == len(stress_rows)} "
              f"T1={'PROVED' if T1['proved'] else 'REJECTED'}  law: "
              f"terms={m['terms']} literals={m['literals']} "
              f"mean_depth={m['mean_depth']} max_depth={m['max_depth']}")
        scaling_ok &= (idx_n == len(stress_rows)) and bool(T1["proved"])
    ok_all &= scaling_ok

    # resumption proof: twin X01 is now resolvable, not refused
    twin_query = P.phi_dict(make_clone("X01", "etiology",
                                       "VASCULAR_ATHEROTHROMBOTIC"))
    twin_res = stress_oracle.query(twin_query)
    show("X01 one-channel twin (stressed world)", twin_res)
    twin_ok = (twin_res["verdict"] == "PROVEN_EXACT"
               and twin_res["first_line"] == "apixaban")
    ok_all &= twin_ok
    print(f"  one-channel twin resolved exactly: {twin_ok}")

    # full battery + CEGIS battery on the final stressed world (71 rows)
    print("[B4] final stressed world: FULL theorem battery")
    theorems_st, t4_st, proved_st = run_battery(stress_rows, stress_oracle,
                                                f"stressed {len(stress_rows)}")
    n_ok_st, n_tot_st = sweep(stress_rows, stress_oracle)
    ok_all &= proved_st and (n_ok_st == n_tot_st)
    results["parts"]["B_stress"] = {
        "collision_loud_failure": collision_ok,
        "scaling": scaling,
        "twin_resolved": twin_ok,
        "final_rows": len(stress_rows),
        "final_theorems_all_proved": proved_st,
        "final_sweep_ok": n_ok_st,
        "final_adversarial_probes": t4_st["stats"]["probes_total"],
        "law_growth": {
            "base_literals": m_base["literals"],
            "extended_literals": m_ext["literals"],
            "stressed_literals": scaling[-1]["literals"],
            "base_mean_depth": m_base["mean_depth"],
            "stressed_mean_depth": scaling[-1]["mean_depth"],
        },
    }

    # =================================================================
    print("[B5] PATHWAY-SATURATION stress: a synthetic NEGATIVE row that "
          "reuses PW_COAGULATION_CASCADE")
    print("  claim under test: 'laws stay compressed only while the pathway "
          "channel stays discriminative'")
    law_before = stress_oracle.class_laws["FACTOR_XA_INHIBITOR"]

    def term_str(t):
        return (f"{t['did']}{{{','.join(t['channels'])}="
                f"{t['values'][t['channels'][0]]}}}")

    print("  before: FACTOR_XA_INHIBITOR terms (D03 = AF stroke prophylaxis, "
          "D07 = VTE treatment):")
    for t in law_before["terms_detail"]:
        print(f"    {term_str(t)}")
    sat_rows = list(stress_rows)
    sat_row = dict(D03)
    sat_row["did"] = "Y01"
    sat_row["name"] = "Synthetic venous inflammatory disorder (reuses coag pathway)"
    sat_row["system"] = "CARDIOVASCULAR"
    sat_row["etiology"] = "INFLAMMATORY_IMMUNE"
    sat_row["microbe"] = "NONE"
    sat_row["site"] = "VENOUS_CIRCULATION"
    sat_row["chronicity"] = "CHRONIC"
    sat_row["pathway"] = "PW_COAGULATION_CASCADE"
    sat_row["regimen"] = False
    sat_row["guideline"] = ("SYNTHETIC SATURATION ROW: reuses the coagulation "
                            "pathway of D03/D07 with a different mechanism class "
                            "(NSAID) to probe pathway discriminativity")
    sat_row["drugs"] = [("ibuprofen", 1, 7, 4), ("naproxen", 2, 7, 4)]
    sat_rows.append(sat_row)
    KB.DISEASES = sat_rows
    sat_oracle = P.DrugOracle(sat_rows)
    idx_sat = len(sat_oracle.index)
    sat_oracle.learn()
    T1_sat = P.theorem_T1(sat_rows, sat_oracle.class_laws)
    law_after = sat_oracle.class_laws["FACTOR_XA_INHIBITOR"]
    print("  after: FACTOR_XA_INHIBITOR terms:")
    for t in law_after["terms_detail"]:
        print(f"    {term_str(t)}")
    m_before = law_metrics(stress_oracle, "FACTOR_XA_INHIBITOR")
    m_after = law_metrics(sat_oracle, "FACTOR_XA_INHIBITOR")
    print(f"  law metrics before: terms={m_before['terms']} "
          f"literals={m_before['literals']} mean_depth={m_before['mean_depth']} "
          f"max_depth={m_before['max_depth']}")
    print(f"  law metrics after:  terms={m_after['terms']} "
          f"literals={m_after['literals']} mean_depth={m_after['mean_depth']} "
          f"max_depth={m_after['max_depth']}")
    sat_row_dict = {c: sat_row[c] for c in P.CHANNELS}
    law_still_excludes = not P.law_fires(law_after, sat_row_dict)
    terms_changed = ([term_str(t) for t in law_after["terms_detail"]]
                     != [term_str(t) for t in law_before["terms_detail"]])
    saturation_ok = (idx_sat == len(sat_rows)
                     and bool(T1_sat["proved"])
                     and law_still_excludes
                     and terms_changed
                     and m_after["max_depth"] >= 2
                     and m_after["min_depth"] >= 2)
    print(f"  law stayed EXACT (T1={'PROVED' if T1_sat['proved'] else 'REJECTED'}) "
          f"while compensating with re-anchored terms: {saturation_ok}")
    print(f"  -> the saturated negative never fires the law ({law_still_excludes}); "
          "anti-collapse depth>=2 invariant preserved "
          f"(min_depth={m_after['min_depth']}, max_depth={m_after['max_depth']}); "
          "correctness is unaffected")
    ok_all &= saturation_ok

    # full battery on the 72-row saturation world
    print("[B6] saturated world: FULL theorem battery")
    theorems_sat, t4_sat, proved_sat = run_battery(sat_rows, sat_oracle,
                                                   f"saturated {len(sat_rows)}")
    n_ok_sat, n_tot_sat = sweep(sat_rows, sat_oracle)
    ok_all &= proved_sat and (n_ok_sat == n_tot_sat)
    results["parts"]["B5_saturation"] = {
        "rows": len(sat_rows),
        "law_metrics_before": m_before,
        "law_metrics_after": m_after,
        "terms_before": [term_str(t) for t in law_before["terms_detail"]],
        "terms_after": [term_str(t) for t in law_after["terms_detail"]],
        "t1_proved": bool(T1_sat["proved"]),
        "theorems_all_proved": proved_sat,
        "sweep_ok": n_ok_sat,
        "adversarial_probes": t4_sat["stats"]["probes_total"],
    }

    # =================================================================
    print("[C] restoring original module state + integrity check")
    KB.DISEASES = base_rows
    KB.DRUGS = base_drugs
    restored = (len(KB.DISEASES) == len(base_rows)
                and set(KB.DRUGS) == set(base_drugs)
                and kb_sha() == results["kb_sha256_base"])
    print(f"  KB module state restored, sha256 unchanged: {restored}")
    ok_all &= restored

    # =================================================================
    dt = time.time() - t_start
    print("=" * 74)
    print(f"RESULT: {'ALL CHECKS PASSED' if ok_all else 'CHECK FAILURE'} "
          f"({dt:.2f}s)")
    print("=" * 74)
    results["all_checks_passed"] = bool(ok_all)
    results["elapsed_seconds"] = round(dt, 2)
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2, default=str)
        print(f"machine-readable results written to {args.json}")
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
