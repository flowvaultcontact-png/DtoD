// =====================================================================
// APEIRON-X v11.1 Evaluation Report generator (docx-js)
// Cover: Recipe R1 (Pure Paragraph Left), palette MC-1 Medical Blue
// Structure: cover / front matter (TOC, Roman) / body (Arabic, 8 sections)
// =====================================================================
const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, PageNumber, NumberFormat, AlignmentType, HeadingLevel,
  WidthType, BorderStyle, ShadingType, TableLayoutType, SectionType,
  TableOfContents, PageBreak, LevelFormat,
} = require("docx");
const fs = require("fs");

// ---------------------------------------------------------------------
// Palette MC-1 (Medical Blue) - light background cover + table tokens
// ---------------------------------------------------------------------
const P = {
  bg: "F5F8FC", primary: "1A5276", accent: "2E86C1", body: "000000",
  secondary: "555555",
  cover: { titleColor: "1A5276", subtitleColor: "606060",
           metaColor: "707070", footerColor: "A0A0A0" },
  table: { headerBg: "2E86C1", headerText: "FFFFFF", accentLine: "1A5276",
           innerLine: "D0DDE8", surface: "EDF3F8" },
};

const NB = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: NB, bottom: NB, left: NB, right: NB };
const allNoBorders = { top: NB, bottom: NB, left: NB, right: NB,
                       insideHorizontal: NB, insideVertical: NB };

// ---------------------------------------------------------------------
// Width-aware title layout (English/Latin) - per design-system rules
// ---------------------------------------------------------------------
function estimateTextWidth(text, pt) {
  let width = 0;
  for (const ch of text) {
    const code = ch.codePointAt(0);
    const isCJK = (code >= 0x4E00 && code <= 0x9FFF) ||
      (code >= 0x3400 && code <= 0x4DBF) ||
      (code >= 0x3000 && code <= 0x303F) ||
      (code >= 0xFF00 && code <= 0xFFEF) ||
      (code >= 0x2E80 && code <= 0x2EFF);
    width += isCJK ? pt * 20 : pt * 11;
  }
  return width;
}

function splitTitleLinesEN(title, maxWidthTwips, pt) {
  // word-based accumulate; never mid-word, no 1-word orphan on last line
  const words = title.split(" ");
  const lines = [];
  let cur = "";
  for (const w of words) {
    const cand = cur ? cur + " " + w : w;
    if (estimateTextWidth(cand, pt) <= maxWidthTwips) {
      cur = cand;
    } else {
      if (cur) lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  // orphan prevention: last line with a single short word -> merge upward
  if (lines.length >= 2) {
    const last = lines[lines.length - 1];
    if (last.split(" ").length === 1 && last.length <= 4) {
      lines[lines.length - 2] += " " + last;
      lines.pop();
    }
  }
  return lines;
}

function calcTitleLayout(title, maxWidthTwips, preferredPt = 40, minPt = 24) {
  let titlePt = preferredPt;
  let lines;
  while (titlePt >= minPt) {
    lines = splitTitleLinesEN(title, maxWidthTwips, titlePt);
    const fits = lines.every((l) => estimateTextWidth(l, titlePt) <= maxWidthTwips);
    if (lines.length <= 3 && fits) break;
    titlePt -= 2;
  }
  if (!lines || lines.length > 3) {
    lines = splitTitleLinesEN(title, maxWidthTwips, minPt);
    titlePt = minPt;
  }
  return { titlePt, titleLines: lines };
}

function calcCoverSpacing(params) {
  const {
    titleLineCount = 1, titlePt = 36, hasSubtitle = false,
    hasEnglishLabel = false, metaLineCount = 0,
    fixedHeight = 800, pageHeight = 16838,
    marginTop = 0, marginBottom = 0,
  } = params;
  const SAFETY = 1200;
  const usableHeight = pageHeight - marginTop - marginBottom - SAFETY;
  const titleHeight = titleLineCount * (titlePt * 23 + 200);
  const subtitleHeight = hasSubtitle ? (12 * 23 + 600) : 0;
  const englishLabelHeight = hasEnglishLabel ? (9 * 23 + 600) : 0;
  const metaHeight = metaLineCount * (10 * 23 + 100);
  const implicitParaHeight = 3 * 300;
  const contentHeight = titleHeight + subtitleHeight + englishLabelHeight +
                        metaHeight + fixedHeight + implicitParaHeight;
  const remainingSpace = usableHeight - contentHeight;
  const safeRemaining = Math.max(remainingSpace, 400);
  const FOOTER_MIN = 800;
  const rawTop = Math.floor(safeRemaining * 0.45);
  const rawBottom = Math.floor(safeRemaining * 0.45);
  const bottomSpacing = Math.max(rawBottom, FOOTER_MIN);
  const topSpacing = Math.max(rawTop - Math.max(0, FOOTER_MIN - rawBottom), 400);
  const midSpacing = Math.max(safeRemaining - topSpacing - bottomSpacing, 0);
  return { topSpacing, midSpacing, bottomSpacing };
}

// ---------------------------------------------------------------------
// Recipe R1: Pure Paragraph Cover (left aligned) - validated recipe
// ---------------------------------------------------------------------
function buildCoverR1(config) {
  const PAL = config.palette;
  const padL = 1200, padR = 800;
  const availableWidth = 11906 - padL - padR - 300;
  const { titlePt, titleLines } = calcTitleLayout(config.title, availableWidth, 40, 24);
  const titleSize = titlePt * 2;
  const spacing = calcCoverSpacing({
    titleLineCount: titleLines.length, titlePt,
    hasSubtitle: !!config.subtitle, hasEnglishLabel: !!config.englishLabel,
    metaLineCount: (config.metaLines || []).length,
    fixedHeight: 400,
  });
  const accentLeft = { style: BorderStyle.SINGLE, size: 8, color: PAL.accent, space: 12 };
  const children = [];

  children.push(new Paragraph({ spacing: { before: spacing.topSpacing } }));

  if (config.englishLabel) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 500 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: PAL.accent, space: 8 } },
      children: [new TextRun({ text: config.englishLabel.split("").join("  "),
        size: 18, color: PAL.accent, font: { ascii: "Arial", eastAsia: "SimHei" },
        characterSpacing: 40 })],
    }));
  }

  for (let i = 0; i < titleLines.length; i++) {
    children.push(new Paragraph({
      indent: { left: padL },
      spacing: { after: i < titleLines.length - 1 ? 100 : 300,
                 line: Math.ceil(titlePt * 23), lineRule: "atLeast" },
      children: [new TextRun({ text: titleLines[i], size: titleSize, bold: true,
        color: PAL.cover.titleColor, font: { eastAsia: "SimHei", ascii: "Arial" } })],
    }));
  }

  if (config.subtitle) {
    children.push(new Paragraph({
      indent: { left: padL, right: padR }, spacing: { after: 800 },
      children: [new TextRun({ text: config.subtitle, size: 24,
        color: PAL.cover.subtitleColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }

  for (const line of (config.metaLines || [])) {
    children.push(new Paragraph({
      indent: { left: padL + 200 }, spacing: { after: 80 },
      border: { left: accentLeft },
      children: [new TextRun({ text: line, size: 24, color: PAL.cover.metaColor,
        font: { eastAsia: "Microsoft YaHei", ascii: "Arial" } })],
    }));
  }

  children.push(new Paragraph({ spacing: { before: spacing.bottomSpacing } }));

  children.push(new Paragraph({
    indent: { left: padL, right: padR },
    border: { top: { style: BorderStyle.SINGLE, size: 2, color: PAL.accent, space: 8 } },
    spacing: { before: 200 },
    children: [
      new TextRun({ text: config.footerLeft || "", size: 16,
        color: PAL.cover.footerColor, font: { ascii: "Arial" } }),
      new TextRun({ text: "                                        " }),
      new TextRun({ text: config.footerRight || "", size: 16,
        color: PAL.cover.footerColor, font: { ascii: "Arial" } }),
    ],
  }));

  return [new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: allNoBorders,
    rows: [new TableRow({
      height: { value: 16838, rule: "exact" },
      children: [new TableCell({
        shading: { type: ShadingType.CLEAR, fill: PAL.bg }, borders: noBorders,
        children,
      })],
    })],
  })];
}

// ---------------------------------------------------------------------
// Body helpers (English report, Profile A formal)
// ---------------------------------------------------------------------
const EN_FONT = { ascii: "Times New Roman", eastAsia: "SimSun" };
const HD_FONT = { ascii: "Arial", eastAsia: "SimHei" };

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 160, line: 312 },
    children: [new TextRun({ text, bold: true, size: 32, color: P.primary, font: HD_FONT })],
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 120, line: 312 },
    children: [new TextRun({ text, bold: true, size: 28, color: P.primary, font: HD_FONT })],
  });
}

function p(runsOrText) {
  const children = typeof runsOrText === "string"
    ? [new TextRun({ text: runsOrText, size: 24, color: P.body, font: EN_FONT })]
    : runsOrText;
  return new Paragraph({
    alignment: AlignmentType.JUSTIFIED,
    spacing: { line: 312, after: 120 },
    children,
  });
}

function bold(text) {
  return new TextRun({ text, bold: true, size: 24, color: P.body, font: EN_FONT });
}
function plain(text) {
  return new TextRun({ text, size: 24, color: P.body, font: EN_FONT });
}

function caption(text) {
  return new Paragraph({
    keepNext: true,
    spacing: { before: 160, after: 80, line: 312 },
    children: [new TextRun({ text, bold: true, size: 21, color: P.secondary, font: HD_FONT })],
  });
}

// Horizontal-only business table (design-system style 3, MC-1 tokens)
function makeTable(headers, rows, widths) {
  const headerRow = new TableRow({
    tableHeader: true, cantSplit: true,
    children: headers.map((text, i) => new TableCell({
      children: [new Paragraph({
        spacing: { line: 276 },
        children: [new TextRun({ text, bold: true, size: 21,
          color: P.table.headerText, font: HD_FONT })],
      })],
      shading: { type: ShadingType.CLEAR, fill: P.table.headerBg },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  });
  const dataRows = rows.map((cells, ri) => new TableRow({
    cantSplit: true,
    children: cells.map((text, i) => new TableCell({
      children: [new Paragraph({
        spacing: { line: 276 },
        children: [new TextRun({ text: String(text), size: 21,
          color: P.body, font: EN_FONT })],
      })],
      shading: ri % 2 === 0
        ? { type: ShadingType.CLEAR, fill: "FFFFFF" }
        : { type: ShadingType.CLEAR, fill: P.table.surface },
      margins: { top: 60, bottom: 60, left: 120, right: 120 },
      width: { size: widths[i], type: WidthType.PERCENTAGE },
    })),
  }));
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    layout: TableLayoutType.FIXED,
    borders: {
      top: { style: BorderStyle.SINGLE, size: 2, color: P.table.accentLine },
      bottom: { style: BorderStyle.SINGLE, size: 2, color: P.table.accentLine },
      left: NB, right: NB,
      insideHorizontal: { style: BorderStyle.SINGLE, size: 1, color: P.table.innerLine },
      insideVertical: NB,
    },
    rows: [headerRow, ...dataRows],
  });
}

function numbered(reference, text) {
  return new Paragraph({
    numbering: { reference, level: 0 },
    spacing: { line: 312, after: 80 },
    children: [new TextRun({ text, size: 24, color: P.body, font: EN_FONT })],
  });
}

// Allow clean wrapping of long SCREAMING_SNAKE identifiers at underscores
function enc(text) {
  return text.replace(/_/g, "_\u200B");
}

function pageFooter() {
  return new Footer({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ children: [PageNumber.CURRENT], size: 18,
        color: "808080", font: EN_FONT })],
    })],
  });
}

function pageHeader() {
  return new Header({
    children: [new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ text: "APEIRON-X v11.1 Evaluation Report",
        size: 18, color: "808080", font: HD_FONT })],
    })],
  });
}

// ---------------------------------------------------------------------
// Content
// ---------------------------------------------------------------------
const T1 = makeTable(
  ["Theorem", "Statement (abridged)", "Verdict", "Counter-examples"],
  [
    ["T0  Well-definedness / KB consistency",
     "D is a consistent closed world: unique ids, injective encoding, exactly one tier-1 first-line agent per non-regimen row, well-typed ranking attributes",
     "PROVED", "0"],
    ["T1  Mechanism-class law exactness",
     "M(d) is exactly feature-determined: minimal-exclusion DNF over the 6 channels, 0 false positives, certified by a GF(2) algebraic-normal-form round-trip",
     "PROVED", "0"],
    ["T1b  Combination-regimen law exactness",
     "The REGIMEN DNF law separates multi-component treatment regimens exactly",
     "PROVED", "0"],
    ["T2  Indication-set membership exactness",
     "For every d in D the returned drug set equals the guideline indication set IND(d) exactly (set equality, cardinality included)",
     "PROVED", "0"],
    ["T3  Ranking law exactness",
     "Every guideline rank order coincides with ascending K(g) = 100*tier - 10*eff + pen with a deterministic name tie-break",
     "PROVED", "0"],
    ["T4  Totality + sound refusal",
     "f(d) is defined and exact for every d in D; f(x) = UNPROVEN outside D and never a drug name",
     "PROVED", "0"],
    ["C1  Corollary (finds the drug every time)",
     "100% retrieval on D and 0 false outputs anywhere, machine-checked by the adversarial CEGIS battery",
     "PROVED", "0"],
  ],
  [22, 46, 16, 16]
);

const T2 = makeTable(
  ["Indication (exact KB name)", "First-line", "Alternatives (ranked)", "Verdict"],
  [
    ["Type 2 diabetes mellitus", "metformin",
     "empagliflozin, sitagliptin, glimepiride", "PROVEN_EXACT"],
    ["Atrial fibrillation - stroke prophylaxis", "apixaban",
     "rivaroxaban, dabigatran, warfarin", "PROVEN_EXACT"],
    ["Pulmonary tuberculosis (drug-sensitive)", "isoniazid (regimen row)",
     "rifampicin, pyrazinamide, ethambutol, moxifloxacin, rifabutin", "PROVEN_EXACT"],
    ["Anaphylaxis (acute)", "epinephrine",
     "chlorphenamine, hydrocortisone", "PROVEN_EXACT"],
  ],
  [26, 18, 32, 24]
);

const T3 = makeTable(
  ["Probe", "Encoding", "Verdict", "Reason"],
  [
    ["Ebola virus disease",
     enc("INFECTIOUS / VIRAL / VIRUS / SYSTEMIC_BLOOD / ACUTE / PW_VIRAL_GLYCOPROTEIN_ENTRY") + " (plausible, not in KB)",
     "UNPROVEN", "out_of_domain (closed world A1)"],
    ["Sickle cell disease",
     enc("HEMATOLOGIC / GENETIC / NONE / RED_CELL_COMPARTMENT / CHRONIC / PW_HBS_POLYMERIZATION") + " (plausible, not in KB)",
     "UNPROVEN", "out_of_domain (closed world A1)"],
    ["Endometriosis",
     enc("REPRODUCTIVE_GYNECOLOGIC / INFLAMMATORY_IMMUNE / NONE / PELVIC_PERITONEUM / CHRONIC / PW_ESTROGEN_DEPENDENT_PROLIFERATION") + " (plausible, not in KB)",
     "UNPROVEN", "out_of_domain (closed world A1)"],
    ["Novel disease reusing a real KB pathway",
     enc("PW_COAGULATION_CASCADE") + " (real) + site " + enc("SPLEEN_RED_PULP") + " (unobserved)",
     "UNPROVEN", "out_of_domain (closed world A1)"],
    ["Name-only query", "{ name: \"Ebola\" } - not the 6-channel dict",
     "UNPROVEN", "malformed_query"],
    ["None / wrong type", "null input", "UNPROVEN", "malformed_query"],
  ],
  [17, 37, 18, 28]
);

const T4 = makeTable(
  ["Probe", "On 60-row world", "On 63-row world", "First-line agent returned (63 rows)"],
  [
    ["Ebola virus disease", "UNPROVEN", "PROVEN_EXACT",
     "ansuvimab (alternative: atoltivimab/maftivimab/odesivimab)"],
    ["Sickle cell disease", "UNPROVEN", "PROVEN_EXACT",
     "hydroxycarbamide (alternatives: crizanlizumab, glutamine)"],
    ["Endometriosis", "UNPROVEN", "PROVEN_EXACT",
     "ethinylestradiol/levonorgestrel (alternatives: dienogest, levonorgestrel IUS, elagolix, medroxyprogesterone acetate)"],
    ["Novel coagulation look-alike", "UNPROVEN", "UNPROVEN", "not applicable"],
    ["Name-only malformed query", "UNPROVEN", "UNPROVEN", "not applicable"],
  ],
  [18, 22, 22, 38]
);

const T5 = makeTable(
  ["K", "Rows", "Law terms", "Law literals", "Mean term depth", "T1 verdict"],
  [
    ["0", "63", "2", "2", "1.0", "PROVED"],
    ["1", "64", "3", "3", "1.0", "PROVED"],
    ["2", "65", "4", "4", "1.0", "PROVED"],
    ["3", "66", "5", "5", "1.0", "PROVED"],
    ["4", "67", "6", "6", "1.0", "PROVED"],
    ["5", "68", "7", "7", "1.0", "PROVED"],
    ["6", "69", "8", "8", "1.0", "PROVED"],
    ["7", "70", "9", "9", "1.0", "PROVED"],
    ["8", "71", "10", "10", "1.0", "PROVED"],
  ],
  [10, 15, 18, 18, 21, 18]
);

const T6 = makeTable(
  ["Metric", "Before saturation (71 rows)", "After saturation (72 rows)"],
  [
    ["FACTOR_XA_INHIBITOR law terms", "10", "10"],
    ["Law literals (total)", "10", "14"],
    ["Mean term depth", "1.0", "1.4"],
    ["Maximum term depth", "1", "2"],
    ["T1 (law exactness)", "PROVED", "PROVED"],
    ["Full-domain sweep", "71/71 PROVEN_EXACT", "72/72 PROVEN_EXACT"],
    ["Adversarial CEGIS probes / violations", "10,233 / 0", "10,377 / 0"],
  ],
  [40, 30, 30]
);

// ---------------------------------------------------------------------
// Body children
// ---------------------------------------------------------------------
const body = [];

// 1. Executive Summary
body.push(h1("1. Executive Summary"));
body.push(p("This report evaluates the APEIRON-X v11.1 disease-to-drug theorem module: a deterministic, proof-only engine that maps guideline indications to ranked drug sets over a closed knowledge base of 60 indications (D01-D60), 13 organ systems and 203 distinct drugs. Each indication is encoded by a six-channel semantic vector phi (system, etiology, microbe, site, chronicity, pathway), and the proved relation is f(d) = RANK_LEX(IND(d)): the guideline first-line agent plus its ranked alternatives, with the required pharmacological mechanism class identified by an exact Boolean DNF law of the encoding."));
body.push(p([plain("The evaluation was performed by deterministic re-runs of the shipped code under a hard exit-code contract: the process exits 0 if and only if every theorem is proved with zero counterexamples. In the baseline configuration, all seven theorems (T0, T1, T1b, T2, T3, T4 and corollary C1) returned "),
  bold("EXACT_UNIVERSAL_PROOF"), plain("; the full-domain sweep resolved 60/60 indications to the correct ranked drug set; and an adversarial counterexample-guided (CEGIS) battery of 8,289 probes produced 0 false outputs. A complete verification run takes approximately 0.07 seconds.")]));
body.push(p("Two follow-up experiments extended the evidence base. First, three guideline-anchored indications (Ebola virus disease, sickle cell disease and endometriosis) were added with ten new drugs whose ATC codes were verified against the WHO ATC/DDD index, KEGG and official labels; every theorem was re-proved over the 63-row world, and the three previously refused queries resolved exactly. Second, the stated expansion limits were stress-tested: duplicate encodings fail loudly, eight one-channel look-alikes leave the laws exact with linear growth, and pathway saturation forces the mechanism law to compensate with deeper terms (mean term depth 1.0 to 1.4) without any loss of correctness."));
body.push(p([plain("Verdict: the engine is internally consistent, deterministic and refuses to guess outside its declared domain. It performs "), bold("exact retrieval with consistency verification"), plain(" over the encoded guidelines; it is not a drug-discovery system and must not be used as clinical advice.")]));

// 2. System Under Evaluation, Scope and Method
body.push(h1("2. System Under Evaluation, Scope and Method"));
body.push(p("The evaluation covers the complete delivered artifact set: disease_drug_kb.py (the knowledge base: 60 guideline-anchored indication rows, 203 distinct drugs with ATC codes and mechanism classes, and structural self-validation), apeiron_drug_discovery_proof.py (the theorem module: GF(2) Mobius/ANF kernel, deterministic DNF law discovery, the DrugOracle relation and the seven-theorem battery with machine-checkable certificates), proof_report.txt (the formal QED report), proof_certificate.json (the machine-readable certificate, with the knowledge base locked by its sha256 digest) and disease_drug_knowledge_base.csv (237 drug records mirroring the knowledge base)."));
body.push(p("Every indication row carries six semantic channels whose observed domains are 13 systems, 19 etiologies, 9 microbes, 38 sites, 2 chronicities and 57 pathways. Axiom A1 closes the world at the knowledge-base rows; axiom A2 requires the encoding phi to be injective on that world; axiom A3 fixes law discovery as a deterministic minimal-exclusion search; and axiom A4 declares the encoded guidelines to be ground truth. Under these axioms the module proves that the mechanism class of every indication is an exact Boolean law of its encoding (additionally certified as an algebraic normal form over GF(2)), and that the guideline rank order coincides exactly with the integer key K(g) = 100*tier - 10*eff + pen."));
body.push(p("All results in this report come from deterministic re-runs: no randomness, no statistical sampling, no permutation luck. The exit-code contract makes the evaluation binary, since exit 0 means every theorem carried a certificate of exact universal proof. Reproducibility was confirmed at byte level: re-generating the certificate and report reproduces the delivered files exactly, apart from the embedded generation timestamp, while the knowledge base and CSV exports are byte-identical (knowledge-base sha256: 0975b7240ea6e16d64d9e4119ba1057af3413025724c8ac4797b0f84b30fb6ec)."));
body.push(p("The evaluation certifies the machinery, not the medicine. Clinical validity of the encoded guidelines, drug-drug interactions, contraindications and patient-specific dosing are outside the scope of the proof and outside this report."));

// 3. Verified Capabilities
body.push(h1("3. Verified Capabilities: Theorem Battery and Full-Domain Sweep"));
body.push(p("Table 1 summarises the theorem battery on the baseline closed world. Every theorem must carry the tier EXACT_UNIVERSAL_PROOF; a single counterexample anywhere would reject the whole battery and flip the exit code to 1."));
body.push(caption("Table 1: Theorem battery on the baseline closed world (60 indications)"));
body.push(T1);
body.push(p("The adversarial battery of Theorem T4 fires 8,289 probes in total: every single-channel mutation of all 60 domain points across all observed channel values, foreign closed-world values injected on every channel, and 9 malformed or boundary inputs. Mutations that land on another domain point must return that point's exact ranked set (10 such in-domain hits were checked and were exact); all 8,270 off-domain probes were refused with UNPROVEN; and 0 violations of either obligation were recorded."));
body.push(caption("Table 2: In-domain query results (verdict PROVEN_EXACT with ranked alternatives)"));
body.push(T2);
body.push(p("Two query interfaces were exercised: the command-line interface (--query, which matches a knowledge-base disease name exactly) and the programmatic interface (DrugOracle.query() over the six-channel dict). Name queries that do not match the knowledge base exactly are refused, so the name channel cannot smuggle an out-of-domain disease into the proved relation."));

// 4. Verified Refusal Behaviour
body.push(h1("4. Verified Refusal Behaviour Outside the Knowledge Base"));
body.push(p("Refusal is Theorem T4(ii) by design. Closed-world axiom A1 admits only the 60 encoded channel vectors; every other input is answered with UNPROVEN plus a reason, and no drug name can ever be emitted outside the domain. Table 3 shows the refusal matrix observed on the baseline world, including encodings that are medically plausible and syntactically well formed."));
body.push(caption("Table 3: Refusal matrix on the baseline 60-row world"));
body.push(T3);
body.push(p("The refusal behaviour is a genuine strength and a precise cost. The engine cannot hallucinate a drug, because every output is gated by a proof obligation; but the same gate means that coverage equals exactly the knowledge base, with zero generalisation, even for close neighbours of encoded diseases. Section 7 additionally shows that the failure mode of the encoding itself, a channel-vector collision, is handled safely: the engine fails loudly rather than silently overwriting an entry."));

// 5. Honest Boundary
body.push(h1("5. The Honest Boundary: Exact Retrieval and Consistency, Not Discovery"));
body.push(p("The certificate must be read with its axiom A4 attached: the knowledge base is declared ground truth. The learned laws (for example, PW_COAGULATION_CASCADE implies FACTOR_XA_INHIBITOR) are derived from the same 60 rows against which they are checked. The proof therefore certifies that the machinery is internally consistent and deterministic over that closed world; it does not certify that the encoded medicine is clinically correct."));
body.push(p("Consequently, the system performs exact retrieval plus consistency verification, not drug discovery. What the certificate guarantees is determinism (identical inputs always yield identical outputs), exactness of the retrieval and ranking relation inside D, and sound refusal outside D. What it does not guarantee is novelty, clinical validity, or behaviour beyond the encoded world."));
body.push(p("Extending coverage therefore requires manually adding a guideline-anchored knowledge-base row, after which the engine re-proves the laws over the larger closed world. Two practical limits accompany expansion, both confirmed experimentally in Section 7: the six-channel encoding must remain injective (two diseases with identical channel vectors abort the build), and the learned laws stay compressed only while the channel values remain discriminative; when a channel value stops separating mechanism classes, the law compensates by growing deeper terms."));

// 6. Extension Experiment
body.push(h1("6. Extension Experiment: Adding Guideline-Anchored Indications D61-D63"));
body.push(h2("6.1 Design of the extension"));
body.push(p("Three new indications were added as rows D61-D63, each anchored to a named, current guideline. Ebola virus disease was anchored to the WHO Ebola virus disease guidance, under which ansuvimab (Ebanga, FDA approved December 2020) and the atoltivimab/maftivimab/odesivimab combination (Inmazeb, FDA approved October 2020) are the recommended first-line therapeutics. Sickle cell disease was anchored to the NHLBI 2014 expert-panel report, in which hydroxyurea is strongly recommended to prevent recurrent pain crises, with crizanlizumab (FDA 2019) and L-glutamine (FDA 2017) as approved add-on options. Endometriosis was anchored to NICE NG73 and ACOG guidance, with combined hormonal contraception or a progestogen first-line and dienogest, the levonorgestrel intrauterine system and elagolix for pain management."));
body.push(p("Ten new drug registry entries were added with ATC codes verified against the WHO ATC/DDD index, KEGG and official product labels: ansuvimab J06BD04, hydroxycarbamide L01XX05, crizanlizumab B06AX01, glutamine A16AA03, ethinylestradiol/levonorgestrel G03AA07, dienogest G03DB08, levonorgestrel IUS G02BA03, medroxyprogesterone acetate G03DA02 and elagolix H01CC03. The Inmazeb fixed-dose combination has no WHO ATC code assigned and is recorded honestly as NO_ATC_ASSIGNED rather than being given an invented code. Seven new channel values (one system, one etiology, one site and three pathways) extended the encoding domains."));
body.push(h2("6.2 Results: refusal-to-proof transition"));
body.push(p("Table 4 shows the before-and-after verdict transition. On the 60-row world all five probes were refused; on the 63-row world the three new indications resolve to the guideline first-line agent and ranked alternatives, while the novel coagulation look-alike (a real pathway value combined with an unobserved site) and the malformed name-only query remain refused. The extension therefore does not overgeneralise."));
body.push(caption("Table 4: Verdict transition for the previously refused probes"));
body.push(T4);
body.push(p("The extended world re-certifies in full: the encoding stays injective (63/63 distinct vectors), structural validation reports 0 violations, the law battery grows from 54 to 57 mechanism-class laws plus the regimen law, all seven theorems again return EXACT_UNIVERSAL_PROOF, the sweep resolves 63/63 indications, and the enlarged adversarial battery fires 9,081 probes with 0 violations. The drug registry now covers 213 distinct agents."));

// 7. Stress Tests
body.push(h1("7. Stress Tests: Injectivity Failure and Law-Compression Limits"));
body.push(h2("7.1 Channel-collision failure (loud, by design)"));
body.push(p("Two synthetic rows were given the identical six-channel vector of D03 (atrial fibrillation stroke prophylaxis) with different disease ids. The index builder rejected the world with ValueError: encoding not injective - the shared vector was reported as belonging to D03 and X00. The failure is loud, immediate and names both colliding rows; nothing is silently overwritten, and the in-memory oracle is untouched. This is the designed behaviour of axiom A2."));
body.push(h2("7.2 One-channel look-alikes: linear law growth, correctness unchanged"));
body.push(p("Eight synthetic rows (X01-X08) were then added, each differing from D03 in exactly one of the six channels (etiology, site, chronicity, microbe and pathway in turn), giving K = 1..8 cumulative look-alikes. Table 5 tracks the FACTOR_XA_INHIBITOR mechanism law. The law grows by exactly one term and one literal per look-alike (2 to 10 terms), the mean term depth stays at 1.0, injectivity holds at every step, and T1 remains PROVED at every step. The one-channel twin is resolved exactly (apixaban first-line), not refused. The final 71-row world re-certifies completely: all seven theorems PROVED, sweep 71/71, and 10,233 adversarial probes with 0 violations."));
body.push(caption("Table 5: FACTOR_XA_INHIBITOR law growth over K one-channel look-alikes"));
body.push(T5);
body.push(h2("7.3 Pathway saturation: the law compensates with deeper terms"));
body.push(p("The claim that laws stay compressed only while the pathway channel stays discriminative was tested directly: a synthetic negative row (Y01, a venous inflammatory disorder of the NSAID class) was added that reuses PW_COAGULATION_CASCADE together with the shared site VENOUS_CIRCULATION. After Y01, no single channel separates every positive of the FACTOR_XA_INHIBITOR law from the negatives, so the law re-derives itself deterministically with deeper terms. Total literals grow from 10 to 14 and mean term depth from 1.0 to 1.4 (maximum 2): D03 compensates by switching from the pathway literal to its site literal, and D07 replaces its single pathway literal with a two-channel term (chronicity, pathway). T1 remains PROVED and the 72-row world re-certifies in full."));
body.push(caption("Table 6: Law metrics before and after pathway saturation"));
body.push(T6);
body.push(p("The lesson is that correctness is independent of compression. Look-alikes make the law larger (more terms); channel saturation makes it deeper (more literals per term); in both cases the engine re-derives an exact law and the exit-code contract still holds. Compression quality, not correctness, is what a knowledge-base curator should monitor."));

// 8. Conclusions
body.push(h1("8. Conclusions, Expansion Protocol and Recommendations"));
body.push(p([plain("All evaluation objectives were reproduced deterministically. Across the baseline (60 rows), extended (63), look-alike-stressed (71) and saturated (72) worlds, every theorem battery returned seven PROVED verdicts with zero counterexamples, every full-domain sweep resolved every encoded indication exactly, and every adversarial battery recorded zero false outputs. The exit code was 0 on every run, and regenerated artifacts are byte-identical to the delivered ones apart from generation timestamps. "), bold("Verdict: PASS on all objectives.")]));
body.push(p("For future expansion of the knowledge base, the following protocol is recommended; the engine enforces parts of it automatically."));
body.push(numbered("protocol", "Anchor every new row to a named, dated guideline and record that anchor in the row's guideline field."));
body.push(numbered("protocol", "Verify every drug's INN and ATC code against an authoritative source; record NO_ATC_ASSIGNED when none exists rather than inventing one."));
body.push(numbered("protocol", "Enforce encoding injectivity: the six-channel vector must differ from every existing row; the build aborts loudly otherwise."));
body.push(numbered("protocol", "Keep the ranking attributes exact: exactly one tier-1 agent per non-regimen row and a K-ascending drug order within every row."));
body.push(numbered("protocol", "Re-run the full theorem battery and accept the new row only on exit code 0."));
body.push(p("Three recommendations follow. First, position the system as a formal-methods artefact - a verifier of guideline-encoding consistency - and not as clinical decision support: the certificate's scope is the closed world of axiom A1. Second, keep the knowledge base hash-locked inside the certificate and re-certify on every knowledge-base change, so that the certificate can never silently describe a different world. Third, monitor law compression as the knowledge base grows: a mean term depth near 1.0 signals a discriminative encoding, while depth values above 2 are an early warning that channel values are saturating and the encoding vocabulary needs refinement."));
body.push(p("Within its declared domain the engine finds the guideline answer every time and refuses everywhere else. That is exactly the guarantee it was built to provide, and exactly as far as it goes."));

// ---------------------------------------------------------------------
// Document assembly: cover / front matter (TOC) / body
// ---------------------------------------------------------------------
const pgSize = { width: 11906, height: 16838 };
const pgMargin = { top: 1440, bottom: 1440, left: 1701, right: 1417 };

const doc = new Document({
  creator: "APEIRON-X evaluation harness",
  title: "APEIRON-X v11.1 Evaluation Report",
  features: { updateFields: true },  // Word prompts to refresh TOC on open
  styles: {
    default: {
      document: {
        run: { font: EN_FONT, size: 24, color: "000000" },
        paragraph: { spacing: { line: 312 } },
      },
      heading1: {
        run: { font: HD_FONT, size: 32, bold: true, color: P.primary },
        paragraph: { spacing: { before: 360, after: 160, line: 312 }, outlineLevel: 0 },
      },
      heading2: {
        run: { font: HD_FONT, size: 28, bold: true, color: P.primary },
        paragraph: { spacing: { before: 240, after: 120, line: 312 }, outlineLevel: 1 },
      },
    },
  },
  numbering: {
    config: [{
      reference: "protocol",
      levels: [{
        level: 0, format: LevelFormat.DECIMAL, text: "%1.",
        alignment: AlignmentType.LEFT,
        style: { paragraph: { indent: { left: 720, hanging: 360 } } },
      }],
    }],
  },
  sections: [
    { // Section 1: cover - margin 0, no header/footer, no page number
      properties: {
        page: { size: pgSize, margin: { top: 0, bottom: 0, left: 0, right: 0 } },
      },
      children: buildCoverR1({
        title: "APEIRON-X v11.1 Evaluation Report",
        subtitle: "Disease-to-drug theorem engine: closed-world guarantees, guideline-anchored knowledge-base extension, and injectivity stress tests",
        englishLabel: "SYSTEM EVALUATION",
        metaLines: [
          "Engine under evaluation: APEIRON-X v11.1 Medical Theorem Module",
          "Knowledge base: disease_drug_kb.py (60 indications, sha256-locked)",
          "Harnesses: demo_query.py + extension_stress_demo.py (deterministic)",
          "Evaluation date: 23 November 2026",
        ],
        footerLeft: "APEIRON-X v11.1 - proof-only, not clinical advice",
        footerRight: "2026-11-23",
        palette: P,
      }),
    },
    { // Section 2: front matter (TOC) - Roman numerals
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.UPPER_ROMAN } },
      },
      headers: { default: pageHeader() },
      footers: { default: pageFooter() },
      children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          spacing: { before: 480, after: 360 },
          children: [new TextRun({ text: "Table of Contents", bold: true, size: 32,
            color: P.primary, font: HD_FONT })],
        }),
        new TableOfContents("Table of Contents", {
          hyperlink: true,
          headingStyleRange: "1-3",
        }),
        new Paragraph({
          spacing: { before: 200 },
          children: [new TextRun({
            text: "Note: This Table of Contents is generated via field codes. To ensure page number accuracy after editing, please right-click the TOC and select \"Update Field.\"",
            italics: true, size: 18, color: "888888", font: EN_FONT })],
        }),
      ],
    },
    { // Section 3: body - Arabic numerals restarting at 1
      properties: {
        type: SectionType.NEXT_PAGE,
        page: { size: pgSize, margin: pgMargin,
                pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } },
      },
      headers: { default: pageHeader() },
      footers: { default: pageFooter() },
      children: body,
    },
  ],
});

Packer.toBuffer(doc).then((buf) => {
  fs.writeFileSync("/home/z/my-project/download/APEIRON_X_v11.1_evaluation_report.docx", buf);
  console.log("report written:", buf.length, "bytes");
});
