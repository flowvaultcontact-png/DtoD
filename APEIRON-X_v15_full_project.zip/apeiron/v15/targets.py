"""Module B — biological target discovery (Phase 3, plan §4).

P3-1 frozen evidence: `v15.target_data` is the hash-pinned table of
machine-verified target evidence (HGNC/UniProt identifiers, Open Targets
association rows, Reactome stable ids, Europe PMC citations). This
module loads it under a pin discipline identical to the vocabulary
(refuses to serve on sha256 mismatch with
`v15/kb_extensions/targets_pins.json`).

P3-2 transparent scoring: every ranked target reports its axes
INDIVIDUALLY — genetic_evidence, functional_evidence,
pharmacological_tractability, safety_penalty, evidence_completeness.
The aggregate is labelled COMPUTATIONAL_RANK and is never a probability.

P3-3 anti-causal-illusion discipline: association-only evidence keeps
the ASSOCIATION_NOT_CAUSATION flag set; the flag propagates into every
derived artefact and can only be cleared by cited functional or genetic
causal evidence (never by computation). `theorem_anti_causal_illusion`
machine-checks this on any rank report.

Accepted behaviors kept from the Phase 1 skeleton (scaffold tests):
TargetEvidence / TargetHypothesis / score_target, incl. empty-evidence
refusal and the flag mechanics.
"""

import json
import os
from dataclasses import dataclass, field

# ---------------------------------------------------------------- paths
HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_DATA_PATH = os.path.abspath(os.path.join(HERE, "target_data.py"))
TARGET_PIN_PATH = os.path.join(HERE, "kb_extensions", "targets_pins.json")

# scoring axes (displayed individually in every report)
AXES = ("genetic_evidence", "functional_evidence", "pharmacological_tractability",
        "safety_penalty", "evidence_completeness")

_CAUSAL_KINDS = {"functional_perturbation", "causal_variant", "rescue_experiment"}


def sha256_of(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class TargetEvidence:
    target_id: str            # e.g. "HGNC:2625" / "UniProt:P35557" (never a bare name)
    target_kind: str          # gene|receptor|enzyme|ion_channel|transporter|
                              # transcription_factor|signaling_protein|complex|pathway_node
    evidence_kind: str        # association|causal_variant|functional_perturbation|
                              # rescue_experiment|drug_binding|guideline
    source_ids: tuple         # must resolve in a TargetTable/ProvenanceLedger at report time
    direction: str = "unknown"  # agonize|inhibit|modulate|unknown
    note: str = ""

    def __post_init__(self):
        if not self.target_id or not self.source_ids:
            raise ValueError("target evidence needs an id and >=1 source id")
        if self.target_kind not in {
            "gene", "receptor", "enzyme", "ion_channel", "transporter",
            "transcription_factor", "signaling_protein", "complex",
            "pathway_node"}:
            raise ValueError(f"unknown target_kind {self.target_kind!r}")


@dataclass
class TargetHypothesis:
    disease_name: str
    evidences: list = field(default_factory=list)
    has_causal_evidence: bool = False
    flags: tuple = ()         # e.g. ("ASSOCIATION_NOT_CAUSATION",)

    def add(self, ev: TargetEvidence) -> None:
        self.evidences.append(ev)
        if ev.evidence_kind in _CAUSAL_KINDS:
            self.has_causal_evidence = True

    def finalize(self) -> "TargetHypothesis":
        """Recompute the causality flag from the evidence records: cited
        causal evidence CLEARS it (that is the only clearing path); a
        recomputation can never be used to clear it, only new evidence."""
        flags = [f for f in self.flags
                 if f != "ASSOCIATION_NOT_CAUSATION"]
        if not self.has_causal_evidence:
            flags.append("ASSOCIATION_NOT_CAUSATION")
        self.flags = tuple(flags)
        return self


def score_target(h: TargetHypothesis, safety_penalty: float = 0.0) -> dict:
    """Per-axis transparency scores in [0,1]; aggregate is a rank hint ONLY.

    All axes are simple, auditable counting functions of the submitted
    evidence records — no learned weights, no hidden merge. An aggregate
    rank with ASSOCIATION_NOT_CAUSATION set must be consumed as hypothesis.
    `safety_penalty` in [0,1]: filled from Module C/D safety data in
    Phase 4/5; defaults to 0.0 (documented placeholder, not a claim).
    """
    if not h.evidences:
        raise ValueError("no evidence records; refusing to score (report "
                         "UNKNOWN instead)")
    kinds = {ev.evidence_kind for ev in h.evidences}
    distinct_sources = {sid for ev in h.evidences for sid in ev.source_ids}
    axes = {
        "genetic_evidence": 1.0 if kinds & {"causal_variant"} else
                            (0.4 if kinds & {"association"} else 0.0),
        "functional_evidence": 1.0 if kinds & {"functional_perturbation",
                                               "rescue_experiment"} else 0.0,
        "pharmacological_tractability": 1.0 if kinds & {"drug_binding",
                                                        "guideline"} else 0.0,
        "safety_penalty": round(min(max(safety_penalty, 0.0), 1.0), 4),
        "evidence_completeness": min(1.0, len(distinct_sources) / 5.0),
    }
    # labelled aggregate: arithmetic mean of the completed axes, explicitly
    # NOT a probability; name says rank, and the label travels with the flag
    agg = sum(axes.values()) / len(AXES)
    label = ("COMPUTATIONAL_RANK" +
             (" [ASSOCIATION_NOT_CAUSATION]" if
              "ASSOCIATION_NOT_CAUSATION" in h.flags else ""))
    return {"axes": axes, "aggregate": round(agg, 4), "aggregate_label": label,
            "tier": "COMPUTATIONAL"}


# =====================================================================
# P3-1 loader: pin-checked facade over the frozen target table
# =====================================================================

class TargetTable:
    """Read-only facade over `v15.target_data` with source resolution."""

    def __init__(self, verify_pin: bool = True):
        from . import target_data as td
        self._td = td
        self.data_sha256 = sha256_of(TARGET_DATA_PATH)
        if not os.path.exists(TARGET_PIN_PATH):
            raise RuntimeError(
                f"target pin file missing: {TARGET_PIN_PATH}. Run "
                "v15/kb_extensions/freeze_targets.py (frozen-table "
                "doctrine: unpinned tables are not served).")
        with open(TARGET_PIN_PATH, encoding="utf-8") as fh:
            self.pins = json.load(fh)
        if verify_pin and self.pins.get("target_data_sha256") != \
                self.data_sha256:
            raise RuntimeError(
                "target_data.py sha256 mismatch: frozen pin "
                f"{self.pins.get('target_data_sha256')} != live "
                f"{self.data_sha256}. If this change is intentional, "
                "re-run the documented re-freeze, never edit silently.")
        problems = td.validate_target_module()
        if problems:
            raise ValueError("target module self-validation failed: "
                             + "; ".join(problems))
        self.schema_version = td.TARGET_SCHEMA_VERSION
        self.frozen_utc = td.FROZEN_UTC
        self.genes = dict(td.GENE_TARGETS)
        self.panel = dict(td.BENCHMARK_PANEL)
        self.evidence = list(td.EVIDENCE_ROWS)
        self.ot_assocs = dict(td.OT_ASSOCIATIONS)
        self.literature = dict(td.LITERATURE)
        self.kind_map = dict(td.OT_DATATYPE_KIND_MAP)
        self.limits = tuple(td.HONEST_LIMITS)

    # -- source resolution (anti-fabrication gate) --------------------
    def source_record(self, source_id: str) -> dict:
        td = self._td
        if source_id in td.SOURCE_RECORDS:
            return dict(td.SOURCE_RECORDS[source_id])
        if source_id in getattr(td, "INTERNAL_SOURCE_RECORDS", {}):
            return dict(td.INTERNAL_SOURCE_RECORDS[source_id])
        if source_id in self.literature:
            rec = dict(self.literature[source_id])
            rec["resource"] = f"Europe PMC record {rec['pmid']}"
            return rec
        raise KeyError(f"no provenance record for source id {source_id}")

    def require_sources(self, source_ids) -> None:
        missing = [s for s in source_ids if self._missing(s)]
        if missing:
            raise KeyError("uncited/unrecorded source ids: "
                           + ", ".join(sorted(set(missing))))

    def _missing(self, s: str) -> bool:
        td = self._td
        return not (s in td.SOURCE_RECORDS
                    or s in getattr(td, "INTERNAL_SOURCE_RECORDS", {})
                    or s in self.literature)

    # -- panel access --------------------------------------------------
    def dids(self):
        return sorted(self.panel)

    def hypotheses_for(self, did: str):
        """Build TargetHypotheses for every (did, target) evidence row.
        One TargetEvidence per evidence KIND keeps the counting functions
        of score_target faithful to the frozen table."""
        if did not in self.panel:
            raise KeyError(f"disease {did} not in the benchmark panel")
        name = self.panel[did]["name"]
        by_symbol = {}
        for row in self.evidence:
            if row["did"] != did:
                continue
            gene = self.genes[row["symbol"]]
            h = by_symbol.setdefault(row["symbol"], TargetHypothesis(name))
            for kind in row["kinds"]:
                h.add(TargetEvidence(
                    target_id=gene["hgnc_id"],
                    target_kind=gene["target_kind"],
                    evidence_kind=kind,
                    source_ids=tuple(row["sources"]),
                    direction=row.get("direction", "unknown"),
                    note=row.get("note", "")))
            h.finalize()
        return by_symbol

    # -- ranking (P3-2) --------------------------------------------------
    def rank_targets(self, did: str, k: int = 10) -> list:
        """Deterministic transparent ranking. Sort key: aggregate desc,
        symbol asc. Every row carries its flags + axes + sources."""
        hyp = self.hypotheses_for(did)
        rows = []
        for symbol, h in hyp.items():
            s = score_target(h)
            rows.append({
                "symbol": symbol,
                "name": self.genes[symbol]["name"],
                "target_kind": self.genes[symbol]["target_kind"],
                "hgnc_id": self.genes[symbol]["hgnc_id"],
                "uniprot": self.genes[symbol]["uniprot"],
                "axes": s["axes"],
                "aggregate": s["aggregate"],
                "aggregate_label": s["aggregate_label"],
                "flags": list(h.flags),
                "kinds": sorted({ev.evidence_kind for ev in h.evidences}),
                "source_ids": sorted({sid for ev in h.evidences
                                      for sid in ev.source_ids}),
                "note": h.evidences[0].note if h.evidences else "",
            })
        rows.sort(key=lambda r: (-r["aggregate"], r["symbol"]))
        for i, r in enumerate(rows, start=1):
            r["rank"] = i
        return rows[:k] if k else rows


# =====================================================================
# P3-3 theorems (standard APEIRON-X theorem shape)
# =====================================================================

def theorem_anti_causal_illusion(rank_report_rows) -> dict:
    """New C-class obligation (plan P3-3): the flag is governed by CITED
    causal evidence only — every ranked target whose evidence kinds
    contain no causal kind (functional_perturbation / causal_variant /
    rescue_experiment) MUST carry ASSOCIATION_NOT_CAUSATION in flags and
    in its aggregate label; targets WITH a cited causal kind must NOT
    carry it (no spurious flags); and every row must EXPOSE its flags.
    Drug-binding/guideline evidence is target-engagement evidence, not
    causality — it never clears the flag. PROVEN_MATH on the encoded
    rank report (machine-check; zero counterexamples <=> proved)."""
    counterexamples = []
    n_flagged = 0
    for row in rank_report_rows:
        kinds = set(row.get("kinds", ()))
        flags = set(row.get("flags", ()))
        has_causal = bool(kinds & _CAUSAL_KINDS)
        association_only = kinds <= {"association"}
        if has_causal:
            n_flagged += 0
            if "ASSOCIATION_NOT_CAUSATION" in flags:
                counterexamples.append(
                    {"symbol": row.get("symbol"), "reason":
                     "cited causal evidence present but flag set "
                     "(over-flagging)"})
        else:
            n_flagged += 1
            if "ASSOCIATION_NOT_CAUSATION" not in flags:
                counterexamples.append(
                    {"symbol": row.get("symbol"), "reason":
                     "no cited causal evidence but flag missing"})
            if "ASSOCIATION_NOT_CAUSATION" not in row.get(
                    "aggregate_label", ""):
                counterexamples.append(
                    {"symbol": row.get("symbol"), "reason":
                     "flag not exposed in aggregate_label"})
        if "flags" not in row:
            counterexamples.append(
                {"symbol": row.get("symbol"), "reason": "flags not exposed"})
    return {
        "theorem": "anti-causal-illusion obligation (Phase 3, P3-3)",
        "statement": "every ranked target without cited causal evidence "
                     "carries ASSOCIATION_NOT_CAUSATION in flags and in "
                     "its aggregate label; targets with cited causal "
                     "evidence never carry the flag; no rank row hides "
                     "its flags",
        "proved": not counterexamples,
        "tier": "PROVEN_MATH",
        "counterexamples": counterexamples,
        "stats": {"rows_checked": len(rank_report_rows),
                  "rows_without_cited_causal_evidence": n_flagged},
        "proof_steps": [
            "for each ranked row: kinds := set of evidence kinds",
            "causal_kinds := {functional_perturbation, causal_variant, "
            "rescue_experiment}",
            "if kinds & causal_kinds is empty: flag must be present in "
            "flags and in aggregate_label; else flag must be absent",
            "every row must expose a flags field (no silent rows)",
            "counterexample list is empty <=> theorem holds",
        ],
    }


def theorem_rank_determinism(table: TargetTable, did: str) -> dict:
    """Ranking integrity: permuting the input evidence order must not
    change the ranked output (pre-view of the P6-2 obligation, already
    binding for Phase 3 reports)."""
    import random
    base = table.rank_targets(did, k=None)
    # shuffle the frozen evidence rows deterministically, re-rank
    saved = list(table.evidence)
    rnd = random.Random(20261125)
    perm = saved[:]
    rnd.shuffle(perm)
    table.evidence = perm
    try:
        shuffled = table.rank_targets(did, k=None)
    finally:
        table.evidence = saved
    same = base == shuffled
    return {
        "theorem": "rank integrity under input permutation (Phase 3)",
        "statement": "rank order is invariant under permutation of the "
                     "input evidence order (deterministic, reproducible)",
        "proved": same,
        "tier": "PROVEN_MATH",
        "counterexamples": [] if same else [{"did": did}],
        "stats": {"rows": len(base)},
        "proof_steps": [
            "rank with the frozen evidence order",
            "shuffle evidence with a fixed seed, rank again",
            "deep equality of the two ranked lists <=> proved",
        ],
    }


# =====================================================================
# Acceptance benchmark (plan §4): top-10 recall on 10 diseases with
# guideline-recognized targets, misses reported honestly.
# =====================================================================

def benchmark(table: TargetTable, k: int = 10) -> dict:
    per, hits_total, targets_total = {}, 0, 0
    for did in table.dids():
        p = table.panel[did]
        ranked = table.rank_targets(did, k=None)
        topk = [r["symbol"] for r in ranked[:k]]
        want = list(p["guideline_targets"])
        hits = [t for t in want if t in topk]
        misses = [t for t in want if t not in topk]
        recall = round(len(hits) / len(want), 4) if want else None
        hits_total += len(hits)
        targets_total += len(want)
        per[did] = {
            "disease": p["name"],
            "guideline": p["guideline"],
            "guideline_targets": want,
            "top_%d" % k: topk,
            "hits": hits,
            "misses": misses,
            "recall_at_%d" % k: recall,
            "ranked_all": ranked,
            "coverage_gaps": list(p.get("coverage_gaps", ())),
            "extra_targets": list(p.get("panel_extra_targets", ())),
            "flags_summary": {
                r["symbol"]: r["flags"] for r in ranked if r["flags"]},
        }
    macro = round(hits_total / targets_total, 4) if targets_total else None
    theorems = []
    for did in table.dids():
        theorems.append(theorem_anti_causal_illusion(per[did]["ranked_all"]))
        theorems.append(theorem_rank_determinism(table, did))
    return {
        "benchmark": "Phase 3 target-discovery acceptance (plan §4)",
        "k": k,
        "panel_diseases": len(table.dids()),
        "guideline_targets_total": targets_total,
        "hits_total": hits_total,
        "macro_recall_at_%d" % k: macro,
        "per_disease": per,
        "theorem_anti_causal_illusion_all_proved":
            all(t["proved"] for t in theorems),
        "rank_determinism_all_proved":
            all(t["proved"] for t in theorems
                if "permutation" in t["theorem"]),
        "schema_version": table.schema_version,
        "frozen_utc": table.frozen_utc,
        "honest_limits": list(table.limits),
    }


def load_targets(verify_pin: bool = True) -> TargetTable:
    """Pin-checked entry point (mirrors v15.vocab.load_vocab)."""
    return TargetTable(verify_pin=verify_pin)
