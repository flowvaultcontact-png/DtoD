#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 4 acceptance artifacts writer.

Runs the temporal repurposing benchmark on the frozen pack and writes
the machine certificate + the human-readable report:

    v15/out/phase4_benchmark.json   — machine-checkable artifact
    v15/out/phase4_benchmark.txt    — readable rank tables + theorems

Fully offline: consumes only the frozen pack (v15/repurposing_data.py,
sha256-pinned), the v14.1 engines (read-only, for the P4-3 bridge), and
never touches the network or the connectors.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # apeiron/ repo root
sys.path.insert(0, ROOT)

from v15.repurposing import load_pack, benchmark_temporal  # noqa: E402

OUT = os.path.join(ROOT, "v15", "out")


def main() -> int:
    pack = load_pack()
    bench = benchmark_temporal(pack, k=10)
    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(OUT, "phase4_benchmark.json"), "w",
              encoding="utf-8") as fh:
        json.dump(bench, fh, indent=1, sort_keys=True)

    lines = []
    A = lines.append
    A("APEIRON-X v15 - PHASE 4 DRUG REPURPOSING - ACCEPTANCE REPORT")
    A("=" * 70)
    A("frozen pack sha256 (pinned): " + pack.pins["repurposing_data_sha256"])
    A("schema version: " + bench["schema_version"] +
      "   frozen_utc: " + bench["frozen_utc"])
    A("")
    A(f"temporal split: pre-{bench['temporal_split_year']} knowledge only "
      f"(molecules by ChEMBL first_approval; channels by cited pre-"
      f"{bench['temporal_split_year']} anchors)")
    A(f"macro recall@{bench['k']} over {bench['truth_pairs_total']} "
      f"post-2015 repurposing outcomes / "
      f"{len(bench['prediction_diseases'])} diseases: "
      f"{bench['macro_recall_at_%d' % bench['k']]}")
    A("P4-2/P4-3/P4-4 theorem results:")
    for tname, proved in bench["theorem_proved"].items():
        A(f"  [{'PROVED' if proved else 'FAILED'}] {tname}")
    A("ALL theorems proved: " + str(bench["theorems_all_proved"]))
    A("")
    for key in sorted(bench["per_disease"]):
        p = bench["per_disease"][key]
        A("-" * 70)
        A(f"{key}  {p['disease']}   (KB encoding: "
          f"{p['kb_did'] or 'none'})")
        A(f"    post-2015 outcomes (ground truth, cited):")
        for t in p["truth_pairs"]:
            A(f"      {t['drug']:<16} {t['evidence_year']}  "
              f"[{t['ot_status']}]")
        A(f"    hits@{bench['k']}: {', '.join(p['hits']) or '-'}   "
          f"misses: {', '.join(p['misses']) or '-'}   "
          f"recall@{bench['k']}: "
          f"{p['recall_at_%d' % bench['k']]}")
        A(f"    separation from zero-support candidates: "
          f"{p['separation_from_zero_support']}")
        A(f"    pre-2015 ranked candidates "
          f"(COMPUTATIONAL_RANK; aggregate is never a probability):")
        for r in p["rows"]:
            flag = ""
            if r["rank_tier"] != "COMPUTATIONAL":
                flag = f" [{r['rank_tier']}]"
            A(f"      #{r['rank']:>2} {r['drug']:<16} "
              f"{r['aggregate']:.4f} {r['support_level']:<8}"
              f"{flag} status={r['status']['status']}")
        if p["false_leads_examined"]:
            A("    false leads examined (top-5 without a post-2015 "
              "outcome row):")
            for fl in p["false_leads_examined"]:
                A(f"      #{fl['rank']:>2} {fl['drug']}")
        for nc in p["negative_controls"]:
            A(f"    negative control: {nc['drug']} (first_approval "
              f"{nc['first_approval']}) correctly ABSENT from the "
              f"pre-2015 candidates")
    A("-" * 70)
    A("THEOREM STATS")
    for tname, st in bench["theorem_stats"].items():
        A(f"  {tname}: {st}")
    A("")
    A("HONEST LIMITS")
    for lim in bench["honest_limits"]:
        A("  * " + lim)
    report = "\n".join(lines) + "\n"
    with open(os.path.join(OUT, "phase4_benchmark.txt"), "w",
              encoding="utf-8") as fh:
        fh.write(report)
    print(report)
    ok = (bench["macro_recall_at_%d" % bench['k']] == 1.0
          and bench["theorems_all_proved"]
          and all(p["separation_from_zero_support"]
                  for p in bench["per_disease"].values()))
    print("wrote v15/out/phase4_benchmark.json and phase4_benchmark.txt")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
