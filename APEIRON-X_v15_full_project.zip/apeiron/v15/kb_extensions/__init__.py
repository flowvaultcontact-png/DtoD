"""APEIRON-X v15 KB growth-pack machinery (P2-3).

A growth pack is a validated DATA module describing new disease rows
(+ optionally new drugs/molecules in later rounds). `apply_pack.py`
implements the V15_AUDIT §5(c) checklist end-to-end:
    validate -> cardinality theorem -> apply edits -> re-freeze
    postulates -> re-pin sha -> update hash snapshots -> full cascade.
"""
