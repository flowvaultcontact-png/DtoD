#!/usr/bin/env python3
"""Freeze the v15 Phase 7 validation dataset registry: pin sha256 of
v15/validation_data.py in v15/kb_extensions/validation_pins.json
(frozen-table doctrine, P7-2).

Run after ANY intentional regeneration of validation_data.py (via
scripts/gen_phase7_pack.py). The pin file carries the authoring
timestamp so re-freezes are auditable (same pattern as
freeze_targets.py / freeze_repurposing.py / freeze_kgraph.py).
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))   # apeiron/ root

VALIDATION_DATA_PATH = os.path.abspath(
    os.path.join(HERE, os.pardir, "validation_data.py"))
VALIDATION_PIN_PATH = os.path.abspath(os.path.join(HERE,
                                                   "validation_pins.json"))


def sha256_of(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    import importlib
    import v15.validation_data as vd
    importlib.reload(vd)
    digest = sha256_of(VALIDATION_DATA_PATH)
    pins = {}
    if os.path.exists(VALIDATION_PIN_PATH):
        with open(VALIDATION_PIN_PATH, encoding="utf-8") as fh:
            pins = json.load(fh)
    history = pins.get("refreeze_history", [])
    if pins.get("validation_data_sha256") and \
            pins["validation_data_sha256"] != digest:
        history.append({"sha256": pins["validation_data_sha256"],
                        "frozen_utc": pins.get("frozen_utc")})
    pins = {
        "validation_data_sha256": digest,
        "pack_schema_version": vd.PACK_SCHEMA_VERSION,
        "generation_utc": vd.FROZEN_UTC,
        "study_count": len(vd.CT_STUDIES_P7),
        "series_count": len(vd.GEO_SERIES_P7),
        "absence_count": len(vd.ABSENCES_P7),
        "source_count": len(vd.SOURCE_RECORDS_P7),
        "frozen_utc": datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"),
        "refreeze_history": history,
    }
    os.makedirs(os.path.dirname(VALIDATION_PIN_PATH), exist_ok=True)
    with open(VALIDATION_PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(pins, fh, indent=1, sort_keys=True)
    print(f"[freeze] validation_data.py sha256 = {digest}")
    print(f"[freeze] pinned in {VALIDATION_PIN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
