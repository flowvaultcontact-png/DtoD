#!/usr/bin/env python3
"""Freeze the v15 Phase 3 target table: pin sha256 of v15/target_data.py
in v15/kb_extensions/targets_pins.json (frozen-table doctrine, P3-1).

Run after ANY intentional edit of target_data.py. The pin file carries
the authoring timestamp so re-freezes are auditable (same pattern as
freeze_vocab.py of Phase 2).
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))   # apeiron/ root

from v15.targets import sha256_of, TARGET_DATA_PATH, TARGET_PIN_PATH  # noqa: E402


def main() -> int:
    digest = sha256_of(TARGET_DATA_PATH)
    pins = {}
    if os.path.exists(TARGET_PIN_PATH):
        with open(TARGET_PIN_PATH, encoding="utf-8") as fh:
            pins = json.load(fh)
    history = pins.get("refreeze_history", [])
    if pins.get("target_data_sha256") and \
            pins["target_data_sha256"] != digest:
        history.append({"sha256": pins["target_data_sha256"],
                        "frozen_utc": pins.get("frozen_utc")})
    import v15.target_data as td
    pins = {
        "target_data_sha256": digest,
        "target_schema_version": td.TARGET_SCHEMA_VERSION,
        "frozen_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "refreeze_history": history,
    }
    os.makedirs(os.path.dirname(TARGET_PIN_PATH), exist_ok=True)
    with open(TARGET_PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(pins, fh, indent=1, sort_keys=True)
    print(f"[freeze] target_data.py sha256 = {digest}")
    print(f"[freeze] pinned in {TARGET_PIN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
