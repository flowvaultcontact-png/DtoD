#!/usr/bin/env python3
"""APEIRON-X v15 — growth-pack applier (P2-3) + cardinality guard (P2-4).

Implements the V15_AUDIT §5(c) checklist end-to-end for a knowledge
pack:

    1. validate_pack()           — schema + cross-checks vs the live KB
    2. theorem_cardinality_guard — P2-4: every vocabulary value the pack
       uses has merged-corpus cardinality >= 2, or its degenerate-
       channel consequence is documented in the pack (audit R10)
    3. apply_edits()             — inserts rows/tuples into the two
       hash-pinned v14.1 data modules (documented re-freeze event)
    4. refreeze()                — rebuilds postulates_v14.json, re-pins
       EXPECTED_POSTULATES_SHA256 in apeiron_correspondence.py, updates
       docs/baseline/frozen_files_sha256_before.txt and writes
       v15/kb_extensions/corpus_pins.json (consumed by the v15 tests)
    5. full cascade re-run       — merge gate; a failing cascade means
       the pack is NOT accepted (engine refuses to certify)

Nothing is edited silently: every mutation prints a diff summary and
leaves an audit trail in corpus_pins.json.

Usage:
    python3 v15/kb_extensions/apply_pack.py --dry-run
    python3 v15/kb_extensions/apply_pack.py --apply [--skip-cascade]
"""

import argparse
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
PKG = os.path.dirname(HERE)                 # apeiron/v15
ROOT = os.path.dirname(PKG)                 # apeiron/
sys.path.insert(0, ROOT)

import disease_drug_kb as KB                # noqa: E402  (read-only pre-apply)
import disease_mechanism_table as MT        # noqa: E402  (read-only pre-apply)
import pack_d64_d68 as PACK                 # noqa: E402
from v15.vocab import Vocabulary            # noqa: E402
from v15.disease_profile import injectivity_report  # noqa: E402

KB_PATH = os.path.join(ROOT, "disease_drug_kb.py")
MT_PATH = os.path.join(ROOT, "disease_mechanism_table.py")
CORR_PATH = os.path.join(ROOT, "apeiron_correspondence.py")
POST_BUILDER = os.path.join(ROOT, "build_postulates.py")
POST_PATH = os.path.join(ROOT, "postulates_v14.json")
SNAPSHOT = os.path.join(ROOT, "docs", "baseline",
                        "frozen_files_sha256_before.txt")
PINS_PATH = os.path.join(HERE, "corpus_pins.json")
REGRESSION = os.path.join(PKG, "run_full_regression.py")

FROZEN = ["disease_drug_kb.py", "drug_structures.py",
          "disease_mechanism_table.py", "postulates_v14.json"]


def sha256_of(path):
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def utcnow():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# =====================================================================
# 1. VALIDATION (§5(c) step i)
# =====================================================================
def _live_counts():
    """Read corpus sizes from a FRESH subprocess so the numbers always
    reflect the CURRENT file state, regardless of how this process got
    here (fresh apply / resumed apply / post-merge test runs)."""
    code = ("import sys; sys.path.insert(0, '.'); "
            "import disease_drug_kb as KB, disease_mechanism_table as MT; "
            "print(len(KB.DISEASES), len(KB.DRUGS), len(MT.MECH_REQUIRED), "
            "len(KB.SYSTEMS))")
    proc = subprocess.run([sys.executable, "-c", code], cwd=ROOT,
                          capture_output=True, text=True, timeout=300)
    if proc.returncode != 0:
        raise RuntimeError("live-count subprocess failed: " + proc.stderr)
    d, g, m, s = (int(x) for x in proc.stdout.split())
    return {"diseases": d, "drugs": g, "mech_profiles": m, "systems": s}


def validate_pack(kb=KB, mt=MT):
    """Returns (problems, checks, mode). mode == 'FRESH' validates the
    pack against a corpus that does NOT yet contain it (the normal
    pre-apply gate). mode == 'APPLIED' validates that the pack is
    byte-consistent with the live corpus (post-merge / idempotence
    check) and a re-apply is refused."""
    problems, checks = [], []

    def ok(name, cond, detail=""):
        checks.append((name, bool(cond), detail))
        if not cond:
            problems.append(f"{name}: {detail}" if detail else name)

    rows = PACK.NEW_DISEASES
    dids = [r["did"] for r in rows]
    existing_dids = {r["did"] for r in kb.DISEASES}
    already_applied = set(dids) <= existing_dids
    mode = "APPLIED" if already_applied else "FRESH"

    ok("pack_id", PACK.PACK_ID.startswith("PACK-"), PACK.PACK_ID)
    if already_applied:
        # -- APPLIED-STATE consistency: live rows must equal pack rows --
        for r in rows:
            live = next((x for x in kb.DISEASES if x["did"] == r["did"]), None)
            equal = live is not None and all(
                live.get(k) == v for k, v in r.items())
            ok(f"applied row {r['did']} matches pack verbatim", equal)
            m_live = mt.MECH_REQUIRED.get(r["did"])
            ok(f"applied mech {r['did']} matches pack verbatim",
               m_live == PACK.NEW_MECH_REQUIRED[r["did"]])
        for ch, values in PACK.NEW_VOCAB_VALUES.items():
            for v, _note in values:
                in_live = any(x[ch] == v for x in kb.DISEASES)
                ok(f"applied value {ch}/{v} present in live corpus", in_live)
    else:
        ok("dids novel + contiguous",
           dids == [f"D{64+i}" for i in range(len(rows))]
           and not (set(dids) & existing_dids), str(dids))

    kb_classes = {c for _a, c in kb.DRUGS.values()}
    for r in rows:
        tag = r["did"]
        for ch in kb.CHANNELS:
            ok(f"{tag}.{ch} non-empty", isinstance(r[ch], str) and r[ch])
        ok(f"{tag}.guideline non-empty", isinstance(r["guideline"], str)
           and len(r["guideline"]) > 20)
        ok(f"{tag}.regimen flag", r.get("regimen") is False, "this pack is "
           "monotherapy-profiled; regimen rows are a later extension")
        names = [d[0] for d in r["drugs"]]
        ok(f"{tag}.tier-1 first + exactly one",
           len(r["drugs"]) >= 1 and r["drugs"][0][1] == 1 and
           sum(1 for d in r["drugs"] if d[1] == 1) == 1, str(names))
        for nm, tier, eff, pen in r["drugs"]:
            ok(f"{tag} drug exists in KB.DRUGS", nm in kb.DRUGS, nm)
            ok(f"{tag}/{nm} tiers/ranges",
               tier in (1, 2) and 1 <= eff <= 10 and 0 <= pen <= 10,
               f"tier={tier} eff={eff} pen={pen}")
        mechs = PACK.NEW_MECH_REQUIRED.get(tag)
        ok(f"{tag}.mech entry present", bool(mechs))
        if mechs:
            ind_classes = [kb.DRUGS[g][1] for g in names]
            ok(f"{tag}.primary mech == first drug class",
               mechs[0] == ind_classes[0], f"{mechs[0]} vs {ind_classes[0]}")
            ok(f"{tag}.mech set == drug class set",
               set(mechs) == set(ind_classes),
               f"{sorted(set(ind_classes) ^ set(mechs))}")
            for c in mechs:
                ok(f"{tag}.mech class exists", c in kb_classes, c)

    # injectivity: FRESH -> merged (existing + pack); APPLIED -> live corpus
    inj = injectivity_report(list(kb.DISEASES) + rows if not already_applied
                             else list(kb.DISEASES))
    ok("merged-corpus phi injectivity", inj["proved"],
       str(inj["counterexamples"]))

    # vocabulary admission contract (P2-4 data side).
    # Base counts: live corpus MINUS the pack rows, so the numbers are
    # identical whether the pack is already applied or not.
    counts = {ch: {} for ch in kb.CHANNELS}
    for r in kb.DISEASES:
        for ch in kb.CHANNELS:
            counts[ch][r[ch]] = counts[ch].get(r[ch], 0) + 1
    for r in rows:
        for ch in kb.CHANNELS:
            counts[ch][r[ch]] = counts[ch].get(r[ch], 0) - 1
    declared = {ch: dict(PACK.NEW_VOCAB_VALUES.get(ch, []))
                for ch in kb.CHANNELS}
    pack_uses = {}
    for r in rows:
        for ch in kb.CHANNELS:
            pack_uses.setdefault(ch, set()).add(r[ch])
    for ch, values in pack_uses.items():
        for v in values:
            merged = counts[ch].get(v, 0) + \
                sum(1 for r in rows if r[ch] == v)
            if v not in declared[ch]:
                # existing value reused by the pack: legal, no note needed
                ok(f"{ch}/{v} declared or pre-existing", v in counts[ch],
                   "pack uses an undeclared NEW value")
            elif merged < 2 and not declared[ch][v]:
                problems.append(
                    f"P2-4: {ch}/{v} merges to cardinality {merged} without "
                    "a documented degenerate-channel consequence")
                checks.append((f"{ch}/{v} degenerate note", False, "missing"))
    for ch, vd in declared.items():
        for v, note in vd.items():
            if v in counts[ch] and counts[ch][v] > 0 and not already_applied:
                problems.append(f"{ch}/{v} declared as NEW but already in KB")
            merged = sum(1 for r in rows if r[ch] == v)
            if merged >= 2 and note:
                pass                    # documented + non-degenerate: fine
            if merged < 2 and not note:
                problems.append(f"{ch}/{v} cardinality 1 without note")
            checks.append((f"{ch}/{v} declared, merged cardinality "
                           f"{merged + max(counts[ch].get(v, 0), 0)}", True,
                           note[:60]))

    # ontology anchors resolve in the FROZEN vocab (pin-checked loader)
    try:
        vocab = Vocabulary()
        for did, mondo in PACK.ONTOLOGY_LINKS.items():
            name, rec = vocab.disease_by_mondo(mondo)
            ok(f"{did} MONDO anchor", rec is not None and
               rec.get("kb_link") == did, f"{mondo} -> {name}")
        for did, mondo in PACK.ONTOLOGY_LINKS.items():
            _n, rec = vocab.disease_by_mondo(mondo)
            if rec:
                ok(f"{did} anchor sources recorded", all(
                    s in vocab.sources for s in rec["sources"]))
    except Exception as exc:                     # noqa: BLE001 — gate reporting
        problems.append(f"vocab unavailable: {exc}")
        checks.append(("vocab pin/load", False, repr(exc)))

    # provenance records complete
    for sid, rec in PACK.SOURCE_RECORDS.items():
        for f in ("resource", "resource_version", "retrieval_utc", "url",
                  "license", "evidence_type", "confidence"):
            ok(f"{sid}.{f}", bool(rec.get(f)))

    return problems, checks, mode


# =====================================================================
# 2. P2-4 CARDINALITY GUARD THEOREM (standard theorem shape)
# =====================================================================
def theorem_cardinality_guard(kb=KB):
    """Every vocabulary value used by the pack has merged-corpus
    cardinality >= 2, or the pack documents the degenerate-channel
    consequence. Machine-checked counting on the merged corpus
    (base = live corpus minus the pack rows, so the verdict is the
    same pre-merge and post-merge)."""
    rows = PACK.NEW_DISEASES
    notes = {ch: dict(PACK.NEW_VOCAB_VALUES.get(ch, []))
             for ch in kb.CHANNELS}
    counter, stats_rows, n_ge2, n_doc = [], [], 0, 0
    for ch in kb.CHANNELS:
        base = {}
        for r in kb.DISEASES:
            base[r[ch]] = base.get(r[ch], 0) + 1
        for r in rows:                     # normalise out the pack itself
            base[r[ch]] = base.get(r[ch], 0) - 1
        for v in sorted({r[ch] for r in rows}):
            merged = max(base.get(v, 0), 0) + sum(1 for r in rows if r[ch] == v)
            if merged >= 2:
                n_ge2 += 1
                stats_rows.append((ch, v, merged, "non-degenerate"))
            elif notes[ch].get(v):
                n_doc += 1
                stats_rows.append((ch, v, merged, "documented-degenerate"))
            else:
                counter.append((ch, v, merged, "cardinality 1, undocumented"))
    return {
        "theorem": "T5 (v15) — knowledge-pack cardinality guard",
        "statement": "every channel value a knowledge pack uses has "
                     "merged-corpus cardinality >= 2, or the pack documents "
                     "the degenerate-channel consequence (audit R10); "
                     "nothing enters the corpus silently degenerate",
        "proved": not counter,
        "tier": "PROVEN_MATH",
        "counterexamples": counter,
        "stats": {
            "values_used": len(stats_rows) + len(counter),
            "cardinality_ge2": n_ge2,
            "degenerate_documented": n_doc,
            "detail": stats_rows,
        },
        "proof_steps": [
            "count value occurrences in the frozen corpus per channel",
            "add pack rows; recompute merged counts",
            "merged >= 2 -> non-degenerate: pass",
            "merged == 1 -> require a non-empty consequence note in "
            "NEW_VOCAB_VALUES; anything else is a counterexample",
        ],
    }


# =====================================================================
# 3. APPLY EDITS (§5(c) step ii — documented re-freeze event)
# =====================================================================
def _insert_once(text, anchor, addition, what):
    if text.count(anchor) != 1:
        raise RuntimeError(f"anchor not unique for {what}: "
                           f"{text.count(anchor)} occurrences")
    return text.replace(anchor, anchor + addition, 1)


def _insert_before_tail(text, tail, addition, what):
    """Insert `addition` immediately before the closing bracket that ends
    `tail` (tail is a unique substring ending in '\\n)' / '\\n]' / '\\n}')."""
    if text.count(tail) != 1:
        raise RuntimeError(f"tail not unique for {what}: "
                           f"{text.count(tail)} occurrences")
    head = tail[:-2] + "\n"                    # everything up to the newline
    closing = tail[-1]                          # ')' or ']' or '}'
    return text.replace(tail, head + addition.rstrip("\n") + "\n" + closing, 1)


def apply_edits():
    sys_new = [v for v, _ in PACK.NEW_VOCAB_VALUES.get("system", [])]
    ety_new = [v for v, _ in PACK.NEW_VOCAB_VALUES.get("etiology", [])]
    mic_new = [v for v, _ in PACK.NEW_VOCAB_VALUES.get("microbe", [])]
    sit_new = [v for v, _ in PACK.NEW_VOCAB_VALUES.get("site", [])]

    def tuple_addition(values):
        if not values:
            return ""
        out = ""
        for i in range(0, len(values), 4):
            chunk = ", ".join(f'"{v}"' for v in values[i:i + 4])
            out += f"    {chunk},\n"
        return out

    kb_text = open(KB_PATH, encoding="utf-8").read()

    # vocabulary tuple extensions: anchor on the unique last VALUE of each
    # tuple followed by the closing paren (whitespace-agnostic in front)
    for what, last_value, values in (
            ("SYSTEMS", '"UROLOGIC"', sys_new),
            ("ETIOLOGIES", '"FUNCTIONAL_DYSREGULATION"', ety_new),
            ("MICROBES", '"MIXED_RESPIRATORY_TYPICAL_ATYPICAL"', mic_new),
            ("SITES", '"MEDULLARY_VOMITING_CENTER"', sit_new)):
        if values:
            kb_text = _insert_before_tail(
                kb_text, f"{last_value},\n)", tuple_addition(values), what)

    # DISEASES rows: insert before the closing bracket of the list.
    # The list ends with the D63 row:  ... 2, 7, 2)]),\n]
    tail = ']),\n]'
    row_addition = "".join(
        f'    dict(did="{r["did"]}", name="{r["name"]}",\n'
        f'         system="{r["system"]}", etiology="{r["etiology"]}",\n'
        f'         microbe="{r["microbe"]}", site="{r["site"]}", '
        f'chronicity="{r["chronicity"]}",\n'
        f'         pathway="{r["pathway"]}", regimen={r["regimen"]},\n'
        f'         guideline="{r["guideline"]}",\n'
        f'         drugs=[' + ", ".join(f'("{d}", {t}, {e}, {p})'
                                        for d, t, e, p in r["drugs"]) +
        ']),\n'
        for r in PACK.NEW_DISEASES)
    kb_text = _insert_before_tail(kb_text, tail, row_addition,
                                  "DISEASES rows")
    with open(KB_PATH, "w", encoding="utf-8") as fh:
        fh.write(kb_text)
    print(f"[apply] {os.path.basename(KB_PATH)}: +{len(sys_new)} systems, "
          f"+{len(ety_new)} etiologies, +{len(mic_new)} microbes, "
          f"+{len(sit_new)} sites, +{len(PACK.NEW_DISEASES)} disease rows")

    # --- MECH_REQUIRED: insert before the closing brace of the dict ---
    mt_text = open(MT_PATH, encoding="utf-8").read()
    mech_addition = "".join(
        f'    "{did}": [' +
        ", ".join(f'"{c}"' for c in PACK.NEW_MECH_REQUIRED[did]) +
        '],\n'
        for did in sorted(PACK.NEW_MECH_REQUIRED))
    mt_text = _insert_before_tail(mt_text, '"D63": ["CCB_DHP", '
                                  '"NITRATE_NO_DONOR"],\n}',
                                  mech_addition, "MECH_REQUIRED entries")
    with open(MT_PATH, "w", encoding="utf-8") as fh:
        fh.write(mt_text)
    print(f"[apply] {os.path.basename(MT_PATH)}: "
          f"+{len(PACK.NEW_MECH_REQUIRED)} mechanism entries")


def verify_post_apply():
    """Fresh-subprocess structural validation of the edited modules:
    sizes must grow by exactly the pack, and BOTH self-validations of
    the frozen modules must pass."""
    pre = _live_counts_minus_pack()
    code = (
        "import sys; sys.path.insert(0, '.')\n"
        "import disease_drug_kb as KB, disease_mechanism_table as MT\n"
        f"assert len(KB.DISEASES) == {pre['diseases'] + len(PACK.NEW_DISEASES)}\n"
        "p1 = KB.validate_kb(); assert not p1, p1\n"
        f"assert len(MT.MECH_REQUIRED) == {pre['mech_profiles'] + len(PACK.NEW_MECH_REQUIRED)}\n"
        "p2 = MT.validate_mech_table(); assert not p2, p2\n"
        "print('post-apply structural validation OK:', len(KB.DISEASES), "
        "'diseases,', len(KB.DRUGS), 'drugs,', len(MT.MECH_REQUIRED), "
        "'mech profiles')\n"
    )
    proc = subprocess.run([sys.executable, "-c", code], cwd=ROOT,
                          capture_output=True, text=True, timeout=300)
    print(proc.stdout.strip())
    if proc.returncode != 0:
        print(proc.stderr.strip())
        raise RuntimeError("post-apply structural validation FAILED")


def _live_counts_minus_pack():
    """Pre-merge counts, valid whether the pack is already applied or not."""
    live = _live_counts()
    return {"diseases": live["diseases"] - len(PACK.NEW_DISEASES),
            "mech_profiles": live["mech_profiles"]
                             - len(PACK.NEW_MECH_REQUIRED),
            "drugs": live["drugs"],
            "systems": live["systems"]
                       - len(PACK.NEW_VOCAB_VALUES.get("system", []))}


# =====================================================================
# 4. RE-FREEZE + RE-PIN (§5(c) steps iii-iv)
# =====================================================================
def refreeze():
    print("[refreeze] rebuilding postulates_v14.json ...")
    proc = subprocess.run([sys.executable, POST_BUILDER], cwd=ROOT,
                          capture_output=True, text=True, timeout=1800)
    print("\n".join((proc.stdout or "").strip().splitlines()[-6:]))
    if proc.returncode != 0:
        print((proc.stderr or "")[-2000:])
        raise RuntimeError("build_postulates FAILED — pack must be rolled "
                           "back (git checkout of the two data files)")
    sha_new = None
    for line in (proc.stdout or "").splitlines():
        if line.startswith("POSTULATES_SHA256 = "):
            sha_new = line.split("= ", 1)[1].strip()
    if not sha_new:
        raise RuntimeError("could not parse POSTULATES_SHA256")
    print(f"[refreeze] new postulates sha256 = {sha_new}")

    corr = open(CORR_PATH, encoding="utf-8").read()
    needle = 'EXPECTED_POSTULATES_SHA256 = "'
    n = corr.count(needle)
    if n != 1:
        raise RuntimeError(f"postulates pin anchor count = {n}, expected 1")
    start = corr.index(needle) + len(needle)
    end = corr.index('"', start)
    old_sha = corr[start:end]
    corr = corr[:start] + sha_new + corr[end:]
    with open(CORR_PATH, "w", encoding="utf-8") as fh:
        fh.write(corr)
    print(f"[refreeze] re-pinned apeiron_correspondence.py: "
          f"{old_sha[:12]}... -> {sha_new[:12]}...")

    # update the baseline hash snapshot (documented re-freeze)
    lines = []
    for name in FROZEN:
        lines.append(f"{sha256_of(os.path.join(ROOT, name))}  {name}")
    with open(SNAPSHOT, "w", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"[refreeze] hash snapshot updated: {os.path.relpath(SNAPSHOT, ROOT)}")

    # corpus pins consumed by the v15 tests (counts read from the CURRENT
    # file state via a fresh subprocess, never from in-memory imports)
    pins = {
        "pack_id": PACK.PACK_ID,
        "applied_utc": utcnow(),
        "expected": _live_counts(),
        "sha256": {name: sha256_of(os.path.join(ROOT, name))
                   for name in FROZEN},
    }
    with open(PINS_PATH, "w", encoding="utf-8") as fh:
        json.dump(pins, fh, indent=1, sort_keys=True)
    print(f"[refreeze] corpus pins written: {os.path.relpath(PINS_PATH, ROOT)}")
    return sha_new


# =====================================================================
# 5. CASCADE (§5(c) step v — merge gate)
# =====================================================================
def run_cascade():
    print("\n[cascade] running the FULL v14.1 regression + v15 tests ...")
    proc = subprocess.run([sys.executable, REGRESSION], cwd=ROOT,
                          text=True, timeout=3600)
    return proc.returncode


# =====================================================================
# MAIN
# =====================================================================
def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true",
                    help="validate + theorem only; no mutation")
    ap.add_argument("--apply", action="store_true",
                    help="apply the pack end-to-end (§5(c) checklist)")
    ap.add_argument("--resume-from-refreeze", action="store_true",
                    help="edits already applied + structurally validated "
                         "in an interrupted run; execute ONLY refreeze + "
                         "re-pin + cascade (never re-insert rows)")
    ap.add_argument("--skip-cascade", action="store_true",
                    help="(debug only) skip the regression merge gate")
    args = ap.parse_args()
    if not (args.dry_run or args.apply or args.resume_from_refreeze):
        ap.error("choose --dry-run, --apply or --resume-from-refreeze")

    print("=" * 74)
    print(f"APEIRON-X v15 growth-pack applier — {PACK.PACK_ID}")
    print("=" * 74)

    if args.resume_from_refreeze:
        print("[resume] edits were applied + structurally validated in the "
              "interrupted run; validation/theorem/edits are skipped "
              "(they would double-count against the mutated corpus). "
              "Recovery path, not a normal route.")
        refreeze()
        if args.skip_cascade:
            print("\n[resume] --skip-cascade: MERGE GATE NOT RUN (debug only)")
            return 0
        code = run_cascade()
        if code != 0:
            print("\nVERDICT: cascade FAILED — pack NOT accepted; roll "
                  "back with git checkout.")
            return code
        print("\nVERDICT: PACK APPLIED AND CERTIFIED (full cascade exit 0).")
        return 0

    problems, checks, mode = validate_pack()
    print(f"pack mode: {mode}")
    if mode == "APPLIED" and args.apply:
        print("\nVERDICT: pack already applied to the live corpus; "
              "refusing a double-apply. Use --dry-run to verify applied "
              "state, or git to inspect history.")
        return 1
    for name, okk, detail in checks:
        print(f"[{'OK ' if okk else 'FAIL'}] {name}" +
              (f" — {detail}" if detail and not okk else ""))
    n_bad = sum(1 for _n, okk, _d in checks if not okk)
    print(f"\nvalidation: {len(checks) - n_bad}/{len(checks)} checks passed")

    thm = theorem_cardinality_guard()
    print(f"\nT5 cardinality guard: proved={thm['proved']} "
          f"(>=2: {thm['stats']['cardinality_ge2']}, documented-"
          f"degenerate: {thm['stats']['degenerate_documented']}, "
          f"counterexamples: {len(thm['counterexamples'])})")
    for ch, v, m, kind in thm["stats"]["detail"]:
        print(f"    {ch:<10} {v:<38} merged={m}  {kind}")
    for cx in thm["counterexamples"]:
        print(f"    COUNTEREXAMPLE: {cx}")

    if problems or not thm["proved"]:
        print("\nVERDICT: PACK REFUSED — fix the pack data, never the gate.")
        return 1

    if args.dry_run:
        print("\nVERDICT: PACK VALID (dry run, nothing mutated). "
              "Re-run with --apply to execute the §5(c) checklist.")
        return 0

    print("\n[apply] mutating the two hash-pinned data modules "
          "(documented re-freeze event) ...")
    apply_edits()
    verify_post_apply()
    refreeze()
    if args.skip_cascade:
        print("\n[apply] --skip-cascade: MERGE GATE NOT RUN (debug only)")
        return 0
    code = run_cascade()
    if code != 0:
        print("\nVERDICT: cascade FAILED after apply — the pack is NOT "
              "accepted. Roll back: git checkout -- disease_drug_kb.py "
              "disease_mechanism_table.py apeiron_correspondence.py "
              "docs/baseline/frozen_files_sha256_before.txt postulates_v14.json")
        return code
    print("\nVERDICT: PACK APPLIED AND CERTIFIED (full cascade exit 0).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
