#!/usr/bin/env python3
"""Freeze the v15 Phase 4 repurposing pack: pin sha256 of
v15/repurposing_data.py in v15/kb_extensions/repurposing_pins.json
(frozen-table doctrine, P4).

Run after ANY intentional edit of repurposing_data.py (regenerate it via
scripts/gen_phase4_pack.py, never hand-edit). Same pattern as
freeze_targets.py / freeze_vocab.py.
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))   # apeiron/ root

from v15.repurposing import sha256_of, PACK_DATA_PATH, PACK_PIN_PATH  # noqa: E402


def main() -> int:
    digest = sha256_of(PACK_DATA_PATH)
    pins = {}
    if os.path.exists(PACK_PIN_PATH):
        with open(PACK_PIN_PATH, encoding="utf-8") as fh:
            pins = json.load(fh)
    history = pins.get("refreeze_history", [])
    if pins.get("repurposing_data_sha256") and \
            pins["repurposing_data_sha256"] != digest:
        history.append({"sha256": pins["repurposing_data_sha256"],
                        "frozen_utc": pins.get("frozen_utc")})
    import v15.repurposing_data as rd
    pins = {
        "repurposing_data_sha256": digest,
        "pack_schema_version": rd.PACK_SCHEMA_VERSION,
        "frozen_utc": datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"),
        "refreeze_history": history,
    }
    os.makedirs(os.path.dirname(PACK_PIN_PATH), exist_ok=True)
    with open(PACK_PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(pins, fh, indent=1, sort_keys=True)
    print(f"[freeze] repurposing_data.py sha256 = {digest}")
    print(f"[freeze] pinned in {PACK_PIN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
