# =====================================================================
# APEIRON-X v15 — GROWTH PACK: PACK-2026-11-24-D64-D68 (P2-3, Module A)
# ---------------------------------------------------------------------
# First knowledge growth pack: 5 new diseases spanning 5 NEW organ
# systems (dermatologic, otolaryngologic, gynecologic, oral/dental,
# obstetric), D64-D68. The pack introduces NO new drug, NO new
# mechanism class and NO new molecule: every listed drug already
# exists in the hash-pinned KB.DRUGS table, so the structure layer
# (L_c / L_G laws, SIBLINGS doctrine) is untouched by construction.
#
# Every row is guideline-anchored; every anchor was content-verified at
# pack-authoring time (see SOURCE_RECORDS). Ontology ids were
# machine-verified against the EBI OLS4 API (see v15.vocab_data and
# scripts/verify_vocab_ols.py + its JSON report).
#
# Applied ONLY by v15/kb_extensions/apply_pack.py, which validates the
# pack, proves the P2-4 cardinality theorem, performs the §5(c)
# checklist (re-freeze postulates, re-pin sha256, update snapshots)
# and re-runs the full v14.1 cascade as the merge gate.
# =====================================================================

PACK_ID = "PACK-2026-11-24-D64-D68"
PACK_UTC = "2026-11-24T00:00:00Z"

# ---------------------------------------------------------------------
# Guideline source records (content-verified at authoring time).
# NICE pages return HTTP 403 to non-browser agents; their existence and
# content were verified via search snapshots on PACK_UTC (recorded in
# `limitations`), not guessed.
# ---------------------------------------------------------------------
SOURCE_RECORDS = {
    "SRC:NICE_CKS_IMPETIGO": {
        "resource": "NICE Clinical Knowledge Summaries — Impetigo",
        "resource_version": "CKS topic, snapshot " + PACK_UTC,
        "retrieval_utc": PACK_UTC,
        "url": "https://cks.nice.org.uk/topics/impetigo",
        "license": "SEE_TERMS (NICE CKS; public guidance content)",
        "evidence_type": "guideline",
        "confidence": "content_verified_via_search_snapshot",
        "limitations": "site returns HTTP 403 to non-browser agents; topic "
                       "slug and prescribing content (flucloxacillin 500 mg "
                       "QDS 5 days first-line; clarithromycin if unsuitable) "
                       "verified via search-result snapshots",
    },
    "SRC:NICE_CKS_AOM": {
        "resource": "NICE Clinical Knowledge Summaries — Otitis media (acute)",
        "resource_version": "CKS topic, snapshot " + PACK_UTC,
        "retrieval_utc": PACK_UTC,
        "url": "https://cks.nice.org.uk/topics/otitis-media-acute",
        "license": "SEE_TERMS (NICE CKS; public guidance content)",
        "evidence_type": "guideline",
        "confidence": "content_verified_via_search_snapshot",
        "limitations": "site returns HTTP 403 to non-browser agents; slug and "
                       "content (amoxicillin 5-7 days first-line when an "
                       "antibiotic is required; clarithromycin/erythromycin "
                       "if penicillin-allergic) verified via search snapshots",
    },
    "SRC:CDC_STI_BV": {
        "resource": "CDC STI Treatment Guidelines 2021 — Bacterial Vaginosis",
        "resource_version": "2021 guidelines (page dated Jul 22, 2021)",
        "retrieval_utc": PACK_UTC,
        "url": "https://www.cdc.gov/std/treatment-guidelines/bv.htm",
        "license": "public domain (US federal guidance)",
        "evidence_type": "guideline",
        "confidence": "content_verified_http200",
        "limitations": "",
    },
    "SRC:NICE_CKS_DENTAL_ABSCESS": {
        "resource": "NICE Clinical Knowledge Summaries — Dental abscess",
        "resource_version": "CKS topic, snapshot " + PACK_UTC,
        "retrieval_utc": PACK_UTC,
        "url": "https://cks.nice.org.uk/topics/dental-abscess",
        "license": "SEE_TERMS (NICE CKS; public guidance content)",
        "evidence_type": "guideline",
        "confidence": "content_verified_via_search_snapshot",
        "limitations": "site returns HTTP 403 to non-browser agents; slug and "
                       "content (amoxicillin or phenoxymethylpenicillin "
                       "first-line; metronidazole or macrolide for true "
                       "penicillin allergy; source control essential) "
                       "verified via search snapshots",
    },
    "SRC:NICE_NG133": {
        "resource": "NICE guideline NG133 — Hypertension in pregnancy: "
                    "diagnosis and management (pre-eclampsia prevention)",
        "resource_version": "published 2019-06-25, last updated 2023-04-17",
        "retrieval_utc": PACK_UTC,
        "url": "https://www.nice.org.uk/guidance/ng133/chapter/recommendations",
        "license": "SEE_TERMS (NICE; public guidance content)",
        "evidence_type": "guideline",
        "confidence": "content_verified_http403_note_full_text_via_search",
        "limitations": "recommendation 1.1.2 (aspirin 75-150 mg daily from "
                       "12 weeks for women at high risk of pre-eclampsia) "
                       "verified verbatim via search snapshot; direct fetch "
                       "returns HTTP 403 to non-browser agents",
    },
    "SRC:OLS_MONDO": {
        "resource": "Mondo Disease Ontology via EBI OLS4 API (identifier "
                    "records for D64-D68)",
        "resource_version": "MONDO release 2026-11-03",
        "retrieval_utc": PACK_UTC,
        "url": "https://www.ebi.ac.uk/ols4/api/ontologies/mondo/terms",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_verified_label_and_xrefs",
        "limitations": "see v15/vocab_data.py SOURCE_RECORDS for the full "
                       "identifier provenance; verification report at "
                       "scripts/ols_verification_report.json",
    },
}

# MONDO anchors (machine-verified; must resolve in v15.vocab_data)
ONTOLOGY_LINKS = {
    "D64": "MONDO:0004592",   # impetigo
    "D65": "MONDO:0001031",   # purulent acute otitis media
    "D66": "MONDO:0005316",   # bacterial vaginosis
    "D67": "MONDO:0006989",   # suppurative periapical periodontitis
    "D68": "MONDO:0005081",   # preeclampsia (prophylaxis indication)
}

# ---------------------------------------------------------------------
# New disease rows (exact dict() format of disease_drug_kb.DISEASES).
# Drugs: (name, tier, efficacy 1-10, safety_penalty 0-10) — tier 1 =
# guideline first-line core; tier 2 = accepted guideline alternatives.
# ---------------------------------------------------------------------
NEW_DISEASES = [
    dict(did="D64", name="Impetigo (widespread non-bullous/bullous)",
         system="DERMATOLOGIC", etiology="BACTERIAL",
         microbe="GRAM_POS_COCCI", site="SKIN_SOFT_TISSUE", chronicity="ACUTE",
         pathway="PW_IMPETIGO_EPIDERMAL_INFECTION", regimen=False,
         guideline="NICE CKS impetigo: oral flucloxacillin first-line for "
                   "widespread non-bullous or bullous impetigo (Staph "
                   "aureus/Strep pyogenes); clarithromycin if penicillin-"
                   "allergic or flucloxacillin unsuitable; topical "
                   "therapy reserved for localized disease",
         drugs=[("flucloxacillin", 1, 9, 2), ("clarithromycin", 2, 8, 2)]),
    dict(did="D65", name="Acute otitis media (bacterial, antibiotic indicated)",
         system="OTOLARYNGOLOGIC", etiology="BACTERIAL",
         microbe="GRAM_POS_COCCI", site="MIDDLE_EAR_TYMPANIC_CAVITY",
         chronicity="ACUTE", pathway="PW_MIDDLE_EAR_SUPPURATION",
         regimen=False,
         guideline="NICE CKS acute otitis media: 5-7 day amoxicillin "
                   "first-line when an antibiotic is required (S. pneumoniae "
                   "most common bacterial cause); clarithromycin or "
                   "erythromycin if penicillin-allergic; delayed/no "
                   "antibiotic strategy for mild cases",
         drugs=[("amoxicillin", 1, 8, 2), ("clarithromycin", 2, 7, 2)]),
    dict(did="D66", name="Bacterial vaginosis (symptomatic)",
         system="GYNECOLOGIC", etiology="BACTERIAL",
         microbe="ANAEROBE_MIXED_OVERGROWTH", site="VAGINAL_MUCOSA",
         chronicity="ACUTE", pathway="PW_VAGINAL_MICROBIOME_DYSBIOSIS",
         regimen=False,
         guideline="CDC STI treatment guidelines 2021: oral metronidazole "
                   "500 mg twice daily 7 days first-line; intravaginal "
                   "clindamycin cream 2% (or metronidazole gel) an "
                   "accepted alternative regimen",
         drugs=[("metronidazole", 1, 8, 3), ("clindamycin", 2, 7, 3)]),
    dict(did="D67", name="Dentoalveolar (periapical) abscess with systemic involvement",
         system="ORAL_DENTAL", etiology="BACTERIAL",
         microbe="ANAEROBE_MIXED_OVERGROWTH", site="ORAL_CAVITY_JAW",
         chronicity="ACUTE", pathway="PW_DENTOALVEOLAR_INFECTION",
         regimen=False,
         guideline="NICE CKS dental abscess: amoxicillin or "
                   "phenoxymethylpenicillin first-line when systemically "
                   "unwell (polymicrobial anaerobic odontogenic infection); "
                   "metronidazole or a macrolide for true penicillin "
                   "allergy; surgical source control (drainage/root "
                   "treatment) is essential alongside antibiotics",
         drugs=[("amoxicillin", 1, 8, 2), ("phenoxymethylpenicillin", 2, 8, 2),
                ("metronidazole", 2, 7, 3)]),
    dict(did="D68", name="Pre-eclampsia prophylaxis (high-risk pregnancy)",
         system="OBSTETRIC", etiology="PLACENTAL_VASCULAR_DYSFUNCTION",
         microbe="NONE", site="UTEROPLACENTAL_UNIT", chronicity="CHRONIC",
         pathway="PW_PLATELET_AGGREGATION", regimen=False,
         guideline="NICE NG133 rec 1.1.2: low-dose aspirin 75-150 mg daily "
                   "from 12 weeks until birth for women at high risk of "
                   "pre-eclampsia (antiplatelet prophylaxis; effect is "
                   "partial risk reduction, hence moderate efficacy); "
                   "prescription-only for this indication",
         drugs=[("aspirin", 1, 5, 2)]),
]

# Mechanism-required bridge (exact format of disease_mechanism_table).
# Cross-check binding: set(mechs) == set(drug classes of the row);
# mechs[0] == class of the first (tier-1) drug.
NEW_MECH_REQUIRED = {
    "D64": ["BETA_LACTAM_CELLWALL", "MACROLIDE_RIBOSOMAL_50S"],
    "D65": ["BETA_LACTAM_CELLWALL", "MACROLIDE_RIBOSOMAL_50S"],
    "D66": ["NITROIMIDAZOLE_DNA_DAMAGE", "LINCOSAMIDE_RIBOSOMAL_50S"],
    "D67": ["BETA_LACTAM_CELLWALL", "NITROIMIDAZOLE_DNA_DAMAGE"],
    "D68": ["COX1_PLATELET_INHIBITOR"],
}

# ---------------------------------------------------------------------
# New vocabulary VALUES this pack introduces (P2-4 admission contract).
# For each value: the documented degenerate-channel consequence (audit
# R10). A value with merged-corpus cardinality >= 2 may carry an empty
# consequence note (""); the theorem then passes it as non-degenerate.
# ---------------------------------------------------------------------
NEW_VOCAB_VALUES = {
    "system": [
        ("DERMATOLOGIC", "cardinality 1: no other KB row shares this "
         "system; disease identity rests on system-anchored depth-2 "
         "conjunctions (system + etiology/site), which remain valid; "
         "the value cannot anchor a SHARED class-law generalization "
         "across diseases"),
        ("OTOLARYNGOLOGIC", "cardinality 1: as DERMATOLOGIC"),
        ("GYNECOLOGIC", "cardinality 1: as DERMATOLOGIC"),
        ("ORAL_DENTAL", "cardinality 1: as DERMATOLOGIC"),
        ("OBSTETRIC", "cardinality 1: as DERMATOLOGIC"),
    ],
    "etiology": [
        ("PLACENTAL_VASCULAR_DYSFUNCTION", "cardinality 1: unique to D68; "
         "identity anchored by (system AND etiology) depth-2; cannot "
         "support cross-disease etiology generalization until another "
         "placental-vascular row joins the corpus"),
    ],
    "microbe": [
        ("ANAEROBE_MIXED_OVERGROWTH", ""),   # merges to cardinality 2 (D66+D67)
    ],
    "site": [
        ("MIDDLE_EAR_TYMPANIC_CAVITY", "cardinality 1: unique to D65"),
        ("VAGINAL_MUCOSA", "cardinality 1: unique to D66"),
        ("ORAL_CAVITY_JAW", "cardinality 1: unique to D67"),
        ("UTEROPLACENTAL_UNIT", "cardinality 1: unique to D68"),
    ],
    "chronicity": [],
    "pathway": [
        ("PW_IMPETIGO_EPIDERMAL_INFECTION", "cardinality 1: unique to D64"),
        ("PW_MIDDLE_EAR_SUPPURATION", "cardinality 1: unique to D65"),
        ("PW_VAGINAL_MICROBIOME_DYSBIOSIS", "cardinality 1: unique to D66"),
        ("PW_DENTOALVEOLAR_INFECTION", "cardinality 1: unique to D67"),
        # PW_PLATELET_AGGREGATION: EXISTING value, merges to cardinality 2
        # (D06 acute coronary antiplatelet + D68 prophylaxis) — the pack
        # deliberately STRENGTHENS an existing pathway anchor instead of
        # minting a new degenerate one, because the antiplatelet pathway
        # is biologically the same in both indications.
    ],
}

# What the pack intentionally does NOT contain (honest scope statement):
SCOPE_NOTES = (
    "This pack adds no drug, no molecule, no structure entry, no "
    "sibling pair and no new mechanism class: every listed drug exists "
    "in KB.DRUGS with a verified structure law, so the chemical layer "
    "is unchanged by construction. Held-out pair lists (HELD_OUT_POSITIVE/"
    "HELD_OUT_NEGATIVE) are untouched. The C0 KB_MODULES sentinel of the "
    "v14.1 correspondence core is untouched: v15 vocab/pack modules are "
    "consumed only by v15 code and never imported at derivation time."
)
