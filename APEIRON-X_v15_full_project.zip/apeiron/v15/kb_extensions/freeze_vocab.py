#!/usr/bin/env python3
"""Freeze the v15 vocabulary: pin sha256 of v15/vocab_data.py in
v15/kb_extensions/vocab_pins.json (frozen-table doctrine, P2-1).

Run after ANY intentional edit of vocab_data.py. The pin file carries
the authoring timestamp so re-freezes are auditable.
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))   # apeiron/ root

from v15.vocab import sha256_of, DATA_PATH, PIN_PATH   # noqa: E402


def main() -> int:
    digest = sha256_of(DATA_PATH)
    pins = {}
    if os.path.exists(PIN_PATH):
        with open(PIN_PATH, encoding="utf-8") as fh:
            pins = json.load(fh)
    history = pins.get("refreeze_history", [])
    if pins.get("vocab_data_sha256") and pins["vocab_data_sha256"] != digest:
        history.append({"sha256": pins["vocab_data_sha256"],
                        "frozen_utc": pins.get("frozen_utc")})
    pins = {
        "vocab_data_sha256": digest,
        "vocab_schema_version": "15.2.0",
        "frozen_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "refreeze_history": history,
    }
    os.makedirs(os.path.dirname(PIN_PATH), exist_ok=True)
    with open(PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(pins, fh, indent=1, sort_keys=True)
    print(f"[freeze] vocab_data.py sha256 = {digest}")
    print(f"[freeze] pinned in {PIN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
