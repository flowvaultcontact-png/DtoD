#!/usr/bin/env python3
"""Freeze the v15 Phase 6 knowledge graph: pin sha256 of v15/kgraph_data.py
in v15/kb_extensions/kgraph_pins.json (frozen-table doctrine, P6-1).

Run after ANY intentional regeneration of kgraph_data.py (via
scripts/gen_phase6_pack.py). The pin file carries the authoring
timestamp so re-freezes are auditable (same pattern as
freeze_targets.py / freeze_repurposing.py).
"""
import json
import os
import sys
from datetime import datetime, timezone

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(os.path.dirname(HERE)))   # apeiron/ root

from v15.kgraph import sha256_of, KGRAPH_DATA_PATH, KGRAPH_PIN_PATH  # noqa: E402


def main() -> int:
    import importlib
    import v15.kgraph_data as kd
    importlib.reload(kd)
    digest = sha256_of(KGRAPH_DATA_PATH)
    pins = {}
    if os.path.exists(KGRAPH_PIN_PATH):
        with open(KGRAPH_PIN_PATH, encoding="utf-8") as fh:
            pins = json.load(fh)
    history = pins.get("refreeze_history", [])
    if pins.get("kgraph_data_sha256") and \
            pins["kgraph_data_sha256"] != digest:
        history.append({"sha256": pins["kgraph_data_sha256"],
                        "frozen_utc": pins.get("frozen_utc")})
    pins = {
        "kgraph_data_sha256": digest,
        "kgraph_schema_version": kd.KG_SCHEMA_VERSION,
        "generation_utc": kd.FROZEN_UTC,
        "edge_count": len(kd.P8_EDGES),
        "absence_count": len(kd.P8_ABSENCES),
        "frozen_utc": datetime.now(timezone.utc).strftime(
            "%Y-%m-%dT%H:%M:%SZ"),
        "refreeze_history": history,
    }
    os.makedirs(os.path.dirname(KGRAPH_PIN_PATH), exist_ok=True)
    with open(KGRAPH_PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(pins, fh, indent=1, sort_keys=True)
    print(f"[freeze] kgraph_data.py sha256 = {digest}")
    print(f"[freeze] pinned in {KGRAPH_PIN_PATH}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
