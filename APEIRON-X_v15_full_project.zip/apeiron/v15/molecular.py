"""Module D — novel molecule discovery (Phase 5, plan §6).

Orchestrates the chem package over the FROZEN v14.1 structure corpus:

  * Reference corpus (P5-4 novelty lane): all 191 KB molecules
    (drug_structures.py, PubChem CID-anchored axiom A6, hash-pinned)
    plus the ChEMBL molecule structures already frozen in the Phase 4
    cache (read directly from the frozen payload files — this module
    imports NO connector code, the derivation/connector isolation is
    AST-checked). Absent structures are reported as absences.
  * Round-trip theorem: SMILES -> freshly recomputed chi -> proved laws
    on ALL 191 KB molecules must reproduce the v14.1 feature vectors
    and re-certify every proved S1 law (0 member violations, 0 false
    positives) — the acceptance clause "round-trip on all 191 KB
    molecules unchanged".
  * Generation: the deterministic P5-4 pipeline (quota 100).
  * Theorems (PROVEN_MATH, standard APEIRON-X shape):
      - theorem_kb_roundtrip        (S-class: corpus unchanged)
      - theorem_truth_in_labeling   (NEW S-class obligation P5-5)
      - theorem_no_docking_claims   (P5-3 gate, machine-checked)
      - theorem_generation_determinism
      - theorem_rank_determinism    (permutation invariance)
  * Every emitted molecule record carries
    status in {KNOWN_MOLECULE, GENERATED_CANDIDATE} and explicit
    NO_CLAIM markers; generated molecules are research candidates
    (tier COMPUTATIONAL), never binding/activity/clinical statements.
"""

import json
import os
import random
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                     # apeiron/ repo root
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from . import chem  # noqa: F401  (package marker)
from .chem import mol_io, props, admet, generate

# ---- v14.1 engines, READ-ONLY (Phase 1 doctrine) ----
import drug_structures as DS          # noqa: E402
import disease_drug_kb as KB          # noqa: E402
import apeiron_structure_proof as SP  # noqa: E402

CACHE_DIR = os.path.join(ROOT, "v15", "cache")
MANIFEST_PATH = os.path.join(CACHE_DIR, "manifest.json")

MOLECULE_SCHEMA_VERSION = "15.5.0"
STATUS_VALUES = ("KNOWN_MOLECULE", "GENERATED_CANDIDATE")


# ------------------------------------------------------------------
# Reference corpus (novelty lane) — frozen KB + frozen ChEMBL payloads
# ------------------------------------------------------------------

def build_reference_corpus(layer) -> dict:
    """Frozen corpus for novelty checks + the report's KNOWN_MOLECULE
    rows. Reads the ChEMBL payloads straight from the frozen cache
    files (no connector import); a structure absence is recorded, not
    guessed."""
    corpus = {
        "kb_smiles": {}, "chembl_smiles": {}, "all_canonical": {},
        "fps": {}, "rows": [], "absences": [],
    }
    # KB lane (axiom A6: PubChem CID-anchored ground truth, frozen file)
    for name in sorted(DS.SMILES):
        smi = DS.SMILES[name]
        canon = mol_io.canonical_smiles(smi)
        row = {
            "label": f"KB:{name}", "status": "KNOWN_MOLECULE",
            "smiles_canonical": canon, "lane": "KB (v14.1 axiom A6, "
            "PubChem CID-anchored, hash-pinned file)",
            "source_id": "KB:AXIOM_A6", "tier": "EVIDENCED",
        }
        corpus["kb_smiles"][name] = canon
        corpus["all_canonical"].setdefault(canon, f"KB:{name}")
        corpus["fps"][f"KB:{name}"] = mol_io.topological_fp(canon)
        corpus["rows"].append(row)
    # ChEMBL lane (Phase 4 frozen cache payloads)
    if os.path.exists(MANIFEST_PATH):
        with open(MANIFEST_PATH, encoding="utf-8") as fh:
            manifest = json.load(fh)
        for name in sorted(k for k in manifest
                           if k.startswith("chembl.molecule.")):
            cid = name.split(".", 2)[2]
            path = os.path.join(CACHE_DIR, manifest[name]["sha256"]
                                + ".json")
            with open(path, encoding="utf-8") as fh:
                payload = json.load(fh)["payload"]
            struct = payload.get("molecule_structures") or {}
            smi = struct.get("canonical_smiles")
            if not smi:
                corpus["absences"].append({
                    "chembl_id": cid,
                    "absence": "NO_STRUCTURE_IN_FROZEN_RECORD",
                    "detail": "the frozen ChEMBL molecule record carries "
                              "no canonical_smiles (reported, not "
                              "guessed); the molecule is excluded from "
                              "the novelty corpus and listed here",
                    "tier": "UNKNOWN",
                })
                continue
            canon = mol_io.canonical_smiles(smi)
            corpus["chembl_smiles"][cid] = canon
            corpus["all_canonical"].setdefault(
                canon, f"ChEMBL:{cid}")
            corpus["fps"][f"ChEMBL:{cid}"] = mol_io.topological_fp(canon)
            corpus["rows"].append({
                "label": f"ChEMBL:{cid}",
                "pref_name": payload.get("pref_name"),
                "status": "KNOWN_MOLECULE",
                "smiles_canonical": canon,
                "lane": "ChEMBL frozen cache (Phase 4 payloads, "
                        "sha256-pinned responses)",
                "source_id": f"ChEMBL:{cid}", "tier": "EVIDENCED",
            })
    else:
        corpus["absences"].append({
            "chembl_id": None,
            "absence": "NO_FROZEN_CACHE_MANIFEST",
            "detail": "v15/cache/manifest.json not found; the ChEMBL "
                      "lane is empty this run (reported, not guessed)",
            "tier": "UNKNOWN",
        })
    return corpus


# ------------------------------------------------------------------
# Round-trip theorem (acceptance: 191 KB molecules unchanged)
# ------------------------------------------------------------------

def _fresh_semantics_satisfies(layer, sem, components, terms) -> bool:
    """v14.1 law semantics re-implemented over FRESHLY recomputed
    feature sets (same shapes as SP.semantics_satisfies /
    layer.satisfies_same_molecule / layer.satisfies):
      same_molecule   -> any single component's feature set contains a
                         whole term
      component_split -> the drug-level union set contains a whole term
    """
    if sem == "component_split":
        union = mol_io.fresh_drug_feature_set(
            layer, [DS.SMILES[c] for c in components])
        return any(all(f in union for f in t) for t in terms)
    per_comp = [mol_io.fresh_component_features(
                    layer, DS.SMILES[c]) for c in components]
    return any(all(f in fs for f in t) for t in terms for fs in per_comp)


def theorem_kb_roundtrip(layer, laws) -> dict:
    """SMILES -> fresh chi -> laws on ALL KB molecules must reproduce
    the cached v14.1 layer vectors and re-certify every proved law.
    PROVEN_MATH on the encoded corpus: zero counterexamples <=> proved."""
    chi_mismatches = []
    for name in sorted(DS.SMILES):
        fresh = mol_io.fresh_component_features(layer, DS.SMILES[name])
        if fresh != layer.comp_feats[name]:
            chi_mismatches.append({
                "component": name,
                "missing": sorted(set(layer.comp_feats[name]) - fresh),
                "extra": sorted(fresh - set(layer.comp_feats[name]))})
    member_violations, false_positives = [], []
    classes = {}
    for drug, (_atc, cls) in KB.DRUGS.items():
        classes.setdefault(cls, set()).add(drug)
    covered = sorted(layer.drug_components)
    for cls in sorted(laws):
        cert = laws[cls]
        if not cert.get("proved"):
            continue
        sib = set(cert.get("siblings", ()))
        terms = mol_io.law_terms(cert)
        sem = cert.get("semantics", "same_molecule")
        for drug in sorted(classes.get(cls, ())):
            comps = layer.drug_components.get(drug)
            if comps is None:
                continue
            if not _fresh_semantics_satisfies(layer, sem, comps, terms):
                member_violations.append({"class": cls, "drug": drug})
        for drug in covered:
            _atc, cls2 = KB.DRUGS[drug]
            if cls2 == cls or cls2 in sib:
                continue
            comps = layer.drug_components.get(drug)
            if comps is None:
                continue
            if _fresh_semantics_satisfies(layer, sem, comps, terms):
                false_positives.append({"class": cls, "drug": drug})
    counterexamples = (
        [{"kind": "chi_mismatch", **c} for c in chi_mismatches] +
        [{"kind": "member_violation", **c} for c in member_violations] +
        [{"kind": "false_positive", **c} for c in false_positives])
    return {
        "theorem": "KB molecular round-trip: SMILES -> fresh chi -> "
                   "proved laws unchanged (Phase 5 acceptance)",
        "statement": "for all 191 frozen KB molecules the freshly "
                     "recomputed D9 feature vector equals the cached "
                     "v14.1 layer vector, and every proved structure "
                     "law re-certifies on the fresh vectors (all "
                     "members satisfy; zero non-sibling falsifiers "
                     "fire)",
        "proved": not counterexamples,
        "tier": "PROVEN_MATH",
        "counterexamples": counterexamples,
        "stats": {"kb_molecules": len(DS.SMILES),
                  "chi_mismatches": len(chi_mismatches),
                  "laws_recertified":
                      sum(1 for c in laws.values() if c.get("proved")),
                  "member_violations": len(member_violations),
                  "false_positives": len(false_positives)},
        "proof_steps": [
            "for every component SMILES: fresh parse + independent "
            "recomputation of the feature set from the frozen tables",
            "compare against the cached layer feature set (must be "
            "equal)",
            "for every proved law: member drugs must satisfy per the "
            "v14.1 semantics on fresh vectors; every covered non-"
            "sibling KB drug must NOT satisfy",
            "counterexample list is empty <=> theorem holds",
        ],
    }


# ------------------------------------------------------------------
# P5-5 truth-in-labeling theorem (NEW S-class obligation)
# ------------------------------------------------------------------

def _scan_text_fields(obj, path=""):
    """Yield (path, string) for every string leaf of a record."""
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _scan_text_fields(v, f"{path}.{k}" if path else k)
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            yield from _scan_text_fields(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        yield path, obj


def theorem_truth_in_labeling(bench: dict) -> dict:
    """P5-5 (S-class): every molecule record in the report carries
    EXACTLY one status in {KNOWN_MOLECULE, GENERATED_CANDIDATE}; every
    generated record carries claims binding=NO_CLAIM, efficacy=NO_CLAIM;
    no text field anywhere carries claim language (banned-token scan);
    zero records claim binding or efficacy."""
    counterexamples = []
    n_gen = n_known = n_rejected = 0
    low = [(tok, tok.lower()) for tok in mol_io.BANNED_CLAIM_TOKENS]
    for rec in bench["molecules"] + bench["reference_corpus"]["rows"]:
        status = rec.get("status")
        if status not in STATUS_VALUES:
            counterexamples.append({
                "label": rec.get("label") or rec.get("smiles"),
                "reason": f"illegal status {status!r}"})
            continue
        if status == "GENERATED_CANDIDATE":
            n_gen += 1
            if rec.get("rejected"):
                n_rejected += 1
            claims = rec.get("claims") or {}
            if claims.get("binding") != "NO_CLAIM" or \
                    claims.get("efficacy") != "NO_CLAIM":
                counterexamples.append({
                    "label": rec.get("smiles"),
                    "reason": f"claims block is not NO_CLAIM: {claims}"})
        else:
            n_known += 1
        for path, text in _scan_text_fields(rec):
            t = text.lower()
            for tok, tl in low:
                if tl in t:
                    counterexamples.append({
                        "label": rec.get("label") or rec.get("smiles"),
                        "reason": f"claim language {tok!r} in field "
                                  f"{path}"})
    return {
        "theorem": "truth-in-labeling obligation (Phase 5, P5-5)",
        "statement": "every molecule record carries exactly one status "
                     "in {KNOWN_MOLECULE, GENERATED_CANDIDATE}; every "
                     "generated record carries binding=NO_CLAIM and "
                     "efficacy=NO_CLAIM; zero records anywhere carry "
                     "binding/activity/claim language",
        "proved": not counterexamples,
        "tier": "PROVEN_MATH",
        "counterexamples": counterexamples,
        "stats": {"records_checked":
                  len(bench["molecules"]) +
                  len(bench["reference_corpus"]["rows"]),
                  "generated_emitted": n_gen - n_rejected,
                  "generated_rejected": n_rejected,
                  "known_molecules": n_known},
        "proof_steps": [
            "status field must be a member of the two-value vocabulary",
            "claims block of every generated record must be exactly "
            "NO_CLAIM on binding and efficacy",
            "every string leaf of every record is scanned for the "
            "banned claim tokens",
            "counterexample list is empty <=> theorem holds",
        ],
    }


def theorem_no_docking_claims(bench: dict) -> dict:
    """P5-3 gate: zero records carry a docking statement; the only
    permitted docking label is NO_DOCKING_RUN_RECORD (no docking run
    record exists in this round)."""
    counterexamples = []
    for rec in bench["molecules"]:
        claim = (rec.get("claims") or {}).get("docking")
        if claim != "NO_DOCKING_RUN_RECORD":
            counterexamples.append({
                "label": rec.get("smiles"), "reason": f"docking claim "
                f"{claim!r} without a complete run record"})
    return {
        "theorem": "no-docking-claims gate (Phase 5, P5-3)",
        "statement": "no emitted record carries a docking statement; "
                     "the docking label is NO_DOCKING_RUN_RECORD "
                     "everywhere (no docking run record exists)",
        "proved": not counterexamples,
        "tier": "PROVEN_MATH",
        "counterexamples": counterexamples,
        "stats": {"records_checked": len(bench["molecules"]),
                  "docking_run_records": 0},
        "proof_steps": [
            "every molecule record's claims.docking must be the "
            "NO_DOCKING_RUN_RECORD sentinel",
            "a real docking claim requires a complete run record "
            "(structure id/source, software, version, protocol, run "
            "timestamp) — none exists in this round",
            "counterexample list is empty <=> theorem holds",
        ],
    }


def theorem_generation_determinism(layer, laws, corpus, quota) -> dict:
    """Two independent generation runs from identical inputs must
    produce bit-identical output (canonical JSON equality)."""
    a = generate.generate_candidates(layer, laws, corpus, quota)
    b = generate.generate_candidates(layer, laws, corpus, quota)
    same = generate.canonical_json(
        {"e": a["emitted"], "r": a["rejected"]}) == \
        generate.canonical_json({"e": b["emitted"], "r": b["rejected"]})
    return {
        "theorem": "generation determinism (Phase 5, P5-4)",
        "statement": "the candidate pipeline is a deterministic "
                     "function of (frozen corpus, frozen laws, config); "
                     "two independent runs agree bit-for-bit",
        "proved": bool(same),
        "tier": "PROVEN_MATH",
        "counterexamples": [] if same else [{"kind": "json_mismatch"}],
        "stats": {"emitted": len(a["emitted"]),
                  "rejected": len(a["rejected"])},
        "proof_steps": [
            "run the pipeline twice on identical frozen inputs",
            "compare canonical JSON of emitted + rejected records",
            "bit equality <=> proved",
        ],
    }


def theorem_rank_determinism(emitted: list) -> dict:
    """Permuting the candidate input order must not change the ranked
    output (deterministic sort on (-aggregate, smiles))."""
    ranked = sorted(emitted, key=lambda r: (-r["aggregate"], r["smiles"]))
    shuffled = ranked[:]
    random.Random(20261125).shuffle(shuffled)
    re_ranked = sorted(shuffled,
                       key=lambda r: (-r["aggregate"], r["smiles"]))
    same = ranked == re_ranked
    return {
        "theorem": "rank integrity under input permutation (Phase 5)",
        "statement": "rank order is invariant under permutation of the "
                     "candidate input order",
        "proved": bool(same),
        "tier": "PROVEN_MATH",
        "counterexamples": [] if same else [{"kind": "order_changed"}],
        "stats": {"rows": len(emitted)},
        "proof_steps": [
            "rank with the generation order",
            "shuffle with a fixed seed, re-rank",
            "deep equality of the two ranked lists <=> proved",
        ],
    }


# ------------------------------------------------------------------
# Module D run (benchmark input for the artifacts writer)
# ------------------------------------------------------------------

def run_module_d(quota: int = generate.QUOTA_DEFAULT,
                 verbose: bool = True) -> dict:
    layer = mol_io.get_layer()
    laws = mol_io.get_structure_laws(layer)
    corpus = build_reference_corpus(layer)

    def log(msg):
        if verbose:
            print(f"    [module D] {msg}")

    log("reference corpus: "
        f"{len(corpus['kb_smiles'])} KB + "
        f"{len(corpus['chembl_smiles'])} ChEMBL structures, "
        f"{len(corpus['absences'])} recorded absence(s)")

    rt = theorem_kb_roundtrip(layer, laws)
    log(f"round-trip theorem: proved={rt['proved']} "
        f"({rt['stats']['laws_recertified']} laws re-certified)")

    gen = generate.generate_candidates(layer, laws, corpus, quota)
    log(f"generation: {len(gen['emitted'])} emitted, "
        f"{len(gen['rejected'])} rejected, "
        f"{gen['stats']['products_evaluated']} products evaluated")

    bench = {
        "benchmark": "Phase 5 novel-molecule-discovery acceptance "
                     "(plan §6)",
        "module": "D — novel molecule discovery",
        "molecule_schema_version": MOLECULE_SCHEMA_VERSION,
        "rdkit_version": mol_io.importlib_rdkit_version(),
        "feature_space": mol_io.feature_space_manifest(),
        "generation_config": gen["config"],
        "generation_stats": gen["stats"],
        "admet_registry": admet.registry_absence_statement(),
        "reference_corpus": {
            "kb_molecules": len(corpus["kb_smiles"]),
            "chembl_molecules": len(corpus["chembl_smiles"]),
            "absences": corpus["absences"],
            "rows": corpus["rows"],
        },
        "seeds_scanned": gen["stats"]["seeds_scanned"],
        "molecules": gen["emitted"] + gen["rejected"],
        "quota": quota,
        "emitted_n": len(gen["emitted"]),
        "rejected_n": len(gen["rejected"]),
        "rejections_by_reason": _tally(gen["rejected"]),
        "honest_limits": [
            "generated molecules are COMPUTATIONAL-tier research "
            "candidates; no binding, activity, or clinical statement "
            "is made for any structure",
            "the ADMET model registry ships EMPTY: no validated ML "
            "model exists, the PREDICTED_ML lane has zero entries and "
            "ML prediction requests are refused",
            "no docking run record exists in this round, so no "
            "structure carries a docking statement",
            "novelty is checked against the frozen 191-molecule KB "
            "corpus plus the frozen ChEMBL Phase 4 structures (17 "
            "structures; 1 recorded absence) — not against a live "
            "global database",
            "PAINS/Brenk alerts are conservative rule flags: they also "
            "trigger on established market drugs (aspirin itself "
            "carries a Brenk phenol-ester flag)",
            "solubility/permeability classes are coarse binned rules "
            "(PREDICTED_RULEBASED), not measured or mechanistic values",
            "law plausibility is satisfaction of a PROVED structure-"
            "class law on the closed KB corpus — a class-pharmacophore "
            "compatibility statement, never a target-activity claim",
            "the synthetic-accessibility axis is the Ertl-Schuffenhauer "
            "heuristic estimate, not a synthesis plan",
        ],
    }

    theorems = {
        "theorem_kb_roundtrip": rt,
        "theorem_truth_in_labeling": theorem_truth_in_labeling(bench),
        "theorem_no_docking_claims": theorem_no_docking_claims(bench),
        "theorem_generation_determinism": theorem_generation_determinism(
            layer, laws, corpus, quota),
        "theorem_rank_determinism": theorem_rank_determinism(
            gen["emitted"]),
    }
    bench["theorems"] = {k: {kk: t[kk] for kk in
                             ("theorem", "statement", "proved", "tier",
                              "counterexamples", "stats", "proof_steps")}
                         for k, t in theorems.items()}
    bench["theorems_all_proved"] = all(t["proved"]
                                       for t in theorems.values())
    return bench


def _tally(rejected) -> dict:
    out = {}
    for r in rejected:
        out[r["reject_reason"]] = out.get(r["reject_reason"], 0) + 1
    return dict(sorted(out.items()))


def load_chem(verify_frozen: bool = True) -> dict:
    """Entry point mirroring v15.targets.load_targets /
    v15.repurposing.load_pack: returns the lazily-built bridge
    {layer, laws, corpus_fn}. Frozen-file integrity is enforced by the
    cascade (sha256 snapshot); this loader re-checks the structure KB
    parse on build."""
    layer = mol_io.get_layer()
    return {"layer": layer, "laws": mol_io.get_structure_laws(layer),
            "corpus": build_reference_corpus(layer)}
