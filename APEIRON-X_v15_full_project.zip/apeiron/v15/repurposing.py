"""Module C — drug repurposing engine (Phase 4, plan §5).

P4-1 frozen-pack retrieval + compatibility law channel:
  `v15.repurposing_data` is the hash-pinned pack of machine-verified
  drug records (ChEMBL first_approval / withdrawn flags, OT mechanism
  rows and indication memberships), landmark trial citations (Europe
  PMC) and the curated pre-2015 disease-channel profiles. Candidate
  generation matches a drug's channels (target-channel table + v14.1
  KB mechanism-class fallback) against a disease's channels, with the
  documented CARDIORENAL / HYPERGLYCEMIA adjacency bridge; opposing
  pharmacology rows surface as CONTRADICTION findings, never silent
  drops.

P4-2 status discipline: every candidate carries EXACTLY ONE of
  APPROVED_INDICATION / INVESTIGATIONAL / EXPERIMENTALLY_VALIDATED /
  COMPUTATIONAL_HYPOTHESIS, with traceable source ids. A
  COMPUTATIONAL_HYPOTHESIS is never rendered as a treatment.

P4-3 consistency bridge (read-only v14.1 import): a candidate whose
  disease has a v14.1 encoding (kb_did) and whose molecule is in the
  structure corpus must ALSO satisfy the direct structure law
  Theta_d to be ranked EVIDENCED. Violations surface as
  MECH_STRUCTURE_CONFLICT findings; molecules outside the corpus
  surface as NOT_IN_CORPUS; no candidate is ever silently dropped.

P4-4 temporal benchmark: predictions use ONLY pre-2015 knowledge
(molecule side: ChEMBL first_approval < 2015; disease side: channels
anchored by pre-2015 citations). `theorem_temporal_hermeticity`
machine-checks that the prediction is invariant when every post-2015
record is removed from the pack. Ground truth = the frozen
post-2015 repurposing outcomes (SGLT2i HF/CKD era).

Doctrine carried over from Phase 3: transparent per-axis scores, the
aggregate is labelled COMPUTATIONAL_RANK and is never a probability,
and the v14.1 engines are imported read-only (the bridge is a
CONSISTENCY check on outputs, never a prediction input — the KB
contains post-2015 guideline rows by design).
"""

import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
PACK_DATA_PATH = os.path.abspath(os.path.join(HERE, "repurposing_data.py"))
PACK_PIN_PATH = os.path.abspath(os.path.join(
    HERE, "kb_extensions", "repurposing_pins.json"))

# Status vocabulary (P4-2) — exactly one per candidate.
STATUSES = ("APPROVED_INDICATION", "INVESTIGATIONAL",
            "EXPERIMENTALLY_VALIDATED", "COMPUTATIONAL_HYPOTHESIS")

AXES_P4 = ("channel_support", "track_record", "safety",
           "evidence_completeness")

SUPPORT_LEVEL_NUM = {"direct": 1.0, "adjacent": 0.5, "none": 0.0}


def sha256_of(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


# =====================================================================
# P4-1 pin-checked facade over the frozen pack
# =====================================================================

class RepurposingPack:
    """Read-only facade over `v15.repurposing_data` with source
    resolution (anti-fabrication gate) and the law-channel logic."""

    def __init__(self, verify_pin: bool = True):
        from . import repurposing_data as rd
        self._rd = rd
        self.data_sha256 = sha256_of(PACK_DATA_PATH)
        if not os.path.exists(PACK_PIN_PATH):
            raise RuntimeError(
                f"repurposing pin file missing: {PACK_PIN_PATH}. Run "
                "v15/kb_extensions/freeze_repurposing.py (frozen-table "
                "doctrine: unpinned tables are not served).")
        with open(PACK_PIN_PATH, encoding="utf-8") as fh:
            self.pins = json.load(fh)
        if verify_pin and self.pins.get("repurposing_data_sha256") != \
                self.data_sha256:
            raise RuntimeError(
                "repurposing_data.py sha256 mismatch: frozen pin "
                f"{self.pins.get('repurposing_data_sha256')} != live "
                f"{self.data_sha256}. If this change is intentional, "
                "re-run the documented re-freeze, never edit silently.")
        problems = rd.validate_repurposing_module()
        if problems:
            raise ValueError("repurposing pack self-validation failed: "
                             + "; ".join(problems))
        self.schema_version = rd.PACK_SCHEMA_VERSION
        self.frozen_utc = rd.FROZEN_UTC
        self.drugs = dict(rd.DRUGS_P4)
        self.diseases = dict(rd.DISEASES_P4)
        self.panel = dict(rd.DISEASE_PANEL)
        self.evidence = list(rd.INDICATION_EVIDENCE)
        self.ground_truth = list(rd.GROUND_TRUTH_POST2015)
        self.literature = dict(rd.LITERATURE)
        self.adjacency = dict(rd.CHANNEL_ADJACENCY)
        self.split_year = rd.TEMPORAL_SPLIT_YEAR
        self.prediction_diseases = list(rd.PREDICTION_DISEASES)
        self.limits = list(rd.HONEST_LIMITS)

    # -- source resolution (anti-fabrication gate) --------------------
    def source_record(self, source_id: str) -> dict:
        rd = self._rd
        if source_id in rd.SOURCE_RECORDS:
            return dict(rd.SOURCE_RECORDS[source_id])
        if source_id in getattr(rd, "INTERNAL_SOURCE_RECORDS", {}):
            return dict(rd.INTERNAL_SOURCE_RECORDS[source_id])
        if source_id in self.literature:
            rec = dict(self.literature[source_id])
            rec["resource"] = f"Europe PMC record {rec['pmid']}"
            return rec
        raise KeyError(f"no provenance record for source id {source_id}")

    def require_sources(self, source_ids) -> None:
        missing = sorted({s for s in source_ids if self._missing(s)})
        if missing:
            raise KeyError("uncited/unrecorded source ids: "
                           + ", ".join(missing))

    def _missing(self, sid: str) -> bool:
        rd = self._rd
        return not (sid in rd.SOURCE_RECORDS
                    or sid in getattr(rd, "INTERNAL_SOURCE_RECORDS", {})
                    or sid in self.literature)

    # -- law channel ----------------------------------------------------
    def drug_channels(self, drug: str) -> dict:
        """Channels of a drug: mapped target symbols (OT mechanism rows)
        plus the v14.1 KB mechanism-class fallback. Unmapped symbols are
        reported, never coerced."""
        d = self.drugs[drug]
        channels, mapped, unmapped, actions = set(), [], [], {}
        for row in d["moa_rows"]:
            for sym in row["target_symbols"]:
                spec = self._rd.TARGET_CHANNEL_MAP.get(sym)
                if spec is None:
                    unmapped.append(sym)
                    continue
                mapped.append(sym)
                actions[sym] = row.get("action_type")
                channels.update(spec["channels"])
        kb_class = d.get("kb_mech_class")
        if kb_class:
            channels.update(self._rd.MECH_CLASS_CHANNELS.get(kb_class, []))
        return {"channels": sorted(channels), "mapped_symbols": mapped,
                "unmapped_symbols": sorted(set(unmapped)),
                "actions_by_symbol": actions, "kb_class": kb_class}

    def disease_channels(self, key: str) -> list:
        return [ch["channel"] for ch in self.diseases[key]
                ["channels_pre2015"]]

    def channel_support(self, drug: str, key: str) -> dict:
        """direct > adjacent (documented bridge) > none. Adjacency runs
        only through the curated CHANNEL_ADJACENCY table, which cites
        its bridge evidence."""
        dc = set(self.drug_channels(drug)["channels"])
        prof = self.diseases[key]["channels_pre2015"]
        direct = [c["channel"] for c in prof if c["channel"] in dc]
        if direct:
            return {"level": "direct", "matched": direct, "bridged": []}
        bridged = []
        for c in prof:
            for src, spec in self.adjacency.items():
                if c["channel"] in spec["adjacent"] and src in dc:
                    bridged.append(
                        {"from_channel": src, "to_channel": c["channel"],
                         "sources": list(spec["sources"])})
        if bridged:
            return {"level": "adjacent", "matched": [], "bridged": bridged}
        return {"level": "none", "matched": [], "bridged": []}

    # -- indication evidence helpers -------------------------------------
    def _disease_key_for_id(self, disease_id):
        for key, rec in self.panel.items():
            if rec.get("disease_id") == disease_id:
                return key
        return None

    def indication_keys_for(self, drug: str) -> set:
        """Disease keys with ANY machine-served indication row for the
        drug (either side). Current-era snapshot (see HONEST_LIMITS)."""
        keys = set()
        for row in self.evidence:
            if row["drug"] != drug:
                continue
            key = row.get("panel_key") or \
                self._disease_key_for_id(row.get("disease_id"))
            if key:
                keys.add(key)
        return keys

    def has_approval_row(self, drug: str, key: str) -> bool:
        for row in self.evidence:
            if row["drug"] != drug:
                continue
            rkey = row.get("panel_key") or \
                self._disease_key_for_id(row.get("disease_id"))
            if rkey == key and \
                    str(row.get("stage") or "").startswith("APPROVAL"):
                return True
        return False

    def has_stage_row(self, drug: str, key: str) -> bool:
        for row in self.evidence:
            if row["drug"] != drug:
                continue
            rkey = row.get("panel_key") or \
                self._disease_key_for_id(row.get("disease_id"))
            if rkey == key:
                return True
        return False

    def status_for(self, drug: str, key: str) -> dict:
        """P4-2 status assignment from machine-served rows + verified
        trial citations. Returns {status, tier, source_ids, note}."""
        sources = ["SRC:OT_P4"]
        if self.has_approval_row(drug, key):
            return {"status": "APPROVED_INDICATION", "tier": "EVIDENCED",
                    "source_ids": sources,
                    "note": "APPROVAL-stage indication row served"}
        gt = [g for g in self.ground_truth
              if g["drug"] == drug and g["disease_key"] == key]
        if gt:
            sources += list(gt[0]["citations"])
            return {"status": "EXPERIMENTALLY_VALIDATED",
                    "tier": "EVIDENCED", "source_ids": sources,
                    "note": "cited outcomes trial publication; "
                            + gt[0]["ot_status"].lower()}
        if self.has_stage_row(drug, key):
            return {"status": "INVESTIGATIONAL", "tier": "EVIDENCED",
                    "source_ids": sources,
                    "note": "clinical-stage indication row served"}
        if self.drugs[drug].get("kb_mech_class"):
            sources.append("SRC:KB_P4")
        return {"status": "COMPUTATIONAL_HYPOTHESIS",
                "tier": "COMPUTATIONAL", "source_ids": sources,
                "note": "law-channel compatibility only; no indication "
                        "row served"}


# =====================================================================
# P4-3 Theta_d consistency bridge (v14.1 engines, READ-ONLY import)
# =====================================================================

_BRIDGE_CACHE = {}


def _get_bridge():
    """Build the structure layer + direct laws ONCE (about 5 s), then
    cache. Imports v14.1 engines read-only (Phase 1 doctrine)."""
    if _BRIDGE_CACHE:
        return _BRIDGE_CACHE
    import apeiron_structure_proof as SP
    import apeiron_direct_laws as DL
    layer = SP.StructLayer()
    laws, _excluded = SP.derive_structure_laws(layer, verbose=False)
    theta = DL.derive_direct_laws(layer, laws)
    _BRIDGE_CACHE["layer"] = layer
    _BRIDGE_CACHE["theta"] = theta
    _BRIDGE_CACHE["theta_satisfies"] = DL.theta_satisfies_drug
    return _BRIDGE_CACHE


def theta_finding(pack: RepurposingPack, drug: str, key: str) -> dict:
    """P4-3 finding for one candidate. Never drops a candidate: every
    case resolves to one of four explicit findings."""
    kb_did = pack.diseases[key].get("kb_did")
    d = pack.drugs[drug]
    if kb_did is None:
        return {"finding": "NO_DISEASE_ENCODING",
                "kb_did": None,
                "detail": f"{key} has no v14.1 encoding; the bridge "
                          f"cannot check {drug} (reported, not guessed)"}
    if not d.get("kb_member"):
        return {"finding": "NOT_IN_CORPUS", "kb_did": kb_did,
                "detail": f"{drug} is not in the v14.1 structure corpus; "
                          f"Theta_d check impossible (reported, not "
                          f"guessed)"}
    bridge = _get_bridge()
    theta = bridge["theta"].get(kb_did)
    if theta is None or not theta.get("has_structure_law"):
        return {"finding": "NO_MOLECULAR_LAW", "kb_did": kb_did,
                "detail": f"KB:{kb_did} has no molecular structure law "
                          f"(non-molecular therapy class)"}
    sat = bool(bridge["theta_satisfies"](bridge["layer"], theta, drug))
    if sat:
        return {"finding": "THETA_SATISFIED", "kb_did": kb_did,
                "detail": f"Theta_{kb_did}(chi({drug})) = 1 "
                          f"(direct structure law satisfied)"}
    return {"finding": "MECH_STRUCTURE_CONFLICT", "kb_did": kb_did,
            "detail": f"Theta_{kb_did}(chi({drug})) = 0 — the candidate "
                      f"contradicts the direct structure law of KB:"
                      f"{kb_did}; kept visible, excluded from "
                      f"EVIDENCED ranking"}


# =====================================================================
# P4-1 candidate generation + transparent scoring
# =====================================================================

def class_precedent(pack: RepurposingPack, drug: str, key: str,
                    support: dict) -> float:
    """track_record axis: 1.0 iff a DIRECT-matched channel carries a
    precedent_class (curated pre-2015 literature anchor: CONSENSUS ->
    ACEI_RAAS, RALES -> MINERALOCORTICOID_ANTAGONIST, RENAAL -> ARB_RAAS,
    UKPDS 33 -> BIGUANIDE_HEPATIC_GLUCOSE) and the candidate maps to
    that mechanism class (via its v14.1 KB class or the class-channel
    fallback table). Never derived from undated snapshot rows."""
    if support["level"] != "direct":
        return 0.0
    dc = pack.drug_channels(drug)
    classes = set()
    if dc.get("kb_class"):
        classes.add(dc["kb_class"])
    for cls, chs in pack._rd.MECH_CLASS_CHANNELS.items():
        if set(chs) & set(support["matched"]):
            classes.add(cls)
    for ch in pack.diseases[key]["channels_pre2015"]:
        if ch["channel"] in support["matched"] and \
                ch.get("precedent_class") in classes:
            return 1.0
    return 0.0


def safety_penalty(pack: RepurposingPack, drug: str) -> float:
    """Withdrawn molecules are penalised hard; KB safety penalties
    (0-10 scale, verbatim KB rows) are normalised; unknown drugs carry
    the documented 0.3 default. Higher = worse."""
    d = pack.drugs[drug]
    if d.get("withdrawn_flag"):
        return 1.0
    kb_pen = d.get("kb_safety_penalty_max")
    if kb_pen is not None:
        return round(kb_pen / 10.0, 4)
    return 0.3


def evidence_completeness(pack: RepurposingPack, drug: str) -> float:
    d = pack.drugs[drug]
    n = len(d.get("sources", []))
    return round(min(1.0, n / 4.0), 4)


def _prune_view(pack: RepurposingPack, as_of_year: int) -> dict:
    """A view of the pack restricted to pre-as_of knowledge (used by
    the hermeticity theorem and by predict_repurposing itself)."""
    drugs = {n: d for n, d in pack.drugs.items()
             if d.get("first_approval") is not None
             and d["first_approval"] < as_of_year}
    evidence = [r for r in pack.evidence if r["drug"] in drugs]
    return {"drugs": drugs, "evidence": evidence,
            "ground_truth": []}


def predict_repurposing(pack: RepurposingPack,
                        as_of_year: int = None) -> dict:
    """Pre-ascertainment candidate generation (P4-1/P4-4).

    Uses ONLY: (a) molecules with ChEMBL first_approval < as_of_year,
    (b) the pre-2015 disease-channel profiles, (c) the curated
    adjacency bridge. Post-2015 records (ground truth, post-2015
    molecules, current-era approval rows) are structurally unreachable
    from this function — machine-checked by
    theorem_temporal_hermeticity."""
    as_of = as_of_year or pack.split_year
    view = _prune_view(pack, as_of)
    drugs = view["drugs"]
    report = {"as_of_year": as_of, "n_candidates": len(drugs),
              "diseases": {}}
    for key in pack.prediction_diseases:
        rows = []
        zero_support_rank_seen = None
        for name in sorted(drugs):
            sup = pack.channel_support(name, key)
            tr = class_precedent(pack, name, key, sup)
            sp = safety_penalty(pack, name)
            ec = evidence_completeness(pack, name)
            axes = {"channel_support": SUPPORT_LEVEL_NUM[sup["level"]],
                    "track_record": tr,
                    "safety": sp,
                    "evidence_completeness": ec}
            agg = round(sum(axes.values()) / len(AXES_P4), 4)
            status = status_from_view(pack, view, name, key)
            finding = theta_finding(pack, name, key)
            if finding["finding"] == "THETA_SATISFIED" and \
                    status["status"] == "APPROVED_INDICATION":
                rank_tier = "EVIDENCED"
            elif finding["finding"] == "MECH_STRUCTURE_CONFLICT":
                rank_tier = "MECH_STRUCTURE_CONFLICT"
            else:
                rank_tier = "COMPUTATIONAL"
            rows.append({
                "drug": name,
                "first_approval": drugs[name]["first_approval"],
                "support_level": sup["level"],
                "matched_channels": sup["matched"],
                "bridged": sup["bridged"],
                "axes": axes,
                "aggregate": agg,
                "aggregate_label": "COMPUTATIONAL_RANK",
                "status": status,
                "bridge": finding,
                "rank_tier": rank_tier,
                "sources": sorted(set(status["source_ids"])),
            })
        rows.sort(key=lambda r: (-r["aggregate"], r["drug"]))
        for i, r in enumerate(rows, start=1):
            r["rank"] = i
            if r["support_level"] == "none" and \
                    zero_support_rank_seen is None:
                zero_support_rank_seen = i
        report["diseases"][key] = {
            "rows": rows,
            "first_zero_support_rank": zero_support_rank_seen,
        }
    report["aggregate_label"] = "COMPUTATIONAL_RANK"
    return report


def track_record_from_view(pack: RepurposingPack, view: dict,
                           drug: str, key: str) -> float:
    """Deprecated pre-2015 helper retained for hermeticity references;
    the live axis is class_precedent (view-independent)."""
    raise NotImplementedError(
        "track_record moved to class_precedent (pre-2015 cited anchors); "
        "undated snapshot rows must not drive prediction axes")


def _view_indicated(pack: RepurposingPack, view: dict, drug: str,
                    key: str) -> bool:
    """Indication membership from the pruned evidence view only."""
    for row in view["evidence"]:
        if row["drug"] != drug:
            continue
        rkey = row.get("panel_key") or \
            pack._disease_key_for_id(row.get("disease_id"))
        if rkey == key:
            return True
    return False


def status_from_view(pack: RepurposingPack, view: dict, drug: str,
                     key: str) -> dict:
    """Status from the pruned view: APPROVAL rows reachable from the
    view are pre-2015-plausible (the molecule predates the split); the
    post-2015 ground truth and approval rows of post-2015 molecules are
    structurally excluded. The undated-snapshot caveat is recorded in
    HONEST_LIMITS."""
    has_row = _view_indicated(pack, view, drug, key)
    approved = False
    for row in view["evidence"]:
        if row["drug"] != drug:
            continue
        rkey = row.get("panel_key") or \
            pack._disease_key_for_id(row.get("disease_id"))
        if rkey == key and \
                str(row.get("stage") or "").startswith("APPROVAL"):
            approved = True
            break
    sources = ["SRC:OT_P4"]
    if approved:
        return {"status": "APPROVED_INDICATION", "tier": "EVIDENCED",
                "source_ids": sources,
                "note": "APPROVAL-stage indication row served"}
    if has_row:
        return {"status": "INVESTIGATIONAL", "tier": "EVIDENCED",
                "source_ids": sources,
                "note": "clinical-stage indication row served"}
    if pack.drugs[drug].get("kb_mech_class"):
        sources.append("SRC:KB_P4")
    return {"status": "COMPUTATIONAL_HYPOTHESIS", "tier": "COMPUTATIONAL",
            "source_ids": sources,
            "note": "law-channel compatibility only; no indication row "
                    "served"}


# =====================================================================
# P4-2/P4-3/P4-4 theorems (standard APEIRON-X shape)
# =====================================================================

def _theorem_shell(name, statement, proved, counterexamples, stats,
                   proof_steps):
    return {"theorem": name, "statement": statement, "proved": proved,
            "tier": "PROVEN_MATH", "counterexamples": counterexamples,
            "stats": stats, "proof_steps": proof_steps}


def theorem_status_discipline(pack: RepurposingPack, report: dict) -> dict:
    """P4-2: every candidate row carries exactly one admissible status,
    every EVIDENCED status cites >=1 recorded source id, and no
    COMPUTATIONAL_HYPOTHESIS row wears approval language."""
    cex = []
    n = 0
    for key, dd in report["diseases"].items():
        for r in dd["rows"]:
            n += 1
            st = r["status"]["status"]
            if st not in STATUSES:
                cex.append({"drug": r["drug"], "key": key,
                            "reason": f"status {st} outside vocabulary"})
            tier = r["status"]["tier"]
            if tier == "EVIDENCED":
                try:
                    pack.require_sources(r["status"]["source_ids"])
                except KeyError as exc:
                    cex.append({"drug": r["drug"], "key": key,
                                "reason": f"EVIDENCED without records: "
                                          f"{exc}"})
            if st == "COMPUTATIONAL_HYPOTHESIS" and \
                    "approv" in r["status"]["note"].lower():
                cex.append({"drug": r["drug"], "key": key,
                            "reason": "hypothesis row wears approval "
                                      "language"})
            for sid in r["sources"]:
                try:
                    pack.source_record(sid)
                except KeyError as exc:
                    cex.append({"drug": r["drug"], "key": key,
                                "reason": str(exc)})
    return _theorem_shell(
        "status-discipline obligation (Phase 4, P4-2)",
        "every repurposing candidate carries exactly one status from "
        "the P4-2 vocabulary; EVIDENCED statuses cite recorded source "
        "ids; COMPUTATIONAL_HYPOTHESIS rows never use approval language",
        not cex, cex, {"rows_checked": n},
        ["for each candidate row: vocabulary check",
         "EVIDENCED rows pass the anti-fabrication require gate",
         "hypothesis rows must not wear approval language",
         "counterexample list is empty <=> theorem holds"])


def theorem_bridge_exposure(pack: RepurposingPack, report: dict) -> dict:
    """P4-3: no silent drops — every candidate for an encoded disease
    exposes a Theta finding; conflicts stay visible in the ranked
    output; only THETA_SATISFIED + approved rows rank EVIDENCED."""
    cex = []
    n_conflict = n_satisfied = 0
    for key, dd in report["diseases"].items():
        kb_did = pack.diseases[key].get("kb_did")
        for r in dd["rows"]:
            f = r["bridge"]["finding"]
            if f == "MECH_STRUCTURE_CONFLICT":
                n_conflict += 1
                if r["rank_tier"] != "MECH_STRUCTURE_CONFLICT":
                    cex.append({"drug": r["drug"], "key": key,
                                "reason": "conflict not surfaced in tier"})
            elif f == "THETA_SATISFIED":
                n_satisfied += 1
                if r["rank_tier"] == "EVIDENCED" and \
                        r["status"]["status"] != "APPROVED_INDICATION":
                    cex.append({"drug": r["drug"], "key": key,
                                "reason": "EVIDENCED without approval"})
            elif f not in ("NOT_IN_CORPUS", "NO_DISEASE_ENCODING",
                           "NO_MOLECULAR_LAW"):
                cex.append({"drug": r["drug"], "key": key,
                            "reason": f"unknown finding {f}"})
            if kb_did is None and f != "NO_DISEASE_ENCODING":
                cex.append({"drug": r["drug"], "key": key,
                            "reason": "encoded finding on unencoded "
                                      "disease"})
        exposed = [r["bridge"]["finding"] for r in dd["rows"]]
        if len(exposed) != len(dd["rows"]):
            cex.append({"key": key, "reason": "a row hides its finding"})
    return _theorem_shell(
        "Theta_d bridge exposure obligation (Phase 4, P4-3)",
        "every candidate exposes its Theta_d finding; MECH_STRUCTURE_"
        "CONFLICT candidates remain visible; only Theta-satisfying "
        "approved candidates rank EVIDENCED",
        not cex, cex,
        {"rows_checked": sum(len(dd["rows"])
                             for dd in report["diseases"].values()),
         "theta_satisfied": n_satisfied,
         "mech_structure_conflicts": n_conflict},
        ["for each candidate: finding vocabulary check",
         "conflicts must surface in rank_tier",
         "EVIDENCED requires THETA_SATISFIED + APPROVED_INDICATION",
         "counterexample list is empty <=> theorem holds"])


def theorem_temporal_hermeticity(pack: RepurposingPack) -> dict:
    """P4-4: the prediction from the FULL pack is identical to the
    prediction from a pack pruned to pre-2015 molecules with the
    ground truth and post-2015 evidence removed — the prediction
    pipeline structurally cannot see post-2015 records."""
    full = predict_repurposing(pack)
    slim = _SlimPack(pack)
    pruned = predict_repurposing(slim)
    cex = []
    for key in full["diseases"]:
        a = [{k: r[k] for k in ("drug", "support_level", "axes",
                                "aggregate", "status", "rank")}
             for r in full["diseases"][key]["rows"]]
        b = [{k: r[k] for k in ("drug", "support_level", "axes",
                                "aggregate", "status", "rank")}
             for r in pruned["diseases"][key]["rows"]]
        if a != b:
            cex.append({"key": key,
                        "reason": "ranking changed when post-2015 "
                                  "records were removed"})
    return _theorem_shell(
        "temporal-hermeticity obligation (Phase 4, P4-4)",
        "repurposing predictions are invariant under removal of every "
        "post-2015 record (molecules, ground truth, evidence rows); "
        "the pre-2015 view alone reproduces them bit-for-bit",
        not cex, cex,
        {"diseases_checked": len(full["diseases"]),
         "candidates_full": full["n_candidates"],
         "candidates_pruned": pruned["n_candidates"]},
        ["predict from the full frozen pack",
         "predict from the pruned pre-2015 view",
         "deep equality of every ranked row <=> theorem holds"])


class _SlimPack:
    """A pack view carrying only pre-split molecules/evidence and no
    ground truth (drives theorem_temporal_hermeticity). Delegates the
    law channel to the underlying frozen pack."""

    def __init__(self, pack: RepurposingPack):
        self._base = pack
        self._rd = pack._rd
        view = _prune_view(pack, pack.split_year)
        self.drugs = view["drugs"]
        self.evidence = view["evidence"]
        self.split_year = pack.split_year
        self.prediction_diseases = pack.prediction_diseases
        self.diseases = pack.diseases
        self.panel = pack.panel
        self.limits = pack.limits

    # delegation to the frozen pack ------------------------------------
    def drug_channels(self, drug):
        return self._base.drug_channels(drug)

    def channel_support(self, drug, key):
        return self._base.channel_support(drug, key)

    def status_for(self, drug, key):
        return self._base.status_for(drug, key)

    def indication_keys_for(self, drug):
        return self._base.indication_keys_for(drug)

    def source_record(self, sid):
        return self._base.source_record(sid)

    def require_sources(self, sids):
        self._base.require_sources(sids)

    def _disease_key_for_id(self, did):
        return self._base._disease_key_for_id(did)


def theorem_candidate_determinism(pack: RepurposingPack) -> dict:
    """Rank integrity: permuting the frozen row order must not change
    the prediction (mirrors theorem_rank_determinism of Phase 3)."""
    import random
    base = predict_repurposing(pack)
    saved_ev = list(pack.evidence)
    saved_dr = dict(pack.drugs)
    rnd = random.Random(20261125)
    ev = saved_ev[:]
    rnd.shuffle(ev)
    pack.evidence = ev
    names = sorted(saved_dr)
    rnd.shuffle(names)
    pack.drugs = {n: saved_dr[n] for n in names}
    try:
        shuffled = predict_repurposing(pack)
    finally:
        pack.evidence = saved_ev
        pack.drugs = saved_dr
    same = base == shuffled
    return _theorem_shell(
        "candidate-rank integrity under input permutation (Phase 4)",
        "rank order is invariant under permutation of the frozen drug "
        "and evidence order (deterministic, reproducible)",
        same, [] if same else [{"reason": "permutation changed ranks"}],
        {"diseases_checked": len(base["diseases"])},
        ["predict with the frozen order",
         "shuffle drug + evidence order with a fixed seed, predict again",
         "deep equality <=> theorem holds"])


# =====================================================================
# P4-4 acceptance benchmark
# =====================================================================

def benchmark_temporal(pack: RepurposingPack, k: int = 10) -> dict:
    """Temporal repurposing benchmark: pre-2015 knowledge must recall
    the post-2015 repurposing outcomes (SGLT2i era). Reports hits,
    misses, false leads examined, and named negative controls
    honestly."""
    pred = predict_repurposing(pack)
    per = {}
    hits_total = truth_total = 0
    for key in pack.prediction_diseases:
        rows = pred["diseases"][key]["rows"]
        names = [r["drug"] for r in rows]
        truth = [g for g in pack.ground_truth
                 if g["disease_key"] == key]
        want = [g["drug"] for g in truth]
        ranks = {r["drug"]: r["rank"] for r in rows}
        topk = names[:k]
        hits = [d for d in want if d in topk]
        misses = [d for d in want if d not in topk]
        truth_total += len(want)
        hits_total += len(hits)
        # separation: every truth pair must outrank every zero-support
        # candidate (the law channel must separate, not merely include)
        zero_ranks = [r["rank"] for r in rows
                      if r["support_level"] == "none"]
        separation = (not zero_ranks) or \
            all(ranks[d] < min(zero_ranks) for d in want)
        false_leads = [{"drug": r["drug"], "rank": r["rank"],
                        "status": r["status"]["status"],
                        "note": "ranked in the pre-2015 top-5 but no "
                                "post-2015 outcome row exists"}
                       for r in rows[:5] if r["drug"] not in want]
        controls = [{"drug": d, "first_approval": pack.drugs[d]
                     ["first_approval"],
                     "note": "post-2015 molecule absent from the "
                             "pre-2015 candidate list as required"}
                    for d in sorted(pack.drugs)
                    if pack.drugs[d]["first_approval"] >= pack.split_year
                    and d not in names]
        per[key] = {
            "disease": pack.diseases[key]["name"],
            "kb_did": pack.diseases[key].get("kb_did"),
            "truth_pairs": [{"drug": g["drug"],
                             "evidence_year": g["evidence_year"],
                             "citations": g["citations"],
                             "ot_status": g["ot_status"]}
                            for g in truth],
            "candidate_count": len(rows),
            "top_%d" % k: topk,
            "truth_ranks": {d: ranks.get(d) for d in want},
            "hits": hits, "misses": misses,
            "recall_at_%d" % k: round(len(hits) / len(want), 4)
            if want else None,
            "separation_from_zero_support": separation,
            "false_leads_examined": false_leads,
            "negative_controls": controls,
            "rows": rows,
        }
    macro = round(hits_total / truth_total, 4) if truth_total else None
    theorems = [theorem_status_discipline(pack, pred),
                theorem_bridge_exposure(pack, pred),
                theorem_temporal_hermeticity(pack),
                theorem_candidate_determinism(pack)]
    return {
        "benchmark": "Phase 4 repurposing acceptance (plan section 5)",
        "k": k,
        "temporal_split_year": pack.split_year,
        "prediction_diseases": pack.prediction_diseases,
        "truth_pairs_total": truth_total,
        "hits_total": hits_total,
        "macro_recall_at_%d" % k: macro,
        "per_disease": per,
        "theorems_all_proved": all(t["proved"] for t in theorems),
        "theorem_proved": {t["theorem"]: t["proved"] for t in theorems},
        "theorem_stats": {t["theorem"]: t["stats"] for t in theorems},
        "schema_version": pack.schema_version,
        "frozen_utc": pack.frozen_utc,
        "honest_limits": pack.limits,
    }


def load_pack(verify_pin: bool = True) -> RepurposingPack:
    """Pin-checked entry point (mirrors v15.targets.load_targets)."""
    return RepurposingPack(verify_pin=verify_pin)
