#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 3 live cache refresh (P3-4 driver).

Fetches and freezes EVERY record needed by the Phase 3 target-discovery
module:

  1. gene identifier verification (HGNC REST + UniProt REST) for the
     benchmark gene set,
  2. Open Targets disease search (EFO/MONDO ids) for the 10-disease
     benchmark panel,
  3. Open Targets (target x disease) association evidence with per-
     datatype scores (genetic_association / known_drug / animal_model /
     literature),
  4. Reactome pathway stable ids (R-HSA-*) for the KB PW_* channel
     values of the panel,
  5. Europe PMC literature citations (title-filtered; E-utilities
     fallback for PMID discovery when Europe PMC search times out).

Everything is stored under v15/cache/<sha256>.json + manifest.json.
At the end it emits v15/out/phase3_verified_values.json — the
machine-verified values that the FROZEN table v15/target_data.py is
authored from (verbatim; absent data stays absent).

This is the ONLY place live network access happens. Usage:

    python3 v15/connectors/refresh_phase3_cache.py --live
    python3 v15/connectors/refresh_phase3_cache.py --check     # offline audit
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))          # apeiron/ repo root

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.abspath(os.path.join(HERE, os.pardir, "out"))
OUT_PATH = os.path.join(OUT_DIR, "phase3_verified_values.json")

from v15.connectors import base, opentargets as OT, uniprot as UP  # noqa: E402
from v15.connectors import reactome as RC, europepmc as EP          # noqa: E402

GENES = ["SLC5A2", "HMGCR", "PCSK9", "EGFR", "ABL1", "ACE", "AGTR1",
         "F10", "DPP4", "ACHE", "TNF", "CFTR", "LDLR", "NPC1L1",
         "APP", "MAPT"]

PANEL = [
    {"did": "D01", "kb_name": "Essential hypertension",
     "search": "essential hypertension", "prefer": ["MONDO:0005044"],
     "pw": "PW_VASCULAR_TONE"},
    {"did": "D02", "kb_name": "Heart failure with reduced ejection fraction",
     "search": "heart failure",
     "prefer": ["MONDO:0006993"], "pw": "PW_NEUROHORMONAL_REMODELING",
     "note": "chosen MONDO:0006993 'systolic heart failure': the OT/MONDO "
             "record closest to HFrEF (reduced EF = systolic dysfunction); "
             "the choice is deliberate and documented, not the first hit"},
    {"did": "D03",
     "kb_name": "Atrial fibrillation - stroke prophylaxis",
     "search": "atrial fibrillation", "prefer": [],
     "pw": "PW_COAGULATION_CASCADE"},
    {"did": "D05",
     "kb_name": "Primary hypercholesterolemia (high CV risk)",
     "search": "hypercholesterolemia", "prefer": [],
     "pw": "PW_CHOLESTEROL_SYNTHESIS"},
    {"did": "D08", "kb_name": "Type 2 diabetes mellitus",
     "search": "type 2 diabetes mellitus", "prefer": ["MONDO:0005148"],
     "pw": "PW_GLUCOSE_HOMEOSTASIS"},
    {"did": "D33", "kb_name": "Alzheimer's disease",
     "search": "Alzheimer disease", "prefer": [],
     "pw": "PW_CHOLINERGIC_DEFICIT"},
    {"did": "D50", "kb_name": "Chronic myeloid leukaemia (chronic phase)",
     "search": "chronic myeloid leukemia", "prefer": [],
     "pw": "PW_BCR_ABL_KINASE"},
    {"did": "D51",
     "kb_name": "EGFR-mutant advanced non-small-cell lung cancer",
     "search": "non-small cell lung carcinoma", "prefer": [],
     "pw": "PW_EGFR_SIGNALING"},
    {"did": "D54", "kb_name": "Rheumatoid arthritis (newly diagnosed)",
     "search": "rheumatoid arthritis", "prefer": [],
     "pw": "PW_AUTOREACTIVE_CYTOKINE_CASCADE"},
    {"did": "CF", "kb_name": None, "search": "cystic fibrosis",
     "prefer": ["MONDO:0009061"], "pw": None,
     "note": "non-KB benchmark disease (v14.1 corpus has no CF row); "
             "guideline target CFTR, modulator class outside the closed "
             "world — demonstrates Module B on a NOT_ENCODABLE disease"},
]

# (target symbol, panel did)
ASSOC_PAIRS = [
    ("ACE", "D01"), ("AGTR1", "D01"),
    ("SLC5A2", "D02"), ("ACE", "D02"),
    ("F10", "D03"),
    ("HMGCR", "D05"), ("PCSK9", "D05"), ("LDLR", "D05"), ("NPC1L1", "D05"),
    ("SLC5A2", "D08"), ("DPP4", "D08"),
    ("ACHE", "D33"), ("APP", "D33"), ("MAPT", "D33"),
    ("ABL1", "D50"), ("EGFR", "D51"), ("TNF", "D54"),
    ("CFTR", "CF"),
]

PATHWAY_QUERIES = {
    "PW_VASCULAR_TONE":
        {"query": "vascular smooth muscle contraction",
         "must": ["smooth muscle"],
         "note": "Reactome models vascular tone as 'Smooth Muscle "
                 "Contraction' (its umbrella pathway); token filter "
                 "'smooth muscle' accepts it, choice recorded"},
    "PW_NEUROHORMONAL_REMODELING":
        {"query": "neurohormonal remodeling",
         "must": ["neurohormonal"],
         "note": "expected ABSENT: Reactome models molecular pathways, "
                 "not organ-level remodeling; an honest absence"},
    "PW_COAGULATION_CASCADE":
        {"query": "fibrin clot formation", "must": ["fibrin"]},
    "PW_CHOLESTEROL_SYNTHESIS":
        {"query": "cholesterol biosynthesis",
         "must": ["cholesterol", "biosynthesis"]},
    "PW_GLUCOSE_HOMEOSTASIS":
        {"query": "glucose homeostasis", "must": ["glucose"]},
    "PW_CHOLINERGIC_DEFICIT":
        {"query": "acetylcholine neurotransmission",
         "must": ["acetylcholine"]},
    "PW_BCR_ABL_KINASE":
        {"query": "BCR-ABL1", "must": ["bcr-abl1"],
         "note": "Reactome search does not surface a BCR-ABL1 fusion "
                 "pathway in its results; ABSENT recorded, not guessed"},
    "PW_EGFR_SIGNALING":
        {"query": "signaling by EGFR", "must": ["egfr"]},
    "PW_AUTOREACTIVE_CYTOKINE_CASCADE":
        {"query": "cytokine signaling in immune system",
         "must": ["cytokine"]},
}

CITATIONS = [
    {"key": "PCSK9_LOF_CORONARY",
     "query": "PCSK9 sequence variations low LDL protection",
     "must": ["PCSK9", "protection"],
     "note": "loss-of-function PCSK9 -> low LDL -> protection (human "
             "genetics; supports causal direction for the D05 panel); "
             "title filter prefers the original sequence-variation paper"},
    {"key": "PCSK9_AB_EVOLOCUMAB",
     "query": "evolocumab and clinical outcomes cardiovascular disease",
     "must": ["evolocumab", "outcomes"],
     "note": "PCSK9-antibody outcome evidence (pharmacological)"},
    {"key": "IMATINIB_CML",
     "query": "imatinib BCR-ABL tyrosine kinase chronic myeloid leukemia",
     "must": ["bcr-abl", "chronic myeloid"],
     "note": "BCR-ABL-directed therapy landmark (pharmacological proof "
             "of ABL1 as the molecular intervention point in CML)"},
    {"key": "EGFR_MUT_LUNG",
     "query": "activating mutations EGFR responsiveness gefitinib lung",
     "must": ["EGFR", "mutations"]},
    {"key": "CFTR_DISCOVERY",
     "query": "identification of the cystic fibrosis gene",
     "must": ["cloning and characterization"],
     "note": "title filter pins the 1989 cloning/characterization paper "
             "(the CFTR discovery landmark) deterministically"},
    {"key": "CFTR_TRIPLE_THERAPY",
     "query": "elexacaftor tezacaftor ivacaftor cystic fibrosis",
     "must": ["elexacaftor"]},
    {"key": "EMPEROR_PRESERVED",
     "query": "empagliflozin heart failure preserved ejection fraction",
     "must": ["empagliflozin", "preserved"]},
    {"key": "DONEPEZIL_AD",
     "query": "donepezil Alzheimer's disease review",
     "must": ["donepezil"]},
    {"key": "TNF_RA_INFLIXIMAB",
     "query": "infliximab methotrexate rheumatoid arthritis",
     "must": ["infliximab", "rheumatoid"]},
    {"key": "FACTOR_XA_VTE",
     "query": "oral apixaban venous thromboembolism treatment",
     "must": ["apixaban", "venous"]},
    {"key": "MAPT_AD_ASSOC",
     "query": "MAPT tau Alzheimer disease association",
     "must": ["tau", "Alzheimer"],
     "note": "deliberate ASSOCIATION-ONLY evidence row for D33 (the "
             "anti-causal-illusion contrast target MAPT, absent from the "
             "OT association page); only association evidence exists in "
             "the frozen table, so the flag must fire"},
]


def step_genes(live):
    out = {}
    for sym in GENES:
        rec = {"symbol": sym}
        try:
            r = base.fetch_frozen(
                f"hgnc.fetch.{sym}", "https://rest.genenames.org/fetch/"
                f"symbol/{sym}",
                headers={"Accept": "application/json"},
                timeout=45, retries=2, resource="HGNC REST API",
                license_field="unrestricted academic use (HGNC data policy)",
                force_live=live)
            docs = r["payload"]["response"]["docs"]
            if docs:
                d = docs[0]
                rec.update({"hgnc_id": d.get("hgnc_id"),
                            "name": d.get("name"),
                            "ensembl": d.get("ensembl_gene_id"),
                            "uniprot_ids": d.get("uniprot_ids"),
                            "status": "VERIFIED",
                            "retrieval_utc": r["retrieval_utc"]})
            else:
                rec["status"] = "ABSENT"
                rec["detail"] = "HGNC returned no doc"
        except base.ConnectorError as exc:
            rec.update({"status": "ABSENT", "detail": str(exc)})
        # UniProt existence proof for the accession HGNC carries
        acc = (rec.get("uniprot_ids") or [None])[0]
        if acc:
            try:
                v = UP.verify_accession(acc, force_live=live)
                rec["uniprot_verify"] = v
            except base.ConnectorError as exc:
                rec["uniprot_verify"] = {"status": "ABSENT",
                                         "detail": str(exc)}
        out[sym] = rec
        print(f"  gene {sym:<8} {rec.get('status')} "
              f"hgnc={rec.get('hgnc_id')} uniprot={acc}")
    return out


def step_panel(live):
    out = {}
    for p in PANEL:
        rec = {"did": p["did"], "kb_name": p["kb_name"], "search": p["search"],
               "pw": p["pw"]}
        try:
            r = OT.search_disease(p["search"], force_live=live)
            hits = r["payload"]["data"]["search"]["hits"]
            pref = [x.replace(":", "_") for x in p["prefer"]]
            efo, label = OT.first_disease_hit(
                r, prefer_ids=pref)
            rec.update({"ot_disease_id": efo, "ot_disease_label": label,
                        "status": "VERIFIED" if efo else "ABSENT",
                        "n_hits": len(hits),
                        "retrieval_utc": r["retrieval_utc"],
                        "sha256": r["sha256"]})
        except base.ConnectorError as exc:
            rec.update({"status": "ABSENT", "detail": str(exc)})
        out[p["did"]] = rec
        print(f"  disease {p['did']:<4} {rec.get('status')} "
              f"id={rec.get('ot_disease_id')} label={rec.get('ot_disease_label')}")
    return out


# panel did -> target symbols needed from its association page
ASSOC_SYMBOLS = {
    "D01": ["ACE", "AGTR1"],
    "D02": ["SLC5A2", "ACE"],
    "D03": ["F10"],
    "D05": ["HMGCR", "PCSK9", "LDLR", "NPC1L1"],
    "D08": ["SLC5A2", "DPP4"],
    "D33": ["ACHE", "APP", "MAPT"],
    "D50": ["ABL1"],
    "D51": ["EGFR"],
    "D54": ["TNF"],
    "CF": ["CFTR"],
}


def step_associations(live, genes_out, panel_out):
    out = {}
    for did, symbols in ASSOC_SYMBOLS.items():
        p = panel_out.get(did, {})
        efo = p.get("ot_disease_id")
        if not efo:
            out[did] = {"status": "ABSENT",
                        "detail": "panel disease id missing",
                        "symbols": {}}
            print(f"  assoc  {did:<4} ABSENT (no efo id)")
            continue
        try:
            a = OT.disease_associated_targets(efo, force_live=live)
            per = OT.rows_for_symbols(a, symbols)
            sym_out = {}
            for s, info in per.items():
                row = info["row"]
                sym_out[s] = {
                    "status": "VERIFIED" if row else "NOT_IN_PAGE",
                    "detail": (None if row else
                               f"not among top {len(a['rows'])} rows "
                               "(count=" + str(a["count"]) + ")"),
                    "row": row,
                }
                dt = [f"{d['id']}:{d['score']:.2f}"
                      for d in (row or {}).get("datatypeScores", [])]
                print(f"  assoc  {did:<4} {s:<8} {sym_out[s]['status']} "
                      f"score={(row or {}).get('score')} {' '.join(dt)}")
            out[did] = {"status": "VERIFIED", "efo_id": efo,
                        "association_count": a["count"],
                        "n_rows_returned": len(a["rows"]),
                        "symbols": sym_out,
                        "sha256": a["sha256"],
                        "retrieval_utc": a["retrieval_utc"]}
        except base.ConnectorError as exc:
            out[did] = {"status": "ABSENT", "detail": str(exc),
                        "symbols": {}}
            print(f"  assoc  {did:<4} ABSENT ({exc.kind})")
    return out


def step_reactome(live):
    out = {}
    for pw, spec in PATHWAY_QUERIES.items():
        try:
            r = RC.search_pathway(spec["query"], force_live=live)
            stid = RC.best_stid(r, must_contain=spec["must"])
            label = None
            for e in RC.clean_entries(r):
                if e["stId"] == stid:
                    label = e["name"]
            out[pw] = {"status": "VERIFIED" if stid else "ABSENT",
                       "query": spec["query"], "stId": stid,
                       "label": label,
                       "note": spec.get("note", ""),
                       "sha256": r["sha256"],
                       "retrieval_utc": r["retrieval_utc"]}
        except base.ConnectorError as exc:
            out[pw] = {"status": "ABSENT", "query": spec["query"],
                       "detail": str(exc), "note": spec.get("note", "")}
        print(f"  pw {pw:<34} {out[pw]['status']} {out[pw].get('stId')}")
    return out


def step_citations(live):
    out = {}
    for spec in CITATIONS:
        try:
            c, via = EP.verify_citation(spec["key"], spec["query"],
                                        spec["must"], force_live=live)
            out[spec["key"]] = {"status": "VERIFIED", "via": via,
                                "must": spec["must"],
                                "note": spec.get("note", ""),
                                **c}
            print(f"  cite {spec['key']:<22} VERIFIED PMID:{c['pmid']} "
                  f"| {str(c.get('title'))[:60]}")
        except base.ConnectorError as exc:
            out[spec["key"]] = {"status": "ABSENT", "must": spec["must"],
                                "note": spec.get("note", ""),
                                "detail": str(exc)}
            print(f"  cite {spec['key']:<22} ABSENT ({exc.kind})")
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true",
                    help="perform live fetches (idempotent: already-"
                         "frozen names are served from cache)")
    ap.add_argument("--force-live", action="store_true",
                    help="re-fetch even frozen names (new sha256 cache "
                         "files, manifest updated)")
    ap.add_argument("--check", action="store_true",
                    help="offline completeness audit of the cache")
    args = ap.parse_args()
    if not (args.live or args.check):
        print("Refusing live work without --live (frozen-response "
              "doctrine). Use --check for an offline audit.")
        return 2

    os.makedirs(OUT_DIR, exist_ok=True)

    if args.check:
        present = base.list_frozen()
        print("frozen names present:", len(present))
        by_prefix = {}
        for n in present:
            by_prefix[n.split(".", 1)[0]] = by_prefix.get(
                n.split(".", 1)[0], 0) + 1
        for k in sorted(by_prefix):
            print(f"  {k:<10} {by_prefix[k]}")
        print("CACHE CHECK:", "OK" if present else "EMPTY")
        return 0 if present else 1

    live = args.live
    force = args.force_live
    if force:
        # force-live path: clear the manifest so every name re-fetches
        if os.path.exists(base.MANIFEST_PATH):
            os.remove(base.MANIFEST_PATH)

    print("== Phase 3 live refresh ==")
    refetch = force           # --force-live: bypass cache on every call
    genes = step_genes(refetch)
    panel = step_panel(refetch)
    assoc = step_associations(refetch, genes, panel)
    react = step_reactome(refetch)
    cites = step_citations(refetch)

    n_absent = sum(1 for d in (genes, panel, assoc, react, cites)
                   for v in d.values() if v.get("status") == "ABSENT")
    result = {
        "generated_utc": base.utcnow(),
        "genes": genes, "panel": panel, "associations": assoc,
        "reactome": react, "citations": cites,
        "absent_count": n_absent,
        "frozen_names": base.list_frozen(),
    }
    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(result, fh, indent=1, sort_keys=True)
    print(f"\nwrote {OUT_PATH}")
    print(f"ABSENT records: {n_absent} (reported, never fabricated)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
