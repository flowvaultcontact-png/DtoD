"""ClinicalTrials.gov connector — Phase 7 dataset hooks (P7-2).

METADATA + ACCESSION ONLY. The modern API v2 endpoint is used:

    https://clinicaltrials.gov/api/v2/studies?query.cond=...&query.intr=...

Everything is served through the frozen-response cache of
``connectors.base``; a failed fetch raises ConnectorError — nothing is
invented.

P7-2 structural guarantee (machine-checked downstream by theorem F4):
the request pins ``fields`` to exactly six whitelisted protocolSection
MODULE paths, so the served payload cannot even carry outcome or
results content (outcomesModule / resultsSection are never requested).
The extraction below additionally refuses any non-whitelisted module
and scans for results tokens as a defense in depth.

Fields kept per study (all public registry metadata):
    nctId, briefTitle, overallStatus, phases, studyType, startDate,
    conditions, intervention names, arm-group LABELS (no outcome data),
    leadSponsor, enrollmentCount.

Resource version note: ClinicalTrials.gov API v2 reports no
machine-readable build version, so resource_version is recorded as the
verbatim retrieval window (same honesty pattern as the Phase 3/4
connectors).
"""

from . import base

STUDIES = "https://clinicaltrials.gov/api/v2/studies"
RESOURCE = "ClinicalTrials.gov API v2"
LICENSE = "SEE_TERMS (ClinicalTrials.gov public registry metadata)"

# Module whitelist — the ONLY protocolSection modules ever requested
# or read. Requesting exactly these module paths means outcome/results
# content is structurally absent from the payload.
_ALLOWED_MODULES = ("identificationModule", "statusModule",
                    "sponsorCollaboratorsModule", "designModule",
                    "conditionsModule", "armsInterventionsModule")
_FIELDS = "|".join(f"protocolSection.{m}" for m in _ALLOWED_MODULES)

# Defense in depth: tokens that would constitute synthesized results.
_FORBIDDEN_TOKENS = ("resultSection", "outcomeMeasure", "primaryOutcome",
                     "secondaryOutcome", "effectSize", "pValue")


def study(nct_id, timeout=45, retries=2, force_live=False):
    """One study record, metadata fields only (whitelist enforced)."""
    name = f"ctgov.study.{nct_id}"
    rec = base.fetch_frozen(name, STUDIES,
                            params={"query.id": nct_id, "pageSize": "1",
                                    "fields": _FIELDS},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    studies = rec["payload"].get("studies", [])
    if not studies:
        raise base.ConnectorError("NO_STUDY", name, STUDIES,
                                  f"{nct_id} resolved to no record")
    return _study_row(rec, studies[0])


def search_studies(query_cond, query_intr=None, limit=20, timeout=60,
                   retries=2, force_live=False):
    """Search by condition (optionally + intervention). Returns up to
    `limit` metadata rows; the logical name is deterministic in the
    query pair so the frozen cache is reproducible."""
    name = f"ctgov.search.{base.slugify(f'{query_intr or ""} IN {query_cond}')}"
    params = {"query.cond": query_cond, "pageSize": str(limit),
              "fields": _FIELDS, "countTotal": "true"}
    if query_intr:
        params["query.intr"] = query_intr
    rec = base.fetch_frozen(name, STUDIES, params=params,
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    payload = rec["payload"]
    rows = [_study_row(rec, s) for s in payload.get("studies", [])]
    return {"query": {"cond": query_cond, "intr": query_intr},
            "total_count": payload.get("totalCount"),
            "studies": rows,
            "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}


def _study_row(rec, s):
    """Distill a protocolSection study dict under the whitelist.

    Raises on ANY module outside the whitelist or ANY results token: a
    payload carrying results content cannot silently pass through the
    metadata lane."""
    proto = s.get("protocolSection", {})
    for module in proto:
        if module not in _ALLOWED_MODULES:
            raise base.ConnectorError(
                "FORBIDDEN_MODULE", rec["name"], rec["url"],
                f"protocolSection module {module!r} is outside the "
                "P7-2 metadata whitelist")
    blob = _json_blob(proto)
    for tok in _FORBIDDEN_TOKENS:
        if tok in blob:
            raise base.ConnectorError(
                "FORBIDDEN_CONTENT", rec["name"], rec["url"],
                f"results content token {tok!r} found — the P7-2 lane "
                "never carries synthesized results")
    idm = proto.get("identificationModule", {})
    stm = proto.get("statusModule", {})
    spm = proto.get("sponsorCollaboratorsModule", {})
    dsm = proto.get("designModule", {})
    con = proto.get("conditionsModule", {})
    arm = proto.get("armsInterventionsModule", {})
    arms = arm.get("armGroups", []) or []
    inter = arm.get("interventions", []) or []
    enr = dsm.get("enrollmentInfo", {}) or {}
    return {
        "nct_id": idm.get("nctId"),
        "brief_title": idm.get("briefTitle"),
        "overall_status": stm.get("overallStatus"),
        "phases": list(dsm.get("phases", []) or []),
        "study_type": dsm.get("studyType"),
        "start_date": (stm.get("startDateStruct") or {}).get("date"),
        "conditions": list(con.get("conditions", []) or []),
        "interventions": [i.get("name") for i in inter if i.get("name")],
        "arm_labels": [a.get("label") for a in arms if a.get("label")],
        "lead_sponsor": (spm.get("leadSponsor") or {}).get("name"),
        "enrollment_count": enr.get("count"),
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }


def _json_blob(obj):
    """Serialize a dict to a flat string (forbidden-token scan)."""
    return base.json.dumps(obj, sort_keys=True, default=str)
