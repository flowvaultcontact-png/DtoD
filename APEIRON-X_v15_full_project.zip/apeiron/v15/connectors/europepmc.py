"""Europe PMC connector — P3-4 skeleton.

Citation verification for literature evidence (plan P3-1: "Europe PMC
citations with ids — never fabricated"). Two access paths:

  * verify_pmid(pmid)   — EXT_ID lookup (fast, reliable).
  * search_literature() — keyword search. The Europe PMC search endpoint
    is occasionally slow (>45 s); a bounded attempt is made, and on
    timeout the connector falls back to NCBI E-utilities esearch for
    PMID discovery, then verifies each candidate through Europe PMC
    EXT_ID metadata. The fallback is recorded in the manifest and in
    the limitation fields of the frozen table (nothing guessed).

Client-side title filtering (`title_matches`) is applied by the caller:
a candidate counts only if its title contains every required token —
so a wrong-hit PMID (e.g. a completely unrelated paper sharing a
remembered id) can never enter the frozen table.
"""

from . import base

SEARCH = "https://www.ebi.ac.uk/europepmc/webservices/rest/search"
EUTILS = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
RESOURCE = "Europe PMC REST"
RESOURCE_FALLBACK = "NCBI E-utilities (esearch; PMID discovery only)"
LICENSE = "SEE_TERMS (Europe PMC; PubMed abstract metadata, vendor terms)"


def verify_pmid(pmid, timeout=45, retries=2, force_live=False):
    name = f"epmc.extid.{pmid}"
    rec = base.fetch_frozen(name, SEARCH,
                            params={"query": f"EXT_ID:{pmid} AND SRC:MED",
                                    "format": "json", "pageSize": "1"},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    results = rec["payload"]["resultList"]["result"]
    if not results:
        raise base.ConnectorError("NO_CITATION", name, SEARCH,
                                  f"EXT_ID {pmid} resolved to no record")
    r = results[0]
    return _citation(pmid, r, rec)


def search_literature(query, limit=5, timeout=60, retries=1,
                      force_live=False):
    name = f"epmc.search.{base.slugify(query)}"
    rec = base.fetch_frozen(name, SEARCH,
                            params={"query": query, "format": "json",
                                    "pageSize": str(limit)},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    return rec["payload"]["resultList"]["result"]


def eutils_esearch(term, limit=5, timeout=30, retries=1, force_live=False):
    """Fallback PMID discovery (NCBI E-utilities)."""
    name = f"pubmed.esearch.{base.slugify(term)}"
    rec = base.fetch_frozen(name, EUTILS,
                            params={"db": "pubmed", "term": term,
                                    "retmode": "json", "retmax": str(limit),
                                    "sort": "relevance"},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE_FALLBACK,
                            license_field=LICENSE, force_live=force_live)
    return rec["payload"]["esearchresult"].get("idlist", [])


def _citation(pmid, r, rec):
    return {"pmid": r.get("id", pmid),
            "title": r.get("title"),
            "journal": r.get("journalTitle"),
            "year": r.get("pubYear"),
            "authors": (r.get("authorString") or "")[:120],
            "doi": r.get("doi"),
            "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}


def title_matches(citation, must_contain):
    t = (citation.get("title") or "").lower()
    return all(tok.lower() in t for tok in must_contain)


def verify_citation(key, query, must_contain, limit=8, force_live=False):
    """Find + verify one citation. Europe PMC search first; candidates are
    title-filtered; if none matches there (or the search fails), the
    E-utilities fallback runs; every candidate is verified through Europe
    PMC EXT_ID metadata. Returns (citation, via) or raises
    ConnectorError("CITATION_NOT_FOUND", ...) — absence is recorded,
    nothing invented.
    """
    # path 1: Europe PMC keyword search
    try:
        for r in search_literature(query, limit=limit, force_live=force_live):
            c = _citation(r.get("id"), r,
                          {"sha256": None, "retrieval_utc": None})
            if title_matches(c, must_contain):
                full = verify_pmid(c["pmid"], force_live=force_live)
                return full, "europepmc.search"
    except base.ConnectorError:
        pass                                  # fall through to fallback
    # path 2: NCBI esearch -> Europe PMC EXT_ID verification
    ids = eutils_esearch(query, limit=max(limit, 5), force_live=force_live)
    for pmid in ids:
        try:
            c = verify_pmid(pmid, force_live=force_live)
        except base.ConnectorError:
            continue
        if title_matches(c, must_contain):
            return c, "europepmc.extid_via_eutils"
    raise base.ConnectorError(
        "CITATION_NOT_FOUND", key, "",
        f"no Europe PMC record matching title tokens {must_contain} for "
        f"query {query!r} (absence recorded, nothing invented)")
