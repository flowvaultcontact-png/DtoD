#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 7 live cache refresh (P7-2 driver).

Fetches and freezes EVERY dataset-metadata record needed by Module F
(experimental-validation intelligence):

  1. ClinicalTrials.gov API v2 study metadata (whitelisted registry
     fields; NEVER any results section) for the deterministic
     intervention x condition panel over the Phase 4 benchmark
     candidates and diseases,
  2. GEO series metadata (accession + summary only) for the
     mechanism/disease transcriptome panel,
  3. one negative-control query (a generated-molecule id, which cannot
     have registry records) recorded as an honest absence.

This is the ONLY place live network access happens for Phase 7.
Usage:
    python3 v15/connectors/refresh_phase7_cache.py --live
    python3 v15/connectors/refresh_phase7_cache.py --check    # offline audit
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))          # apeiron/ repo root

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.abspath(os.path.join(HERE, os.pardir, "out"))
OUT_PATH = os.path.join(OUT_DIR, "phase7_verified_values.json")

from v15.connectors import base                      # noqa: E402
from v15.connectors import clinicaltrials as CT      # noqa: E402
from v15.connectors import geo as GEO                # noqa: E402

# ------------------------------------------------------------------
# Deterministic dataset panel (authored; every query frozen by name)
# ------------------------------------------------------------------
# (panel id, kind, intervention, condition/query)
CT_PANEL = [
    ("CT01", "dapagliflozin", "chronic kidney disease"),
    ("CT02", "dapagliflozin", "heart failure"),
    ("CT03", "empagliflozin", "chronic kidney disease"),
    ("CT04", "empagliflozin", "heart failure"),
    ("CT05", "canagliflozin", "diabetic kidney disease"),
    ("CT06", "lisinopril", "heart failure"),
    ("CT07", "losartan", "chronic kidney disease"),
    ("CT08", "spironolactone", "heart failure"),
    ("CT09", "metformin", "chronic kidney disease"),
    ("CT10", "finerenone", "chronic kidney disease"),
]

GEO_PANEL = [
    ("GE01", "dapagliflozin kidney"),
    ("GE02", "empagliflozin heart"),
    ("GE03", "SGLT2 inhibitor diabetic nephropathy"),
    ("GE04", "diabetic kidney disease glomerulus transcriptome"),
    ("GE05", "heart failure myocardium RNA"),
]

# Negative control: a GENERATED molecule id cannot have registry records.
NEGATIVE_CONTROL = "APXD-0001"


def fetch_all(live: bool) -> dict:
    out = {"ctgov": [], "geo": [], "absences": [],
           "negative_control": {"query": NEGATIVE_CONTROL}}

    # -- ClinicalTrials.gov lane -------------------------------------
    for pid, intr, cond in CT_PANEL:
        logical = f"ctgov.search.{base.slugify(f'{intr} IN {cond}')}"
        try:
            res = CT.search_studies(cond, query_intr=intr, limit=20,
                                    force_live=live)
            studies = res["studies"]
            n_found = len(studies)
            print(f"[ ct.gov] {pid} {intr} IN {cond}: {n_found} studies"
                  f" (total={res['total_count']})")
            out["ctgov"].append({
                "panel_id": pid, "query": {"intr": intr, "cond": cond},
                "logical_name": logical,
                "sha256": res["sha256"],
                "retrieval_utc": res["retrieval_utc"],
                "total_count": res["total_count"],
                "studies": studies,
            })
        except base.ConnectorError as exc:
            print(f"[ ct.gov] {pid} {intr} IN {cond}: ABSENT ({exc.kind})")
            out["absences"].append({
                "panel_id": pid, "lane": "ctgov", "logical_name": logical,
                "kind": exc.kind, "detail": str(exc)[:200]})

    # -- GEO lane -----------------------------------------------------
    for pid, term in GEO_PANEL:
        logical = f"geo.search.{base.slugify(term)}"
        try:
            res = GEO.search_series(term, limit=8, force_live=live)
            print(f"[    geo] {pid} {term!r}: {len(res['series'])} series")
            out["geo"].append({
                "panel_id": pid, "query": term,
                "logical_name": logical,
                "sha256": res["sha256"],
                "retrieval_utc": res["retrieval_utc"],
                "series": res["series"],
            })
        except base.ConnectorError as exc:
            print(f"[    geo] {pid} {term!r}: ABSENT ({exc.kind})")
            out["absences"].append({
                "panel_id": pid, "lane": "geo", "logical_name": logical,
                "kind": exc.kind, "detail": str(exc)[:200]})

    # -- negative control (structural absence, proven offline too) ----
    out["negative_control"]["absence_reason"] = (
        "GENERATED_MOLECULE_HAS_NO_REGISTRY_RECORD — a Phase 5 generated "
        "candidate is new, so no trial or dataset can exist for it; the "
        "validation plan records this absence instead of guessing.")
    print(f"[control] {NEGATIVE_CONTROL}: no registry record can exist "
          "(recorded absence, never guessed)")

    # provenance summary over every frozen payload actually served
    out["cache_summary"] = {
        "ctgov_queries": len(out["ctgov"]),
        "geo_queries": len(out["geo"]),
        "ctgov_studies": sum(len(r["studies"]) for r in out["ctgov"]),
        "geo_series": sum(len(r["series"]) for r in out["geo"]),
        "absences": len(out["absences"]),
    }
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true",
                    help="perform live fetches (only sanctioned network path)")
    ap.add_argument("--check", action="store_true",
                    help="offline audit of the frozen cache")
    args = ap.parse_args()
    if args.live:
        out = fetch_all(live=True)
        os.makedirs(OUT_DIR, exist_ok=True)
        with open(OUT_PATH, "w", encoding="utf-8") as fh:
            json.dump(out, fh, indent=1, sort_keys=True)
        print(f"\n[write] {OUT_PATH}")
        print(f"[summary] {json.dumps(out['cache_summary'], sort_keys=True)}")
        return 0
    # offline audit
    missing = []
    for pid, intr, cond in CT_PANEL:
        logical = f"ctgov.search.{base.slugify(f'{intr} IN {cond}')}"
        if not base.is_frozen(logical):
            missing.append(logical)
    for pid, term in GEO_PANEL:
        logical = f"geo.search.{base.slugify(term)}"
        if not base.is_frozen(logical):
            missing.append(logical)
    if missing:
        for m in missing:
            print(f"[ABSENT] {m}")
        return 1
    print("[check] all Phase 7 dataset payloads are frozen (offline OK)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
