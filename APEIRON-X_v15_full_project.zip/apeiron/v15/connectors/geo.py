"""GEO connector — Phase 7 dataset hooks (P7-2).

METADATA + ACCESSION ONLY. NCBI E-utilities over the `gds` database:

    esearch.fcgi?db=gds&term=...   -> UID discovery
    esummary.fcgi?db=gds&id=...    -> Series/DataSet metadata

Everything is served through the frozen-response cache of
``connectors.base``; a failed fetch raises ConnectorError — nothing is
invented. Raw expression matrices are NEVER fetched: the connector
keeps only the Series accession, title, summary, organism, sample
count, platform and series type (metadata that identifies the dataset
so a researcher can retrieve it themselves). This is the P7-2
"metadata + accession records only; results never synthesized"
doctrine, machine-checked downstream (theorem F4).
"""

from . import base

ESEARCH = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi"
ESUMMARY = "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi"
RESOURCE = "NCBI Gene Expression Omnibus (GEO, via E-utilities)"
RESOURCE_DISCOVERY = "NCBI E-utilities (esearch; UID discovery only)"
LICENSE = "SEE_TERMS (NCBI public data; vendor terms)"

# Fields this connector may carry out of an esummary document-summary
# row. Anything else (per-sample data, value matrices) is forbidden.
_ALLOWED_SUMMARY_KEYS = ("uid", "accession", "gdstype", "title", "summary",
                         "taxon", "n_samples", "gpl", "platformtitle",
                         "subsetinfo", "pdat", "gse")


def search_series(term, limit=8, timeout=45, retries=2, force_live=False):
    """Term search returning up to `limit` dataset metadata rows."""
    name = f"geo.search.{base.slugify(term)}"
    rec = base.fetch_frozen(name, ESEARCH,
                            params={"db": "gds", "term": term,
                                    "retmode": "json", "retmax": str(limit)},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE_DISCOVERY,
                            license_field=LICENSE, force_live=force_live)
    uids = rec["payload"].get("esearchresult", {}).get("idlist", [])
    if not uids:
        return {"query": term, "series": [], "total": 0,
                "sha256": rec["sha256"], "retrieval_utc": rec["retrieval_utc"]}
    return {"query": term, "series": summarize(uids, force_live=force_live),
            "total": len(uids), "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}


def summarize(uids, timeout=45, retries=2, force_live=False):
    """esummary metadata for the given gds UIDs (whitelist enforced)."""
    uids = ",".join(str(u) for u in uids)
    name = f"geo.summary.{base.slugify(uids)}"
    rec = base.fetch_frozen(name, ESUMMARY,
                            params={"db": "gds", "id": uids,
                                    "retmode": "json"},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    rows = []
    result = rec["payload"].get("result", {})
    for uid in (result.get("uids") or []):
        doc = result.get(str(uid), {})
        if not isinstance(doc, dict):
            continue
        row = {k: doc.get(k) for k in _ALLOWED_SUMMARY_KEYS}
        # normalize the esummary keys (gdstype/taxon/gpl/pdat)
        platform = row.get("gpl")
        ptitle = row.get("platformtitle")
        rows.append({
            "uid": str(row.get("uid")),
            "accession": row.get("accession"),
            "series_type": row.get("gdstype"),
            "title": row.get("title"),
            "summary": (row.get("summary") or "")[:280],
            "organism": row.get("taxon"),
            "n_samples": row.get("n_samples"),
            "platform": f"{platform} ({ptitle})" if ptitle else platform,
            "last_update": row.get("pdat"),
        })
    return rows
