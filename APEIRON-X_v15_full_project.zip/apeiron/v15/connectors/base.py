"""APEIRON-X v15 — frozen-response fetcher base (P3-4).

Doctrine (V15_IMPLEMENTATION_PLAN §4 P3-4):
  * A fetcher stores the RAW response together with retrieval metadata
    under ``v15/cache/<sha256(raw)>.json``; a manifest maps logical names
    to frozen payloads so downstream code can consume them WITHOUT network.
  * Derivation code (targets ranking, benchmarks, tests) consumes ONLY the
    frozen cache / frozen tables — the C0 hermeticity doctrine of the
    correspondence core carries into v15 integration.
  * NO FABRICATION: a failed or timed-out fetch raises ConnectorError with
    a named field; absent data is reported as absent. Nothing is ever
    invented to fill a gap.

Only the stdlib is used (urllib), so the skeleton has no dependency of its
own. Live network access happens exclusively through an explicit
``--live`` tool (``refresh_phase3_cache.py``); unit tests and the cascade
never touch the network.
"""

import base64
import datetime
import hashlib
import json
import os
import re
import time
import urllib.parse
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE_DIR = os.path.abspath(os.path.join(HERE, os.pardir, "cache"))
MANIFEST_PATH = os.path.join(CACHE_DIR, "manifest.json")

UA = "APEIRON-X-v15-phase3-connector (research corpus builder; no clinical use)"


class ConnectorError(RuntimeError):
    """Raised instead of inventing data. `kind` names the failure field."""

    def __init__(self, kind, name, url, detail):
        super().__init__(f"{kind} [{name}] {url}: {detail}")
        self.kind = kind          # e.g. "FETCH_FAILED", "ABSENT_CACHE"
        self.name = name
        self.url = url
        self.detail = detail


def utcnow() -> str:
    return datetime.datetime.now(datetime.timezone.utc).strftime(
        "%Y-%m-%dT%H:%M:%SZ")


def slugify(name: str) -> str:
    """Deterministic logical-name slug for manifest keys."""
    s = re.sub(r"[^A-Za-z0-9]+", "_", name).strip("_").lower()
    return s[:60] if s else "unnamed"


def _http(method, url, params, data_bytes, headers, timeout, retries, name):
    """One HTTP exchange with bounded retries. Raises, never fabricates."""
    if params:
        url = url + "?" + urllib.parse.urlencode(params)
    headers = dict(headers or {})
    headers.setdefault("User-Agent", UA)
    last_exc = None
    for attempt in range(retries + 1):
        req = urllib.request.Request(url, data=data_bytes, method=method,
                                     headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.getcode(), resp.read(), resp.headers.get_content_type()
        except Exception as exc:                     # noqa: BLE001 — connector
            last_exc = exc
            time.sleep(1.5 * (attempt + 1))
    raise ConnectorError("FETCH_FAILED", name, url,
                         f"{type(last_exc).__name__}: {last_exc}")


def _load_manifest() -> dict:
    if not os.path.exists(MANIFEST_PATH):
        return {}
    with open(MANIFEST_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def _save_manifest(manifest: dict) -> None:
    os.makedirs(CACHE_DIR, exist_ok=True)
    tmp = MANIFEST_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=1, sort_keys=True)
    os.replace(tmp, MANIFEST_PATH)


def cache_path_for(digest: str) -> str:
    return os.path.join(CACHE_DIR, digest + ".json")


def fetch_frozen(name, url, method="GET", params=None, data=None,
                 headers=None, timeout=45, retries=2, resource="",
                 license_field="SEE_TERMS", force_live=False) -> dict:
    """Fetch (once) and freeze; or serve the previously frozen payload.

    Returns {"name", "url", "method", "retrieval_utc", "http_status",
             "sha256", "resource", "license", "content_type", "payload"}.

    The cache file ``<sha256>.json`` contains the retrieval metadata plus
    the parsed payload (JSON APIs) or a base64 blob (any other content
    type). The sha256 is always of the RAW response bytes, so the frozen
    artifact is byte-exact for audit.
    """
    manifest = _load_manifest()
    if not force_live and name in manifest:
        return load_frozen(name)

    data_bytes = None
    if data is not None:
        data_bytes = data if isinstance(data, bytes) else \
            json.dumps(data).encode("utf-8")

    status, raw, ctype = _http(method, url, params, data_bytes, headers,
                               timeout, retries, name)
    digest = hashlib.sha256(raw).hexdigest()
    try:
        payload = json.loads(raw.decode("utf-8"))
        payload_kind = "json"
    except (UnicodeDecodeError, json.JSONDecodeError):
        payload = base64.b64encode(raw).decode("ascii")
        payload_kind = "base64"

    record = {
        "name": name,
        "url": url,
        "method": method,
        "params": {k: v for k, v in (params or {}).items()},
        "retrieval_utc": utcnow(),
        "http_status": status,
        "sha256": digest,
        "resource": resource,
        "license": license_field,
        "content_type": ctype,
        "payload_kind": payload_kind,
        "payload": payload,
    }
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = cache_path_for(digest)
    if not os.path.exists(path):
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(record, fh, indent=1, sort_keys=True)
        os.replace(tmp, path)
    manifest[name] = {k: record[k] for k in
                      ("url", "method", "retrieval_utc", "http_status",
                       "sha256", "resource", "license", "content_type")}
    _save_manifest(manifest)
    return record


def load_frozen(name) -> dict:
    """Serve a frozen payload by logical name. Absence is reported, and
    raises ConnectorError('ABSENT_CACHE', ...) — never fabricated."""
    manifest = _load_manifest()
    if name not in manifest:
        raise ConnectorError(
            "ABSENT_CACHE", name, "",
            "no frozen response under this logical name; run the "
            "--live refresh tool to create one (absence is reported, "
            "never filled by invention)")
    meta = manifest[name]
    path = cache_path_for(meta["sha256"])
    if not os.path.exists(path):
        raise ConnectorError("ABSENT_CACHE", name, path,
                             "manifest points to a missing cache file")
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def is_frozen(name) -> bool:
    return name in _load_manifest()


def list_frozen() -> list:
    return sorted(_load_manifest())


def strip_html(text: str) -> str:
    """Reactome labels carry <span class="highlighting"> fragments; strip
    them for clean display (the raw payload stays frozen unmodified)."""
    return re.sub(r"<[^>]+>", "", text or "")
