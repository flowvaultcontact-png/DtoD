"""Reactome Content Service connector — P3-4 skeleton.

Searches human pathways by text and returns stable ids (R-HSA-*). The
service annotates query terms with <span> highlighting in the label; the
raw payload is frozen verbatim, and `clean_entries()` only strips those
display tags for the derived table (documented, non-destructive at the
source level).
"""

from . import base

SEARCH = "https://reactome.org/ContentService/search/query"
RESOURCE = "Reactome Content Service (search)"
LICENSE = "CC-BY-4.0"


def search_pathway(query, timeout=45, retries=2, force_live=False):
    name = f"reactome.{base.slugify(query)}"
    params = {"query": query, "species": "Homo sapiens", "types": "Pathway"}
    rec = base.fetch_frozen(name, SEARCH, params=params, timeout=timeout,
                            retries=retries, resource=RESOURCE,
                            license_field=LICENSE, force_live=force_live)
    payload = rec["payload"]
    entries = []
    for group in payload.get("results", []):
        for e in group.get("entries", []):
            entries.append({"stId": e.get("stId"),
                            "name": e.get("name"),
                            "species": e.get("species"),
                            "dbId": e.get("dbId")})
    return {"query": query, "rowCount": payload.get("rowCount"),
            "numberOfMatches": payload.get("numberOfMatches"),
            "entries": entries,
            "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}


def clean_entries(search_result):
    """Return entries with display tags stripped (raw stays frozen)."""
    out = []
    for e in search_result["entries"]:
        e = dict(e)
        e["name"] = base.strip_html(e.get("name") or "")
        out.append(e)
    return out


def best_stid(search_result, must_contain=(), prefer_exact=None):
    """Deterministic pick from cleaned entries: prefer a name that contains
    every `must_contain` token (case-insensitive); exact match wins; ties
    broken by stable id. Returns stId or None (absence is honest)."""
    cands = clean_entries(search_result)
    tokens = [t.lower() for t in must_contain]
    hits = []
    for e in cands:
        nm = (e.get("name") or "").lower()
        if tokens and not all(t in nm for t in tokens):
            continue
        hits.append(e)
    if not hits:
        return None
    if prefer_exact:
        for e in hits:
            if (e.get("name") or "").lower() == prefer_exact.lower():
                return e["stId"]
    hits.sort(key=lambda e: (e.get("stId") or ""))
    return hits[0]["stId"]
