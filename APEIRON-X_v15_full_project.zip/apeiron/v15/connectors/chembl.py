"""ChEMBL webresource connector — Phase 4 (Module C drug data).

Endpoints used (verified live, 2026-11-25):
  * molecule record  : {CORE}/molecule/{id}.json
                       -> first_approval, withdrawn_flag, maximum_phase,
                          pref_name, molecule_type
  * mechanisms       : {CORE}/mechanism.json?molecule_chembl_id={id}
                       -> action_type + target_chembl_id rows
  * drug indications : {CORE}/drug_indication.json?molecule_chembl_id={id}
                       -> mesh_indication_id + max_phase rows

NOTE: the live ChEMBL REST base is /chembl/api/data/ (the older
/chembl/api/core/ path returns HTTP 404 on the current build; same for
a release /status.json probe — none exists, so resource_version is
recorded as the verbatim retrieval window, same honesty pattern as the
Phase 3 connectors). Everything is served through the frozen-response
cache of connectors.base; a failed fetch raises ConnectorError —
nothing is invented.
"""

from . import base

CORE = "https://www.ebi.ac.uk/chembl/api/data"
RESOURCE = "ChEMBL webresource (REST)"
LICENSE = "CC-BY-4.0"


def molecule(chembl_id, timeout=60, retries=2, force_live=False):
    """Distilled molecule record (approval year anchors the temporal
    split of the Phase 4 benchmark)."""
    name = f"chembl.molecule.{chembl_id}"
    rec = base.fetch_frozen(name, f"{CORE}/molecule/{chembl_id}.json",
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    m = rec["payload"]
    return {
        "chembl_id": chembl_id,
        "pref_name": m.get("pref_name"),
        "molecule_type": m.get("molecule_type"),
        "first_approval": m.get("first_approval"),
        "withdrawn_flag": bool(m.get("withdrawn_flag")),
        "withdrawn_reason": m.get("withdrawn_reason"),
        "maximum_phase": m.get("maximum_phase"),
        "usan_stem": (m.get("usan", {}) or {}).get("usan_stem"),
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }


def mechanisms(chembl_id, limit=50, timeout=60, retries=2, force_live=False):
    """Mechanism-of-action rows (action type + ChEMBL target id)."""
    name = f"chembl.mechanisms.{chembl_id}"
    rec = base.fetch_frozen(name, f"{CORE}/mechanism.json",
                            params={"molecule_chembl_id": chembl_id,
                                    "limit": str(limit)},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    rows = rec["payload"].get("mechanisms", [])
    return {
        "chembl_id": chembl_id,
        "rows": [{"action_type": r.get("action_type"),
                  "target_chembl_id": r.get("target_chembl_id"),
                  "mechanism_of_action": r.get("mechanism_of_action")}
                 for r in rows],
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }


def indications(chembl_id, limit=200, timeout=60, retries=2,
                force_live=False):
    """Drug-indication rows (MeSH indication + max phase)."""
    name = f"chembl.indications.{chembl_id}"
    rec = base.fetch_frozen(name, f"{CORE}/drug_indication.json",
                            params={"molecule_chembl_id": chembl_id,
                                    "limit": str(limit)},
                            timeout=timeout, retries=retries,
                            resource=RESOURCE, license_field=LICENSE,
                            force_live=force_live)
    rows = rec["payload"].get("drug_indications", [])
    return {
        "chembl_id": chembl_id,
        "rows": [{"mesh_indication_id": r.get("mesh_indication_id"),
                  "mesh_heading": r.get("mesh_heading"),
                  "max_phase": r.get("max_phase")}
                 for r in rows],
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }
