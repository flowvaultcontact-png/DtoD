"""APEIRON-X v15 connectors — Phase 3 skeleton (P3-4).

Modules:
  base       — frozen-response fetcher (sha256-named cache + manifest)
  opentargets — disease/target search + association evidence (GraphQL)
  uniprot    — reviewed protein-entry verification
  reactome   — pathway search (R-HSA stable ids)
  europepmc  — literature citation verification (with NCBI eutils fallback)

Live access only via refresh_phase3_cache.py --live; everything else
consumes the frozen cache.
"""
