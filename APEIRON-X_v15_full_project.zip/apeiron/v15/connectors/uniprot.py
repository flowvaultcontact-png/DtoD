"""UniProtKB connector — P3-4 skeleton.

Verifies reviewed (Swiss-Prot) human protein entries for a gene symbol:
accession, entry name, protein name, gene names. Machine verification
only; a symbol that resolves to nothing is reported as absent.
"""

from . import base

SEARCH = "https://rest.uniprot.org/uniprotkb/search"
ENTRY = "https://rest.uniprot.org/uniprotkb/{acc}.json"
RESOURCE = "UniProtKB REST (reviewed Swiss-Prot)"
LICENSE = "CC-BY-4.0"


def resolve_gene(symbol, timeout=45, retries=2, force_live=False):
    """Reviewed human entry for a gene symbol (gene_exact query)."""
    name = f"uniprot.resolve.{base.slugify(symbol)}"
    params = {
        "query": f"(gene:{symbol}) AND (organism_id:9606) AND (reviewed:true)",
        "fields": "accession,id,protein_name,gene_names,organism_name",
        "format": "json",
        "size": "1",
    }
    rec = base.fetch_frozen(name, SEARCH, params=params, timeout=timeout,
                            retries=retries, resource=RESOURCE,
                            license_field=LICENSE, force_live=force_live)
    results = rec["payload"].get("results", [])
    return {"symbol": symbol, "n_results": len(results),
            "entry": results[0] if results else None,
            "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}


def verify_accession(acc, timeout=45, retries=2, force_live=False):
    """Fetch a specific reviewed entry by accession (existence proof)."""
    name = f"uniprot.entry.{acc}"
    rec = base.fetch_frozen(name, ENTRY.format(acc=acc), timeout=timeout,
                            retries=retries, resource=RESOURCE,
                            license_field=LICENSE, force_live=force_live)
    payload = rec["payload"]
    return {"accession": acc,
            "primaryAccession": payload.get("primaryAccession"),
            "uniProtkbId": payload.get("uniProtkbId"),
            "proteinName": (payload.get("proteinDescription", {})
                             .get("recommendedName", {})
                             .get("fullName", {}).get("value")),
            "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}


def entry_function(acc, timeout=45, retries=2, force_live=False):
    """Function-comment text of a reviewed entry (Phase 4: anchors the
    target-channel law table, e.g. SLC5A2 proximal-tubule glucose
    reabsorption). The full frozen payload stays in the cache; only an
    excerpt (600 chars) is distilled. Absence is reported as None, and
    the sha256 still pins the verbatim record."""
    name = f"uniprot.function.{acc}"
    rec = base.fetch_frozen(name, ENTRY.format(acc=acc), timeout=timeout,
                            retries=retries, resource=RESOURCE,
                            license_field=LICENSE, force_live=force_live)
    payload = rec["payload"]
    func = ""
    for c in payload.get("comments", []):
        if c.get("texts"):
            t = " ".join(x.get("value", "") for x in c["texts"])
            func = t.strip()
            break
    return {"accession": acc,
            "function_excerpt": func[:600] if func else None,
            "sha256": rec["sha256"],
            "retrieval_utc": rec["retrieval_utc"]}
