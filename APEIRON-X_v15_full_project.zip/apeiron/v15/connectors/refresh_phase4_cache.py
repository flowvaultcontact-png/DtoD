#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 4 live cache refresh (P4 driver).

Fetches and freezes EVERY record needed by the Phase 4 repurposing
module:

  1. drug records for the 18-drug candidate universe (Open Targets
     drug search + drug record with mechanism rows and the paged
     indication list),
  2. ChEMBL molecule records (first_approval anchors the temporal
     split; withdrawn_flag anchors safety), mechanism rows and
     drug-indication rows,
  3. indication-disease pages (the live drugAndClinicalCandidates
     replacement of the retired knownDrugs field) for the 5-disease
     benchmark panel {HFREF, HFPEF, CKD, DKD, T2DM},
  4. UniProt reviewed-entry records + function excerpts for every
     target symbol the drug mechanisms resolve to,
  5. Europe PMC citations for the landmark trials that anchor the
     pre-2015 disease-channel law table and the post-2015 ground
     truth (DAPA-HF, EMPEROR-Reduced, DAPA-CKD, EMPA-KIDNEY,
     CREDENCE, EMPEROR-Preserved, DELIVER, RENAAL, CONSENSUS,
     RALES, Ronco cardiorenal, UKPDS 33, pre-2015 SGLT2-kidney).

Everything is stored under v15/cache/<sha256>.json + manifest.json.
At the end it emits v15/out/phase4_verified_values.json — the
machine-verified values the FROZEN pack v15/repurposing_data.py is
authored from (verbatim; absent data stays absent, recorded in the
absences list).

This is the ONLY place live network access happens. Usage:

    python3 v15/connectors/refresh_phase4_cache.py --live
    python3 v15/connectors/refresh_phase4_cache.py --check    # offline audit
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))))          # apeiron/ repo root

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.abspath(os.path.join(HERE, os.pardir, "out"))
OUT_PATH = os.path.join(OUT_DIR, "phase4_verified_values.json")

from v15.connectors import base, opentargets as OT  # noqa: E402
from v15.connectors import chembl as CH, uniprot as UP  # noqa: E402
from v15.connectors import europepmc as EP  # noqa: E402


def verify_citation_with_hints(spec, live):
    """verify_citation, with optional PMID hints tried FIRST.

    Hints are ONLY search candidates: every hint goes through Europe PMC
    EXT_ID verification + client-side title-token filtering exactly like
    the E-utilities fallback path. A wrong hint is rejected, never
    admitted (same anti-fabrication discipline as Phase 3)."""
    for pmid in spec.get("pmid_hints", []):
        try:
            c = EP.verify_pmid(pmid, force_live=live)
            if EP.title_matches(c, spec["must"]):
                return c, "pmid_hint_verified"
        except base.ConnectorError:
            continue
    return EP.verify_citation(spec["key"], spec["query"], spec["must"],
                              force_live=live)

# 18-drug candidate universe. 15 drugs carry ChEMBL first_approval
# strictly before 2015 (the OLD side of the temporal benchmark);
# finerenone (2021) and semaglutide (2017) are post-2015 molecules that
# serve as named NEGATIVE CONTROLS for temporal hermeticity (they must
# never appear in a pre-2015 prediction).
DRUGS = [
    "dapagliflozin", "empagliflozin", "canagliflozin",        # SGLT2i
    "metformin", "glimepiride", "sitagliptin",                # other T2D classes
    "losartan", "irbesartan", "valsartan",                    # ARBs
    "captopril", "lisinopril",                                # ACEi
    "carvedilol",                                             # beta-blocker
    "spironolactone",                                         # MRA
    "atorvastatin", "pravastatin",                            # statins
    "amlodipine",                                             # CCB
    "finerenone", "semaglutide",                              # post-2015 controls
]

# Indication-disease benchmark panel.
PANEL = [
    {"key": "HFREF", "search": "systolic heart failure",
     "prefer": ["MONDO:0006993"],
     "note": "MONDO:0006993 'systolic heart failure' = the OT record "
             "closest to HFrEF; choice documented in Phase 3 too"},
    {"key": "HFPEF", "search": "diastolic heart failure",
     "prefer": ["MONDO:0006727"],
     "note": "MONDO_0006727 'diastolic heart failure' = the OT record "
             "closest to HFpEF (preserved EF = diastolic dysfunction); "
             "the full phrase returns only GWAS-study hits, so the "
             "shorter MONDO term is used deliberately and documented"},
    {"key": "CKD", "search": "chronic kidney disease",
     "prefer": ["MONDO:0005300"]},
    {"key": "DKD", "search": "diabetic kidney disease", "prefer": []},
    {"key": "T2DM", "search": "type 2 diabetes mellitus",
     "prefer": ["MONDO:0005148"]},
]

# Landmark citations. Each anchors a channel row or a ground-truth row
# of the frozen pack; `must` tokens are title-filtered client-side and
# FIRST_PDATE ranges constrain the publication window so the LANDMARK
# trial publication is matched (not a later review mentioning it).
CITATIONS = [
    {"key": "DAPA_HF",
     "query": '(TITLE:"dapagliflozin in patients with heart failure and '
              'reduced ejection fraction")',
     "must": ["dapagliflozin"],
     "pmid_hints": ["31535829"]},
    {"key": "DAPA_CKD",
     "query": '(TITLE:"dapagliflozin in patients with chronic kidney '
              'disease")',
     "must": ["dapagliflozin"],
     "pmid_hints": ["32970393", "32970396"]},
    {"key": "EMPEROR_REDUCED",
     "query": '(TITLE:"cardiovascular and renal outcomes with empagliflozin '
              'in heart failure")',
     "must": ["empagliflozin"]},
    {"key": "EMPEROR_PRESERVED",
     "query": '(TITLE:"empagliflozin in heart failure with a preserved '
              'ejection fraction")',
     "must": ["empagliflozin"],
     "pmid_hints": ["34459213"]},
    {"key": "EMPA_KIDNEY",
     "query": '(TITLE:"empagliflozin in patients with chronic kidney '
              'disease")',
     "must": ["empagliflozin"],
     "pmid_hints": ["36331190"]},
    {"key": "DELIVER",
     "query": '(TITLE:"dapagliflozin in heart failure with mildly reduced '
              'or preserved ejection fraction")',
     "must": ["dapagliflozin"],
     "pmid_hints": ["36027570"]},
    {"key": "CREDENCE",
     "query": '(TITLE:"canagliflozin and renal outcomes in type 2 diabetes '
              'and nephropathy")',
     "must": ["canagliflozin"]},
    {"key": "RENAAL",
     "query": '(RENAAL) AND (FIRST_PDATE:[2000 TO 2002])',
     "must": ["losartan"],
     "pmid_hints": ["11967819"],
     "note": "RENAAL program publication (design paper, 2000; the primary "
             "results paper resists keyword recovery — the ChEMBL "
             "indication row carries the indication evidence)"},
    {"key": "ENALAPRIL_HF_SURVIVAL",
     "query": '(TITLE:"effect of enalapril on survival")',
     "must": ["enalapril"],
     "pmid_hints": ["2883575"],
     "note": "CONSENSUS primary paper (enalapril survival, 1987)"},
    {"key": "RALES",
     "query": '(TITLE:"the effect of spironolactone on morbidity and '
              'mortality")',
     "must": ["spironolactone"]},
    {"key": "CARDIORENAL_PRE2015",
     "query": '(TITLE:"cardiorenal syndrome") AND (FIRST_PDATE:[2008 TO '
              '2010])',
     "must": ["cardiorenal"],
     "note": "pre-2015 cardiorenal-syndrome classification anchor for the "
             "CARDIORENAL channel bridge"},
    {"key": "SGLT2_KIDNEY_PRE2015",
     "query": '(dapagliflozin) AND (urinary glucose) AND '
              '(FIRST_PDATE:[2009 TO 2014])',
     "must": ["dapagliflozin"],
     "note": "pre-2015 anchor for the KIDNEY_TUBULE_GLUCOSE channel"},
    {"key": "UKPDS_33",
     "query": '(TITLE:"UKPDS 33")',
     "must": ["diabetes"]},
]


def step_drugs(live, absences, panel_ids):
    """Drug universe: OT search + record + ChEMBL molecule/mechanisms/
    indications. Returns {name: distilled} + the union of target symbols."""
    out, symbols = {}, []
    for name in DRUGS:
        rec = {"search_name": name}
        try:
            hits = OT.search_drug(name, force_live=live)
            chembl_id, ot_name = OT.first_drug_hit(hits)
            rec["chembl_id"], rec["ot_name"] = chembl_id, ot_name
        except Exception as exc:                       # noqa: BLE001
            absences.append({"where": f"drug.search.{name}",
                             "detail": str(exc)[:200]})
            rec["chembl_id"] = None
        if rec.get("chembl_id"):
            try:
                dr = OT.drug_record(rec["chembl_id"], force_live=live)
                rec["ot_record"] = {
                    "maximum_clinical_stage": dr["maximum_clinical_stage"],
                    "moa_rows": dr["moa_rows"],
                    "indications_count": dr["indications_count"],
                    "panel_indication_rows": [
                        r for r in dr["indication_rows"]
                        if r.get("disease_id") in panel_ids],
                    "sha256": dr["sha256"],
                    "retrieval_utc": dr["retrieval_utc"]}
                for row in dr["moa_rows"]:
                    symbols.extend(row["target_symbols"])
            except Exception as exc:                   # noqa: BLE001
                absences.append({"where": f"drug.record.{name}",
                                 "detail": str(exc)[:200]})
            try:
                mol = CH.molecule(rec["chembl_id"], force_live=live)
                rec["chembl_molecule"] = {
                    "first_approval": mol["first_approval"],
                    "withdrawn_flag": mol["withdrawn_flag"],
                    "withdrawn_reason": mol["withdrawn_reason"],
                    "maximum_phase": mol["maximum_phase"],
                    "pref_name": mol["pref_name"],
                    "sha256": mol["sha256"],
                    "retrieval_utc": mol["retrieval_utc"]}
            except Exception as exc:                   # noqa: BLE001
                absences.append({"where": f"chembl.molecule.{name}",
                                 "detail": str(exc)[:200]})
            try:
                mechs = CH.mechanisms(rec["chembl_id"], force_live=live)
                rec["chembl_mechanisms"] = {
                    "rows": mechs["rows"], "sha256": mechs["sha256"],
                    "retrieval_utc": mechs["retrieval_utc"]}
            except Exception as exc:                   # noqa: BLE001
                absences.append({"where": f"chembl.mechanisms.{name}",
                                 "detail": str(exc)[:200]})
            try:
                inds = CH.indications(rec["chembl_id"], force_live=live)
                rec["chembl_indications"] = {
                    "n_rows": len(inds["rows"]), "rows": inds["rows"],
                    "sha256": inds["sha256"],
                    "retrieval_utc": inds["retrieval_utc"]}
            except Exception as exc:                   # noqa: BLE001
                absences.append({"where": f"chembl.indications.{name}",
                                 "detail": str(exc)[:200]})
        out[name] = rec
        print(f"  drug {name:<16} chembl={rec.get('chembl_id')} "
              f"first_approval={rec.get('chembl_molecule', {}).get('first_approval')}")
    return out, sorted(set(symbols))


def step_diseases(live, absences):
    """Indication-disease panel: resolve ids + fetch candidate pages.
    Membership of our drug universe is filtered in main() once the drug
    ids are known (the raw pages stay frozen in the cache)."""
    out = {}
    for p in PANEL:
        rec = {"key": p["key"], "search": p["search"], "note": p.get("note", "")}
        try:
            hits = OT.search_disease(p["search"], force_live=live)
            did, dname = OT.first_disease_hit(hits, prefer_ids=p["prefer"])
            rec["disease_id"], rec["disease_name"] = did, dname
        except Exception as exc:                       # noqa: BLE001
            absences.append({"where": f"disease.search.{p['key']}",
                             "detail": str(exc)[:200]})
            rec["disease_id"] = None
        rec["our_drug_rows"] = []
        rec["_rows"] = []
        if rec.get("disease_id"):
            try:
                page = OT.disease_drug_candidates(rec["disease_id"],
                                                  force_live=live)
                rec["count"] = page["count"]
                rec["_rows"] = page["rows"]
            except Exception as exc:                   # noqa: BLE001
                absences.append({"where": f"disease.drugs.{p['key']}",
                                 "detail": str(exc)[:200]})
        print(f"  disease {p['key']:<6} {rec.get('disease_id')} "
              f"page_rows={len(rec.get('_rows', []))}")
        out[p["key"]] = rec
    return out


def filter_membership(diseases, drug_ids):
    """Filter the frozen candidate pages down to our drug universe."""
    for key, rec in diseases.items():
        rec["our_drug_rows"] = [r for r in rec.pop("_rows")
                                if r["drug_id"] in drug_ids]


def step_uniprot(live, absences, symbols):
    """Reviewed entries + function excerpts for the target symbols."""
    out = {}
    for sym in symbols:
        rec = {"symbol": sym}
        try:
            r = UP.resolve_gene(sym, force_live=live)
            entry = r.get("entry") or {}
            rec["accession"] = entry.get("primaryAccession")
            rec["protein_name"] = (entry.get("proteinDescription", {})
                                   .get("recommendedName", {})
                                   .get("fullName", {}).get("value"))
            rec["resolve_n"] = r["n_results"]
        except Exception as exc:                       # noqa: BLE001
            absences.append({"where": f"uniprot.resolve.{sym}",
                             "detail": str(exc)[:200]})
            rec["accession"] = None
        if rec.get("accession"):
            try:
                fn = UP.entry_function(rec["accession"], force_live=live)
                rec["function_excerpt"] = fn["function_excerpt"]
            except Exception as exc:                   # noqa: BLE001
                absences.append({"where": f"uniprot.function.{sym}",
                                 "detail": str(exc)[:200]})
        print(f"  uniprot {sym:<8} {rec.get('accession')} "
              f"func={'yes' if rec.get('function_excerpt') else 'absent'}")
        out[sym] = rec
    return out


def step_citations(live, absences):
    """Landmark trial citations (hint-verified or search + title filter)."""
    out = {}
    for c in CITATIONS:
        try:
            cit, via = verify_citation_with_hints(c, live)
            out[c["key"]] = {
                "pmid": cit["pmid"], "title": cit["title"],
                "journal": cit["journal"], "year": cit["year"],
                "doi": cit["doi"], "via": via,
                "note": c.get("note", "")}
            print(f"  citation {c['key']:<24} PMID:{cit['pmid']} "
                  f"({cit.get('year')}) via={via}")
        except Exception as exc:                       # noqa: BLE001
            absences.append({"where": f"citation.{c['key']}",
                             "detail": str(exc)[:200]})
            print(f"  citation {c['key']:<24} ABSENT")
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--live", action="store_true",
                    help="fetch missing records (idempotent)")
    ap.add_argument("--force-live", action="store_true",
                    help="refetch EVERY record (new freeze)")
    ap.add_argument("--check", action="store_true",
                    help="offline audit: list frozen records + emit none")
    args = ap.parse_args()

    if args.check:
        names = base.list_frozen()
        print(f"{len(names)} frozen records available; "
              f"phase4 names: {sum(1 for n in names if '.p4' in n or True)}")
        return 0
    if not (args.live or args.force_live):
        print("Refusing live work without --live (absence is reported, "
              "never fabricated). See module docstring.")
        return 2

    # Idempotent semantics (Phase 3 doctrine): --live serves every name
    # already frozen in the manifest and fetches only missing ones;
    # --force-live refetches ALL names. force_live=True is what makes
    # connectors.base.fetch_frozen bypass the cache.
    live = bool(args.force_live)
    absences = []
    print("[P4] step 1/5: indication-disease panel")
    diseases = step_diseases(live, absences)
    panel_ids = {d.get("disease_id") for d in diseases.values()
                 if d.get("disease_id")}
    print("[P4] step 2/5: drug universe (OT + ChEMBL)")
    drugs, symbols = step_drugs(live, absences, panel_ids)
    print("[P4] step 3/5: panel membership of the drug universe")
    drug_ids = {d.get("chembl_id") for d in drugs.values()
                if d.get("chembl_id")}
    filter_membership(diseases, drug_ids)
    for k, d in diseases.items():
        print(f"  {k:<6} our_drugs="
              f"{[r['drug_name'] for r in d['our_drug_rows']]}")
    print("[P4] step 4/5: UniProt target records")
    uniprot = step_uniprot(live, absences, symbols)
    print("[P4] step 5/5: Europe PMC citations")
    citations = step_citations(live, absences)

    verified = {
        "frozen_utc": base.utcnow(),
        "phase": "P4 repurposing (Module C)",
        "drugs": drugs,
        "diseases": diseases,
        "uniprot": uniprot,
        "citations": citations,
        "absences": absences,
    }
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(OUT_PATH, "w", encoding="utf-8") as fh:
        json.dump(verified, fh, indent=1, sort_keys=True)
    n_abs = len(absences)
    print(f"\nwrote {OUT_PATH}")
    print(f"drugs={len(drugs)} diseases={len(diseases)} "
          f"targets={len(uniprot)} citations={len(citations)} "
          f"absences={n_abs}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
