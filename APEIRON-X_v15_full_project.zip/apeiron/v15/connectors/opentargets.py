"""Open Targets Platform connector (GraphQL) — P3-4 skeleton.

NOTE ON THE LIVE SCHEMA (verified by introspection during the Phase 3
freeze, 2026-11-25): the current Platform API exposes associations from
the DISEASE side — `disease(efoId){ associatedTargets(...) }`. The older
`target(ensemblId){ associatedDiseases(efoId: ...) }` signature returns
HTTP 400 ("Unknown argument 'efoId'") and is NOT usable.

Datatype ids are carried verbatim from the Platform (as of the freeze):
genetic_association, genetic_literature, literature, clinical,
animal_model, known_drug, somatic_mutation, rna_expression, affected_pathway.
Mappings into the v15 evidence kinds are recorded in
v15/target_data.py — never silently renamed.

This module never fabricates: a GraphQL error or a missing row raises
ConnectorError / yields None, and the caller records the absence.
"""

import json

from . import base

ENDPOINT = "https://api.platform.opentargets.org/api/v4/graphql"
RESOURCE = "Open Targets Platform"
LICENSE = "CC-BY-4.0 (opentargets.org licensing; datasource-specific terms)"


def _graphql(name, query, variables=None, timeout=75, retries=2,
             force_live=False):
    body = json.dumps({"query": query, "variables": variables or {}})
    rec = base.fetch_frozen(
        name, ENDPOINT, method="POST", data=body.encode("utf-8"),
        headers={"Content-Type": "application/json"},
        timeout=timeout, retries=retries, resource=RESOURCE,
        license_field=LICENSE, force_live=force_live)
    payload = rec["payload"]
    if payload.get("errors"):
        raise base.ConnectorError(
            "GRAPHQL_ERROR", name, ENDPOINT, json.dumps(payload["errors"]))
    return rec


def search_disease(name, force_live=False):
    """Search a disease string; returns the frozen record with hits."""
    q = f'query{{search(queryString:{json.dumps(name)})' \
        f'{{hits{{id name entity}}}}}}'
    return _graphql(f"ot.search.{base.slugify(name)}", q,
                    force_live=force_live)


def search_target(symbol, force_live=False):
    """Search a gene symbol; returns the frozen record with hits."""
    q = f'query{{search(queryString:{json.dumps(symbol)})' \
        f'{{hits{{id name entity}}}}}}'
    return _graphql(f"ot.search.{base.slugify(symbol)}", q,
                    force_live=force_live)


def first_disease_hit(rec, prefer_ids=()):
    """Deterministic pick: first hit whose id is in prefer_ids, else the
    first disease-entity hit. Returns (id, name) or (None, None).
    Prefer ids may be given as "MONDO:xxxx" or "MONDO_xxxx"."""
    hits = rec["payload"]["data"]["search"]["hits"]
    norm = [p.replace(":", "_") for p in prefer_ids]
    for want in norm:
        for h in hits:
            if h["id"] == want:
                return h["id"], h["name"]
    for h in hits:
        if h.get("entity") == "disease":
            return h["id"], h["name"]
    return None, None


def first_target_hit(rec):
    """Deterministic pick of the first target-entity hit."""
    hits = rec["payload"]["data"]["search"]["hits"]
    for h in hits:
        if h.get("entity") == "target":
            return h["id"], h["name"]
    return None, None


def disease_associated_targets(efo_id, page_size=150, force_live=False):
    """Top associated targets for a disease, with per-datatype scores,
    verbatim from the Platform (enableIndirect: true)."""
    q = '''query($efo: String!, $size: Int!) {
  disease(efoId: $efo) {
    id
    name
    associatedTargets(enableIndirect: true,
                      page: {size: $size, index: 0}) {
      count
      rows {
        target { id approvedSymbol }
        score
        datatypeScores { id score }
      }
    }
  }
}'''
    name = f"ot.assoc.{base.slugify(efo_id)}"
    rec = _graphql(name, q, {"efo": efo_id, "size": page_size},
                   force_live=force_live)
    dis = rec["payload"]["data"].get("disease")
    if not dis:
        raise base.ConnectorError("NO_DISEASE", name, ENDPOINT,
                                  f"no disease record for {efo_id}")
    at = dis.get("associatedTargets") or {}
    return {
        "efo_id": efo_id,
        "disease_id": dis.get("id"),
        "disease_name": dis.get("name"),
        "count": at.get("count", 0),
        "rows": at.get("rows", []),
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }


def rows_for_symbols(assoc, symbols):
    """Extract per-symbol rows (or None if not in the returned page).
    Honest: absence from the page is reported, not interpolated."""
    by_symbol = {}
    for r in assoc["rows"]:
        by_symbol.setdefault(r["target"]["approvedSymbol"], []).append(r)
    out = {}
    for s in symbols:
        rows = by_symbol.get(s, [])
        out[s] = {"row": rows[0] if rows else None,
                  "n_rows": len(rows)}
    return out


# =====================================================================
# Phase 4 additions (Module C — drug records and indication pages).
#
# LIVE-SCHEMA NOTES (introspection-verified 2026-11-25, Phase 4 freeze):
#   * Drug.isApproved / withdrawn / maximumClinicalTrialPhase /
#     firstApproval no longer exist on the Drug type. The live shape is
#     `maximumClinicalStage` (String, e.g. "APPROVAL"/"PHASE_3") and a
#     paged `indications` block of ClinicalIndicationFromDrug rows
#     {id, maxClinicalStage, disease{id name}}.
#   * MechanismOfAction rows expose {actionType, mechanismOfAction,
#     targetName, targets{id approvedSymbol}}; the older `targetId`
#     field returns HTTP 400 and is NOT used.
#   * Disease.knownDrugs is GONE; the live replacement is
#     `drugAndClinicalCandidates{count rows{drug{...}}}` (no page args
#     on the current build — the server returns the full row list).
# Approval YEARS for the Phase 4 temporal split come from ChEMBL
# (v15.connectors.chembl.molecule), never invented here.
# =====================================================================

def search_drug(name, force_live=False):
    """Search a drug string; returns the frozen record with hits."""
    q = f'query{{search(queryString:{json.dumps(name)})' \
        f'{{hits{{id name entity}}}}}}'
    return _graphql(f"ot.search.{base.slugify(name)}", q,
                    force_live=force_live)


def first_drug_hit(rec):
    """Deterministic pick of the first drug-entity hit."""
    hits = rec["payload"]["data"]["search"]["hits"]
    for h in hits:
        if h.get("entity") == "drug":
            return h["id"], h["name"]
    return None, None


def drug_record(chembl_id, force_live=False):
    """Full drug record: clinical stage, mechanism rows (with target
    symbols), and the paged indication list with disease ids."""
    q = '''query($id: String!) {
  drug(chemblId: $id) {
    id
    name
    maximumClinicalStage
    mechanismsOfAction {
      rows {
        actionType
        mechanismOfAction
        targetName
        targets { id approvedSymbol }
      }
    }
    indications {
      count
      rows { id maxClinicalStage disease { id name } }
    }
  }
}'''
    name = f"ot.drug.{base.slugify(chembl_id)}"
    rec = _graphql(name, q, {"id": chembl_id}, force_live=force_live)
    d = rec["payload"]["data"].get("drug")
    if not d:
        raise base.ConnectorError("NO_DRUG", name, ENDPOINT,
                                  f"no drug record for {chembl_id}")
    moa = d.get("mechanismsOfAction") or {}
    ind = d.get("indications") or {}
    return {
        "chembl_id": chembl_id,
        "ot_name": d.get("name"),
        "maximum_clinical_stage": d.get("maximumClinicalStage"),
        "moa_rows": [{"action_type": r.get("actionType"),
                      "mechanism_of_action": r.get("mechanismOfAction"),
                      "target_name": r.get("targetName"),
                      "target_symbols": sorted({t.get("approvedSymbol")
                                                for t in
                                                (r.get("targets") or [])
                                                if t.get("approvedSymbol")})}
                     for r in (moa.get("rows") or [])],
        "indications_count": ind.get("count", 0),
        "indication_rows": [{"disease_id": r.get("disease", {}).get("id"),
                             "disease_name": r.get("disease", {}).get("name"),
                             "max_clinical_stage": r.get("maxClinicalStage")}
                            for r in (ind.get("rows") or [])],
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }


def disease_drug_candidates(efo_id, force_live=False):
    """Disease-side drug/candidate list (the live replacement of the
    retired knownDrugs field): rows of {drug, maxClinicalStage}."""
    q = '''query($efo: String!) {
  disease(efoId: $efo) {
    id
    name
    drugAndClinicalCandidates {
      count
      rows { drug { id name maximumClinicalStage } }
    }
  }
}'''
    name = f"ot.drugs_for_disease.{base.slugify(efo_id)}"
    rec = _graphql(name, q, {"efo": efo_id}, force_live=force_live)
    dis = rec["payload"]["data"].get("disease")
    if not dis:
        raise base.ConnectorError("NO_DISEASE", name, ENDPOINT,
                                  f"no disease record for {efo_id}")
    dcc = dis.get("drugAndClinicalCandidates") or {}
    return {
        "efo_id": efo_id,
        "disease_id": dis.get("id"),
        "disease_name": dis.get("name"),
        "count": dcc.get("count", 0),
        "rows": [{"drug_id": r.get("drug", {}).get("id"),
                  "drug_name": r.get("drug", {}).get("name"),
                  "max_clinical_stage": r.get("drug", {}).get(
                      "maximumClinicalStage")}
                 for r in (dcc.get("rows") or [])],
        "sha256": rec["sha256"],
        "retrieval_utc": rec["retrieval_utc"],
    }
