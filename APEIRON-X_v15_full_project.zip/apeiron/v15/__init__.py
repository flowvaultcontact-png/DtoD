"""APEIRON-X v15 scaffold package (Phase 1, additive only).

Doctrine:
- v15 code NEVER modifies v14.1 modules; it imports them read-only.
- v15 derivation code must stay hermetic in the v14 sense: knowledge
  modules are listed in run_full_regression.KB_SENTINELS and must never be
  imported at derivation time by any future hermetic engine.
- Every scientific claim carries an explicit ClaimTier; see claims.py.
"""

__version__ = "15.0.0a1"

from .claims import Claim, ClaimTier
from .provenance import SourceRecord, ProvenanceLedger
from .disease_profile import (DiseaseProfile, Encodability,
                              injectivity_report, profile_from_kb_row)
from .targets import TargetEvidence, TargetHypothesis, score_target
from .vocab import Vocabulary

__all__ = [
    "Claim", "ClaimTier",
    "SourceRecord", "ProvenanceLedger",
    "DiseaseProfile", "Encodability", "injectivity_report",
    "profile_from_kb_row",
    "TargetEvidence", "TargetHypothesis", "score_target",
    "Vocabulary",
]
