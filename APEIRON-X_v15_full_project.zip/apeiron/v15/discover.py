#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 8 (P8-1): end-to-end discovery pipeline.

Implements the 12-step workflow of the master prompt on top of the
v14.1 proof engine (read-only) and the v15 modules A–F, and emits the
structured discovery report as a VERSIONED 18-section JSON document.

Binding rules (plan §0, restated for this module):
  * v14.1 modules are imported read-only; no law, theorem or frozen row
    is ever edited to make a report look better.
  * Every claim carries a tier: PROVEN_MATH / EVIDENCED / COMPUTATIONAL /
    HYPOTHESIS. Aggregates are labelled COMPUTATIONAL_RANK and are rank
    hints, never probabilities.
  * Absent data is reported as an explicit absence record — the pipeline
    NEVER invents a drug, target, molecule, citation or plan.
  * Reports are deterministic: no wall-clock fields anywhere; two builds
    of the same input yield byte-identical canonical JSON (theorem R1).
  * The temporal lane (as_of_year) uses the Phase 4 hermeticity
    machinery; a pre-as-of report must not contain post-split knowledge
    (theorem R2).

CLI:
    python3 v15/discover.py --disease D02 [--as-of 2015] [--out FILE]
    python3 v15/discover.py --list-steps
"""

import argparse
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from v15.disease_profile import (  # noqa: E402
    V15_CHANNELS, PROFILE_FIELDS, FIELD_STATUSES,
    DiseaseProfile, Encodability, injectivity_report, profile_from_kb_row,
)
from v15.targets import load_targets                       # noqa: E402
from v15.repurposing import load_pack, predict_repurposing  # noqa: E402
from v15.kgraph import load_kgraph, tier_meet              # noqa: E402
from v15 import validation_plan as vp                      # noqa: E402

DISCOVER_SCHEMA_VERSION = "15.8.0"
REPORT_LABEL = "APEIRON-X_STRUCTURED_DISCOVERY_REPORT"
PROGRAM_VERSION = "v15 Phase 8 (P8-1..P8-4)"

TIER_LADDER = ("PROVEN_MATH", "EVIDENCED", "COMPUTATIONAL", "HYPOTHESIS")
TIER_RANK = {t: i for i, t in enumerate(TIER_LADDER)}


def tier_join(a: str, b: str) -> str:
    """Strongest tier across independent lanes (fusion semantics):
    a drug evidenced in ANY lane is evidenced. The conservative chain
    propagation stays tier_meet (v15.kgraph); fusion deliberately uses
    the join and says so on every fused row."""
    if a not in TIER_RANK or b not in TIER_RANK:
        raise ValueError(f"unknown tier in fusion: {a!r} / {b!r}")
    return a if TIER_RANK[a] <= TIER_RANK[b] else b

# --- the 12 workflow steps (master prompt §5; plan §1 target end-state) ---
WORKFLOW_STEPS = (
    "S1_normalize_input",
    "S2_build_disease_profile",
    "S3_resolve_six_channel_identity",
    "S4_resolve_graph_neighborhood",
    "S5_rank_molecular_intervention_points",
    "S6_retrieve_approved_and_investigational_drugs",
    "S7_generate_repurposing_hypotheses",
    "S8_surface_novel_candidate_molecules",
    "S9_admet_toxicity_screen",
    "S10_evidence_weighted_transparent_ranking",
    "S11_apeiron_x_consistency_checks",
    "S12_attach_experimental_validation_plan",
)

# --- the 18 report sections (master prompt §9; versioned schema) ---------
REPORT_SECTIONS = (
    "S01_report_header",
    "S02_claim_tier_legend",
    "S03_input_record",
    "S04_disease_profile",
    "S05_encodability_verdict",
    "S06_kb_identity",
    "S07_graph_neighborhood",
    "S08_ranked_targets",
    "S09_approved_and_investigational_drugs",
    "S10_repurposing_candidates",
    "S11_novel_candidate_molecules",
    "S12_admet_toxicity_screen",
    "S13_evidence_weighted_ranking",
    "S14_consistency_checks",
    "S15_experimental_validation_plans",
    "S16_provenance_ledger",
    "S17_honest_limits",
    "S18_reproducibility_and_non_goals",
)

CLAIM_TIER_LEGEND = {
    "PROVEN_MATH": "exact machine-checked statement on the closed frozen "
                   "corpus (v14.1 five-layer proof chain / v15 theorems)",
    "EVIDENCED": "cited experimental or guideline evidence from the frozen "
                 "packs (every row carries resolvable source ids)",
    "COMPUTATIONAL": "inference computed from frozen data (transparent "
                     "axes shown; aggregates labelled COMPUTATIONAL_RANK)",
    "HYPOTHESIS": "speculative; recorded as a hypothesis with its absence "
                  "records, never as a finding",
}

NON_GOALS = (
    "clinical decision support",
    "claiming efficacy for any candidate",
    "replacing experimental validation",
    "claiming any drug works for every disease",
)

# Same token convention as the Phase 7 battery (substring, case- #
# insensitive): "cure", "efficacious", "treats ". Disclaimers that NAME #
# the doctrine (e.g. "never 'efficacy shown'") live in S14/S18 which the #
# content scan excludes.                                                 #
FORBIDDEN_CLAIM_TOKENS = ("cure", "efficacious", "treats ")

ABSENCE_FIELDS = ("code", "subject", "reason", "lane")


# ---------------------------------------------------------------------
# theorem shell (standard APEIRON-X shape, local to this module)
# ---------------------------------------------------------------------

def _th(name, statement, proved, stats, steps, counterexamples=None):
    return {"theorem": name, "statement": statement, "proved": bool(proved),
            "tier": "PROVEN_MATH", "counterexamples": counterexamples or [],
            "stats": stats, "proof_steps": steps}


def canonical_sha256(obj) -> str:
    return hashlib.sha256(
        json.dumps(obj, sort_keys=True, ensure_ascii=True,
                   separators=(",", ":")).encode("utf-8")).hexdigest()


def absence(code, subject, reason, lane):
    return {"code": code, "subject": subject, "reason": reason,
            "lane": lane}


def _scan_language(obj, path=""):
    """Forbidden-claim token scan over all string leaves. Values under
    'guideline' keys are quoted third-party guideline text and are
    EXCLUDED from the scan per the acceptance-gate rule ('outside
    quoted citations')."""
    hits = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            hits += _scan_language(v, f"{path}.{k}")
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            hits += _scan_language(v, f"{path}[{i}]")
    elif isinstance(obj, str):
        leaf = path.rsplit(".", 1)[-1].split("[")[0]
        if leaf not in ("guideline", "quotation", "quoted_text"):
            low = obj.lower()
            for tok in FORBIDDEN_CLAIM_TOKENS:
                if tok in low:
                    hits.append({"path": path, "token": tok})
    return hits


# ---------------------------------------------------------------------
# input resolution (S1) — exact matches only; no substring guessing
# ---------------------------------------------------------------------

def resolve_disease(spec: dict, kb, pack) -> dict:
    """Resolve a disease input to KB row / pack key / panel did /
    graph node. Every miss is an explicit absence, never a guess."""
    if not isinstance(spec, dict) or not spec:
        raise ValueError("disease spec must be a non-empty dict")
    known_keys = {"did", "name", "mondo_id", "phi", "phi_source_ids",
                  "genetic_profile"}
    unknown = set(spec) - known_keys
    if unknown:
        raise ValueError(f"unknown spec keys: {sorted(unknown)}; allowed "
                         f"{sorted(known_keys)}")
    if len(spec) > 1 and set(spec) != {"name", "genetic_profile"} and \
            not ({"phi", "phi_source_ids"} & set(spec)):
        raise ValueError("spec carries multiple selectors; allowed combos: "
                         "one selector alone, name+genetic_profile, or "
                         "phi+phi_source_ids")

    res = {"match_kind": None, "kb_row": None, "pack_key": None,
           "kb_did": None, "graph_node": None, "absences": []}

    did = spec.get("did")
    if did:
        row = next((r for r in kb.DISEASES if r["did"] == did), None)
        if row:
            res.update(match_kind="kb_did", kb_row=row, kb_did=row["did"])
        else:
            res["absences"].append(absence(
                "DID_NOT_IN_FROZEN_KB", did,
                "no disease row with this did exists in the hash-pinned "
                "v14.1 knowledge base", "S1_normalize_input"))

    name = spec.get("name")
    if name:
        row = next((r for r in kb.DISEASES
                    if r["name"].lower() == str(name).lower()), None)
        if row:
            res.update(match_kind=res["match_kind"] or "kb_name",
                       kb_row=row, kb_did=row["did"])
        else:
            res["absences"].append(absence(
                "NAME_NOT_IN_FROZEN_KB", name,
                "no disease row with this exact (case-insensitive) name "
                "exists in the hash-pinned v14.1 knowledge base",
                "S1_normalize_input"))

    if spec.get("mondo_id"):
        res["absences"].append(absence(
            "MONDO_LOOKUP_NOT_WIRED", spec["mondo_id"],
            "MONDO->KB resolution is served by the frozen v15 vocab "
            "(Vocabulary.disease_by_kb_link); the discover pipeline "
            "resolves did/name/phi only in this round — the vocab route "
            "is recorded, not guessed", "S1_normalize_input"))

    if res["kb_did"]:
        for key, d in pack.diseases.items():
            if d.get("kb_did") == res["kb_did"]:
                res["pack_key"] = key
                break
    else:
        res["absences"].append(absence(
            "NO_REPURPOSING_PACK_LINK", "-",
            "disease not in the frozen Phase 4 repurposing pack "
            "(cardio-renal panel + T2DM only); the repurposing and "
            "validation-plan lanes will record absences",
            "S7_generate_repurposing_hypotheses"))
    return res


def _kb_profile_section(kb_row) -> dict:
    prof = profile_from_kb_row(kb_row)
    return {
        "name": prof.name,
        "phi": dict(prof.phi),
        "phi_source_ids": list(prof.phi_source_ids),
        "fields": {k: [[v, list(s)] for v, s in entries]
                   for k, entries in prof.fields.items()},
        "field_status": dict(prof.field_status),
        "unknown_fields": list(prof.unknown_fields()),
        "tier": "PROVEN_MATH",
        "note": "profile built from the hash-pinned v14.1 KB row "
                "(round-trip entry point; the KB row is the citation)",
    }


def _ood_profile_section(spec, name) -> dict:
    fields = {}
    for f in PROFILE_FIELDS:
        if f == "ontology_ids":
            continue
        entries = spec.get("genetic_profile") if f == "genetics" else None
        if entries:
            fields[f] = [(str(e), ("USER:INPUT",)) for e in entries]
    phi = spec.get("phi")
    if phi:
        if not spec.get("phi_source_ids"):
            raise ValueError(
                "an explicit six-channel phi requires phi_source_ids "
                "(cited guideline/mechanism evidence); refusing to "
                "encode an uncited input (Tier-B honesty)")
        prof = DiseaseProfile(name=name, phi=dict(phi),
                              phi_source_ids=tuple(spec["phi_source_ids"]))
        prof.encodability = Encodability.ENCODABLE
    else:
        prof = DiseaseProfile(name=name, fields=fields)
    sec = {
        "name": prof.name,
        "phi": dict(prof.phi) if prof.phi else None,
        "phi_source_ids": list(prof.phi_source_ids),
        "fields": {k: [[v, list(s)] for v, s in entries]
                   for k, entries in prof.fields.items()},
        "field_status": {f: ("established" if f in fields else "unknown")
                         for f in PROFILE_FIELDS if f != "ontology_ids"},
        "unknown_fields": list(prof.unknown_fields()),
        "tier": "EVIDENCED" if prof.phi else "HYPOTHESIS",
        "note": "out-of-domain disease: profile built from the submitted "
                "input only; every downstream lane must confirm coverage "
                "or record an absence",
    }
    return sec


def _verdict_section(prof_sec, resolved) -> dict:
    if prof_sec["phi"]:
        verdict = "ENCODABLE"
        why = "six-channel encoding present and cited"
    elif prof_sec["fields"]:
        verdict = "NOT_ENCODABLE"
        why = ("input fields do not determine a six-channel encoding; "
               "v15 records NOT_ENCODABLE(v15) instead of guessing "
               "channel values")
    else:
        verdict = "NOT_ENCODABLE"
        why = "no channel evidence supplied with the input"
    return {"verdict": verdict, "why": why,
            "unresolved_channels": [] if prof_sec["phi"]
            else list(V15_CHANNELS),
            "tier": "PROVEN_MATH" if prof_sec["phi"] else "HYPOTHESIS",
            "in_domain": bool(resolved["kb_row"]),
            "absences": [] if prof_sec["phi"] else [absence(
                "PHI_NOT_DERIVABLE", prof_sec["name"], why,
                "S3_resolve_six_channel_identity")],
            "doctrine": "extends the v14.1 UNPROVEN / Tier-B sound-refusal "
                        "doctrine to v15 profiles"}


# ---------------------------------------------------------------------
# lane builders (S4..S12)
# ---------------------------------------------------------------------

def _graph_section(g, did, resolved) -> dict:
    node = did if resolved["kb_row"] else None
    if not node or g.lookup(node)["found"] is False:
        return {
            "found": False,
            "absences": [absence(
                "DISEASE_NODE_NOT_IN_FROZEN_GRAPH", node or "(none)",
                "the frozen P8 knowledge graph covers the 10-disease "
                "panel (CF, D01, D02, D03, D05, D08, D33, D50, D51, "
                "D54); this disease has no node, so no gene/protein/"
                "pathway neighborhood is asserted",
                "S4_resolve_graph_neighborhood")],
            "disease_gene_edges": [], "graph_ranking": [],
            "tier": "HYPOTHESIS",
        }
    edges = []
    for e in g.edges_of("disease->gene"):
        if e["src"] != node:
            continue
        edges.append({
            "gene": e["dst"], "tier": e["tier"],
            "sources": list(e["sources"]),
            "association_score": e["attrs"].get("association_score"),
            "association_kind": e["attrs"].get("association_kind"),
            "direction": e["attrs"].get("direction"),
            "external_id": e["attrs"].get("disease_id_external"),
        })
    edges.sort(key=lambda x: (-(x["association_score"] or 0.0), x["gene"]))
    ranked = g.rank_drugs_for_disease(node)
    return {"found": True, "absences": [],
            "disease_gene_edges": edges, "graph_ranking": ranked["ranking"],
            "rank_label": ranked["rank_label"], "tier": "EVIDENCED"}


def _targets_section(table, did, resolved) -> dict:
    if resolved["kb_did"] not in table.panel:
        return {
            "in_panel": False,
            "absences": [absence(
                "DISEASE_NOT_IN_TARGET_PANEL", resolved["kb_did"] or "-",
                "the frozen Module B target table carries evidence rows "
                "for its 10-disease benchmark panel only; no target "
                "hypothesis is fabricated outside it",
                "S5_rank_molecular_intervention_points")],
            "ranked_targets": [], "tier": "HYPOTHESIS",
        }
    rows = table.rank_targets(resolved["kb_did"], k=10)
    for r in rows:
        r["tier"] = "EVIDENCED" if r["kinds"] else "COMPUTATIONAL"
        if r["flags"]:
            r["tier"] = tier_meet(r["tier"], "COMPUTATIONAL")
    return {"in_panel": True, "absences": [],
            "ranked_targets": rows, "tier": "EVIDENCED",
            "note": "transparent per-axis scores; the aggregate is "
                    "COMPUTATIONAL_RANK, never a probability"}


def _approved_drugs_section(kb_row, kb_module, pack, as_of) -> dict:
    if not kb_row:
        return {
            "absences": [absence(
                "NO_KB_ROW_NO_GUIDELINE_DRUGS", "-",
                "guideline first-line drugs exist only for diseases with "
                "a v14.1 KB row", "S6_retrieve_approved_and_investigational_"
                "drugs")],
            "drugs": [], "tier": "HYPOTHESIS",
        }
    # KB drug tuple: (name, guideline_tier, kb_priority, safety_penalty)
    # (disease_drug_kb.py:289) — carried verbatim, never recomputed.
    drugs, post_split = [], []
    for name, g_tier, kb_prio, kb_safe in kb_row["drugs"]:
        atc, mech = kb_module.DRUGS.get(name, (None, None))
        drugs.append({"drug": name, "guideline_tier": g_tier,
                      "kb_priority": kb_prio,
                      "kb_safety_penalty": kb_safe,
                      "atc_code": atc, "mechanism_class": mech,
                      "guideline": kb_row["guideline"],
                      "tier": "EVIDENCED",
                      "sources": [f"KB:{kb_row['did']}"]})
    # enrich from the frozen P4 pack where the drug is covered
    for d in drugs:
        p = pack.drugs.get(d["drug"])
        if p:
            d["atc_code"] = None
            d["mechanism_class"] = p["kb_mech_class"]
            d["chembl_id"] = p["chembl_id"]
            d["first_approval"] = p["first_approval"]
            d["sources"] = sorted(set(d["sources"]) | set(p["sources"]))
            if as_of and p["first_approval"] >= as_of:
                d["post_split_knowledge"] = True
                post_split.append(d["drug"])
            else:
                d["post_split_knowledge"] = False
        else:
            d["first_approval"] = None
            d["post_split_knowledge"] = None
            d["absence_note"] = (
                "drug not in the frozen Phase 4 pack; approval year "
                "UNKNOWN here — recorded as absent, not guessed")
    drugs.sort(key=lambda d: (d["guideline_tier"], d["drug"]))
    sec = {"drugs": drugs,
           "post_split_excluded": post_split if as_of else None,
           "guideline": kb_row["guideline"], "tier": "EVIDENCED",
           "absences": []}
    return sec


def _repurposing_section(pack, resolved, as_of, graph_ns=None) -> dict:
    key = resolved["pack_key"]
    if not key or key not in pack.prediction_diseases:
        return {
            "absences": [absence(
                "DISEASE_NOT_IN_PREDICTION_PANEL",
                key or resolved["kb_did"] or "-",
                "the Phase 4 prediction panel covers "
                + ", ".join(pack.prediction_diseases)
                + "; candidate lists for other diseases are NOT "
                "extrapolated (single-rule collapse is the v14.1 defect "
                "this lane refuses to recreate)",
                "S7_generate_repurposing_hypotheses")],
            "candidates": [], "tier": "HYPOTHESIS",
        }
    pred = predict_repurposing(pack, as_of_year=as_of)
    block = pred["diseases"][key]
    rows = []
    for r in block["rows"]:
        rows.append({
            "drug": r["drug"], "rank": r["rank"],
            "first_approval": r["first_approval"],
            "support_level": r["support_level"],
            "matched_channels": r["matched_channels"],
            "bridged": r["bridged"],
            "axes": r["axes"], "aggregate": r["aggregate"],
            "aggregate_label": r["aggregate_label"],
            "status": r["status"], "bridge": r["bridge"],
            "rank_tier": r["rank_tier"],
            "tier": ("EVIDENCED" if r["rank_tier"] == "EVIDENCED"
                     else "COMPUTATIONAL"),
            "sources": r["sources"],
        })
    return {
        "disease_key": key,
        "as_of_year": pred["as_of_year"],
        "candidates": rows,
        "first_zero_support_rank": block["first_zero_support_rank"],
        "tier": "EVIDENCED",
        "absences": [],
        "note": "candidates carry the Theta_d structure-law bridge "
                "finding; MECH_STRUCTURE_CONFLICT rows are exposed, "
                "never silently dropped",
    }


PHASE5_PATH = os.path.join(ROOT, "v15", "out", "phase5_benchmark.json")


def _load_phase5():
    if not os.path.exists(PHASE5_PATH):
        raise RuntimeError(
            "frozen Phase 5 artifact missing: "
            f"{PHASE5_PATH}. Run v15/write_phase5_artifacts.py first "
            "(frozen-artifact doctrine: unpinned stores are not served).")
    with open(PHASE5_PATH, encoding="utf-8") as fh:
        bench = json.load(fh)
    sha = hashlib.sha256(open(PHASE5_PATH, "rb").read()).hexdigest()
    emitted = [m for m in bench["molecules"]
               if m.get("status") == "GENERATED_CANDIDATE"
               and not m.get("rejected")]
    return bench, sha, emitted


def _molecules_section(emitted, phase5_sha, prof_sec) -> dict:
    if not prof_sec["phi"]:
        return {
            "absences": [absence(
                "NO_DISEASE_LINK_FOR_MOLECULES", prof_sec["name"],
                "generated molecules are class-pharmacophore candidates "
                "over the frozen structure laws; an out-of-domain disease "
                "has no encoding, so no class-level compatibility "
                "statement is made", "S8_surface_novel_candidate_"
                "molecules")],
            "candidates": [], "tier": "HYPOTHESIS",
        }
    cands = [{
        "mol_id": m["mol_id"], "smiles": m["smiles"], "status": m["status"],
        "tier": m.get("tier", "COMPUTATIONAL"),
        "laws_satisfied": m.get("laws_satisfied", []),
        "seed": m.get("seed"), "edit": m.get("edit"),
        "aggregate": m.get("aggregate"),
        "aggregate_label": m.get("aggregate_label"),
        "claims": m.get("claims"),
    } for m in emitted]
    return {
        "candidates": cands,
        "candidate_count": len(cands),
        "phase5_artifact_sha256": phase5_sha,
        "tier": "COMPUTATIONAL",
        "absences": [],
        "note": "structure-only research candidates served from the "
                "FROZEN Phase 5 artifact; class-pharmacophore "
                "compatibility only (laws_satisfied) — never a "
                "disease-linked activity claim",
    }


def _admet_section(emitted, bench5, prof_sec) -> dict:
    if not prof_sec["phi"]:
        return {
            "absences": [absence(
                "ADMET_SCREEN_REQUIRES_MOLECULES", prof_sec["name"],
                "no molecule lane content for this disease, so no ADMET "
                "screen is attached", "S9_admet_toxicity_screen")],
            "screened": 0, "rows": [], "tier": "HYPOTHESIS",
        }
    rows = [{
        "mol_id": m["mol_id"],
        "descriptors": m.get("descriptors", {}),
        "lipinski": m.get("lipinski"), "veber": m.get("veber"),
        "sa_score": m.get("sa_score"),
        "solubility_class": m.get("solubility_class"),
        "permeability_class": m.get("permeability_class"),
        "toxicity_alerts": m.get("toxicity_alerts", []),
        "prediction_label": "PREDICTED_RULEBASED",
    } for m in emitted]
    return {"screened": len(rows), "rows": rows,
            "admet_registry": bench5.get("admet_registry"),
            "tier": "COMPUTATIONAL",
            "absences": [],
            "note": "rule-layer descriptors only; the ADMET ML-model "
                    "registry ships EMPTY — PREDICTED_ML requests are "
                    "refused, and no docking claim exists in this round"}


def _ranking_section(targets_sec, repurposing_sec, graph_sec,
                     approved_sec) -> dict:
    """Evidence-weighted transparent fusion. No hidden weights: each
    lane contributes (tier, rank); fusion sort key is
    (tier asc, best rank asc, name). Every contributing lane value is
    displayed on the row."""
    rows = {}

    def add(name, kind, lane, tier, rank, flags=()):
        r = rows.setdefault(name, {"name": name, "kind": kind,
                                   "lanes": [], "tiers": [],
                                   "lane_ranks": [], "flags": set()})
        r["lanes"].append(lane)
        r["tiers"].append(tier)
        r["lane_ranks"].append(rank)
        r["flags"] |= set(flags)

    for r in targets_sec.get("ranked_targets", []):
        add(r["symbol"], "intervention_point", "module_B_targets",
            r["tier"], r["rank"], r["flags"])
    for r in repurposing_sec.get("candidates", []):
        flags = []
        if r["rank_tier"] == "MECH_STRUCTURE_CONFLICT":
            flags.append("MECH_STRUCTURE_CONFLICT")
        add(r["drug"], "drug", "module_C_repurposing", r["tier"],
            r["rank"], flags)
    for r in graph_sec.get("graph_ranking", []):
        add(r["drug"], "drug", "module_E_graph", "EVIDENCED", None)
    for r in approved_sec.get("drugs", []):
        add(r["drug"], "drug", "kb_guideline_first_line", "EVIDENCED",
            r["guideline_tier"])

    out = []
    for name, r in rows.items():
        tier = "HYPOTHESIS"
        for t in r["tiers"]:
            tier = tier_join(tier, t)
        ranks = [x for x in r["lane_ranks"] if x is not None]
        out.append({
            "name": name, "kind": r["kind"], "lanes": r["lanes"],
            "lane_tiers": r["tiers"], "lane_ranks": r["lane_ranks"],
            "fusion_tier": tier,
            "best_lane_rank": min(ranks) if ranks else None,
            "flags": sorted(r["flags"]),
            "aggregate_label": "COMPUTATIONAL_RANK (rank fusion; never a "
                               "probability; never a predicted efficacy)",
        })
    out.sort(key=lambda r: (TIER_RANK.get(r["fusion_tier"], 9),
                            r["best_lane_rank"] is None,
                            r["best_lane_rank"] or 0, r["name"]))
    for i, r in enumerate(out, 1):
        r["rank"] = i
    return {"rows": out, "row_count": len(out),
            "fusion_rule": "sort by (fusion tier, best lane rank, name); "
                           "fusion tier = JOIN (strongest lane evidence) "
                           "over contributing lanes",
            "tier": "COMPUTATIONAL",
            "absences": [] if out else [absence(
                "NO_RANKABLE_CANDIDATES", "-",
                "no lane produced candidates for this disease",
                "S10_evidence_weighted_transparent_ranking")]}


def _checks_section(kb, g, report) -> dict:
    kb.validate_kb()                                   # raises on failure
    inj = injectivity_report(kb.DISEASES)
    lang = _scan_language(report)
    checks = {
        "kb_validate": {"passed": True, "tier": "PROVEN_MATH",
                        "note": "v14.1 KB self-validation raised nothing"},
        "phi_injectivity": {"passed": bool(inj["proved"]),
                            "tier": "PROVEN_MATH",
                            "stats": inj["stats"]},
        "graph_consistency": {"passed": True, "tier": "PROVEN_MATH",
                              "stats": {"edges": len(g.edges),
                                        "nodes": len(g.node_layer)},
                              "note": "build gate admits only "
                                      "relation/layer/tier-consistent "
                                      "edges; construction succeeded"},
        "forbidden_language_scan": {
            "passed": not lang, "hits": lang,
            "tier": "PROVEN_MATH",
            "note": "scan for cure/treats/efficacious-class tokens "
                    "outside quoted guideline text"},
        "pin_status": {
            "passed": True, "tier": "PROVEN_MATH",
            "note": "all served tables are pin-checked at load time "
                    "(target, repurposing, P8 graph, validation, "
                    "chem manifest); Phase 5 artifact sha256 recorded "
                    "in S11 of this report",
        },
    }
    return {"checks": checks, "all_passed": all(
        c["passed"] for c in checks.values())}


def _plans_section(reg, pack, resolved, top_rows) -> dict:
    key = resolved["pack_key"]
    if not key or key not in pack.prediction_diseases:
        return {
            "absences": [absence(
                "NO_VALIDATION_PLAN_SOURCE", key or resolved["kb_did"] or "-",
                "validation plans are built from the Phase 4 prediction "
                "panel (top-3 ranked + ground-truth drugs per panel "
                "disease) and the Phase 5 generated molecules; this "
                "disease is not in the panel, so no plan is invented",
                "S12_attach_experimental_validation_plan")],
            "plans": [], "tier": "HYPOTHESIS",
            "generated_molecule_lane_note":
                "APXD-* generated molecules carry structure-only plans in "
                "the frozen Phase 7 universe (no disease context)",
        }
    pname = pack.diseases[key]["name"]
    plans = []
    for row in top_rows[:3]:
        plans.append(vp.plan_for_drug(reg, pack, row, key, pname))
    plans.sort(key=lambda p: p["plan_id"])
    return {"plans": plans, "plan_count": len(plans),
            "tier": "EVIDENCED",
            "absences": [],
            "note": "plans carry stage gates with honest states and the "
                    "required-evidence-to-change-status section; a "
                    "REGISTRY_ACTIVITY_PRESENT gate state means 'trials "
                    "exist', never 'efficacy shown'"}


# ---------------------------------------------------------------------
# report assembly
# ---------------------------------------------------------------------

def discover(spec: dict, as_of_year: int = None, verbose: bool = True) -> dict:
    """Build the 18-section structured discovery report for one disease.

    Deterministic: no wall-clock fields; two invocations with the same
    spec produce identical canonical JSON.
    """
    import disease_drug_kb as kb_module

    def log(m):
        if verbose:
            print(f"[discover] {m}")

    table = load_targets()
    pack = load_pack()
    from v15.kgraph import KnowledgeGraph
    graph = KnowledgeGraph.from_frozen()
    bench5, phase5_sha, emitted = _load_phase5()
    reg = None                                   # built lazily (S12)

    steps = {s: {"status": "not_run", "absences": []} for s in WORKFLOW_STEPS}

    # --- S1 -----------------------------------------------------------
    resolved = resolve_disease(spec, kb_module, pack)
    steps["S1_normalize_input"]["status"] = "done"
    steps["S1_normalize_input"]["absences"] = resolved["absences"]
    log(f"resolved: match_kind={resolved['match_kind']} "
        f"kb_did={resolved['kb_did']} pack_key={resolved['pack_key']}")

    # --- S2/S3 --------------------------------------------------------
    if resolved["kb_row"]:
        prof_sec = _kb_profile_section(resolved["kb_row"])
    else:
        nm = spec.get("name") or spec.get("did") or "(unnamed input)"
        prof_sec = _ood_profile_section(spec, nm)
    verdict_sec = _verdict_section(prof_sec, resolved)
    steps["S2_build_disease_profile"]["status"] = "done"
    steps["S3_resolve_six_channel_identity"]["status"] = (
        "done" if prof_sec["phi"] else "done_with_explicit_absence")
    steps["S3_resolve_six_channel_identity"]["absences"] = \
        verdict_sec["absences"]

    did = resolved["kb_did"]

    # --- S4 -----------------------------------------------------------
    graph_sec = _graph_section(graph, did, resolved)
    steps["S4_resolve_graph_neighborhood"]["status"] = (
        "done" if graph_sec["found"] else "done_with_explicit_absence")
    steps["S4_resolve_graph_neighborhood"]["absences"] = \
        graph_sec["absences"]

    # --- S5 -----------------------------------------------------------
    targets_sec = _targets_section(table, did, resolved)
    steps["S5_rank_molecular_intervention_points"]["status"] = (
        "done" if targets_sec["in_panel"] else "done_with_explicit_absence")
    steps["S5_rank_molecular_intervention_points"]["absences"] = \
        targets_sec["absences"]

    # --- S6 -----------------------------------------------------------
    approved_sec = _approved_drugs_section(resolved["kb_row"], kb_module,
                                           pack, as_of_year)
    steps["S6_retrieve_approved_and_investigational_drugs"]["status"] = (
        "done" if approved_sec["drugs"] else "done_with_explicit_absence")

    # --- S7 -----------------------------------------------------------
    repurposing_sec = _repurposing_section(pack, resolved, as_of_year)
    steps["S7_generate_repurposing_hypotheses"]["status"] = (
        "done" if repurposing_sec.get("candidates")
        else "done_with_explicit_absence")
    steps["S7_generate_repurposing_hypotheses"]["absences"] = \
        repurposing_sec["absences"]

    # --- S8/S9 --------------------------------------------------------
    mol_sec = _molecules_section(emitted, phase5_sha, prof_sec)
    admet_sec = _admet_section(emitted, bench5, prof_sec)
    steps["S8_surface_novel_candidate_molecules"]["status"] = (
        "done" if mol_sec.get("candidates")
        else "done_with_explicit_absence")
    steps["S8_surface_novel_candidate_molecules"]["absences"] = \
        mol_sec["absences"]
    steps["S9_admet_toxicity_screen"]["status"] = (
        "done" if admet_sec.get("screened")
        else "done_with_explicit_absence")
    steps["S9_admet_toxicity_screen"]["absences"] = admet_sec["absences"]

    # --- S10 (needs S5-S8 rows) ---------------------------------------
    ranking_sec = _ranking_section(targets_sec, repurposing_sec,
                                   graph_sec, approved_sec)
    steps["S10_evidence_weighted_transparent_ranking"]["status"] = "done"

    # --- S12 (plans first: S11's language scan covers plan text) ------
    top_rows = repurposing_sec.get("candidates", [])
    reg = vp._registry_with_ledgers(pack, graph_ns=None)
    plans_sec = _plans_section(reg, pack, resolved, top_rows)
    steps["S12_attach_experimental_validation_plan"]["status"] = (
        "done" if plans_sec.get("plans")
        else "done_with_explicit_absence")
    steps["S12_attach_experimental_validation_plan"]["absences"] = \
        plans_sec["absences"]

    # --- S11 (needs the assembled content lanes for the scan) ---------
    draft = {
        "S04": prof_sec, "S07": graph_sec, "S08": targets_sec,
        "S09": approved_sec, "S10": repurposing_sec, "S11": mol_sec,
        "S12": admet_sec, "S15": plans_sec,
    }
    checks_sec = _checks_section(kb_module, graph, draft)
    steps["S11_apeiron_x_consistency_checks"]["status"] = (
        "done" if checks_sec["all_passed"]
        else "failed_loudly")

    # --- assemble the 18 sections -------------------------------------
    kb_identity = {
        "kb_did": did,
        "in_kb": bool(resolved["kb_row"]),
        "phi": prof_sec["phi"],
        "injectivity_context": {
            "theorem": "phi-injectivity on the disease corpus",
            "proved": bool(injectivity_report(
                kb_module.DISEASES)["proved"]),
        },
        "tier": "PROVEN_MATH" if resolved["kb_row"] else "HYPOTHESIS",
    }
    dg_edges = [e for e in graph.edges_of("disease->gene")
                if did and e["src"] == did]
    prov = _provenance_ledger(table, pack, graph, bench5, phase5_sha,
                              resolved, targets_sec, repurposing_sec,
                              approved_sec, dg_edges)
    report = {
        "S01_report_header": {
            "report_label": REPORT_LABEL,
            "schema_version": DISCOVER_SCHEMA_VERSION,
            "program_version": PROGRAM_VERSION,
            "determinism": "no wall-clock fields; two builds of the same "
                           "input are byte-identical (canonical sha256 "
                           "recorded at S18)",
            "as_of_year": as_of_year,
            "sections": list(REPORT_SECTIONS),
            "workflow_steps": list(WORKFLOW_STEPS),
            "tier": "PROVEN_MATH",
        },
        "S02_claim_tier_legend": {
            "tiers": CLAIM_TIER_LEGEND,
            "tier_order": list(TIER_LADDER),
            "aggregate_label": "COMPUTATIONAL_RANK",
            "tier": "PROVEN_MATH",
        },
        "S03_input_record": {
            "spec_submitted": {k: spec[k] for k in sorted(spec)},
            "resolution": {k: v for k, v in resolved.items()
                           if k != "kb_row"},
            "kb_row_included": bool(resolved["kb_row"]),
            "tier": "PROVEN_MATH",
        },
        "S04_disease_profile": prof_sec,
        "S05_encodability_verdict": verdict_sec,
        "S06_kb_identity": kb_identity,
        "S07_graph_neighborhood": graph_sec,
        "S08_ranked_targets": targets_sec,
        "S09_approved_and_investigational_drugs": approved_sec,
        "S10_repurposing_candidates": repurposing_sec,
        "S11_novel_candidate_molecules": mol_sec,
        "S12_admet_toxicity_screen": admet_sec,
        "S13_evidence_weighted_ranking": ranking_sec,
        "S14_consistency_checks": checks_sec,
        "S15_experimental_validation_plans": plans_sec,
        "S16_provenance_ledger": prov,
        "S17_honest_limits": _limits_section(resolved, prof_sec,
                                             targets_sec, repurposing_sec,
                                             graph_sec),
        "S18_reproducibility_and_non_goals": {
            "workflow_steps_status": steps,
            "non_goals": list(NON_GOALS),
            "canonical_sha256_note": "computed over the report payload "
                                     "with this field removed "
                                     "(see sha256_of_report)",
            "tier": "PROVEN_MATH",
        },
    }
    report["S01_report_header"]["canonical_sha256"] = None
    report["S01_report_header"]["canonical_sha256"] = \
        sha256_of_report(report)
    return report


def sha256_of_report(report: dict) -> str:
    body = {k: v for k, v in report.items() if k != "S01_report_header"}
    return canonical_sha256(body)


# ---------------------------------------------------------------------
# provenance ledger
# ---------------------------------------------------------------------

def _provenance_ledger(table, pack, graph, bench5, phase5_sha, resolved,
                       targets_sec, repurposing_sec, approved_sec,
                       graph_edges) -> dict:
    ids = set()
    for r in targets_sec.get("ranked_targets", []):
        ids |= set(r["source_ids"])
    for r in repurposing_sec.get("candidates", []):
        ids |= set(r["sources"])
    for r in approved_sec.get("drugs", []):
        ids |= set(r["sources"])
    for e in graph_edges:
        ids |= set(e["sources"])
    ledger, unresolvable = {}, []
    for sid in sorted(ids):
        try:
            rec = None
            for facade in (table, pack, graph):
                try:
                    rec = facade.source_record(sid)
                    break
                except KeyError:
                    continue
            if rec is None:
                unresolvable.append(sid)
            else:
                ledger[sid] = {k: rec[k] for k in sorted(rec)
                               if k not in ("absences",)}
        except KeyError:
            unresolvable.append(sid)
    return {
        "source_ids_used": sorted(ids),
        "records": ledger,
        "unresolvable": unresolvable,
        "phase5_artifact_sha256": phase5_sha,
        "tier": "EVIDENCED" if not unresolvable else "COMPUTATIONAL",
        "note": "every cited source id resolves against a frozen "
                "provenance ledger; an unresolvable id is a defect and "
                "would fail the acceptance gate",
    }


def _limits_section(resolved, prof_sec, targets_sec, repurposing_sec,
                    graph_sec) -> dict:
    lim = {
        "coverage": [
            "Module B target evidence exists for the 10-disease panel "
            "only; other diseases get an explicit absence",
            "Module C repurposing candidates exist for the Phase 4 "
            "cardio-renal prediction panel (HFREF/HFPEF/CKD/DKD) only",
            "the frozen P8 graph covers 10 diseases; other diseases "
            "have no asserted gene neighborhood",
            "novel molecules are served from the frozen Phase 5 "
            "artifact; they are class-pharmacophore candidates, never "
            "disease-linked activity claims",
            "ADMET content is PREDICTED_RULEBASED; the ML-model "
            "registry is EMPTY and no docking run record exists",
            "validation plans exist for the prediction-panel diseases "
            "and the APXD generated molecules only",
            "licences for DrugBank/BindingDB were not obtained, so "
            "those resources are cited by absence, not content",
        ],
        "this_report": {
            "in_domain": bool(resolved["kb_row"]),
            "encodability": prof_sec["phi"] and "ENCODABLE"
                            or "NOT_ENCODABLE",
            "absent_lanes": [s["lane"] for lane_list in
                             [targets_sec["absences"],
                              repurposing_sec["absences"],
                              graph_sec["absences"]]
                             for s in lane_list],
        },
        "doctrine": "absent data is named; it is never replaced by an "
                    "estimate, a guess or a fabrication",
    }
    return lim


# ---------------------------------------------------------------------
# report-level theorems (used by the Phase 8 battery + artifacts)
# ---------------------------------------------------------------------

def theorem_report_schema_completeness(reports) -> dict:
    bad, stats = [], {"reports": len(reports)}
    for label, rep in reports.items():
        missing = [s for s in REPORT_SECTIONS if s not in rep]
        extra = [k for k in rep if k not in REPORT_SECTIONS]
        steps = rep["S18_reproducibility_and_non_goals"][
            "workflow_steps_status"]
        missing_steps = [s for s in WORKFLOW_STEPS if s not in steps]
        if missing or extra or missing_steps:
            bad.append({"report": label, "missing_sections": missing,
                        "extra_sections": extra,
                        "missing_steps": missing_steps})
        stats[label] = {"sections": len(rep), "steps": len(steps)}
    return _th(
        "theorem_report_schema_completeness",
        "every discovery report carries exactly the 18 declared sections "
        "and the 12 declared workflow steps",
        not bad, stats,
        ["collect reports", "diff section/step keys against the declared "
         "tuples", "any diff is a counterexample"],
        bad)


def theorem_report_determinism(build_fn, labels) -> dict:
    """build_fn(label) -> a freshly built report for that label.
    Each probe is built twice; canonical sha256 must agree."""
    bad, stats = [], {}
    for label in labels:
        first = build_fn(label)
        second = build_fn(label)
        a, b = sha256_of_report(first), sha256_of_report(second)
        stats[label] = {"sha": a[:16], "identical": a == b}
        if a != b:
            bad.append(label)
    return _th(
        "theorem_report_determinism",
        "two independent builds of the same disease input produce "
        "byte-identical canonical reports (no wall-clock, no "
        "nondeterministic iteration order)",
        not bad, stats,
        ["build each probe report twice", "canonical-sha256 both",
         "a mismatch is a counterexample"], bad)


def theorem_report_absence_discipline(reports) -> dict:
    bad, stats = [], {"reports": len(reports), "absences": 0}
    for label, rep in reports.items():
        for sec_name, sec in rep.items():
            if not isinstance(sec, dict):
                continue
            for ab in sec.get("absences", []) or []:
                stats["absences"] += 1
                if not isinstance(ab, dict) or \
                        any(f not in ab for f in ABSENCE_FIELDS):
                    bad.append({"report": label, "section": sec_name,
                                "absence": ab})
        if rep["S03_input_record"]["resolution"]["absences"] is None:
            bad.append({"report": label, "section": "S03",
                        "absence": "null absences"})
    return _th(
        "theorem_report_absence_discipline",
        "every absence record carries exactly the four declared fields "
        "(code, subject, reason, lane); no absence is null or free-form",
        not bad, stats,
        ["walk all sections", "validate each absence record's fields"],
        bad)


def theorem_report_leakage_control(reports) -> dict:
    """Temporal + status leakage:
      1. an as_of report must not rank any drug whose frozen first
         approval year is >= as_of in ANY lane;
      2. APPROVED_INDICATION repurposing rows must have
         first_approval < as_of;
      3. generated APXD-* molecules never appear in any approved-drug
         or repurposing lane."""
    bad, stats = [], {"reports": len(reports)}
    for label, rep in reports.items():
        as_of = rep["S01_report_header"]["as_of_year"]
        names = [r["name"] for r in
                 rep["S13_evidence_weighted_ranking"]["rows"]]
        if as_of:
            for r in rep["S10_repurposing_candidates"].get("candidates",
                                                           []):
                fa = r.get("first_approval")
                if r["status"]["status"] == "APPROVED_INDICATION" and \
                        fa is not None and fa >= as_of:
                    bad.append({"report": label, "kind": "status_leak",
                                "drug": r["drug"], "first_approval": fa})
            post = rep["S09_approved_and_investigational_drugs"].get(
                "post_split_excluded") or []
            for d in post:
                if d in names:
                    bad.append({"report": label, "kind": "post_split_rank",
                                "drug": d})
        for lane in ("S09_approved_and_investigational_drugs",
                     "S10_repurposing_candidates"):
            rows = rep[lane].get("drugs", []) or \
                rep[lane].get("candidates", [])
            for r in rows:
                nm = r.get("drug", "")
                if nm.startswith("APXD-"):
                    bad.append({"report": label, "kind": "apxd_leak",
                                "lane": lane, "drug": nm})
        stats[label] = {"as_of": as_of, "ranked_names": len(names)}
    return _th(
        "theorem_report_leakage_control",
        "no report leaks post-split knowledge into an as_of view, and "
        "no generated molecule masquerades as an approved or "
        "repurposing drug",
        not bad, stats,
        ["check APPROVED_INDICATION rows against first_approval years",
         "check post-split excluded drugs against ranked names",
         "scan approved/repurposing lanes for APXD-* ids"],
        bad)


def theorem_report_claim_tier_discipline(reports) -> dict:
    bad, stats = [], {"reports": len(reports), "rows": 0}
    for label, rep in reports.items():
        for lane, key in (("S08_ranked_targets", "ranked_targets"),
                          ("S10_repurposing_candidates", "candidates"),
                          ("S11_novel_candidate_molecules", "candidates")):
            for r in rep[lane].get(key, []):
                stats["rows"] += 1
                if r.get("tier") not in TIER_LADDER:
                    bad.append({"report": label, "lane": lane,
                                "row": r.get("drug") or r.get("symbol")
                                or r.get("mol_id"),
                                "tier": r.get("tier")})
        for sec, kfield in (("S13_evidence_weighted_ranking", "rows"),):
            for r in rep[sec][kfield]:
                if "COMPUTATIONAL_RANK" not in r["aggregate_label"]:
                    bad.append({"report": label, "lane": sec,
                                "row": r["name"],
                                "label": r["aggregate_label"]})
        hits = rep["S14_consistency_checks"]["checks"][
            "forbidden_language_scan"]["hits"]
        if hits:
            bad.append({"report": label, "lane": "language_scan",
                        "hits": hits})
    return _th(
        "theorem_report_claim_tier_discipline",
        "every candidate row carries a tier from the four-rung ladder; "
        "every fusion row is labelled COMPUTATIONAL_RANK; the "
        "forbidden-language scan is clean",
        not bad, stats,
        ["walk candidate lanes", "validate tiers + labels", "language "
         "scan results from S14"], bad)


def theorem_report_out_of_domain(reports) -> dict:
    """An out-of-domain input must produce: NOT_ENCODABLE or explicitly
    cited phi, no targets, no repurposing, no plans, no graph
    neighborhood — absences everywhere, never guesses."""
    bad, stats = [], {"reports": len(reports)}
    for label, rep in reports.items():
        in_dom = rep["S05_encodability_verdict"]["in_domain"]
        if in_dom:
            continue
        if rep["S08_ranked_targets"]["in_panel"]:
            bad.append({"report": label, "lane": "targets"})
        if rep["S10_repurposing_candidates"].get("candidates"):
            bad.append({"report": label, "lane": "repurposing"})
        if rep["S15_experimental_validation_plans"].get("plans"):
            bad.append({"report": label, "lane": "plans"})
        if rep["S07_graph_neighborhood"].get("found"):
            bad.append({"report": label, "lane": "graph"})
        stats[label] = {"in_domain": False,
                        "verdict": rep["S05_encodability_verdict"]
                        ["verdict"]}
    return _th(
        "theorem_report_out_of_domain",
        "an out-of-domain disease input yields the honest empty world: "
        "no targets, no repurposing candidates, no plans, no graph "
        "neighborhood — only explicit absences",
        not bad, stats,
        ["select reports with in_domain=false", "assert every covered "
         "lane is empty-with-absence"], bad)


# ---------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------

def _short_report_text(rep) -> str:
    lines = []
    A = lines.append
    hdr = rep["S01_report_header"]
    A(f"APEIRON-X STRUCTURED DISCOVERY REPORT — schema "
      f"{hdr['schema_version']} ({hdr['program_version']})")
    A(f"canonical sha256: {hdr['canonical_sha256'][:32]}…  "
      f"as_of_year: {hdr['as_of_year']}")
    prof = rep["S04_disease_profile"]
    A(f"disease: {prof['name']}  "
      f"encodability: {rep['S05_encodability_verdict']['verdict']}")
    A("")
    A("evidence-weighted ranking (fusion of lanes; COMPUTATIONAL_RANK):")
    for r in rep["S13_evidence_weighted_ranking"]["rows"][:12]:
        A(f"  #{r['rank']:>2} {r['name']:<28} [{r['fusion_tier']}] "
          f"lanes={','.join(r['lanes'])}")
    tg = rep["S08_ranked_targets"]
    if tg.get("in_panel"):
        A("")
        A("top intervention points (Module B):")
        for r in tg["ranked_targets"][:5]:
            A(f"  #{r['rank']:>2} {r['symbol']:<10} "
              f"agg={r['aggregate']:<7} "
              f"label={r['aggregate_label'].split(' [')[0]}")
    rp = rep["S10_repurposing_candidates"]
    if rp.get("candidates"):
        A("")
        A("repurposing top-5 (Module C, Theta_d bridge exposed):")
        for r in rp["candidates"][:5]:
            A(f"  #{r['rank']:>2} {r['drug']:<20} "
              f"support={r['support_level']:<9} "
              f"tier={r['rank_tier']}")
    pl = rep["S15_experimental_validation_plans"]
    if pl.get("plans"):
        A("")
        A(f"validation plans attached: {pl['plan_count']} "
          f"(Module F)")
        for p in pl["plans"]:
            A(f"  {p['plan_id']}: {p['candidate']['id']} "
              f"[{p['candidate']['status']}]")
    ab = [(s, a["code"]) for s, sec in rep.items()
          if isinstance(sec, dict)
          for a in (sec.get("absences") or [])]
    if ab:
        A("")
        A("explicit absences:")
        for s, code in ab:
            A(f"  {s}: {code}")
    lim = rep["S17_honest_limits"]["this_report"]
    A("")
    A(f"honest limits: in_domain={lim['in_domain']}  "
      f"encodability={lim['encodability']}")
    A("non-goals: " + "; ".join(rep["S18_reproducibility_and_non_goals"]
                                ["non_goals"]))
    return "\n".join(lines)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--disease", help='disease did or exact name, e.g. '
                   '"D02" or "type 2 diabetes mellitus"')
    g.add_argument("--json-spec", help="disease spec as a JSON object")
    g.add_argument("--list-steps", action="store_true",
                   help="print the 12 workflow steps + 18 sections")
    ap.add_argument("--as-of", type=int, default=None,
                    help="temporal lane: build the pre-<year> view")
    ap.add_argument("--out", default=None, help="write JSON here")
    args = ap.parse_args()

    if args.list_steps:
        print("workflow steps:")
        for s in WORKFLOW_STEPS:
            print(f"  {s}")
        print("report sections:")
        for s in REPORT_SECTIONS:
            print(f"  {s}")
        return 0

    if args.json_spec:
        spec = json.loads(args.json_spec)
    else:
        d = args.disease
        spec = {"did": d} if _looks_like_did(d) else {"name": d}

    rep = discover(spec, as_of_year=args.as_of)
    print(_short_report_text(rep))
    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(rep, fh, indent=2, sort_keys=True)
        print(f"\n[discover] JSON written to {args.out}")
    return 0


def _looks_like_did(s: str) -> bool:
    import re as _re
    return bool(_re.fullmatch(r"[A-Z]{1,3}\d{1,4}", s or ""))


if __name__ == "__main__":
    sys.exit(main())
