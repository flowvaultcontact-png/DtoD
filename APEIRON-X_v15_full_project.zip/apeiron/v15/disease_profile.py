"""Module A data model — universal disease profile (P2-2).

A DiseaseProfile extends (never replaces) the v14.1 six-channel encoding:
it layers evidence-tagged biological fields on top. Conversion to phi(d)
is explicit and fails loudly when the vocabulary cannot serve the
disease, so the v14.1 honesty doctrine (Tier B: sound refusals) carries
into v15.

P2-2 upgrades over the Phase 1 scaffold:
  * layered evidence map: per-field status established / inferred /
    unknown, and phi resolution via CITED channel-value candidates
    (`phi_candidates`) validated against the LIVE v14.1 vocabulary;
  * `derive_phi()`: profile -> phi(d) with the three-valued encodability
    verdict (ENCODABLE / PARTIALLY_ENCODABLE / NOT_ENCODABLE);
  * `profile_from_kb_row()` + `to_phi_checked()`: machine round-trip
    KB row -> profile -> phi (acceptance test of Phase 2);
  * `injectivity_report()`: the merged-corpus injectivity theorem helper
    (all six-channel tuples pairwise distinct).

Pure data model: imports NO knowledge table at module level, performs no
biological inference, fabricates nothing. Field values arrive from the
frozen v15 vocab / knowledge packs with SourceRecord citations.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional

# The v14.1 channels, re-declared read-only (single source of truth stays
# disease_drug_kb.CHANNELS; the cascade test asserts the two agree).
V15_CHANNELS = ("system", "etiology", "microbe", "site", "chronicity",
                "pathway")

# Layered-evidence fields of the universal profile (master prompt, Module A).
PROFILE_FIELDS = (
    "ontology_ids",        # e.g. MONDO:, OMIM:, ICD-10, MeSH (with source ids)
    "genetics",            # mutations/variants (HGNC/Ensembl ids + evidence)
    "expression",          # gene-expression signature
    "protein_abnormality", # protein-level pathology
    "metabolic",           # metabolic dysfunction
    "immune",              # immune dysfunction
    "cellular",            # cellular dysfunction
    "tissue_pathology",    # tissue-specific pathology
    "pathways",            # disease-associated molecular pathways
    "progression",         # progression / phenotypes
    "environmental",       # environmental & infectious factors
)

FIELD_STATUSES = ("established", "inferred", "unknown")


class Encodability(Enum):
    ENCODABLE = "ENCODABLE"              # all six channels derivable + cited
    PARTIALLY_ENCODABLE = "PARTIALLY"    # some channels derivable + cited
    NOT_ENCODABLE = "NOT_ENCODABLE"      # vocabulary cannot serve this disease


@dataclass
class DiseaseProfile:
    name: str
    fields: dict = field(default_factory=dict)      # field -> list of (value, source_ids)
    field_status: dict = field(default_factory=dict)  # field -> established|inferred|unknown
    phi: Optional[dict] = None                      # six-channel encoding if resolved
    phi_source_ids: tuple = ()                      # citations for the encoding itself
    phi_candidates: dict = field(default_factory=dict)
    #   channel -> list of (value, source_ids); >=1 entry per derivable channel
    encodability: Encodability = Encodability.NOT_ENCODABLE
    unresolved_channels: tuple = ()
    notes: str = ""

    def __post_init__(self):
        if not self.name or not isinstance(self.name, str):
            raise ValueError("DiseaseProfile.name must be a non-empty string")
        unknown = set(self.fields) - set(PROFILE_FIELDS)
        if unknown:
            raise ValueError(f"unknown profile fields: {sorted(unknown)}")
        for k, entries in self.fields.items():
            for e in entries:
                if not (isinstance(e, tuple) and len(e) == 2 and e[1]):
                    raise ValueError(
                        f"field {k} entries must be (value, non-empty source_ids)")
        for k, st in self.field_status.items():
            if k not in PROFILE_FIELDS or st not in FIELD_STATUSES:
                raise ValueError(
                    f"field_status[{k}] must be one of {FIELD_STATUSES} "
                    "and name a known profile field")
        for ch, cands in self.phi_candidates.items():
            if ch not in V15_CHANNELS:
                raise ValueError(f"phi_candidates channel {ch!r} not in "
                                 "the six v14.1 channels")
            for e in cands:
                if not (isinstance(e, tuple) and len(e) == 2 and e[1]
                        and isinstance(e[0], str) and e[0]):
                    raise ValueError(
                        f"phi_candidates[{ch}] entries must be "
                        "(value, non-empty source_ids)")
        if self.phi is not None:
            if set(self.phi) != set(V15_CHANNELS):
                raise ValueError("phi must have exactly the six v14.1 channels")
            if any(not isinstance(self.phi[c], str) or not self.phi[c]
                   for c in V15_CHANNELS):
                raise ValueError("phi channel values must be non-empty strings")
            if not self.phi_source_ids:
                raise ValueError("an explicit phi encoding needs citations "
                                 "(guideline/mechanism evidence), not guesses")
        if not isinstance(self.encodability, Encodability):
            self.encodability = Encodability(self.encodability)

    # -- layered evidence -------------------------------------------------
    def set_field(self, field_name: str, entries, status: str) -> None:
        if field_name not in PROFILE_FIELDS:
            raise ValueError(f"unknown profile field {field_name!r}")
        if status not in FIELD_STATUSES:
            raise ValueError(f"status must be one of {FIELD_STATUSES}")
        self.fields[field_name] = list(entries)
        self.field_status[field_name] = status

    def unknown_fields(self) -> tuple:
        return tuple(f for f in PROFILE_FIELDS
                     if self.field_status.get(f, "unknown") == "unknown")

    # -- encoding paths ----------------------------------------------------
    def set_encoding(self, phi: dict, source_ids) -> None:
        """Attach a cited six-channel encoding and mark ENCODABLE."""
        self.phi = dict(phi)
        self.phi_source_ids = tuple(source_ids)
        self.__post_init__()
        self.encodability = Encodability.ENCODABLE

    def mark_not_encodable(self, why: str) -> None:
        """Honest refusal path (extends the v14.1 Tier B doctrine)."""
        if self.phi is not None:
            raise ValueError("cannot mark a profile with an encoding as "
                             "NOT_ENCODABLE; clear phi first")
        self.encodability = Encodability.NOT_ENCODABLE
        self.notes = (self.notes + " | " if self.notes else "") + why

    def derive_phi(self, valid_values: dict) -> dict:
        """Resolve phi from `phi_candidates` against the LIVE vocabulary.

        `valid_values`: channel -> iterable of values the v14.1 closed
        world can serve (KB rows + pack-declared new values). Every
        candidate value must be a member — unknown values raise, they are
        never coerced into the corpus.

        Verdict:
          ENCODABLE           — all six channels resolved uniquely + cited
          PARTIALLY_ENCODABLE — 1..5 channels resolved; phi stays unset
          NOT_ENCODABLE       — zero channels resolved
        """
        resolved, unresolved = {}, []
        for ch in V15_CHANNELS:
            cands = self.phi_candidates.get(ch, [])
            if not cands:
                unresolved.append(ch)
                continue
            allowed = set(valid_values[ch])
            for v, _src in cands:
                if v not in allowed:
                    raise ValueError(
                        f"{self.name}: channel {ch} candidate {v!r} is not "
                        "in the live vocabulary; refusing to invent a value")
            values = {v for v, _s in cands}
            if len(values) != 1:
                unresolved.append(ch)     # conflicting candidates: not derived
                continue
            resolved[ch] = cands[0][0]
        if len(resolved) == len(V15_CHANNELS):
            srcs = tuple(sorted({s for ch in V15_CHANNELS
                                 for _v, s in self.phi_candidates[ch]}))
            self.set_encoding(resolved, srcs)
            self.unresolved_channels = ()
        elif resolved:
            self.encodability = Encodability.PARTIALLY_ENCODABLE
            self.unresolved_channels = tuple(unresolved)
        else:
            self.encodability = Encodability.NOT_ENCODABLE
            self.unresolved_channels = tuple(unresolved)
            self.notes = (self.notes + " | " if self.notes else "") + \
                "no channel derivable from cited candidates"
        return dict(resolved)

    def to_phi_checked(self, engine_module) -> dict:
        """Return phi(d) only if the encoding exists AND is accepted by the
        v14.1 normalizer (pass `apeiron_drug_discovery_proof` here; the
        import stays read-only). Raises, never coerces."""
        if self.phi is None:
            raise ValueError(f"{self.name}: no six-channel encoding attached "
                             f"(encodability={self.encodability.value})")
        engine_module.normalize_query(self.phi)   # strict v14.1 gate, raises if invalid
        return dict(self.phi)


# -- builders / theorems ---------------------------------------------------

def profile_from_kb_row(row: dict) -> DiseaseProfile:
    """Build a profile from a v14.1 KB row (round-trip entry point).
    The KB row itself is the citation for its encoding (internal,
    hash-pinned source), ontology ids come from the frozen vocab when
    available."""
    prof = DiseaseProfile(
        name=row["name"],
        phi={c: row[c] for c in V15_CHANNELS},
        phi_source_ids=(f"KB:{row['did']}",),
    )
    prof.encodability = Encodability.ENCODABLE
    prof.fields["ontology_ids"] = [(f"KB:{row['did']}", "KB:INDEX")]
    prof.field_status["ontology_ids"] = "established"
    return prof


def injectivity_report(rows) -> dict:
    """Theorem T4-style report: the map phi is injective on `rows`
    (pairwise-distinct six-channel tuples). PROVEN_MATH on the corpus."""
    seen, dup = {}, []
    for r in rows:
        key = tuple(r[c] for c in V15_CHANNELS)
        if key in seen:
            dup.append((seen[key], r.get("did", "?")))
        seen[key] = r.get("did", "?")
    return {
        "theorem": "phi-injectivity on the disease corpus",
        "statement": "every six-channel encoding denotes exactly one "
                     "disease row (pairwise distinct tuples)",
        "proved": not dup,
        "tier": "PROVEN_MATH",
        "counterexamples": dup,
        "stats": {"rows": len(rows), "distinct_tuples": len(seen)},
        "proof_steps": [
            "enumerate all rows; build tuple T(d) over CHANNELS",
            "hash-insert T(d); a collision is a counterexample",
            f"result: {len(seen)} distinct tuples over {len(rows)} rows",
        ],
    }
