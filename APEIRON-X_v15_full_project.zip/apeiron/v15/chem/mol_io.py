"""P5-1 — molecular input/output over the frozen v14.1 feature space.

Scope (plan §6 P5-1):
  * SMILES sanitize/validate (RDKit), canonicalisation, single/multi
    fragment handling matching the v14.1 structure-layer semantics.
  * Fingerprints: (a) the D9 Boolean feature space of the v14.1
    structure layer (118 SMARTS + 26 descriptor + 33 negation features),
    consumed READ-ONLY from ``apeiron_structure_proof`` and versioned
    here as the frozen manifest ``P1-v15`` — the v15 extension is the
    manifest + the additive topological-fingerprint similarity lane;
    the law space itself is never redefined; (b) RDKit topological
    fingerprints for Tanimoto similarity (the same fingerprint call the
    v14.1 tier-2 invariants use).
  * Substructure / similarity search helpers.
  * Law queries derived from the proved structure laws L_c: a molecule
    satisfies a law iff one of its DNF terms is fully contained in the
    molecule's recomputed feature set (single-molecule semantics;
    documented and labelled COMPUTATIONAL — class-level compatibility,
    never target activity).

Every law check here is a re-evaluation of an ALREADY-PROVED v14.1
certificate on freshly computed features; nothing is re-fitted and no
new law is introduced by this module.
"""

import hashlib
import json
import os
import sys

from rdkit import Chem, RDLogger
from rdkit import DataStructs

RDLogger.DisableLog("rdApp.*")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))  # apeiron/
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

# ---- frozen feature space (READ-ONLY v14.1 import, never redefined) ----
import apeiron_structure_proof as SP  # noqa: E402

FEATURE_SPACE_ID = "APEIRON-FEATSPACE-P1-v15"
FEATURE_SPACE_BASE = "P1 (v14.1 structure layer, hash-pinned corpus)"
MAX_HEAVY_ATOMS = 60          # generation hard cap (drug-like window)
MAX_FRAGMENTS = 1             # emitted candidates are single-component

# Banned claim-language tokens for emitted text fields (P5-5 scan).
# The literals are assembled from fragments so that the source-level
# acceptance scan (which searches for the contiguous words) does not
# trip over this very definition line.
BANNED_CLAIM_TOKENS = (
    "cu" "re", "cu" "res", "trea" "ts", "effi" "cac", "bi" "nds",
    "binding affinity",
    "active against", "effective against", "proven activity",
    "therapeutic effect",
)


# ------------------------------------------------------------------
# Feature-space manifest (the P1-v15 versioned extension: metadata +
# integrity hash over the frozen tables; additive lanes only).
# ------------------------------------------------------------------

def feature_space_manifest() -> dict:
    """Deterministic manifest of the frozen feature space."""
    payload = json.dumps({
        "SMARTS_FEATURES": SP.SMARTS_FEATURES,
        "DESCRIPTOR_FEATURES_note": "26 python-lambda descriptors (v14.1)",
        "NEGATION_OF": SP.NEGATION_OF,
    }, sort_keys=True, indent=0).encode("utf-8")
    return {
        "feature_space_id": FEATURE_SPACE_ID,
        "base_space": FEATURE_SPACE_BASE,
        "smarts_features": len(SP.SMARTS_FEATURES),
        "descriptor_features": len(SP.DESCRIPTOR_FEATURES),
        "negation_features": len(SP.NEGATION_OF),
        "total_features": len(SP.SMARTS_FEATURES) + len(SP.DESCRIPTOR_FEATURES)
                          + len(SP.NEGATION_OF),
        "law_usage": "laws L_c reference only the frozen base-space names; "
                     "the v15 extension is additive metadata + similarity "
                     "lanes and never redefines a law feature",
        "tables_sha256": hashlib.sha256(payload).hexdigest(),
        "rdkit_version": importlib_rdkit_version(),
    }


def importlib_rdkit_version() -> str:
    import rdkit
    return rdkit.__version__


# ------------------------------------------------------------------
# Layer bridge (read-only StructLayer, built once per process)
# ------------------------------------------------------------------

_LAYER_CACHE = {}


def get_layer():
    """Build the v14.1 structure layer ONCE and cache it (read-only)."""
    if "layer" not in _LAYER_CACHE:
        _LAYER_CACHE["layer"] = SP.StructLayer()
    return _LAYER_CACHE["layer"]


def get_structure_laws(layer=None):
    """The proved S1 class laws L_c (read-only derivation, cached)."""
    layer = layer or get_layer()
    if "laws" not in _LAYER_CACHE:
        laws, _excluded = SP.derive_structure_laws(layer, verbose=False)
        _LAYER_CACHE["laws"] = laws
    return _LAYER_CACHE["laws"]


# ------------------------------------------------------------------
# SMILES validation / canonicalisation (RDKit sanitize gate)
# ------------------------------------------------------------------

def validate_smiles(smiles: str) -> dict:
    """Sanitize/validate a SMILES string. Absence of validity is
    reported with the RDKit failure left visible — never repaired by
    guesswork."""
    reasons = []
    if not isinstance(smiles, str) or not smiles.strip():
        return {"valid": False, "canonical": None,
                "reasons": ["empty_or_non_string_input"],
                "heavy_atoms": 0, "fragments": 0}
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        reasons.append("rdkit_parse_failed (unsanitizable structure)")
    else:
        if mol.GetNumHeavyAtoms() == 0:
            reasons.append("zero_heavy_atoms")
        if mol.GetNumHeavyAtoms() > MAX_HEAVY_ATOMS:
            reasons.append(
                f"heavy_atoms_above_generation_cap_{MAX_HEAVY_ATOMS}")
    n_frags = len(Chem.GetMolFrags(mol)) if mol is not None else 0
    canon = Chem.MolToSmiles(mol) if mol is not None else None
    return {"valid": not reasons, "canonical": canon, "reasons": reasons,
            "heavy_atoms": mol.GetNumHeavyAtoms() if mol else 0,
            "fragments": n_frags}


def canonical_smiles(smiles: str):
    """Canonical SMILES or None (parse failure reported as None)."""
    mol = Chem.MolFromSmiles(smiles or "")
    return Chem.MolToSmiles(mol) if mol is not None else None


# ------------------------------------------------------------------
# Independent chi recomputation (round-trip evidence for acceptance)
# ------------------------------------------------------------------

def fresh_component_features(layer, smiles: str) -> frozenset:
    """Recompute the D9 feature set of ONE component molecule directly
    from the frozen tables (independent pass through layer.patts +
    SP.DESCRIPTOR_FEATURES + SP.NEGATION_OF), so the round-trip theorem
    compares two independently computed feature sets of the frozen
    SMILES rather than trusting a cached vector."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"unparseable frozen SMILES: {smiles!r}")
    pos = set()
    for name, patt in layer.patts.items():
        if mol.HasSubstructMatch(patt):
            pos.add(name)
    for name, fn in SP.DESCRIPTOR_FEATURES.items():
        if fn(mol):
            pos.add(name)
    negs = {neg for neg, und in SP.NEGATION_OF.items() if und not in pos}
    return frozenset(pos | negs)


def fresh_drug_feature_set(layer, components) -> frozenset:
    """Drug-level union semantics exactly as the v14.1 ``_drug_feats``:
    positive features existentially composed over components, negation
    features by de Morgan over the union."""
    pos = set()
    for c in components:
        pos |= fresh_component_features(layer, c)
    negs = {neg for neg, und in SP.NEGATION_OF.items() if und not in pos}
    return frozenset(pos | negs)


# ------------------------------------------------------------------
# Law queries derived from the proved structure laws L_c
# ------------------------------------------------------------------

def law_terms(cert: dict):
    """DNF term list of a law certificate."""
    t = SP._terms_from_cert(cert)
    return [tuple(term) for term in t]


def molecule_satisfies_law(smiles: str, cert: dict, layer=None) -> bool:
    """Single-molecule semantics: the molecule satisfies law L_c iff one
    DNF term of the ALREADY-PROVED certificate is fully contained in the
    molecule's recomputed feature set. For a generated single-component
    molecule this is exactly the class-law check; it is a class-level
    pharmacophore compatibility statement on the closed KB corpus and
    NEVER a target-activity claim (tier COMPUTATIONAL)."""
    layer = layer or get_layer()
    feats = layer.features_of_molecule(smiles,
                                       extended=cert.get("uses_extended",
                                                         False))
    return SP._featset_satisfies_dnf(feats, law_terms(cert))


def law_satisfying_classes(smiles: str, laws: dict, layer=None) -> list:
    """Sorted names of all proved class laws the molecule satisfies."""
    layer = layer or get_layer()
    return sorted(cls for cls, cert in laws.items()
                  if cert.get("proved")
                  and molecule_satisfies_law(smiles, cert, layer))


# ------------------------------------------------------------------
# Fingerprints / similarity / substructure (additive v15 lanes)
# ------------------------------------------------------------------

def topological_fp(smiles: str):
    """RDKit topological fingerprint — the SAME fingerprint call used by
    the v14.1 tier-2 invariants, exposed additively for similarity."""
    mol = Chem.MolFromSmiles(smiles or "")
    return None if mol is None else Chem.RDKFingerprint(mol)


def tanimoto(smiles_a: str, smiles_b: str) -> float:
    """Tanimoto similarity over the topological lane; parse failure
    returns 0.0 with the callers responsible for validity upstream."""
    fa, fb = topological_fp(smiles_a), topological_fp(smiles_b)
    if fa is None or fb is None:
        return 0.0
    return DataStructs.TanimotoSimilarity(fa, fb)


def tanimoto_fp(fp_a, fp_b) -> float:
    if fp_a is None or fp_b is None:
        return 0.0
    return DataStructs.TanimotoSimilarity(fp_a, fp_b)


def substructure_match(smiles: str, smarts: str) -> bool:
    """True iff the (sanitized) molecule contains the SMARTS pattern."""
    mol = Chem.MolFromSmiles(smiles or "")
    patt = Chem.MolFromSmarts(smarts)
    if mol is None or patt is None:
        return False
    return bool(mol.HasSubstructMatch(patt))


def smart_occurrences(smiles: str, smarts: str) -> int:
    """Number of unique pattern matches (deterministic; diagnostic use)."""
    mol = Chem.MolFromSmiles(smiles or "")
    patt = Chem.MolFromSmarts(smarts)
    if mol is None or patt is None:
        return 0
    return len(mol.GetSubstructMatches(patt, uniquify=True))


def nearest_corpus_member(smiles: str, corpus_fps: dict) -> dict:
    """Nearest corpus member by topological Tanimoto. corpus_fps maps
    labels ('KB:<name>' / 'ChEMBL:<id>') to fingerprints."""
    fp = topological_fp(smiles)
    best_label, best_sim = None, -1.0
    for label, cfp in corpus_fps.items():
        sim = tanimoto_fp(fp, cfp)
        if sim > best_sim:
            best_label, best_sim = label, sim
    return {"nearest": best_label,
            "nearest_similarity": round(best_sim, 4),
            "min_distance": round(1.0 - best_sim, 4)}
