"""P5-2 — RDKit descriptors + rule-based property flags.

Every value this module emits is a DETERMINISTIC COMPUTED descriptor or
a RULE-BINNED class, labelled ``PREDICTED_RULEBASED``. Nothing here is a
measured experimental value, and no rule output may be rendered as one.
Thresholds (Lipinski 1997 / Veber 2002 rule-of-thumb windows) are named
for auditability; the classes are coarse research heuristics on the
closed candidate list, not pharmacokinetics.
"""

from . import mol_io

PROPS_SCHEMA_VERSION = "15.5.0"
LABEL = "PREDICTED_RULEBASED"


def _mol(smiles: str):
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles or "")
    if mol is None:
        raise ValueError(f"props: unparseable SMILES (reported, not "
                         f"guessed): {smiles!r}")
    return mol


# ------------------------------------------------------------------
# Exact RDKit descriptors
# ------------------------------------------------------------------

def descriptors(smiles: str) -> dict:
    """Deterministic RDKit descriptor block. Each descriptor is an exact
    function of the 2D graph; the block label records that these are
    computed rule-layer values, not measurements."""
    from rdkit import Chem
    from rdkit.Chem import Descriptors, rdMolDescriptors
    m = _mol(smiles)
    n_arom = sum(1 for r in m.GetRingInfo().AtomRings()
                 if all(m.GetAtomWithIdx(a).GetIsAromatic() for a in r))
    return {
        "prediction_label": LABEL,
        "schema_version": PROPS_SCHEMA_VERSION,
        "note": "exact RDKit descriptor computations on the 2D graph; "
                "rule-layer values, not experimental measurements",
        "mw": round(Descriptors.MolWt(m), 2),
        "clogp": round(Descriptors.MolLogP(m), 2),
        "tpsa": round(Descriptors.TPSA(m), 1),
        "hbd": Descriptors.NumHDonors(m),
        "hba": Descriptors.NumHAcceptors(m),
        "rotatable_bonds": Descriptors.NumRotatableBonds(m),
        "heavy_atoms": m.GetNumHeavyAtoms(),
        "rings_total": m.GetRingInfo().NumRings(),
        "aromatic_rings": n_arom,
        "formal_charge": Chem.GetFormalCharge(m),
        "fraction_sp3": round(rdMolDescriptors.CalcFractionCSP3(m), 4),
    }


# ------------------------------------------------------------------
# Lipinski / Veber rule-of-thumb windows
# ------------------------------------------------------------------

def lipinski(smiles: str) -> dict:
    """Lipinski RO5 rule-of-thumb window (Lipinski et al., 1997 — named
    threshold set; a screening heuristic, not a bioavailability claim)."""
    d = descriptors(smiles)
    checks = [
        {"rule": "mw <= 500", "value": d["mw"], "ok": d["mw"] <= 500},
        {"rule": "clogp <= 5", "value": d["clogp"], "ok": d["clogp"] <= 5},
        {"rule": "hbd <= 5", "value": d["hbd"], "ok": d["hbd"] <= 5},
        {"rule": "hba <= 10", "value": d["hba"], "ok": d["hba"] <= 10},
    ]
    return {
        "prediction_label": LABEL,
        "threshold_source": "Lipinski et al. 1997 rule-of-thumb window",
        "checks": checks,
        "passes_n": sum(1 for c in checks if c["ok"]),
        "violations": [c["rule"] for c in checks if not c["ok"]],
    }


def veber(smiles: str) -> dict:
    """Veber oral-rule-of-thumb window (Veber et al., 2002 — named
    threshold set; a screening heuristic, not a permeability claim)."""
    d = descriptors(smiles)
    checks = [
        {"rule": "rotatable_bonds <= 10", "value": d["rotatable_bonds"],
         "ok": d["rotatable_bonds"] <= 10},
        {"rule": "tpsa <= 140", "value": d["tpsa"], "ok": d["tpsa"] <= 140},
    ]
    return {
        "prediction_label": LABEL,
        "threshold_source": "Veber et al. 2002 rule-of-thumb window",
        "checks": checks,
        "passes_n": sum(1 for c in checks if c["ok"]),
        "violations": [c["rule"] for c in checks if not c["ok"]],
    }


# ------------------------------------------------------------------
# Crude solubility / permeability classes (binned rules)
# ------------------------------------------------------------------

def solubility_class(smiles: str) -> dict:
    """Coarse binned class on cLogP/TPSA. A research triage bucket with
    the rule text inlined — never a measured solubility value."""
    d = descriptors(smiles)
    clogp, tpsa, mw = d["clogp"], d["tpsa"], d["mw"]
    if clogp <= 2 and mw <= 400:
        cls = "class_1_favorable_bucket"
    elif clogp <= 4 and tpsa >= 40:
        cls = "class_2_intermediate_bucket"
    elif clogp <= 6:
        cls = "class_3_poor_bucket"
    else:
        cls = "class_4_very_poor_bucket"
    return {
        "prediction_label": LABEL,
        "class": cls,
        "rule": "clogp<=2 and mw<=400 -> bucket 1; clogp<=4 and "
                "tpsa>=40 -> bucket 2; clogp<=6 -> bucket 3; else "
                "bucket 4 (coarse research triage, not a measurement)",
        "inputs": {"clogp": clogp, "tpsa": tpsa, "mw": mw},
    }


def permeability_class(smiles: str) -> dict:
    """Egan-style passive-permeability proxy bucket (TPSA/cLogP
    cutoffs). A rule-of-thumb classification, never a measured
    permeability or an absorption claim."""
    d = descriptors(smiles)
    tpsa, clogp = d["tpsa"], d["clogp"]
    if tpsa <= 120 and clogp <= 5.88:
        cls = "egan_style_high_proxy"
    elif tpsa <= 200:
        cls = "egan_style_low_proxy"
    else:
        cls = "egan_style_very_low_proxy"
    return {
        "prediction_label": LABEL,
        "class": cls,
        "rule": "Egan-style cutoffs (TPSA<=120 and clogp<=5.88 -> high "
                "proxy; TPSA<=200 -> low proxy; else very low proxy); "
                "rule-of-thumb triage only",
        "inputs": {"tpsa": tpsa, "clogp": clogp},
    }


def full_property_block(smiles: str) -> dict:
    """One auditable property block for a molecule record."""
    lip, veb = lipinski(smiles), veber(smiles)
    return {
        "descriptors": descriptors(smiles),
        "lipinski": lip,
        "veber": veb,
        "solubility_class": solubility_class(smiles),
        "permeability_class": permeability_class(smiles),
        "drug_likeness_axis": round(
            (lip["passes_n"] + (1 if not veb["violations"] else 0)) / 5.0, 4),
    }
