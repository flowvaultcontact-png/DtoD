"""P5-4 — deterministic structure-law-guided candidate generation.

Pipeline (plan §6 P5-4), fully deterministic (no random search — the
v14.1 doctrine carries into Module D):

  1. SEEDS     law-satisfying scaffolds: KB molecules whose recomputed
               feature set satisfies at least one PROVED structure law
               L_c (seed list sorted by name; every seed cites its
               laws).
  2. EDITS     single-site aromatic-CH substitutions from a fixed,
               ordered substituent library (F, Cl, CH3, OH, OCH3, CN,
               NH2, CF3) applied via reaction SMARTS — standard
               matched-analog enumeration, one site per candidate.
  3. FILTERS   every rejection is RECORDED with its reason (nothing is
               silently dropped):
                 a. chemical validity  (RDKit sanitize + canonical
                    round-trip, single fragment, heavy-atom cap)
                 b. novelty            (canonical SMILES must differ
                    from every KB and frozen-ChEMBL corpus structure)
                 c. toxicity alerts    (PAINS/Brenk rule catalogs;
                    alert-bearing products are listed as rejected
                    candidates with the alert text)
                 d. law plausibility   (satisfies >= 1 proved L_c after
                    the edit; else rejected, recorded)
  4. RANK      transparent per-axis scores (novelty distance,
               drug-likeness windows, synthetic-accessibility estimate,
               law plausibility, seed conservation), aggregate labelled
               COMPUTATIONAL_RANK — a rank hint, never a probability,
               never a predicted activity.

Every emitted record is status=GENERATED_CANDIDATE with claims
binding=NO_CLAIM / efficacy=NO_CLAIM / docking=NO_DOCKING_RUN_RECORD.
"""

import hashlib
import json

from . import mol_io, props, admet
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem
from rdkit.Contrib.SA_Score import sascorer

RDLogger.DisableLog("rdApp.*")

GENERATION_SCHEMA_VERSION = "15.5.0"
QUOTA_DEFAULT = 100

# Ordered substituent library (fixed order = determinism).
SUBSTITUENTS = (
    {"name": "F", "reaction_smarts": "[cH:1]>>[c:1]F",
     "note": "aromatic fluorine scan"},
    {"name": "Cl", "reaction_smarts": "[cH:1]>>[c:1]Cl",
     "note": "aromatic chlorine scan"},
    {"name": "CH3", "reaction_smarts": "[cH:1]>>[c:1]C",
     "note": "methyl scan"},
    {"name": "OH", "reaction_smarts": "[cH:1]>>[c:1]O",
     "note": "phenol scan"},
    {"name": "OCH3", "reaction_smarts": "[cH:1]>>[c:1]OC",
     "note": "methoxy scan"},
    {"name": "CN", "reaction_smarts": "[cH:1]>>[c:1]C#N",
     "note": "nitrile scan"},
    {"name": "NH2", "reaction_smarts": "[cH:1]>>[c:1]N",
     "note": "aniline scan"},
    {"name": "CF3", "reaction_smarts": "[cH:1]>>[c:1]C(F)(F)F",
     "note": "trifluoromethyl scan"},
)

REJECT_REASONS = ("RDKit_parse_failed", "heavy_atoms_above_cap",
                  "multi_fragment", "not_novel_vs_corpus",
                  "toxicity_alert", "no_law_plausibility")

# well-known synthetic-accessibility estimate range of the Ertl-
# Schuffenhauer score (documented range 1..10, lower = easier)
SA_RANGE = (1.0, 10.0)


# ------------------------------------------------------------------
# Seeds: law-satisfying scaffolds from the KB molecular corpus
# ------------------------------------------------------------------

def seed_scaffolds(layer, laws, kb_smiles: dict):
    """KB molecules satisfying >= 1 proved L_c, deterministically
    ordered. Returns [{component, smiles, laws}] plus the honest
    non-seed remainder (satisfying none — reported, not hidden)."""
    seeds, remainder = [], []
    for name in sorted(kb_smiles):
        smi = kb_smiles[name]
        hits = mol_io.law_satisfying_classes(smi, laws, layer)
        row = {"component": name, "smiles": smi, "laws": hits}
        (seeds if hits else remainder).append(row)
    return seeds, remainder


# ------------------------------------------------------------------
# Single-site enumeration
# ------------------------------------------------------------------

def _reactions():
    rxns = []
    for spec in SUBSTITUENTS:
        rxn = AllChem.ReactionFromSmarts(spec["reaction_smarts"])
        if rxn is None:
            raise ValueError(f"bad reaction SMARTS for {spec['name']}")
        rxns.append((spec, rxn))
    return rxns


def _unique_products(seed_mol, rxn) -> list:
    """Deterministic product list: canonical SMILES, sorted, sanitized;
    invalid products are dropped with their count reported."""
    out, bad = set(), 0
    for products in rxn.RunReactants((seed_mol,)):
        p = products[0]
        try:
            Chem.SanitizeMol(p)
            smi = Chem.MolToSmiles(p)
            back = Chem.MolFromSmiles(smi)          # canonical round-trip
            if back is None:
                bad += 1
                continue
            out.add(Chem.MolToSmiles(back))
        except Exception:                            # noqa: BLE001 — filter
            bad += 1
    return sorted(out), bad


# ------------------------------------------------------------------
# Generation + filters + transparent ranking
# ------------------------------------------------------------------

def generate_candidates(layer, laws, corpus, quota=QUOTA_DEFAULT,
                        seeds=None) -> dict:
    """Run the pipeline. ``corpus`` is the frozen reference corpus dict
    from v15.molecular (labels + canonical SMILES + fingerprints).
    Returns emitted records, rejected records and stats. Deterministic:
    identical inputs reproduce identical output bit-for-bit."""
    rxns = _reactions()
    kb_smiles = dict(corpus["kb_smiles"])
    if seeds is None:
        seeds, _remainder = seed_scaffolds(layer, laws, kb_smiles)

    emitted, rejected = [], []
    stats = {"products_evaluated": 0, "invalid_products_dropped": 0,
             "seeds_scanned": 0, "reactions_scanned": 0,
             "stopped_early_quota_reached": False}

    for seed in seeds:
        if len(emitted) >= quota:
            stats["stopped_early_quota_reached"] = True
            break
        stats["seeds_scanned"] += 1
        seed_mol = Chem.MolFromSmiles(seed["smiles"])
        if seed_mol is None:
            rejected.append(_reject(seed["smiles"], seed, "RDKit_parse_failed",
                                    "seed SMILES no longer parses"))
            continue
        seed_fp = mol_io.topological_fp(seed["smiles"])
        for spec, rxn in rxns:
            if len(emitted) >= quota:
                stats["stopped_early_quota_reached"] = True
                break
            stats["reactions_scanned"] += 1
            products, bad = _unique_products(seed_mol, rxn)
            stats["invalid_products_dropped"] += bad
            for smi in products:
                if len(emitted) >= quota:
                    break
                stats["products_evaluated"] += 1
                # (a) validity gate (cap + fragments)
                val = mol_io.validate_smiles(smi)
                if not val["valid"]:
                    rejected.append(_reject(smi, seed, val["reasons"][0],
                                            "; ".join(val["reasons"])))
                    continue
                if val["fragments"] > mol_io.MAX_FRAGMENTS:
                    rejected.append(_reject(smi, seed, "multi_fragment",
                                            "emitted candidates are "
                                            "single-component"))
                    continue
                # (b) novelty gate vs the frozen corpus
                if smi in corpus["all_canonical"]:
                    rejected.append(_reject(
                        smi, seed, "not_novel_vs_corpus",
                        f"identical to corpus member "
                        f"{corpus['all_canonical'][smi]}"))
                    continue
                # (c) toxicity-alert gate (recorded, visible)
                alerts = admet.structural_alerts(smi)
                if alerts["n_alerts"] > 0:
                    rejected.append(_reject(
                        smi, seed, "toxicity_alert",
                        "; ".join(a["alert"] for a in alerts["alerts"]),
                        extras={"alerts": alerts["alerts"]}))
                    continue
                # (d) law-plausibility gate (proved L_c only)
                law_hits = mol_io.law_satisfying_classes(smi, laws, layer)
                if not law_hits:
                    rejected.append(_reject(
                        smi, seed, "no_law_plausibility",
                        "satisfies no proved structure law after the "
                        "edit (recorded, kept visible)"))
                    continue
                emitted.append(_record(smi, seed, spec, law_hits,
                                       corpus, seed_fp))
    emitted.sort(key=lambda r: (-r["aggregate"], r["smiles"]))
    for i, r in enumerate(emitted, start=1):
        r["mol_id"] = f"APXD-{i:04d}"
    return {"emitted": emitted, "rejected": rejected, "stats": stats,
            "config": config_record(quota)}


def _reject(smiles, seed, reason, detail, extras=None):
    rec = {"status": "GENERATED_CANDIDATE", "rejected": True,
           "reject_reason": reason, "reject_detail": detail,
           "smiles": smiles, "seed_component": seed["component"],
           "edit_substituent": None, "claims": _claims()}
    if extras:
        rec.update(extras)
    return rec


def _claims():
    return {"binding": "NO_CLAIM", "efficacy": "NO_CLAIM",
            "docking": "NO_DOCKING_RUN_RECORD",
            "note": "structure exists as a generated research candidate "
                    "only; no binding, activity or clinical statement "
                    "is made or implied"}


def _record(smiles, seed, spec, law_hits, corpus, seed_fp) -> dict:
    block = props.full_property_block(smiles)
    sa = sascorer.calculateScore(Chem.MolFromSmiles(smiles))
    sa_norm = 1.0 - min(max((sa - SA_RANGE[0]) /
                            (SA_RANGE[1] - SA_RANGE[0]), 0.0), 1.0)
    nov = mol_io.nearest_corpus_member(smiles, corpus["fps"])
    prox = mol_io.tanimoto_fp(mol_io.topological_fp(smiles), seed_fp)
    axes = {
        "novelty_distance": nov["min_distance"],
        "drug_likeness": block["drug_likeness_axis"],
        "synthetic_accessibility_estimate": round(sa_norm, 4),
        "law_plausibility": round(min(1.0, len(law_hits) / 3.0), 4),
        "seed_conservation": round(prox, 4),
    }
    agg = round(sum(axes.values()) / len(axes), 4)
    return {
        "status": "GENERATED_CANDIDATE",
        "rejected": False,
        "tier": "COMPUTATIONAL",
        "smiles": smiles,
        "seed": {"component": seed["component"],
                 "smiles": seed["smiles"],
                 "pubchem_cid": seed.get("pubchem_cid")},
        "edit": {"kind": "aromatic_ch_single_site_substitution",
                 "substituent": spec["name"],
                 "reaction_smarts": spec["reaction_smarts"]},
        "descriptors": block["descriptors"],
        "lipinski": block["lipinski"],
        "veber": block["veber"],
        "solubility_class": block["solubility_class"],
        "permeability_class": block["permeability_class"],
        "sa_score": {"value": round(sa, 3),
                     "range": "1 (easy) .. 10 (hard), Ertl-Schuffenhauer "
                              "estimate",
                     "prediction_label": props.LABEL},
        "toxicity_alerts": admet.structural_alerts(smiles),
        "laws_satisfied": law_hits,
        "novelty": nov,
        "axes": axes,
        "aggregate": agg,
        "aggregate_label": "COMPUTATIONAL_RANK (rank hint only; never a "
                           "probability; never a predicted activity)",
        "claims": _claims(),
    }


def config_record(quota: int) -> dict:
    """Canonical generation config — its canonical JSON hash is the
    reproducibility lock of a run."""
    cfg = {
        "generation_schema_version": GENERATION_SCHEMA_VERSION,
        "quota": quota,
        "seed_rule": "KB molecules satisfying >= 1 proved L_c, "
                     "sorted by component name",
        "substituents": [s["name"] for s in SUBSTITUENTS],
        "edit_rule": "one aromatic-CH site per candidate via reaction "
                     "SMARTS; deterministic site/product order",
        "hard_filters": ["validity", "single_fragment",
                         "novelty_vs_corpus", "toxicity_alerts",
                         "law_plausibility"],
        "rdkit_version": mol_io.importlib_rdkit_version(),
        "feature_space_sha256": mol_io.feature_space_manifest()[
            "tables_sha256"],
    }
    cfg["config_sha256"] = hashlib.sha256(canonical_json(cfg)).hexdigest()
    return cfg


def canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, indent=1,
                      ensure_ascii=True).encode("utf-8")
