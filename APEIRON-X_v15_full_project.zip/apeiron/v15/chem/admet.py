"""P5-3 — ADMET model registry, structural alerts, docking gate.

Honesty architecture (plan §6 P5-3):
  * The registry schema is shipped and versioned, and it ships EMPTY:
    no validated ML ADMET model exists in this round, so the
    ``PREDICTED_ML`` lane has zero entries. Absence is reported here as
    a documented limit — never filled with invented model output.
  * Any ``predict`` call on an unregistered model raises. No hidden
    defaults, no silent rule-fallback inside the ML lane (the explicit
    rule-based lane lives in ``v15.chem.props`` under
    PREDICTED_RULEBASED).
  * Docking: a docking statement requires a COMPLETE run record
    (structure id/source, software, version, protocol, run timestamp).
    Without it the only permitted label is NO_DOCKING_RUN_RECORD; the
    assert raises DockingRecordRequired otherwise.
  * PAINS / Brenk structural alerts are RULE-BASED conservative flags
    (RDKit filter catalogs, version recorded) — they are recorded per
    molecule and never interpreted as a toxicity verdict.
"""

from . import mol_io

ADMET_SCHEMA_VERSION = "15.5.0"
ML_LANE_LABEL = "PREDICTED_ML"
RULE_LANE_LABEL = "PREDICTED_RULEBASED"

_DOCKING_KEYS = ("structure_id", "structure_source", "software",
                 "software_version", "protocol", "run_utc")


class UnregisteredModelError(KeyError):
    """Raised instead of inventing model output."""


class DockingRecordRequired(RuntimeError):
    """Raised when a docking statement lacks a complete run record."""


# ------------------------------------------------------------------
# Model registry (versioned; provenance + validation sheet required)
# ------------------------------------------------------------------

class ModelRegistry:
    """Registry of ADMET models. Registration requires: model_id,
    endpoint, estimator kind, version, training provenance and a
    validation sheet. A model without a validation sheet cannot be
    registered (that is the point)."""

    REQUIRED_SHEET_KEYS = ("external_test_set", "metrics")

    def __init__(self, name: str):
        self.name = name
        self._models = {}

    def register(self, model_id, endpoint, kind, version,
                 training_provenance, validation_sheet) -> dict:
        for field_name, field in (("model_id", model_id),
                                  ("endpoint", endpoint),
                                  ("kind", kind), ("version", version)):
            if not field or not isinstance(field, str):
                raise ValueError(
                    f"registry registration: {field_name} must be a "
                    f"non-empty string")
        if not isinstance(training_provenance, dict) or \
                not training_provenance:
            raise ValueError("training_provenance must be a non-empty "
                             "record (source, date, licence)")
        missing = [k for k in self.REQUIRED_SHEET_KEYS
                   if k not in validation_sheet]
        if missing:
            raise ValueError("validation sheet missing keys: "
                             + ", ".join(missing))
        if model_id in self._models:
            raise ValueError(f"duplicate model_id {model_id}")
        rec = {
            "model_id": model_id, "endpoint": endpoint, "kind": kind,
            "version": version,
            "training_provenance": dict(training_provenance),
            "validation_sheet": dict(validation_sheet),
            "output_label": ML_LANE_LABEL,
        }
        self._models[model_id] = rec
        return rec

    def list(self):
        return sorted(self._models)

    def get(self, model_id) -> dict:
        if model_id not in self._models:
            raise UnregisteredModelError(
                f"no registered model {model_id!r}; registered models: "
                f"{self.list() or 'NONE'} — absence is reported, never "
                f"filled with invented output")
        return dict(self._models[model_id])

    def predict(self, model_id, smiles: str):
        self.get(model_id)           # raises on unregistered models
        raise UnregisteredModelError(
            "registered models must ship a validated inference path; "
            "no such path exists in this round")


# The registry that ships with this round: ZERO models, on purpose.
DEFAULT_REGISTRY = ModelRegistry("APEIRON-X-v15-phase5")
# (deliberately no register() calls — see module docstring)


def registry_absence_statement() -> dict:
    return {
        "registered_models": DEFAULT_REGISTRY.list(),
        "n_registered": len(DEFAULT_REGISTRY.list()),
        "statement": "no validated ML ADMET model exists in this round; "
                     "the PREDICTED_ML lane is therefore EMPTY and any "
                     "ML prediction request is refused with "
                     "UnregisteredModelError. Rule-based triage values "
                     "are served by v15.chem.props under "
                     "PREDICTED_RULEBASED.",
        "schema_version": ADMET_SCHEMA_VERSION,
    }


# ------------------------------------------------------------------
# Structural alerts (rule-based catalogs, version recorded)
# ------------------------------------------------------------------

_CATALOG_LABELS = ("PAINS_A", "PAINS_B", "PAINS_C", "BRENK")


_CATALOG_CACHE = []


def _catalog():
    if _CATALOG_CACHE:
        return _CATALOG_CACHE[0]
    from rdkit.Chem.FilterCatalog import (FilterCatalog,
                                          FilterCatalogParams)
    params = FilterCatalogParams()
    for label in _CATALOG_LABELS:
        params.AddCatalog(getattr(FilterCatalogParams.FilterCatalogs,
                                  label))
    fc = FilterCatalog(params)
    _CATALOG_CACHE.append(fc)
    return fc


def structural_alerts(smiles: str) -> dict:
    """PAINS + Brenk rule hits. Conservative flags for triage — the
    catalogs also flag established market drugs, so an alert is a
    recorded finding, not a verdict."""
    mol = None
    from rdkit import Chem
    mol = Chem.MolFromSmiles(smiles or "")
    if mol is None:
        raise ValueError(f"structural_alerts: unparseable SMILES "
                         f"(reported): {smiles!r}")
    fc = _catalog()
    # Family attribution: catalog matches do not expose their source
    # sub-catalog, so the honest record is the alert id itself with the
    # combined-catalog family label (catalogs + version recorded below).
    hits = [{"family": "PAINS_BRENK_CATALOG",
             "alert": m.GetDescription()}
            for m in fc.GetMatches(mol)]
    return {
        "prediction_label": RULE_LANE_LABEL,
        "catalogs": list(_CATALOG_LABELS),
        "rdkit_version": mol_io.importlib_rdkit_version(),
        "alerts": hits,
        "n_alerts": len(hits),
        "note": "rule-based conservative flags; also triggered by "
                "established drugs (e.g. aspirin carries a Brenk "
                "phenol-ester flag); triage input, not a verdict",
    }


# ------------------------------------------------------------------
# Docking gate
# ------------------------------------------------------------------

def docking_claim_status(run_record) -> str:
    """The ONLY permitted docking labels: DOCKING_EVIDENCE (complete run
    record) or NO_DOCKING_RUN_RECORD. Anything else is refused."""
    if run_record is None:
        return "NO_DOCKING_RUN_RECORD"
    missing = [k for k in _DOCKING_KEYS
               if not run_record.get(k)]
    if missing:
        raise DockingRecordRequired(
            "docking run record incomplete; missing fields: "
            + ", ".join(missing))
    return "DOCKING_EVIDENCE"


def assert_docking_record(run_record) -> None:
    if docking_claim_status(run_record) != "DOCKING_EVIDENCE":
        raise DockingRecordRequired(
            "a docking statement requires a complete run record "
            f"({', '.join(_DOCKING_KEYS)}); none was provided")
