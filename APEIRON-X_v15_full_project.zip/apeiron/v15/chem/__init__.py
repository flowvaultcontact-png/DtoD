"""APEIRON-X v15 — chem package (Module D, Phase 5, plan §6).

Submodules:
  mol_io    (P5-1) SMILES validation, fingerprints over the frozen
                   v14.1 feature space (versioned P1-v15), substructure /
                   similarity search, law queries derived from the proved
                   structure laws L_c.
  props     (P5-2) RDKit descriptors, Lipinski / Veber flags, crude
                   solubility / permeability classes — every output is
                   labelled PREDICTED_RULEBASED, never measured.
  admet     (P5-3) model registry (versioned, provenance-carrying; the
                   registry ships EMPTY — no validated ML model exists,
                   and absence is reported rather than filled), PAINS /
                   Brenk structural alerts, and a hard docking gate:
                   no docking statement without a complete run record.
  generate  (P5-4) deterministic structure-law-guided candidate
                   enumeration with visible filters (validity, SA score,
                   novelty vs KB+ChEMBL corpus, toxicity alerts,
                   law plausibility).

Doctrine:
  * v14.1 modules are imported READ-ONLY; the feature/law space of the
    proved structure laws is never redefined here.
  * Nothing in this package claims binding, activity or clinical
    effect for any molecule; every emitted record carries explicit
    NO_CLAIM markers (P5-5 theorem in v15.molecular).
"""
