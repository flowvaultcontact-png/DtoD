#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 8 (P8-2): read-only versioned REST API.

Serves the frozen knowledge and the deterministic discover pipeline as
JSON over HTTP. Binding design rules:

  * READ-ONLY: only GET is implemented; every other method answers 405
    with an explicit read-only notice. No route can mutate any store,
    artifact or pin.
  * VERSIONED: every route lives under /api/v1/ and every payload
    carries the schema version of the module that produced it.
  * HERMETIC: the server imports the frozen modules only — no connector
    code, no network fetches. All data served is already frozen and
    pin-checked at load time.
  * DETERMINISTIC: discover reports are memoized per (disease, as_of)
    because two builds are byte-identical (Phase 8 theorem); the memo
    is a cache, never a source.

CLI:
    python3 v15/api.py --port 8765        # serve (Ctrl-C to stop)
    python3 v15/api.py --routes           # print the route table
"""

import argparse
import json
import os
import re
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

API_VERSION = "v1"
API_SCHEMA_VERSION = "15.8.0"

# ---------------------------------------------------------------------
# lazy, memoized facades (all pin-checked at load time)
# ---------------------------------------------------------------------

_STATE = {"kb": None, "table": None, "pack": None, "graph": None,
          "phase5": None, "reports": {}, "plans": None}


def _kb():
    if _STATE["kb"] is None:
        import disease_drug_kb as kb_module
        kb_module.validate_kb()
        _STATE["kb"] = kb_module
    return _STATE["kb"]


def _table():
    if _STATE["table"] is None:
        from v15.targets import load_targets
        _STATE["table"] = load_targets()
    return _STATE["table"]


def _pack():
    if _STATE["pack"] is None:
        from v15.repurposing import load_pack
        _STATE["pack"] = load_pack()
    return _STATE["pack"]


def _graph():
    if _STATE["graph"] is None:
        from v15.kgraph import KnowledgeGraph
        _STATE["graph"] = KnowledgeGraph.from_frozen()
    return _STATE["graph"]


def _phase5():
    if _STATE["phase5"] is None:
        from v15.discover import _load_phase5
        bench5, sha, emitted = _load_phase5()
        _STATE["phase5"] = (bench5, sha, emitted)
    return _STATE["phase5"]


def _report(did: str, as_of):
    key = (did, as_of)
    if key not in _STATE["reports"]:
        from v15.discover import discover
        _STATE["reports"][key] = discover({"did": did}, as_of_year=as_of,
                                          verbose=False)
    return _STATE["reports"][key]


def _plans():
    if _STATE["plans"] is None:
        from v15 import validation_plan as vp
        from v15.repurposing import benchmark_temporal
        pack = _pack()
        kbench = benchmark_temporal(pack, k=10)
        reg = vp._registry_with_ledgers(pack, graph_ns=None)
        apxd, _ = vp.load_apxd_universe()
        plans = []
        for row, key in vp.plan_universe(pack, kbench):
            pname = kbench["per_disease"][key]["disease"]
            plans.append(vp.plan_for_drug(reg, pack, row, key, pname))
        for mol in apxd:
            plans.append(vp.plan_for_generated_molecule(
                reg, mol, _phase5()[1]))
        plans.sort(key=lambda p: p["plan_id"])
        _STATE["plans"] = plans
    return _STATE["plans"]


# ---------------------------------------------------------------------
# route handlers (all pure functions payload -> dict)
# ---------------------------------------------------------------------

def _hdr(payload_extra=None):
    h = {
        "api_version": API_VERSION,
        "api_schema_version": API_SCHEMA_VERSION,
        "program": "APEIRON-X v15",
    }
    if payload_extra:
        h.update(payload_extra)
    return h


def route_health(_q, _m):
    from v15.discover import DISCOVER_SCHEMA_VERSION
    kb = _kb()
    return {
        "status": "ok",
        "kb_diseases": len(kb.DISEASES),
        "kb_drugs": len(kb.DRUGS),
        "discover_schema_version": DISCOVER_SCHEMA_VERSION,
        "read_only": True,
        "network_access": "none (hermetic; frozen modules only)",
        "endpoints": sorted(r[0] for r in ROUTES),
    }


def route_schemas(_q, _m):
    import disease_drug_kb as _kbmod
    from v15.discover import DISCOVER_SCHEMA_VERSION
    from v15.targets import load_targets
    from v15.repurposing import load_pack
    from v15.validation_plan import SCHEMA_VERSION as F_SCHEMA
    table = _table()
    pack = load_pack()
    return {
        "schemas": {
            "discover_report": DISCOVER_SCHEMA_VERSION,
            "module_B_target_table": table.schema_version,
            "module_C_repurposing_pack": pack.schema_version,
            "module_F_validation_plans": F_SCHEMA,
            "molecule_record": "15.5.0 (frozen Phase 5 artifact)",
            "api_envelope": API_SCHEMA_VERSION,
        },
        "frozen_utc": {
            "module_B": table.frozen_utc,
            "module_C": pack.frozen_utc,
        },
    }


def route_diseases(_q, _m):
    kb = _kb()
    return {
        "count": len(kb.DISEASES),
        "diseases": [{"did": r["did"], "name": r["name"],
                      "system": r["system"]}
                     for r in kb.DISEASES],
        "note": "hash-pinned v14.1 knowledge base (read-only index)",
    }


def route_disease(q, _m, did: str):
    from v15.disease_profile import profile_from_kb_row
    kb = _kb()
    row = next((r for r in kb.DISEASES if r["did"] == did), None)
    if row is None:
        return {"status": 404,
                "error": {"code": "DID_NOT_IN_FROZEN_KB", "subject": did,
                          "reason": "no disease row with this did exists "
                                    "in the hash-pinned knowledge base"}}
    prof = profile_from_kb_row(row)
    return {
        "did": row["did"], "name": row["name"],
        "phi": {c: row[c] for c in kb.CHANNELS},
        "ontology_ids": [v for v, _s in prof.fields.get(
            "ontology_ids", [])],
        "guideline": row["guideline"],
        "kb_drugs": [{"drug": d[0], "guideline_tier": d[1]} for d in
                     row["drugs"]],
        "tier": "PROVEN_MATH",
    }


def route_targets(q, _m, did: str):
    table = _table()
    if did not in table.panel:
        return {"status": 404,
                "error": {"code": "DISEASE_NOT_IN_TARGET_PANEL",
                          "subject": did,
                          "reason": "the frozen Module B table covers its "
                                    "10-disease benchmark panel only"}}
    return {"did": did, "ranked_targets": table.rank_targets(did, k=10),
            "tier": "EVIDENCED"}


def route_repurposing(q, _m, did: str):
    pack = _pack()
    key = next((k for k, d in pack.diseases.items()
                if d.get("kb_did") == did), None)
    if key is None or key not in pack.prediction_diseases:
        return {"status": 404,
                "error": {"code": "DISEASE_NOT_IN_PREDICTION_PANEL",
                          "subject": did,
                          "reason": "the Phase 4 prediction panel covers "
                                    + ", ".join(pack.prediction_diseases)}}
    from v15.repurposing import predict_repurposing
    as_of = q.get("as_of")
    as_of = int(as_of[0]) if as_of and as_of[0].isdigit() else None
    pred = predict_repurposing(pack, as_of_year=as_of)
    block = pred["diseases"][key]
    return {"did": did, "disease_key": key, "as_of_year": as_of,
            "rows": block["rows"][:10], "tier": "EVIDENCED"}


def route_discover(q, _m, did: str):
    kb = _kb()
    if not any(r["did"] == did for r in kb.DISEASES):
        return {"status": 404,
                "error": {"code": "DID_NOT_IN_FROZEN_KB", "subject": did,
                          "reason": "no disease row with this did exists; "
                                    "the API serves discover reports for "
                                    "KB diseases only"}}
    as_of = q.get("as_of")
    as_of = int(as_of[0]) if as_of and as_of[0].isdigit() else None
    return _report(did, as_of)


def route_molecules(q, _m):
    bench5, sha, emitted = _phase5()
    q_status = (q.get("status") or [None])[0]
    rows = emitted
    if q_status:
        rows = [m for m in rows if m.get("status") == q_status]
    compact = [{"mol_id": m["mol_id"], "smiles": m["smiles"],
                "status": m["status"], "tier": m.get("tier"),
                "laws_satisfied": m.get("laws_satisfied", []),
                "claims": m.get("claims", {}).get("note", ""),
                "toxicity_alerts": m.get("toxicity_alerts", [])}
               for m in rows]
    return {"phase5_artifact_sha256": sha, "count": len(compact),
            "molecules": compact,
            "admet_registry": bench5.get("admet_registry"),
            "tier": "COMPUTATIONAL",
            "note": "served from the FROZEN Phase 5 artifact; "
                    "structure-only research candidates"}


def route_validation_plans(q, _m):
    plans = _plans()
    q_key = (q.get("disease") or [None])[0]
    rows = plans
    if q_key:
        rows = [p for p in plans
                if p["disease_context"].get("disease_key") == q_key]
    compact = [{"plan_id": p["plan_id"],
                "candidate": p["candidate"],
                "disease_context": p["disease_context"],
                "stage_gates": p["stage_gates"],
                "required_evidence_to_change_status":
                    p.get("required_evidence_to_change_status")}
               for p in rows]
    return {"count": len(compact), "plans": compact, "tier": "EVIDENCED"}


def route_theorems(_q, _m):
    """v15 theorem inventory by runtime introspection + the v14.1
    cascade battery labels (static, mirrors run_full_regression)."""
    import inspect
    from v15 import discover, targets, repurposing, kgraph, \
        validation_plan, molecular, disease_profile
    inventory = {}
    for mod_name, mod in (("module_A_profile", disease_profile),
                          ("module_B_targets", targets),
                          ("module_C_repurposing", repurposing),
                          ("module_D_molecules", molecular),
                          ("module_E_kgraph", kgraph),
                          ("module_F_validation", validation_plan),
                          ("module_P8_discover", discover)):
        names = sorted(n for n, _f in inspect.getmembers(mod, inspect.isfunction)
                       if n.startswith("theorem_"))
        inventory[mod_name] = names
    inventory["v14_1_cascade"] = [
        "T-battery (v11.1 core)", "S-battery (v12.1 structure)",
        "D-battery (v13.0 direct laws)", "E-battery (v13.1 equations)",
        "C-battery (v14.0 correspondence, hermetic + REG)"]
    return {"theorems": inventory,
            "note": "v15 theorem names collected from the live modules; "
                    "each returns the standard theorem shape and is "
                    "re-verified in the cascade"}


def route_limits(_q, _m):
    from v15.limitation_report import build_limitation_report
    return build_limitation_report()


# ---------------------------------------------------------------------
# route table + handler
# ---------------------------------------------------------------------

ROUTES = [
    ("api/v1/health", route_health),
    ("api/v1/schemas", route_schemas),
    ("api/v1/diseases", route_diseases),
    ("api/v1/diseases/<did>", route_disease),
    ("api/v1/diseases/<did>/targets", route_targets),
    ("api/v1/diseases/<did>/repurposing", route_repurposing),
    ("api/v1/diseases/<did>/discover", route_discover),
    ("api/v1/molecules", route_molecules),
    ("api/v1/validation-plans", route_validation_plans),
    ("api/v1/theorems", route_theorems),
    ("api/v1/limits", route_limits),
]

_DID_RE = re.compile(r"^[A-Z]{1,3}\d{1,4}$|^CF$")


def dispatch(path: str, query: dict, method: str):
    """Pure dispatcher: (path, query, method) -> (status, payload)."""
    if method != "GET":
        return 405, {"error": {
            "code": "READ_ONLY_API",
            "reason": f"method {method} is refused; this API serves the "
                      "frozen knowledge read-only and has no mutation "
                      "routes by design"}}
    path = path.strip("/")
    if not path.startswith(f"api/{API_VERSION}/"):
        return 404, {"error": {
            "code": "UNKNOWN_API_VERSION",
            "reason": f"only /api/{API_VERSION}/ routes are served"}}
    if path == f"api/{API_VERSION}":
        return 200, _hdr({"routes": [r[0] for r in ROUTES]})
    for pattern, fn in ROUTES:
        pat = re.fullmatch(re.escape(pattern).replace("<did>", "([A-Z0-9]+)"),
                           path)
        if pat:
            try:
                if "<did>" in pattern:
                    payload = fn(query, method, *pat.groups())
                else:
                    payload = fn(query, method)
            except Exception as exc:             # loud, never silent
                return 500, {"error": {"code": "HANDLER_FAULT",
                                       "reason": repr(exc)}}
            if isinstance(payload, dict) and payload.get("status") \
                    and set(payload) == {"status", "error"}:
                status = payload.pop("status")
                return status, payload
            return 200, payload
    return 404, {"error": {
        "code": "NO_SUCH_ROUTE",
        "reason": f"no route matches '{path}'",
        "routes": [r[0] for r in ROUTES]}}


class ApeironHandler(BaseHTTPRequestHandler):
    def _send(self, status: int, payload: dict):
        body = json.dumps(payload, sort_keys=True, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-APEIRON-API-Version", API_VERSION)
        self.send_header("X-APEIRON-Read-Only", "true")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        try:
            status, payload = dispatch(u.path, q, "GET")
        except Exception as exc:                     # loud, never silent
            status = 500
            payload = {"error": {"code": "HANDLER_FAULT",
                                 "reason": repr(exc)}}
        self._send(status, payload)

    def do_POST(self):
        self._send(*dispatch(self.path, {}, "POST"))

    do_PUT = do_DELETE = do_PATCH = do_POST

    def log_message(self, fmt, *args):               # quiet by default
        pass


def make_server(host: str = "127.0.0.1", port: int = 8765) -> HTTPServer:
    return HTTPServer((host, port), ApeironHandler)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--routes", action="store_true")
    args = ap.parse_args()
    if args.routes:
        for p, _fn in ROUTES:
            print(f"  /{p}")
        return 0
    srv = make_server(args.host, args.port)
    print(f"APEIRON-X v15 read-only API on http://{args.host}:{args.port} "
          f"(routes under /{API_VERSION}/; Ctrl-C to stop)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\n[api] stopped")
    return 0


if __name__ == "__main__":
    sys.exit(main())
