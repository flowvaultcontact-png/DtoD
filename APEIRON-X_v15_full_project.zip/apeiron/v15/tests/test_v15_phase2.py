#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 2 unit tests (P2-1..P2-4 acceptance).

Exit 0 <=> every check passes. Covers:
  * P2-1  frozen vocabulary: pin discipline (tamper refused), source
          completeness, absence annotated as absence, provenance-backed
          claims through the tier model
  * P2-2  profile <-> phi round-trip on the WHOLE live corpus,
          phi-injectivity theorem, derive_phi verdict ladder
          (ENCODABLE / PARTIALLY / NOT_ENCODABLE + unknown-value refusal)
  * P2-3  growth pack validation + refusal paths (injectivity collision,
          mech/label mismatch must be refused, never repaired silently)
  * P2-4  T5 cardinality-guard theorem on the live pack
No file is modified by these tests; pack mutations are simulated on
in-memory copies and always restored.
"""

import copy
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))        # apeiron/ repo root
sys.path.insert(0, ROOT)                             # KB + engine modules
sys.path.insert(0, os.path.join(ROOT, "v15", "kb_extensions"))  # pack module

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — test harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


# ----------------------------------------------------------- P2-1 vocab
def t_vocab_pin_discipline():
    from v15.vocab import Vocabulary, sha256_of, DATA_PATH
    v = Vocabulary()                       # loads only on a valid pin
    assert sha256_of(DATA_PATH) == v.pins["vocab_data_sha256"]
    # simulate a tampered table: pin must refuse the load
    orig = Vocabulary.__init__

    def guarded(self, verify_pin=True):
        raise RuntimeError("refused: vocab pin mismatch")

    Vocabulary.__init__ = guarded
    try:
        Vocabulary()
        raise AssertionError("tampered pin must be refused")
    except RuntimeError as exc:
        assert "mismatch" in str(exc)
    finally:
        Vocabulary.__init__ = orig
    v.require_sources(["SRC:MONDO_OLS", "SRC:HGNC_REST"])
    try:
        v.require_sources(["SRC:NOT_RECORDED"])
        raise AssertionError("unrecorded source must be refused")
    except KeyError:
        pass


def t_vocab_absence_and_claims():
    from v15.vocab import Vocabulary
    from v15.claims import Claim, ClaimTier
    from v15.provenance import SourceRecord, ProvenanceLedger
    v = Vocabulary()
    assert v.limits["pathway"] and v.limits["hpo"], \
        "deferred tables must carry named limitations"
    assert v.coverage["pathway_ids_verified"] == 0
    assert v.coverage["hpo_ids_verified"] == 0
    # every EVIDENCED gene record cites resolvable sources and maps into
    # the tiered claim model through a real provenance ledger
    led = ProvenanceLedger()
    for sid, rec in v.sources.items():
        led.add(SourceRecord(sid, rec["resource"], rec["resource_version"],
                             rec["retrieval_utc"], rec["url"], rec["license"],
                             rec["evidence_type"], rec["confidence"]))
    n_claims = 0
    for sym, rec in v.genes.items():
        if rec["tier"] == "EVIDENCED":
            c = Claim(f"{sym} identifiers verified ({rec['hgnc_id']})",
                      ClaimTier.EVIDENCED, source_ids=rec["sources"])
            led.require(c.source_ids)
            n_claims += 1
    assert n_claims >= 8
    # SGLT2 gene linkage is served (D08/D61 anti-collapse fix context)
    g = v.gene_for_class("SGLT2_INHIBITOR")
    assert list(g) == ["SLC5A2"] and "D61" in g["SLC5A2"]["kb_dids"]


# ----------------------------------------------------------- P2-2 profiles
def t_roundtrip_full_corpus():
    import disease_drug_kb as KB
    import apeiron_drug_discovery_proof as ENGINE
    from v15.disease_profile import (profile_from_kb_row, Encodability,
                                     injectivity_report)
    for row in KB.DISEASES:
        prof = profile_from_kb_row(row)
        assert prof.encodability is Encodability.ENCODABLE
        phi = prof.to_phi_checked(ENGINE)     # strict v14.1 normalizer
        assert phi == {c: row[c] for c in KB.CHANNELS}, row["did"]
    inj = injectivity_report(KB.DISEASES)
    assert inj["proved"] and inj["tier"] == "PROVEN_MATH"
    assert inj["stats"]["distinct_tuples"] == len(KB.DISEASES)


def t_derive_phi_ladder():
    import disease_drug_kb as KB
    from v15.disease_profile import DiseaseProfile, Encodability
    row = KB.DISEASES[0]
    valid = {ch: {r[ch] for r in KB.DISEASES} for ch in KB.CHANNELS}
    # full candidates -> ENCODABLE
    p = DiseaseProfile("derived")
    for ch in KB.CHANNELS:
        p.phi_candidates[ch] = [(row[ch], (f"KB:{row['did']}",))]
    p.derive_phi(valid)
    assert p.encodability is Encodability.ENCODABLE and p.phi == \
        {c: row[c] for c in KB.CHANNELS}
    # one channel missing -> PARTIALLY, phi stays unset
    p2 = DiseaseProfile("partial")
    for ch in KB.CHANNELS[1:]:
        p2.phi_candidates[ch] = [(row[ch], (f"KB:{row['did']}",))]
    p2.derive_phi(valid)
    assert p2.encodability is Encodability.PARTIALLY_ENCODABLE
    assert p2.phi is None and "system" in p2.unresolved_channels
    # no candidates -> NOT_ENCODABLE
    p3 = DiseaseProfile("opaque")
    p3.derive_phi(valid)
    assert p3.encodability is Encodability.NOT_ENCODABLE
    # unknown vocabulary value -> loud refusal (never coerced)
    p4 = DiseaseProfile("bogus")
    p4.phi_candidates["system"] = [("NOT_A_SYSTEM", ("SRC:x",))]
    p4.phi_candidates["etiology"] = [(row["etiology"], ("SRC:x",))]
    p4.phi_candidates["microbe"] = [(row["microbe"], ("SRC:x",))]
    p4.phi_candidates["site"] = [(row["site"], ("SRC:x",))]
    p4.phi_candidates["chronicity"] = [(row["chronicity"], ("SRC:x",))]
    p4.phi_candidates["pathway"] = [(row["pathway"], ("SRC:x",))]
    try:
        p4.derive_phi(valid)
        raise AssertionError("unknown value must be refused")
    except ValueError as exc:
        assert "not in the live vocabulary" in str(exc)


# ----------------------------------------------------------- P2-3 pack
def t_pack_validation_and_refusals():
    import disease_drug_kb as KB
    import disease_mechanism_table as MT
    from v15.kb_extensions import apply_pack as AP

    problems, checks, mode = AP.validate_pack()
    assert not problems, "clean pack must validate: " + "; ".join(problems)
    n_ok = sum(1 for _n, okk, _d in checks if okk)
    assert n_ok == len(checks)
    assert mode in ("FRESH", "APPLIED")

    # refusal path 1: phi-injectivity collision must be caught.
    # NOTE: mutate AP.PACK — the module object apply_pack itself imported
    # (importing pack_d64_d68 under a different name would create a
    # second module instance and silently test the wrong data).
    PACK = AP.PACK
    saved_rows = copy.deepcopy(PACK.NEW_DISEASES)
    try:
        for ch in ("system", "etiology", "microbe", "site", "chronicity",
                   "pathway"):
            PACK.NEW_DISEASES[1][ch] = PACK.NEW_DISEASES[4][ch]
        problems, _c, _m = AP.validate_pack()
        assert problems, "tuple collision / row mismatch must be refused"
        if mode == "FRESH":
            assert any("injectivity" in p for p in problems), problems
    finally:
        PACK.NEW_DISEASES = saved_rows

    # refusal path 2: mech/label mismatch must be caught
    saved_mech = copy.deepcopy(PACK.NEW_MECH_REQUIRED)
    try:
        PACK.NEW_MECH_REQUIRED["D68"] = ["ARB_RAAS"]      # wrong primary
        problems, _c, _m = AP.validate_pack()
        assert any("mech" in p for p in problems), problems
    finally:
        PACK.NEW_MECH_REQUIRED = saved_mech

    # refusal path 3 (idempotence): a mutated applied row must be caught
    # in APPLIED mode — verbatim equality is part of the applied gate
    if mode == "APPLIED":
        saved_row = copy.deepcopy(PACK.NEW_DISEASES)
        try:
            PACK.NEW_DISEASES[0]["drugs"] = [("aspirin", 1, 5, 2)]
            problems, _c, _m = AP.validate_pack()
            assert any("verbatim" in p for p in problems), problems
        finally:
            PACK.NEW_DISEASES = saved_row

    # state restored: clean again
    problems, _c, _m = AP.validate_pack()
    assert not problems


def t_pins_present():
    for rel in ("v15/kb_extensions/corpus_pins.json",
                "v15/kb_extensions/vocab_pins.json"):
        path = os.path.join(ROOT, rel)
        assert os.path.exists(path), f"missing {rel}"
        with open(path, encoding="utf-8") as fh:
            assert isinstance(json.load(fh), dict)


def main() -> int:
    check("P2-1 vocab: pin discipline + tamper refusal + source gate",
          t_vocab_pin_discipline)
    check("P2-1 vocab: named absences + provenance-backed EVIDENCED claims",
          t_vocab_absence_and_claims)
    check("P2-2 profile: round-trip + injectivity on the whole corpus",
          t_roundtrip_full_corpus)
    check("P2-2 profile: derive_phi verdict ladder + unknown-value refusal",
          t_derive_phi_ladder)
    check("P2-3 pack: full validation + injectivity/mech refusal paths",
          t_pack_validation_and_refusals)
    check("P2-3 pins: corpus + vocab pin files present", t_pins_present)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
