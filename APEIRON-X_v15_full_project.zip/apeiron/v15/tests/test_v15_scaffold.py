#!/usr/bin/env python3
"""APEIRON-X v15 scaffold unit tests (Phase 1 acceptance).

Exit 0 <=> every check passes. These tests exercise ONLY the v15 additive
scaffold and read-only interactions with v14.1 modules; they do not modify
any file and run in seconds (no RDKit dependency).
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))   # apeiron/ repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.dirname(HERE))       # for `import v15`

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — test harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


# ---------------------------------------------------------------- claims
def t_claim_tiers():
    from v15.claims import Claim, ClaimTier
    c = Claim("metformin is biguanide law member D08", ClaimTier.PROVEN_MATH)
    w = c.weaken_to(ClaimTier.COMPUTATIONAL)
    assert w.tier is ClaimTier.COMPUTATIONAL
    try:
        w.weaken_to(ClaimTier.PROVEN_MATH)
        raise AssertionError("upgrade must be refused")
    except ValueError:
        pass
    try:
        Claim("x", ClaimTier.EVIDENCED)          # no citation
        raise AssertionError("EVIDENCED without source must fail")
    except ValueError:
        pass


# ------------------------------------------------------------- provenance
def t_provenance():
    import tempfile
    from v15.provenance import SourceRecord, ProvenanceLedger
    led = ProvenanceLedger()
    rec = SourceRecord("PUBCHEM_CID:4091", "PubChem", "2026-11", "2026-11-24T00:00:00Z",
                       "https://pubchem.ncbi.nlm.nih.gov/compound/4091",
                       "public", "annotation", "curated")
    led.add(rec)
    with tempfile.TemporaryDirectory() as td:
        p = rec.freeze_payload(b'{"cid": 4091}', td)
        assert os.path.exists(p) and rec.sha256
        dump_path = os.path.join(td, "ledger.json")
        led.dump(dump_path)
        led2 = ProvenanceLedger.load(dump_path)
        assert led2.get("PUBCHEM_CID:4091").sha256 == rec.sha256
    led.require(["PUBCHEM_CID:4091"])
    try:
        led.require(["PUBCHEM_CID:1"])           # unrecorded id
        raise AssertionError("uncited id must be refused")
    except KeyError:
        pass
    try:
        SourceRecord("", "x", "x", "x", "x", "x", "x", "x")
        raise AssertionError("empty field must fail")
    except ValueError:
        pass


# --------------------------------------------------------- disease profile
def t_disease_profile():
    import disease_drug_kb as KB
    import apeiron_drug_discovery_proof as ENGINE
    from v15.disease_profile import (DiseaseProfile, Encodability,
                                     V15_CHANNELS)
    assert V15_CHANNELS == tuple(KB.CHANNELS), "channel spine must agree"
    prof = DiseaseProfile("Test syndrome")
    prof.mark_not_encodable("no vocab value for helminth etiology at v14.1")
    assert prof.encodability is Encodability.NOT_ENCODABLE
    try:
        prof.set_encoding({c: "X" for c in V15_CHANNELS}, ["SRC:1"])
        # invalid vocabulary must be caught by the strict v14.1 gate later
    except ValueError:
        pass
    # a real, valid encoding must pass the v14.1 normalizer
    row = KB.DISEASES[0]
    phi = {c: row[c] for c in V15_CHANNELS}
    prof2 = DiseaseProfile("copy of " + row["name"])
    prof2.set_encoding(phi, ["KB:D01"])
    out = prof2.to_phi_checked(ENGINE)
    assert out == phi
    # an out-of-vocabulary encoding must be structurally rejected or
    # soundly refused by the v14.1 oracle (UNPROVEN, never a drug name)
    prof3 = DiseaseProfile("bogus")
    prof3.set_encoding({c: "NOT_A_VALUE" for c in V15_CHANNELS}, ["SRC:bogus"])
    try:
        prof3.to_phi_checked(ENGINE)   # structural gate may accept...
        oracle = ENGINE.DrugOracle(KB.DISEASES)
        oracle.learn()
        verdict = oracle.query(prof3.phi)
        assert verdict["verdict"] == "UNPROVEN", verdict   # ...domain gate refuses
    except (ValueError, KeyError):
        pass                                           # ...or reject outright


# ----------------------------------------------------------------- targets
def t_targets():
    from v15.targets import TargetEvidence, TargetHypothesis, score_target
    h = TargetHypothesis("assoc-only disease")
    h.add(TargetEvidence("HGNC:1", "gene", "association", ("SRC:a",)))
    h.finalize()
    s = score_target(h)
    assert "ASSOCIATION_NOT_CAUSATION" in h.flags
    assert "ASSOCIATION_NOT_CAUSATION" in s["aggregate_label"]
    assert s["tier"] == "COMPUTATIONAL"
    h2 = TargetHypothesis("causal disease")
    h2.add(TargetEvidence("HGNC:2", "enzyme", "rescue_experiment",
                          ("SRC:b",)))
    h2.finalize()
    assert "ASSOCIATION_NOT_CAUSATION" not in h2.flags
    try:
        score_target(TargetHypothesis("empty"))
        raise AssertionError("empty evidence must be refused")
    except ValueError:
        pass


# ------------------------------------------------- v14.1 read-only coupling
def t_v14_imports_readonly():
    import disease_drug_kb as KB
    import json
    import v15
    # counts come from the corpus pins file (updated by the documented
    # re-freeze of every applied growth pack), never from a stale literal
    pins_path = os.path.join(ROOT, "v15", "kb_extensions", "corpus_pins.json")
    with open(pins_path, encoding="utf-8") as fh:
        pins = json.load(fh)["expected"]
    assert len(KB.DISEASES) == pins["diseases"], \
        f"corpus drift: {len(KB.DISEASES)} != pins {pins['diseases']}"
    assert len(KB.DRUGS) == pins["drugs"]
    assert isinstance(v15.__version__, str)


def main() -> int:
    check("claims: tier ladder + anti-upgrade + citation gate", t_claim_tiers)
    check("provenance: records, freeze, require() anti-fabrication gate",
          t_provenance)
    check("disease profile: encodability + strict v14.1 phi gate", t_disease_profile)
    check("targets: causality flag + transparent scoring + refusals", t_targets)
    check("v14.1 read-only coupling: pinned corpus sizes + package import",
          t_v14_imports_readonly)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
