#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 4 unit tests (P4-1..P4-4 acceptance).

Exit 0 <=> every check passes. Covers:
  * P4-1  frozen pack: pin discipline (tamper refused), anti-fabrication
          source gate, VERBATIM cross-check against the machine-verified
          values (v15/out/phase4_verified_values.json), law channel
          (target-channel table + KB class fallback + unmapped-symbol
          reporting), channel support (direct/adjacent/none + the cited
          cardiorenal bridge), class-precedent axis
  * P4-2  status discipline: vocabulary, tier transitions, the theorem
          on the full report, negative control (hypothesis row wearing
          approval language -> theorem fails)
  * P4-3  Theta_d bridge: all four findings exercised on real candidates
          (THETA_SATISFIED / MECH_STRUCTURE_CONFLICT / NOT_IN_CORPUS /
          NO_DISEASE_ENCODING), conflict rows stay visible, theorem +
          negative control (hidden conflict -> theorem fails)
  * P4-4  temporal hermeticity theorem, named negative controls
          (finerenone/semaglutide absent), candidate determinism
          theorem, benchmark acceptance (macro recall@10, separation,
          false leads, HFpEF plan-named top-1), artifact integrity
  * connectors: derivation/connector AST isolation (repurposing modules
    import no connector code), live driver refusal without --live,
    claim-tier language scan
No file is modified by these tests; they run fully offline against the
frozen pack, the frozen cache and the read-only v14.1 engines.
"""

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))        # apeiron/ repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "v15", "kb_extensions"))

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — test harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


# ------------------------------------------------- P4-1 frozen pack
def t_pins_and_sources():
    from v15.repurposing import load_pack, sha256_of, PACK_DATA_PATH
    pack = load_pack()                           # loads only on a valid pin
    assert sha256_of(PACK_DATA_PATH) == \
        pack.pins["repurposing_data_sha256"]
    # anti-fabrication gate: every source id anywhere must resolve
    for d in pack.drugs.values():
        pack.require_sources(d["sources"])
    for prof in pack.diseases.values():
        for ch in prof["channels_pre2015"]:
            pack.require_sources(ch["sources"])
    for spec in pack.adjacency.values():
        pack.require_sources(spec["sources"])
    for row in pack.ground_truth:
        pack.require_sources(row["citations"])
    try:
        pack.require_sources(["SRC:NOT_RECORDED_P4"])
        raise AssertionError("unrecorded source must be refused")
    except KeyError:
        pass
    # tamper: pin must refuse a modified pack
    from v15.repurposing import RepurposingPack
    orig = RepurposingPack.__init__

    def guarded(self, verify_pin=True):
        raise RuntimeError("refused: repurposing pin mismatch")

    RepurposingPack.__init__ = guarded
    try:
        RepurposingPack()
        raise AssertionError("tampered pin must be refused")
    except RuntimeError as exc:
        assert "mismatch" in str(exc)
    finally:
        RepurposingPack.__init__ = orig


def t_verbatim_crosscheck():
    """The frozen pack must agree, field by field, with the machine
    verified values it was authored from."""
    from v15.repurposing import load_pack
    pack = load_pack()
    values = json.load(open(os.path.join(
        ROOT, "v15", "out", "phase4_verified_values.json"),
        encoding="utf-8"))
    assert len(pack.drugs) == len(values["drugs"]) == 18
    for name, src in values["drugs"].items():
        got = pack.drugs[name]
        assert got["chembl_id"] == src["chembl_id"], name
        mol = src.get("chembl_molecule", {})
        assert got["first_approval"] == mol.get("first_approval"), name
        assert got["withdrawn_flag"] == bool(mol.get("withdrawn_flag"))
        rec = src.get("ot_record", {})
        assert got["maximum_clinical_stage"] == \
            rec.get("maximum_clinical_stage"), name
    for key, c in values["citations"].items():
        rec = pack.literature[f"EPMC:PMID-{c['pmid']}"]
        assert rec["title"] == c["title"], key
        assert str(rec["year"]) == str(c["year"]), key
    for key, dd in values["diseases"].items():
        assert pack.panel[key]["disease_id"] == dd.get("disease_id"), key
    # literature count: 13 verified landmark records
    assert len(pack.literature) == 13, len(pack.literature)


def t_law_channel():
    from v15.repurposing import load_pack
    pack = load_pack()
    # target-channel table: gliflozins -> KIDNEY_TUBULE_GLUCOSE
    for drug in ("dapagliflozin", "empagliflozin", "canagliflozin"):
        dc = pack.drug_channels(drug)
        assert "KIDNEY_TUBULE_GLUCOSE" in dc["channels"], drug
        assert "SLC5A2" in dc["mapped_symbols"], drug
        assert dc["actions_by_symbol"]["SLC5A2"] == "INHIBITOR", drug
    # KB class fallback: metformin's many complex-I symbols are honestly
    # UNMAPPED; its channel comes from the BIGUANIDE class row
    dc = pack.drug_channels("metformin")
    assert dc["unmapped_symbols"], "metformin unmapped symbols must show"
    assert "GLUCOSE_HOMEOSTASIS" in dc["channels"], dc
    assert dc["kb_class"] == "BIGUANIDE_HEPATIC_GLUCOSE"
    # channel support: direct / adjacent (cited bridge) / none
    sup = pack.channel_support("dapagliflozin", "CKD")
    assert sup["level"] == "direct" and \
        "KIDNEY_TUBULE_GLUCOSE" in sup["matched"], sup
    sup = pack.channel_support("dapagliflozin", "HFREF")
    assert sup["level"] == "adjacent", sup
    bridge = sup["bridged"][0]
    assert bridge["from_channel"] == "KIDNEY_TUBULE_GLUCOSE"
    assert bridge["to_channel"] == "CARDIORENAL"
    assert bridge["sources"] == ["EPMC:PMID-21253529"]
    sup = pack.channel_support("atorvastatin", "HFREF")
    assert sup["level"] == "none", sup
    # class-precedent axis: cited pre-2015 anchors only
    from v15.repurposing import class_precedent
    assert class_precedent(pack, "losartan", "CKD",
                           pack.channel_support("losartan", "CKD")) == 1.0
    assert class_precedent(pack, "dapagliflozin", "CKD",
                           pack.channel_support(
                               "dapagliflozin", "CKD")) == 0.0, \
        "the repurposing frontier must carry NO precedent"
    assert class_precedent(pack, "dapagliflozin", "HFREF",
                           pack.channel_support(
                               "dapagliflozin", "HFREF")) == 0.0, \
        "adjacent support must never grant precedent"


# ------------------------------------------------- P4-2 status discipline
def t_status_discipline():
    from v15.repurposing import load_pack, STATUSES, \
        predict_repurposing, theorem_status_discipline
    pack = load_pack()
    assert pack.status_for("dapagliflozin", "HFREF")["status"] == \
        "APPROVED_INDICATION"
    # the recorded OT coverage gap: empagliflozin x HFREF has the trial
    # citation but no approval row -> EXPERIMENTALLY_VALIDATED
    st = pack.status_for("empagliflozin", "HFREF")
    assert st["status"] == "EXPERIMENTALLY_VALIDATED"
    assert "EPMC:PMID-32865377" in st["source_ids"]
    assert pack.status_for("glimepiride", "HFREF")["status"] == \
        "COMPUTATIONAL_HYPOTHESIS"
    report = predict_repurposing(pack)
    th = theorem_status_discipline(pack, report)
    assert th["proved"] and not th["counterexamples"]
    # negative control: a hypothesis row wearing approval language
    bad = {"diseases": {"HFREF": {"rows": [{
        "drug": "glimepiride", "key": "HFREF",
        "status": {"status": "COMPUTATIONAL_HYPOTHESIS",
                   "tier": "COMPUTATIONAL",
                   "source_ids": ["SRC:OT_P4"],
                   "note": "approved for heart failure"},
        "sources": ["SRC:OT_P4"]}]}}}
    th = theorem_status_discipline(pack, bad)
    assert not th["proved"] and th["counterexamples"]


# ------------------------------------------------- P4-3 Theta_d bridge
def t_theta_bridge():
    from v15.repurposing import load_pack, theta_finding, \
        predict_repurposing, theorem_bridge_exposure
    pack = load_pack()
    cases = [
        ("dapagliflozin", "HFREF", "THETA_SATISFIED", "D02"),
        ("empagliflozin", "HFREF", "THETA_SATISFIED", "D02"),
        ("losartan", "HFREF", "MECH_STRUCTURE_CONFLICT", "D02"),
        ("canagliflozin", "HFREF", "NOT_IN_CORPUS", "D02"),
        ("dapagliflozin", "CKD", "NO_DISEASE_ENCODING", None),
    ]
    for drug, key, want, did in cases:
        f = theta_finding(pack, drug, key)
        assert f["finding"] == want, (drug, key, f)
        assert f["kb_did"] == did, (drug, key, f)
    # conflict rows stay visible in the ranked output
    report = predict_repurposing(pack)
    rows = {r["drug"]: r for r in report["diseases"]["HFREF"]["rows"]}
    assert rows["losartan"]["bridge"]["finding"] == \
        "MECH_STRUCTURE_CONFLICT"
    assert rows["losartan"]["rank_tier"] == "MECH_STRUCTURE_CONFLICT"
    assert rows["losartan"]["rank"] > 0, "conflicts are never dropped"
    # only Theta-satisfying approved candidates rank EVIDENCED
    ev = [(r["drug"], r["status"]["status"])
          for r in report["diseases"]["HFREF"]["rows"]
          if r["rank_tier"] == "EVIDENCED"]
    for drug, st in ev:
        assert st == "APPROVED_INDICATION", (drug, st)
    th = theorem_bridge_exposure(pack, report)
    assert th["proved"] and th["stats"]["mech_structure_conflicts"] >= 1
    # negative control: hide a conflict inside the tier -> theorem fails
    tampered = {"diseases": {"HFREF": {"rows": [
        dict(rows["losartan"], rank_tier="COMPUTATIONAL")]}}}
    th = theorem_bridge_exposure(pack, tampered)
    assert not th["proved"] and th["counterexamples"]


# ------------------------------------------------- P4-4 hermeticity
def t_temporal_hermeticity_and_controls():
    from v15.repurposing import load_pack, predict_repurposing, \
        theorem_temporal_hermeticity, theorem_candidate_determinism
    pack = load_pack()
    th = theorem_temporal_hermeticity(pack)
    assert th["proved"], th["counterexamples"]
    report = predict_repurposing(pack)
    # named negative controls: post-2015 molecules must be absent
    for key, dd in report["diseases"].items():
        names = [r["drug"] for r in dd["rows"]]
        assert "finerenone" not in names, key
        assert "semaglutide" not in names, key
        for r in dd["rows"]:
            assert r["first_approval"] < report["as_of_year"], (key, r)
    th = theorem_candidate_determinism(pack)
    assert th["proved"], th["counterexamples"]


# ------------------------------------------------- acceptance
def t_benchmark_acceptance():
    from v15.repurposing import load_pack, benchmark_temporal
    pack = load_pack()
    bench = benchmark_temporal(pack, k=10)
    assert bench["macro_recall_at_10"] == 1.0, bench["macro_recall_at_10"]
    assert bench["theorems_all_proved"]
    assert bench["truth_pairs_total"] == 6
    for key, p in bench["per_disease"].items():
        assert p["recall_at_10"] == 1.0, key
        assert p["separation_from_zero_support"], key
        assert p["false_leads_examined"], \
            "false leads must be examined, not hidden"
    # plan-named case: the HFpEF frontier ranks dapagliflozin #1 from
    # pre-2015 knowledge alone
    hfpef = bench["per_disease"]["HFPEF"]["rows"]
    assert hfpef[0]["drug"] == "dapagliflozin", hfpef[0]
    # artifact integrity: files exist, parse, carry no probability talk
    txt_path = os.path.join(ROOT, "v15", "out", "phase4_benchmark.txt")
    js_path = os.path.join(ROOT, "v15", "out", "phase4_benchmark.json")
    assert os.path.exists(txt_path) and os.path.exists(js_path)
    txt = open(txt_path, encoding="utf-8").read()
    # the word "probability" may appear ONLY inside the disavowal
    # phrase ("... never a probability"); any other use fails
    import re
    for m in re.finditer("probability", txt.lower()):
        window = txt.lower()[max(0, m.start() - 40):m.end() + 2]
        assert "never a probability" in window, window
    json.load(open(js_path, encoding="utf-8"))


# ------------------------------------------------- connectors discipline
def t_connector_isolation_and_driver():
    import ast
    for mod in ("v15/repurposing.py", "v15/repurposing_data.py"):
        tree = ast.parse(open(os.path.join(ROOT, mod),
                              encoding="utf-8").read())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert not any("connectors" in a.name
                               for a in node.names), mod
            if isinstance(node, ast.ImportFrom):
                assert "connectors" not in (node.module or ""), mod
    # the pack data module must stay a pure-data module (imports nothing)
    tree = ast.parse(open(os.path.join(ROOT, "v15/repurposing_data.py"),
                          encoding="utf-8").read())
    assert not any(isinstance(n, (ast.Import, ast.ImportFrom))
                   for n in ast.walk(tree)), \
        "repurposing_data.py must import nothing (pure frozen data)"
    # live driver refuses without --live
    r = subprocess.run(
        [sys.executable, os.path.join(ROOT, "v15", "connectors",
                                      "refresh_phase4_cache.py")],
        capture_output=True, text=True, timeout=60)
    assert r.returncode == 2, r.returncode
    assert "Refusing live work" in r.stdout
    # chembl connector constants (module shape sanity)
    from v15.connectors import chembl as CH
    assert CH.CORE.startswith("https://www.ebi.ac.uk/chembl/api/")


def t_claim_tier_language():
    """Acceptance gate 3: no cure/treats/efficacious language outside
    quoted citations in the Phase 4 sources."""
    banned = ("cure", "efficacious", "treats ")
    for mod in ("v15/repurposing.py", "v15/repurposing_data.py",
                "v15/write_phase4_artifacts.py",
                "v15/connectors/refresh_phase4_cache.py"):
        text = open(os.path.join(ROOT, mod),
                    encoding="utf-8").read().lower()
        for word in banned:
            assert word not in text, (mod, word)


def main() -> int:
    check("P4-1 pins: discipline + anti-fabrication source gate + tamper",
          t_pins_and_sources)
    check("P4-1 verbatim cross-check vs machine-verified values",
          t_verbatim_crosscheck)
    check("P4-1 law channel: target-channel table + class fallback + "
          "bridge + class precedent", t_law_channel)
    check("P4-2 status discipline: vocabulary, tiers, theorem + "
          "negative control", t_status_discipline)
    check("P4-3 Theta_d bridge: four findings, exposure theorem + "
          "negative control", t_theta_bridge)
    check("P4-4 temporal hermeticity + named controls + determinism",
          t_temporal_hermeticity_and_controls)
    check("acceptance: macro recall@10, separation, false leads, "
          "HFpEF top-1, artifact integrity", t_benchmark_acceptance)
    check("connectors: AST isolation + pure-data pack + driver refusal "
          "+ chembl shape", t_connector_isolation_and_driver)
    check("claim-tier language scan (no cure/treats/efficacious)",
          t_claim_tier_language)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
