#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 8 unit tests (P8-1..P8-4 acceptance).

Exit 0 <=> every check passes. Covers:
  * P8-1  discover pipeline: 18-section/12-step schema completeness,
          report determinism (double build, canonical sha256),
          absence discipline (4-field absence records everywhere),
          claim-tier discipline (tiers from the ladder, fusion rows
          labelled COMPUTATIONAL_RANK), forbidden-language scan clean
  * temporal validation: as_of=2015 lane — no APPROVED_INDICATION row
          with first_approval >= 2015, post-split drugs never ranked,
          as_of view changes the canonical sha (lane is live)
  * leakage checks: APXD-* molecules never appear in approved/repurposing
          lanes; pin status present in every report
  * negative controls: unknown did/name, ghost phi without citations,
          multi-selector spec, unknown spec keys, API 404s, POST -> 405
  * out-of-domain theorem: the OOD probe yields the honest empty world
  * P8-2  API: read-only discipline (all mutation verbs -> 405),
          versioned routes, schema versions surfaced, live server on an
          ephemeral port answers GET /api/v1/health (no network egress),
          deterministic memoized discover payloads
  * P8-3  module test-suite coverage scan (every v15 module named in
          some test file), cascade stage list includes phase 8
  * P8-4  limitation report: achievements backed by frozen artifact
          values, known-gap lanes present, non-goals present
  * artifacts integrity (phase8_benchmark.json/.txt + dashboard.html),
          frozen-file integrity vs baseline snapshot, claim-tier
          language scan on the new sources

No file is modified by these tests; everything runs offline against the
frozen stores (the HTTP check binds 127.0.0.1 on an ephemeral port and
serves only the frozen knowledge).
"""

import ast
import json
import os
import sys
import threading
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))        # apeiron/ repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "v15", "kb_extensions"))

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


# ---------------------------------------------------------------------
# shared probe reports (built once; deterministic content)
# ---------------------------------------------------------------------

_PROBE_CACHE = {}
PROBES = [
    ("D02_did", {"did": "D02"}),
    ("D08_name", {"name": "type 2 diabetes mellitus"}),
    ("D61_name_hybrid", {"name": "heart failure with preserved "
                         "ejection fraction"}),
    ("CF_panel", {"did": "CF"}),
    ("OOD_probe", {"name": "Acute Z-syndrome (OOD probe)",
                   "genetic_profile": ["ZZZ1 gain-of-function"]}),
    ("D02_as2015", {"did": "D02", "as_of": 2015}),
]


def _probe(label):
    if label not in _PROBE_CACHE:
        from v15.discover import discover
        spec, as_of = _probe_spec(label)
        _PROBE_CACHE[label] = discover(spec, as_of_year=as_of,
                                       verbose=False)
    return _PROBE_CACHE[label]


def _probe_spec(label):
    for lbl, spec in PROBES:
        if lbl == label:
            return ({k: v for k, v in spec.items() if k != "as_of"},
                    spec.get("as_of"))
    raise KeyError(label)


def _probe_reports():
    return {label: _probe(label) for label, _s in PROBES}


# ---------------------------------------------------------------------
# P8-1 theorems
# ---------------------------------------------------------------------

def t_schema_completeness():
    from v15.discover import theorem_report_schema_completeness
    th = theorem_report_schema_completeness(_probe_reports())
    assert th["proved"], th["counterexamples"]
    assert th["tier"] == "PROVEN_MATH"
    assert all(v["sections"] == 18 and v["steps"] == 12
               for v in th["stats"].values() if isinstance(v, dict)
               and "sections" in v), th["stats"]


def t_report_determinism():
    from v15.discover import theorem_report_determinism, sha256_of_report
    labels = ["D02_did", "OOD_probe"]
    th = theorem_report_determinism(lambda lbl: _probe_spec_build(lbl),
                                    labels)
    assert th["proved"], th["counterexamples"]
    # canonical sha recorded in the header must equal sha256_of_report
    rep = _probe("D02_did")
    assert rep["S01_report_header"]["canonical_sha256"] == \
        sha256_of_report(rep)


def _probe_spec_build(label):
    spec, as_of = _probe_spec(label)
    from v15.discover import discover
    return discover(spec, as_of_year=as_of, verbose=False)


def t_absence_discipline():
    from v15.discover import theorem_report_absence_discipline
    th = theorem_report_absence_discipline(_probe_reports())
    assert th["proved"], th["counterexamples"]
    assert th["stats"]["absences"] >= 10, th["stats"]


def t_claim_tier_discipline():
    from v15.discover import theorem_report_claim_tier_discipline
    th = theorem_report_claim_tier_discipline(_probe_reports())
    assert th["proved"], th["counterexamples"]
    assert th["stats"]["rows"] > 50, th["stats"]


def t_out_of_domain():
    from v15.discover import theorem_report_out_of_domain
    th = theorem_report_out_of_domain(_probe_reports())
    assert th["proved"], th["counterexamples"]
    rep = _probe("OOD_probe")
    v = rep["S05_encodability_verdict"]
    assert v["in_domain"] is False and v["verdict"] == "NOT_ENCODABLE"
    assert rep["S08_ranked_targets"]["in_panel"] is False
    assert rep["S10_repurposing_candidates"].get("candidates") == []
    assert rep["S15_experimental_validation_plans"].get("plans") == []
    assert rep["S07_graph_neighborhood"].get("found") is False


def t_temporal_validation():
    rep = _probe("D02_as2015")
    assert rep["S01_report_header"]["as_of_year"] == 2015
    from v15.repurposing import load_pack
    pack = load_pack()
    post_split = {d for d, p in pack.drugs.items()
                  if p["first_approval"] >= 2015}
    # 1. no APPROVED_INDICATION row with first_approval >= 2015
    for r in rep["S10_repurposing_candidates"].get("candidates", []):
        if r["status"]["status"] == "APPROVED_INDICATION":
            assert r["first_approval"] < 2015, r["drug"]
    # 2. post-split drugs never ranked in the fused view
    ranked = {r["name"] for r in rep["S13_evidence_weighted_ranking"]
              ["rows"]}
    assert not (post_split & ranked), post_split & ranked
    # 3. the as_of lane is live: different input -> different canonical sha
    assert rep["S01_report_header"]["canonical_sha256"] != \
        _probe("D02_did")["S01_report_header"]["canonical_sha256"]
    # 4. excluded drug(s) are listed in S09 post_split_excluded
    excluded = rep["S09_approved_and_investigational_drugs"][
        "post_split_excluded"]
    assert isinstance(excluded, list)


def t_leakage_apxd():
    reports = _probe_reports()
    from v15.discover import theorem_report_leakage_control
    th = theorem_report_leakage_control(reports)
    assert th["proved"], th["counterexamples"]
    for label, rep in reports.items():
        for lane in ("S09_approved_and_investigational_drugs",
                     "S10_repurposing_candidates"):
            rows = rep[lane].get("drugs", []) or \
                rep[lane].get("candidates", [])
            assert all(not str(r.get("drug", "")).startswith("APXD-")
                       for r in rows), (label, lane)


def t_consistency_checks_and_pins():
    for label, rep in _probe_reports().items():
        checks = rep["S14_consistency_checks"]["checks"]
        assert rep["S14_consistency_checks"]["all_passed"], (label, checks)
        assert checks["phi_injectivity"]["passed"]
        assert checks["forbidden_language_scan"]["hits"] == []
        assert checks["graph_consistency"]["stats"]["edges"] >= 1000


# ---------------------------------------------------------------------
# negative controls
# ---------------------------------------------------------------------

def t_negative_controls():
    from v15.discover import discover, resolve_disease
    import disease_drug_kb as kb
    from v15.repurposing import load_pack
    kb.validate_kb()
    pack = load_pack()
    # ghost did -> explicit absence, no fabricated row
    r = resolve_disease({"did": "D99"}, kb, pack)
    codes = [a["code"] for a in r["absences"]]
    assert "DID_NOT_IN_FROZEN_KB" in codes and r["kb_row"] is None
    # ghost name
    r = resolve_disease({"name": "Definitely Not A Disease"}, kb, pack)
    assert r["kb_row"] is None and r["absences"]
    # uncited phi refuses loudly
    try:
        discover({"phi": {"system": "CARDIOVASCULAR",
                          "etiology": "VASCULAR_ATHEROTHROMBOTIC",
                          "microbe": "NONE", "site": "MYOCARDIUM",
                          "chronicity": "CHRONIC",
                          "pathway": "PW_NEUROHORMONAL_REMODELING"}},
                 verbose=False)
        raise AssertionError("uncited phi must raise")
    except ValueError as exc:
        assert "phi_source_ids" in str(exc)
    # unknown spec keys refuse
    try:
        resolve_disease({"magic": 1}, kb, pack)
        raise AssertionError("unknown spec keys must raise")
    except ValueError as exc:
        assert "unknown spec keys" in str(exc)
    # two independent selectors refuse (name+phi not a legal combo)
    try:
        resolve_disease({"name": "x", "did": "D01"}, kb, pack)
        raise AssertionError("multi-selector spec must raise")
    except ValueError:
        pass


def t_api_readonly_and_routing():
    from v15.api import dispatch
    # mutation verbs are refused with the read-only notice
    for m in ("POST", "PUT", "DELETE", "PATCH"):
        st, p = dispatch("/api/v1/health", {}, m)
        assert st == 405 and p["error"]["code"] == "READ_ONLY_API", (m, st)
    # unknown route and unknown version
    st, p = dispatch("/api/v1/definitely-not-a-route", {}, "GET")
    assert st == 404 and p["error"]["code"] == "NO_SUCH_ROUTE"
    st, p = dispatch("/api/v9/health", {}, "GET")
    assert st == 404 and p["error"]["code"] == "UNKNOWN_API_VERSION"
    # unknown disease ids: explicit 404 errors, never fabricated data
    st, p = dispatch("/api/v1/diseases/D99", {}, "GET")
    assert st == 404 and p["error"]["code"] == "DID_NOT_IN_FROZEN_KB"
    st, p = dispatch("/api/v1/diseases/D99/targets", {}, "GET")
    assert st == 404 and p["error"]["code"] == "DISEASE_NOT_IN_TARGET_PANEL"
    st, p = dispatch("/api/v1/diseases/D01/repurposing", {}, "GET")
    assert st == 404 and p["error"]["code"] == \
        "DISEASE_NOT_IN_PREDICTION_PANEL"
    # versioned discovery: same payload as the pipeline, memoized
    st, a = dispatch("/api/v1/diseases/D02/discover", {}, "GET")
    st, b = dispatch("/api/v1/diseases/D02/discover", {}, "GET")
    assert a == b and st == 200
    assert a["S01_report_header"]["schema_version"].startswith("15.")


def t_api_live_server():
    """Ephemeral-port HTTP round trip: GET answers, headers carry the
    read-only + version contract, POST is refused over the wire."""
    from v15.api import make_server
    srv = make_server("127.0.0.1", 0)
    port = srv.server_address[1]
    th = threading.Thread(target=srv.serve_forever, daemon=True)
    th.start()
    try:
        with urllib.request.urlopen(
                f"http://127.0.0.1:{port}/api/v1/health", timeout=30) as r:
            assert r.status == 200
            assert r.headers.get("X-APEIRON-Read-Only") == "true"
            assert r.headers.get("X-APEIRON-API-Version") == "v1"
            body = json.loads(r.read().decode("utf-8"))
            assert body["status"] == "ok" and body["read_only"] is True
        req = urllib.request.Request(
            f"http://127.0.0.1:{port}/api/v1/health", data=b"{}", method="POST")
        try:
            urllib.request.urlopen(req, timeout=30)
            raise AssertionError("POST must be refused")
        except urllib.error.HTTPError as exc:
            assert exc.code == 405
    finally:
        srv.shutdown()


def t_api_no_network_egress():
    """AST gate: api.py imports no outbound-network machinery; the only
    sockets are the local serving socket."""
    src = open(os.path.join(ROOT, "v15", "api.py"),
               encoding="utf-8").read()
    tree = ast.parse(src)
    banned = {"socket", "requests", "urllib.request", "http.client",
              "subprocess"}
    imported = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported |= {a.name.split(".")[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module.split(".")[0])
    # urllib.parse is allowed (query parsing); urllib.request is NOT
    assert "requests" not in imported and "socket" not in imported
    assert "http.client" not in imported and "subprocess" not in imported
    # and the discover pipeline (api -> discover) imports no connector
    from v15 import discover as D
    dsrc = open(D.__file__, encoding="utf-8").read()
    assert "connectors" not in dsrc


# ---------------------------------------------------------------------
# P8-3 coverage + cascade wiring
# ---------------------------------------------------------------------

def t_module_test_suite_coverage():
    tests_dir = os.path.join(ROOT, "v15", "tests")
    corpus = ""
    for fn in sorted(os.listdir(tests_dir)):
        if fn.endswith(".py"):
            corpus += open(os.path.join(tests_dir, fn),
                           encoding="utf-8").read().lower()
    modules = ("disease_profile", "vocab", "targets", "repurposing",
               "molecular", "kgraph", "validation_plan", "discover",
               "api", "dashboard", "limitation_report")
    for m in modules:
        assert m in corpus, f"module {m} not covered by any test file"
    # the per-phase batteries exist for phases 1..7 plus this file
    for phase in ("scaffold", "phase2", "phase3", "phase4", "phase5",
                  "phase6", "phase7"):
        path = os.path.join(tests_dir, f"test_v15_{phase}.py")
        assert os.path.exists(path), path


def t_cascade_wiring():
    src = open(os.path.join(ROOT, "v15", "run_full_regression.py"),
               encoding="utf-8").read()
    assert "test_v15_phase8.py" in src, "phase-8 battery not in cascade"
    assert src.count('("' ) >= 17, "expected >= 17 cascade stages"


# ---------------------------------------------------------------------
# P8-4 limitation report + dashboard
# ---------------------------------------------------------------------

def t_limitation_report():
    from v15.limitation_report import build_limitation_report
    rep = build_limitation_report()
    assert rep["schema_version"].startswith("15.")
    # achievements backed by frozen artifacts
    bench3 = json.load(open(os.path.join(ROOT, "v15", "out",
                                         "phase3_benchmark.json"),
                            encoding="utf-8"))
    assert rep["achievements"]["module_B_targets"][
        "benchmark_macro_recall_at_10"] == bench3["macro_recall_at_10"]
    # the known-gap lanes are all present
    assert set(rep["known_gaps"]) == {"module_B_targets",
                                      "module_C_repurposing",
                                      "module_D_molecules",
                                      "module_F_validation",
                                      "cross_cutting"}
    joined = json.dumps(rep).lower()
    for needle in ("drugbank", "admet model registry", "docking",
                   "metadata only"):
        assert needle in joined, needle
    assert rep["non_goals"]


def t_dashboard():
    from v15.dashboard import build_dashboard_html
    a, b = build_dashboard_html(), build_dashboard_html()
    assert a == b and len(a) > 5000
    low = a.lower()
    for needle in ("target panel", "repurposing panel",
                   "validation plans", "honest limitations", "non-goals"):
        assert needle in low, needle
    # hermetic static page: no scripts, no external assets, no iframes
    assert "<script" not in low and "iframe" not in low
    assert "src=\"http" not in low and "href=\"http" not in low


def t_artifacts_integrity():
    out = os.path.join(ROOT, "v15", "out")
    bench = json.load(open(os.path.join(out, "phase8_benchmark.json"),
                           encoding="utf-8"))
    assert bench["benchmark"].startswith("Phase 8")
    th = bench["theorems_all_proved"]
    assert th is True, {k: v["proved"] for k, v in bench["theorems"]
                        .items()} if isinstance(bench["theorems"], dict) \
        else bench["theorems"]
    assert bench["reports"] and len(bench["reports"]) >= 5
    txt = open(os.path.join(out, "phase8_benchmark.txt"),
               encoding="utf-8").read()
    assert "ALL THEOREMS PROVED" in txt
    dash = open(os.path.join(out, "dashboard.html"), encoding="utf-8").read()
    assert "APEIRON-X v15" in dash
    lim = json.loads(json.dumps(bench["limitation_report"]))
    assert lim["schema_version"].startswith("15.")


def t_frozen_file_integrity():
    snap = os.path.join(ROOT, "docs", "baseline",
                        "frozen_files_sha256_before.txt")
    expected = {}
    with open(snap, encoding="utf-8") as fh:
        for line in fh:
            h, name = line.split()
            expected[name] = h
    import hashlib
    for name in ("disease_drug_kb.py", "drug_structures.py",
                 "disease_mechanism_table.py", "postulates_v14.json"):
        h = hashlib.sha256()
        with open(os.path.join(ROOT, name), "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 16), b""):
                h.update(chunk)
        assert expected[name] == h.hexdigest(), name


def t_claim_tier_language():
    banned = ("cure", "efficacious", "treats ")
    mods = ("v15/api.py", "v15/dashboard.py",
            "v15/limitation_report.py", "v15/write_phase8_artifacts.py")
    for mod in mods:
        text = open(os.path.join(ROOT, mod),
                    encoding="utf-8").read().lower()
        for word in banned:
            assert word not in text, (mod, word)


def main() -> int:
    check("P8-1 report schema completeness (18 sections, 12 steps)",
          t_schema_completeness)
    check("P8-1 report determinism (double build + header sha)",
          t_report_determinism)
    check("P8-1 absence discipline (4-field records everywhere)",
          t_absence_discipline)
    check("P8-1 claim-tier discipline (ladder + COMPUTATIONAL_RANK)",
          t_claim_tier_discipline)
    check("P8-1 out-of-domain theorem (OOD probe = honest empty world)",
          t_out_of_domain)
    check("temporal validation (as_of=2015 lane, no post-split rows)",
          t_temporal_validation)
    check("leakage checks (APXD never in approved/repurposing lanes)",
          t_leakage_apxd)
    check("consistency checks + pin status present in every report",
          t_consistency_checks_and_pins)
    check("negative controls (ghost did/name, uncited phi, bad specs)",
          t_negative_controls)
    check("P8-2 API read-only + routing + explicit 404s", t_api_readonly_and_routing)
    check("P8-2 API live server on ephemeral port (GET ok, POST 405)",
          t_api_live_server)
    check("P8-2 API hermetic (no outbound-network imports, no "
          "connector coupling)", t_api_no_network_egress)
    check("P8-3 module test-suite coverage + cascade wiring",
          t_module_test_suite_coverage)
    check("P8-3 cascade stage list includes phase 8", t_cascade_wiring)
    check("P8-4 limitation report (artifact-backed achievements, gap "
          "lanes)", t_limitation_report)
    check("P8-2 dashboard (deterministic, static, no JS/external assets)",
          t_dashboard)
    check("artifacts integrity (phase8_benchmark + dashboard)",
          t_artifacts_integrity)
    check("frozen-file integrity (sha256 vs baseline snapshot)",
          t_frozen_file_integrity)
    check("claim-tier language scan (no cure/treats/efficacious)",
          t_claim_tier_language)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
