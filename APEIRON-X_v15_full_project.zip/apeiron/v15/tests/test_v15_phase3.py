#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 3 unit tests (P3-1..P3-4 acceptance).

Exit 0 <=> every check passes. Covers:
  * P3-1  frozen target table: pin discipline (tamper refused), source
          completeness (anti-fabrication require gate), literature
          records resolve, identifier cross-check against the Phase 2
          vocabulary (HGNC/UniProt agreement, T2DM MONDO cross-check)
  * P3-2  transparent scoring: axes exposed individually, aggregate
          labelled COMPUTATIONAL_RANK, no probability language in any
          emitted benchmark artefact
  * P3-3  anti-causal-illusion theorem: proved on the whole panel,
          negative controls (stripped flag -> fails; spurious flag on
          causally-evidenced target -> fails), finalize() clearing rule
  * P3-4  frozen-response connectors: absence raises (never fabricates),
          cache integrity (sha256-named files), derivation modules do
          not import connectors, live driver refuses without --live
  * benchmark: 10-disease top-10 recall with honest coverage gaps,
    MAPT/LDLR flag discipline, CF as a non-KB (NOT_ENCODABLE) disease
No file is modified by these tests; they run fully offline against the
frozen tables and the frozen response cache.
"""

import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))        # apeiron/ repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "v15", "kb_extensions"))

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — test harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


# ------------------------------------------------- P3-1 frozen table
def t_pins_and_sources():
    from v15.targets import load_targets, sha256_of, TARGET_DATA_PATH
    t = load_targets()                          # loads only on a valid pin
    assert sha256_of(TARGET_DATA_PATH) == t.pins["target_data_sha256"]
    # anti-fabrication gate: every evidence source id must resolve
    for row in t.evidence:
        t.require_sources(row["sources"])
    for did, p in t.panel.items():
        t.require_sources(p["sources"])
    for sym, g in t.genes.items():
        t.require_sources(g["sources"])
    for key, rec in t.literature.items():
        assert key.startswith("EPMC:PMID-"), key
        assert rec["pmid"] and rec["title"] and rec["doi"], key
    try:
        t.require_sources(["SRC:NOT_RECORDED_P3"])
        raise AssertionError("unrecorded source must be refused")
    except KeyError:
        pass
    # tamper: pin must refuse a modified table
    from v15.targets import TargetTable
    orig = TargetTable.__init__

    def guarded(self, verify_pin=True):
        raise RuntimeError("refused: target pin mismatch")

    TargetTable.__init__ = guarded
    try:
        TargetTable()
        raise AssertionError("tampered pin must be refused")
    except RuntimeError as exc:
        assert "mismatch" in str(exc)
    finally:
        TargetTable.__init__ = orig


def t_identifier_crosscheck_with_vocab():
    from v15.targets import load_targets
    t = load_targets()
    from v15.vocab import Vocabulary
    v = Vocabulary()
    shared = set(v.genes) & set(t.genes)
    assert {"SLC5A2", "HMGCR", "PCSK9", "CFTR", "EGFR", "ACE",
            "ABL1"} <= shared, shared
    for sym in shared:
        assert v.genes[sym]["hgnc_id"] == t.genes[sym]["hgnc_id"], sym
        assert v.genes[sym]["uniprot"] == t.genes[sym]["uniprot"], sym
    # T2DM MONDO cross-check (panel vs Phase 2 OLS-verified record)
    from v15.targets import load_targets as _lt
    panel_id = t.panel["D08"]["ot_disease_id"]
    vocab_id = v.diseases["type 2 diabetes mellitus"]["mondo_id"]
    assert panel_id.replace("_", ":") == vocab_id or \
        panel_id == vocab_id.replace(":", "_"), (panel_id, vocab_id)
    # every panel target has full identifiers (never a bare name)
    for did in t.dids():
        for sym in t.panel[did]["guideline_targets"]:
            g = t.genes[sym]
            assert g["hgnc_id"].startswith("HGNC:") and g["uniprot"], (did, sym)


# ------------------------------------------------- P3-2 transparency
def t_transparent_scoring():
    from v15.targets import load_targets
    t = load_targets()
    for did in t.dids():
        for row in t.rank_targets(did, k=None):
            assert set(row["axes"]) == {
                "genetic_evidence", "functional_evidence",
                "pharmacological_tractability", "safety_penalty",
                "evidence_completeness"}
            assert row["aggregate_label"].startswith("COMPUTATIONAL_RANK")
            assert row["axes"]["safety_penalty"] == 0.0   # documented
            assert 0.0 <= row["aggregate"] <= 1.0
    bench = json.dumps(
        __import__("v15.targets", fromlist=["benchmark"]).benchmark(t, k=10))
    assert "probability" not in bench.lower(), \
        "rank output must never use probability language"


# ------------------------------------------------- P3-3 illusion
def t_anti_causal_illusion():
    from v15.targets import load_targets, benchmark, \
        theorem_anti_causal_illusion
    from v15.claims import Claim, ClaimTier
    t = load_targets()
    bench = benchmark(t, k=10)
    assert bench["theorem_anti_causal_illusion_all_proved"]
    # flag discipline: MAPT and LDLR are association-only and flagged
    d33 = {r["symbol"]: r for r in bench["per_disease"]["D33"]["ranked_all"]}
    d05 = {r["symbol"]: r for r in bench["per_disease"]["D05"]["ranked_all"]}
    assert "ASSOCIATION_NOT_CAUSATION" in d33["MAPT"]["flags"]
    assert d33["MAPT"]["kinds"] == ["association"]
    assert "ASSOCIATION_NOT_CAUSATION" in d05["LDLR"]["flags"]
    # causally-evidenced targets must NOT carry the flag
    assert d33["MAPT"]["aggregate_label"].endswith("[ASSOCIATION_NOT_CAUSATION]")
    for did, sym in (("D50", "ABL1"), ("D51", "EGFR"), ("CF", "CFTR"),
                     ("D33", "ACHE")):
        rank = {r["symbol"]: r for r in
                bench["per_disease"][did]["ranked_all"]}
        assert sym in rank
        assert "ASSOCIATION_NOT_CAUSATION" not in rank[sym]["flags"], \
            (did, sym)
    # negative control 1: strip a flag -> theorem must fail
    rows = [dict(r) for r in bench["per_disease"]["D33"]["ranked_all"]]
    for r in rows:
        if r["symbol"] == "MAPT":
            r["flags"] = []
            r["aggregate_label"] = "COMPUTATIONAL_RANK"
    th = theorem_anti_causal_illusion(rows)
    assert not th["proved"] and th["counterexamples"]
    # negative control 2: spurious flag on causally-evidenced ABL1
    rows = [dict(r) for r in bench["per_disease"]["D50"]["ranked_all"]]
    for r in rows:
        if r["symbol"] == "ABL1":
            r["flags"] = ["ASSOCIATION_NOT_CAUSATION"]
    th = theorem_anti_causal_illusion(rows)
    assert not th["proved"]
    # finalize() clearing rule: causal evidence clears, computation can't
    from v15.targets import TargetHypothesis, TargetEvidence
    h = TargetHypothesis("assoc only")
    h.add(TargetEvidence("HGNC:6893", "signaling_protein", "association",
                         ("EPMC:PMID-42783847",)))
    h.finalize()
    assert "ASSOCIATION_NOT_CAUSATION" in h.flags
    h.add(TargetEvidence("HGNC:6893", "signaling_protein",
                         "functional_perturbation", ("SRC:OT_P3",)))
    h.finalize()
    assert "ASSOCIATION_NOT_CAUSATION" not in h.flags
    # claim tier: flag rows must stay below EVIDENCED without citations
    c = Claim("MAPT AD linkage", ClaimTier.COMPUTATIONAL,
              source_ids=("EPMC:PMID-42783847",))
    assert c.weaken_to(ClaimTier.HYPOTHESIS).tier is ClaimTier.HYPOTHESIS


def t_theorem_shapes():
    from v15.targets import load_targets, benchmark
    t = load_targets()
    bench = benchmark(t, k=10)
    ths = []
    for did in t.dids():
        rows = bench["per_disease"][did]["ranked_all"]
        ths.append(__import__("v15.targets",
                              fromlist=["theorem_anti_causal_illusion"])
                   .theorem_anti_causal_illusion(rows))
    for th in ths:
        for key in ("theorem", "statement", "proved", "tier",
                    "counterexamples", "stats", "proof_steps"):
            assert key in th, key
        assert th["tier"] == "PROVEN_MATH"


# ------------------------------------------------- P3-4 connectors
def t_connectors_frozen_response():
    from v15.connectors import base
    names = base.list_frozen()
    assert len(names) >= 100, names
    manifest = json.load(open(base.MANIFEST_PATH, encoding="utf-8"))
    for name in names:
        meta = manifest[name]
        path = base.cache_path_for(meta["sha256"])
        assert os.path.exists(path), (name, path)
        rec = json.load(open(path, encoding="utf-8"))
        for k in ("retrieval_utc", "url", "http_status", "sha256",
                  "resource", "license"):
            assert rec.get(k), (name, k)
    # absence is reported, never fabricated
    try:
        base.load_frozen("definitely.not.frozen.name")
        raise AssertionError("missing cache must raise")
    except base.ConnectorError as exc:
        assert exc.kind == "ABSENT_CACHE"
    # derivation modules must not IMPORT the connectors (C0-style split;
    # comments mentioning the refresh tool are fine, imports are not)
    import ast
    for mod in ("v15/targets.py", "v15/target_data.py"):
        tree = ast.parse(open(os.path.join(ROOT, mod),
                              encoding="utf-8").read())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert not any("connectors" in a.name for a in node.names), mod
            if isinstance(node, ast.ImportFrom):
                assert "connectors" not in (node.module or ""), mod


def t_live_driver_refusal():
    r = subprocess.run(
        [sys.executable, os.path.join(ROOT, "v15", "connectors",
                                      "refresh_phase3_cache.py")],
        capture_output=True, text=True, timeout=60)
    assert r.returncode == 2, r.returncode
    assert "Refusing live work" in r.stdout


# ------------------------------------------------- acceptance
def t_benchmark_acceptance():
    from v15.targets import load_targets, benchmark
    t = load_targets()
    k = 10
    bench = benchmark(t, k=k)
    assert bench["panel_diseases"] == 10
    assert bench["macro_recall_at_%d" % k] == 1.0
    # recall arithmetic consistency + honest coverage gaps
    for did, p in bench["per_disease"].items():
        want, hits = p["guideline_targets"], p["hits"]
        assert p["recall_at_%d" % k] == round(len(hits) / len(want), 4)
        assert len(p["coverage_gaps"]) >= 0
        assert p["top_%d" % k]  # ranked list non-empty
    # the three plan-named examples rank #1 in their diseases
    top1 = {d: p["ranked_all"][0]["symbol"]
            for d, p in bench["per_disease"].items()}
    assert top1["D50"] == "ABL1"       # BCR-ABL example
    assert top1["CF"] == "CFTR"        # CFTR example
    assert top1["D05"] == "PCSK9"      # PCSK9 example
    # CF is the non-KB disease (NOT_ENCODABLE, evidence-table driven)
    cf = t.panel["CF"]
    assert cf["kb_link"] is None and "NOT_ENCODABLE" in cf["encodability_note"]
    assert bench["rank_determinism_all_proved"]
    assert isinstance(bench["honest_limits"], list) and bench["honest_limits"]


def main() -> int:
    check("P3-1 pins: discipline + anti-fabrication source gate + tamper",
          t_pins_and_sources)
    check("P3-1 identifiers: cross-check vs Phase 2 vocabulary (HGNC/"
          "UniProt/MONDO)", t_identifier_crosscheck_with_vocab)
    check("P3-2 transparency: axes exposed, COMPUTATIONAL_RANK label, "
          "no probability language", t_transparent_scoring)
    check("P3-3 anti-causal-illusion: theorem + negative controls + "
          "clearing rule", t_anti_causal_illusion)
    check("P3-3 theorem shape: standard APEIRON-X theorem keys",
          t_theorem_shapes)
    check("P3-4 connectors: frozen cache integrity + absence refusal + "
          "derivation isolation", t_connectors_frozen_response)
    check("P3-4 live driver: refuses without --live", t_live_driver_refusal)
    check("acceptance: 10-disease top-10 recall, honest gaps, plan-named "
          "targets rank #1", t_benchmark_acceptance)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
