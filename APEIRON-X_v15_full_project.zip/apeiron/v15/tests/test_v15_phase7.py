#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 7 unit tests (P7-1..P7-3 acceptance, Module F).

Exit 0 <=> every check passes. Covers:
  * P7-2  frozen validation registry: pin discipline (tamper refuses),
          self-validation, counts vs pin, structural results absence,
          mechanical link filters resolvable
  * plan build gate: refusal lanes (missing section, unknown gate state,
          non-canonical gate order, out-of-prefix completion, uncited
          completion, unknown evidence id, forbidden results token,
          unresolvable dataset accession, status/transition mismatch)
  * F1    plan-schema completeness (incl. EVIDENCED+ subset)
  * F2    stage-gate ordering (prefix completion; injections refused)
  * F3    evidence-citation completeness over P4/P7/P8 ledgers
  * F4    no-results-synthesis (connector AST whitelist, registry scan,
          plan scan, injection refused)
  * F5    status-transition discipline (upgrade path always raises)
  * F6    plan determinism (two live builds, canonical sha256, no
          wall-clock fields; artifact round-trip)
  * F7    out-of-domain detection (ghost drug/disease probes)
  * gate-state honesty: REGISTRY_ACTIVITY_PRESENT only on the HUMAN
          lane and always metadata-labelled
  * hygiene: derivation/connector AST isolation, artifacts integrity,
          frozen-file integrity vs baseline snapshot, claim-tier
          language scan, registry forbidden-token scan

No file is modified by these tests; they run fully offline against the
frozen P7 registry, the frozen P4 pack, the frozen P8 graph, the
frozen Phase 5 artifact (all read-only).
"""

import ast
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))        # apeiron/ repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "v15", "kb_extensions"))

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


_MODULE_F_CACHE = {}


def _module_f():
    if "bench" not in _MODULE_F_CACHE:
        from v15.validation_plan import run_module_f
        _MODULE_F_CACHE["bench"] = run_module_f(verbose=False)
    return _MODULE_F_CACHE["bench"]


def _plans():
    return _module_f()["plans"]


def _registry():
    from v15.validation_plan import _registry_with_ledgers
    return _registry_with_ledgers()


# ------------------------------------------------- P7-2 frozen registry
def t_registry_pin_and_selfvalidation():
    from v15.validation_plan import (ValidationRegistry,
                                     VALIDATION_PIN_PATH,
                                     VALIDATION_DATA_PATH, sha256_text)
    assert os.path.exists(VALIDATION_PIN_PATH)
    with open(VALIDATION_PIN_PATH, encoding="utf-8") as fh:
        pins = json.load(fh)
    digest = sha256_text(open(VALIDATION_DATA_PATH,
                              encoding="utf-8").read())
    assert pins["validation_data_sha256"] == digest
    reg = ValidationRegistry(verify_pin=True)
    assert len(reg.studies) == pins["study_count"]
    assert len(reg.series) == pins["series_count"]
    assert len(reg.absences) == pins["absence_count"]
    assert len(reg._vd.SOURCE_RECORDS_P7) == pins["source_count"]
    # structural results absence in the served tables
    import v15.validation_data as vd
    blob = repr({"s": vd.CT_STUDIES_P7, "g": vd.GEO_SERIES_P7,
                 "l": vd.CANDIDATE_DATASET_LINKS_P7,
                 "gl": vd.GEO_DISEASE_LINKS_P7}).lower()
    for tok in ("resultsection", "outcomemeasure", "primaryoutcome",
                "secondaryoutcome", "effectsize"):
        assert tok not in blob, tok
    # pin discipline: a tampered pin refuses to serve (restore no
    # matter what happens)
    with open(VALIDATION_PIN_PATH, "rb") as fh:
        original = fh.read()
    tampered = json.loads(original.decode("utf-8"))
    tampered["validation_data_sha256"] = "0" * 64
    with open(VALIDATION_PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(tampered, fh)
    try:
        try:
            ValidationRegistry(verify_pin=True)
            raise AssertionError("tampered pin must refuse to serve")
        except RuntimeError:
            pass
    finally:
        with open(VALIDATION_PIN_PATH, "wb") as fh:
            fh.write(original)
    # link filters: every link's study ids resolve + counts consistent
    for lnk in reg.links:
        for nid in lnk["study_ids"]:
            assert nid in reg.studies, (lnk["link_id"], nid)
        assert lnk["matched_total"] >= len(lnk["study_ids"])
    for gl in reg.geo_links:
        for acc in gl["series_ids"]:
            assert acc in reg.series, (gl["link_id"], acc)


def t_build_gate_refusal_lanes():
    import copy
    from v15.validation_plan import (build_plan, PlanBuildError,
                                     GATE_COMPLETED, GATE_PROPOSED)
    plans = _plans()
    reg = _registry()
    base = copy.deepcopy(plans[0])

    def attempt(label, mutate, plan_id="INJ:lane"):
        bad = copy.deepcopy(base)
        mutate(bad)
        try:
            build_plan(reg, plan_id=plan_id,
                       **{k: v for k, v in bad.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
        except PlanBuildError:
            return
        raise AssertionError(f"gate accepted the {label} injection")

    attempt("missing section (None)", lambda p: p.update(endpoints=None),
            "INJ:null-section")
    attempt("unknown candidate status",
            lambda p: p["candidate"].update(status="WONDERDRUG"))
    attempt("unknown candidate tier",
            lambda p: p["candidate"].update(tier="CERTAIN"))
    attempt("unknown gate state",
            lambda p: p["stage_gates"][0].update(state="DONE"))
    attempt("registry state below HUMAN",
            lambda p: p["stage_gates"][0].update(
                state="REGISTRY_ACTIVITY_PRESENT"))
    attempt("out-of-prefix completion",
            lambda p: (p["stage_gates"][0].update(state=GATE_PROPOSED),
                       p["stage_gates"][3].update(
                           state=GATE_COMPLETED,
                           cited_source_ids=["SRC:OT_P4"])))
    attempt("uncited completion",
            lambda p: p["stage_gates"][0].update(
                state=GATE_COMPLETED, cited_source_ids=[]))
    attempt("unresolvable evidence id",
            lambda p: p["supporting_evidence"].append(
                {"kind": "x", "source_ids": ["SRC:NOPE"], "note": ""}))
    attempt("results-token content",
            lambda p: p["endpoints"].append(
                {"name": "x", "assay_annotation": "ok",
                 "measurable": "hazard ratio 0.7"}))
    attempt("unresolvable CT accession",
            lambda p: p["datasets"].update(ct_accessions=["NCT00000000"]))
    attempt("unresolvable dataset source id",
            lambda p: p["datasets"].update(source_ids=["SRC:P7_CT_ZZ"]))
    attempt("empty honest limits",
            lambda p: p.update(honest_limits=[]))
    # datasets without content AND without absence note
    attempt("empty datasets without absence note",
            lambda p: p["datasets"].update(ct_accessions=[],
                                           geo_accessions=[],
                                           source_ids=[],
                                           absence_note=None))

    # artifact-layer lanes (plans loaded from an artifact/API payload
    # must re-pass the same gate via validate_loaded_plan)
    from v15.validation_plan import validate_loaded_plan

    def attempt_loaded(label, mutate, plan_id="INJ:loaded"):
        bad = copy.deepcopy(base)
        mutate(bad)
        try:
            validate_loaded_plan(reg, bad)
        except PlanBuildError:
            return
        raise AssertionError(f"loaded-plan gate accepted the {label} "
                             "injection")

    attempt_loaded("status/transition mismatch",
                   lambda p: p.update(required_evidence_to_change_status={
                       "from": "INVESTIGATIONAL",
                       "to": "APPROVED_INDICATION",
                       "evidence_classes": ["x"],
                       "never_by_computation": True}))
    attempt_loaded("transition without never_by_computation",
                   lambda p: p["required_evidence_to_change_status"].update(
                       never_by_computation=False))
    attempt_loaded("unknown status on load",
                   lambda p: p["candidate"].update(status="MIRACLE_CURE"),
                   "INJ:loaded-status")
    # and the honest path: every artifact plan re-passes the gate
    for p in plans:
        validate_loaded_plan(reg, p)


# ------------------------------------------------------- F1 (schema)
def t_f1_schema_completeness():
    bench = _module_f()
    t = bench["theorems"]["F1"]
    assert t["proved"] and t["tier"] == "PROVEN_MATH"
    st = t["stats"]
    assert st["missing_sections"] == 0 and not st["injection_failures"]
    # the EVIDENCED+ subset must equal the writer's evidenced count
    plans = bench["plans"]
    ev = [p for p in plans
          if p["candidate"]["tier"] in ("PROVEN_MATH", "EVIDENCED")]
    assert len(ev) == bench["evidenced_plan_count"] == st["evidenced_plans"]
    assert all(p["supporting_evidence"] for p in ev)


# ------------------------------------------------- F2 (gate ordering)
def t_f2_stage_gate_ordering():
    bench = _module_f()
    t = bench["theorems"]["F2"]
    assert t["proved"] and t["stats"]["violations"] == 0
    assert t["stats"]["gate_ladder"] == ["BIOCHEMICAL", "CELLULAR",
                                         "TISSUE", "ANIMAL", "HUMAN"]


# ---------------------------------------------------- F3 (citations)
def t_f3_evidence_citation_completeness():
    bench = _module_f()
    t = bench["theorems"]["F3"]
    assert t["proved"]
    st = t["stats"]
    assert st["unresolved"] == 0 and st["evidence_ids_checked"] > 100
    assert set(st["ledgers"]) == {"P4", "P7", "P8"}


# ------------------------------------------- F4 (no results synthesis)
def t_f4_no_results_synthesis():
    bench = _module_f()
    t = bench["theorems"]["F4"]
    assert t["proved"]
    st = t["stats"]
    assert st["plan_token_hits"] == 0 and st["registry_token_hits"] == []
    assert st["connector_whitelist_enforced"] is True
    # connector source: the request fields whitelist cannot carry
    # outcomes/results modules (AST-level, re-checked here)
    import v15.connectors.clinicaltrials as CTS
    assert len(CTS._ALLOWED_MODULES) == 6
    for m in CTS._ALLOWED_MODULES:
        assert "outcome" not in m.lower() and "result" not in m.lower()
    assert "outcomesModule" not in CTS._FIELDS
    assert "resultSection" not in CTS._FIELDS
    assert not any(tok.lower() in CTS._FIELDS.lower()
                   for tok in CTS._FORBIDDEN_TOKENS)


# --------------------------------------------------- F5 (transitions)
def t_f5_status_transition_discipline():
    from v15.validation_plan import attempt_status_upgrade, PlanBuildError
    bench = _module_f()
    t = bench["theorems"]["F5"]
    assert t["proved"]
    for p in bench["plans"]:
        try:
            attempt_status_upgrade(p)
            raise AssertionError("upgrade path must always raise")
        except PlanBuildError:
            pass
        tr = p["required_evidence_to_change_status"]
        assert tr["never_by_computation"] is True
        assert tr["evidence_classes"]


# ------------------------------------------------- F6 (determinism)
def t_f6_plan_determinism():
    bench = _module_f()
    t = bench["theorems"]["F6"]
    assert t["proved"]
    st = t["stats"]
    assert st["identical"] and st["sha_build1"] == st["sha_build2"]
    assert st["wall_clock_fields"] == 0
    # artifact round-trip: the certificate's plans hash deterministically
    import hashlib
    blob = json.dumps(bench["plans"], sort_keys=True).encode("utf-8")
    d1 = hashlib.sha256(blob).hexdigest()
    d2 = hashlib.sha256(json.dumps(
        json.loads(blob.decode("utf-8")), sort_keys=True).encode(
            "utf-8")).hexdigest()
    assert d1 == d2


# ---------------------------------------------- F7 (out-of-domain)
def t_f7_out_of_domain():
    bench = _module_f()
    t = bench["theorems"]["F7"]
    assert t["proved"]
    st = t["stats"]
    assert st["fabrications"] == 0 and st["honest_refusal"] is True
    from v15.validation_plan import ValidationRegistry
    reg = ValidationRegistry(verify_pin=True)
    assert reg.study_ids_for("notarealdrug", "CKD") is None
    assert reg.geo_series_for("NOT_A_DISEASE") == []
    assert reg.study_ids_for("dapagliflozin", "CKD") is not None


# --------------------------------------------- gate-state honesty
def t_gate_state_honesty():
    plans = _plans()
    for p in plans:
        for g in p["stage_gates"]:
            if g["state"] == "REGISTRY_ACTIVITY_PRESENT":
                assert g["gate"] == "HUMAN", p["plan_id"]
                assert "metadata only" in g["basis"]
                assert "results" in g["basis"]
                assert g["registry_accessions"]
            if g["state"] == "PROPOSED":
                assert not g["cited_source_ids"]
            if g["state"] == "COMPLETED_WITH_CITED_EVIDENCE":
                assert g["cited_source_ids"]
    # generated molecules: every gate PROPOSED, structural absence
    for p in plans:
        if p["candidate"]["kind"] == "GENERATED_MOLECULE":
            assert all(g["state"] == "PROPOSED"
                       for g in p["stage_gates"])
            assert p["datasets"]["absence_note"]
            assert "ABS:APXD_NO_REGISTRY_RECORD" in \
                p["datasets"]["absence_note"]


# ------------------------------------------------- dataset panel spot
def t_dataset_panel_spotchecks():
    reg = _registry()
    # dapagliflozin x CKD: the DAPA/EMPA-era cardio-renal panel must be
    # represented (mechanical filter over registry metadata)
    lnk = reg.study_ids_for("dapagliflozin", "CKD")
    assert lnk is not None and lnk["matched_total"] >= 3
    assert lnk["specificity"] == "EXACT_DISEASE_CONTEXT"
    assert lnk["filter_recorded"]["drug_token"] == "dapagliflozin"
    # HFREF/HFPEF links are honestly CONDITION_LEVEL_ONLY
    for key in ("HFREF", "HFPEF"):
        l2 = reg.study_ids_for("dapagliflozin", key)
        assert l2 is None or l2["specificity"] == "CONDITION_LEVEL_ONLY"
    # a queried drug with a condition-level query still has sources
    study = reg.studies[lnk["study_ids"][0]]
    assert study["nct_id"] == lnk["study_ids"][0]
    assert study["brief_title"] and study["overall_status"]
    # GEO lane: accessions + organism metadata present, no data columns
    acc = reg.geo_links[0]["series_ids"][0]
    s = reg.series[acc]
    assert acc == s["accession"]
    assert s["title"] and s["summary"] is not None
    assert not any(k in s for k in ("samples", "suppfile", "value"))


# ------------------------------------------------------------ hygiene
def t_isolation_and_artifacts():
    # derivation modules must import no connector code (AST)
    for mod in ("v15/validation_plan.py", "v15/validation_data.py",
                "v15/kb_extensions/freeze_validation.py"):
        tree = ast.parse(open(os.path.join(ROOT, mod),
                              encoding="utf-8").read())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert not any("connectors" in a.name
                               for a in node.names), mod
            if isinstance(node, ast.ImportFrom):
                assert "connectors" not in (node.module or ""), mod
    # the frozen data module imports nothing at all
    tree = ast.parse(open(os.path.join(ROOT, "v15/validation_data.py"),
                          encoding="utf-8").read())
    assert not [n for n in ast.walk(tree)
                if isinstance(n, (ast.Import, ast.ImportFrom))]
    # artifacts exist, parse, carry the theorem block
    js_path = os.path.join(ROOT, "v15", "out", "phase7_benchmark.json")
    txt_path = os.path.join(ROOT, "v15", "out", "phase7_benchmark.txt")
    assert os.path.exists(js_path) and os.path.exists(txt_path)
    bench = json.load(open(js_path, encoding="utf-8"))
    assert bench["all_proved"] is True
    assert len(bench["theorems"]) == 7
    assert bench["plan_count"] >= 20
    txt = open(txt_path, encoding="utf-8").read()
    assert "VALIDATION_PLAN" in txt and "REGISTRY_ACTIVITY_PRESENT" in txt
    assert "HONEST LIMITS" in txt
    assert os.path.exists(os.path.join(
        ROOT, "v15", "write_phase7_artifacts.py"))


def t_frozen_file_integrity():
    snap = os.path.join(ROOT, "docs", "baseline",
                        "frozen_files_sha256_before.txt")
    expected = {}
    with open(snap, encoding="utf-8") as fh:
        for line in fh:
            h, name = line.split()
            expected[name] = h
    import hashlib
    for name in ("disease_drug_kb.py", "drug_structures.py",
                 "disease_mechanism_table.py", "postulates_v14.json"):
        h = hashlib.sha256()
        with open(os.path.join(ROOT, name), "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 16), b""):
                h.update(chunk)
        assert expected[name] == h.hexdigest(), name


def t_claim_tier_language():
    banned = ("cure", "efficacious", "treats ")
    mods = ("v15/validation_plan.py", "v15/validation_data.py",
            "v15/write_phase7_artifacts.py")
    for mod in mods:
        text = open(os.path.join(ROOT, mod),
                    encoding="utf-8").read().lower()
        for word in banned:
            assert word not in text, (mod, word)


def main() -> int:
    check("P7-2 registry pin discipline + self-validation + structural "
          "results absence", t_registry_pin_and_selfvalidation)
    check("plan build-gate refusal lanes (13 negative controls)",
          t_build_gate_refusal_lanes)
    check("F1 plan-schema completeness (incl. EVIDENCED+ subset)",
          t_f1_schema_completeness)
    check("F2 stage-gate ordering (prefix completion)", t_f2_stage_gate_ordering)
    check("F3 evidence-citation completeness (P4/P7/P8)",
          t_f3_evidence_citation_completeness)
    check("F4 no-results-synthesis (connector whitelist + scans + "
          "injection)", t_f4_no_results_synthesis)
    check("F5 status-transition discipline (upgrade path raises)",
          t_f5_status_transition_discipline)
    check("F6 plan determinism (double build + artifact round-trip)",
          t_f6_plan_determinism)
    check("F7 out-of-domain detection (ghost probes)", t_f7_out_of_domain)
    check("gate-state honesty (REGISTRY only on HUMAN lane; generated "
          "molecules all-PROPOSED)", t_gate_state_honesty)
    check("dataset panel spot-checks (link filters, specificity, GEO "
          "metadata shape)", t_dataset_panel_spotchecks)
    check("AST isolation + artifact integrity", t_isolation_and_artifacts)
    check("frozen-file integrity (sha256 vs baseline snapshot)",
          t_frozen_file_integrity)
    check("claim-tier language scan (no cure/treats/efficacious)",
          t_claim_tier_language)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
