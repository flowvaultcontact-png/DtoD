#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 6 unit tests (P6-1..P6-4 acceptance, Module E).

Exit 0 <=> every check passes. Covers:
  * P6-1  frozen P8 knowledge graph: pin discipline (tamper refuses),
          1539 edges over the 7 formal relations, build-gate refusal
          lanes (unknown relation/tier, empty EVIDENCED sources,
          layer-order violation, node on conflicting layers)
  * E1    graph-consistency theorem + negative control (a tampered
          back-edge is refused by the build gate)
  * E2    disease-identity-uniqueness theorem + negative control (a
          conflicting external id is detected)
  * E3    contradiction-detection theorem + negative control (an
          injected opposing action pair is exposed)
  * E4    provenance-completeness theorem + negative control (an
          uncited EVIDENCED edge cannot be built)
  * E5    rank-integrity theorem (5 deterministic permutation rebuilds)
  * E6    tier-propagation theorem + negative control (one HYPOTHESIS
          edge downgrades the whole chain; never the reverse)
  * E7    out-of-domain detection (unknown ids -> explicit absences;
          unencodable profile refused; coercion raises)
  * E8    bit-for-bit reproducibility (in-memory + generator subprocess)
  * E9    fingerprint-portability gate (P6-3 / audit R4)
  * E10   memo determinism + warm speedup (P6-4 / audit R5)
  * hygiene: derivation/connector AST isolation, artifacts integrity,
          frozen-file integrity vs baseline snapshot, claim-tier
          language scan
No file is modified by these tests; they run fully offline against the
frozen P8 section, the frozen v14.1 corpus (read-only) and the pinned
RDKit build.
"""

import ast
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(HERE))        # apeiron/ repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "v15", "kb_extensions"))

CHECKS = []


def check(name, fn):
    try:
        fn()
        CHECKS.append((name, True, ""))
        print(f"[ OK ] {name}")
    except Exception as exc:                     # noqa: BLE001 — harness
        CHECKS.append((name, False, str(exc)))
        print(f"[FAIL] {name}: {exc}")


def _load_bench():
    js = os.path.join(ROOT, "v15", "out", "phase6_benchmark.json")
    if not os.path.exists(js):
        raise RuntimeError("run v15/write_phase6_artifacts.py first")
    with open(js, encoding="utf-8") as fh:
        return json.load(fh)


def _graph():
    from v15.kgraph import KnowledgeGraph
    return KnowledgeGraph.from_frozen(verify_pin=True)


# ------------------------------------------------- P6-1 frozen artifact
def t_p8_pin_and_build_gate():
    from v15.kgraph import (KnowledgeGraph, sha256_of, KGRAPH_DATA_PATH,
                            KGRAPH_PIN_PATH, load_kgraph)
    assert os.path.exists(KGRAPH_PIN_PATH)
    with open(KGRAPH_PIN_PATH, encoding="utf-8") as fh:
        pins = json.load(fh)
    digest = sha256_of(KGRAPH_DATA_PATH)
    assert pins["kgraph_data_sha256"] == digest
    ns = load_kgraph(verify_pin=False)
    edges = ns["P8_EDGES"]
    assert len(edges) == 1539, len(edges)
    stats = ns["P8_STATS"]
    assert sum(stats.values()) == len(edges)
    assert len(ns["P8_ABSENCES"]) == 73
    for rel in ("disease->gene", "gene->protein", "protein->pathway",
                "target->mechanism", "mechanism->drug", "drug->structure",
                "structure->property"):
        assert stats[rel] > 0, rel
    g = KnowledgeGraph.from_frozen()
    assert g.stats["nodes"] == 726
    # pin discipline: refuse to serve on a tampered pin (swap-in the
    # tampered file, expect refusal, restore the original bytes no
    # matter what happens)
    with open(KGRAPH_PIN_PATH, "rb") as fh:
        original_pin_bytes = fh.read()
    tampered = json.loads(original_pin_bytes.decode("utf-8"))
    tampered["kgraph_data_sha256"] = "0" * 64
    with open(KGRAPH_PIN_PATH, "w", encoding="utf-8") as fh:
        json.dump(tampered, fh)
    try:
        try:
            load_kgraph(verify_pin=True)
            raise AssertionError("tampered pin must refuse to serve")
        except RuntimeError:
            pass
    finally:
        with open(KGRAPH_PIN_PATH, "wb") as fh:
            fh.write(original_pin_bytes)
    # build gate refusal lanes
    recs = ns["SOURCE_RECORDS_P8"]
    layers = ns["NODE_LAYERS"]
    base = dict(edges[0])
    for bad in (
        dict(base, rel="gene->disease"),                 # unknown relation
        dict(base, tier="CERTAIN"),                      # unknown tier
        dict(base, tier="EVIDENCED", sources=[]),        # uncited
        dict(base, rel="structure->drug"),               # layer order
    ):
        try:
            KnowledgeGraph([bad], recs, layers)
            raise AssertionError(f"gate must refuse: {bad['rel']}/"
                                 f"{bad['tier']}")
        except ValueError:
            pass


# ------------------------------------------------- E1..E4 theorem lanes
def t_theorems_e1_to_e4():
    bench = _load_bench()
    th = bench["theorems"]
    for key in ("E1", "E2", "E3", "E4"):
        assert th[key]["proved"], (key, th[key]["counterexamples"][:2])
    assert th["E1"]["stats"]["cycles"] == 0
    assert th["E1"]["stats"]["layer_violations"] == 0
    assert th["E2"]["stats"]["phi_tuples"] == 68          # CF: no phi
    assert th["E3"]["stats"]["excluded_member_violations"] == 0
    assert th["E4"]["stats"]["violations"] == 0


def t_negative_controls_gate_and_detectors():
    from v15.kgraph import (KnowledgeGraph, theorem_disease_identity_uniqueness,
                            theorem_contradiction_detection)
    ns = load_kgraph_ns()
    edges, recs, layers = ns["P8_EDGES"], ns["SOURCE_RECORDS_P8"], \
        ns["NODE_LAYERS"]
    # NC1: a tampered back-edge (drug->gene) must be refused by the gate
    back = dict(edges[0], rel="gene->disease")
    back["src"], back["dst"] = edges[0]["dst"], edges[0]["src"]
    try:
        KnowledgeGraph([back], recs, layers)
        raise AssertionError("back-edge must be refused")
    except ValueError:
        pass
    # NC2: conflicting external id must be detected by E2
    g = KnowledgeGraph(edges, recs, layers)
    th = theorem_disease_identity_uniqueness(
        g, tamper={"D01": "MONDO_0009061"})          # CF's MONDO id
    assert not th["proved"] and th["counterexamples"], "E2 must flag"
    # NC3: an injected opposing action pair must be exposed by E3
    inj = [{"rel": "target->mechanism", "src": "ACE", "dst": "ACEI_RAAS",
            "tier": "EVIDENCED", "sources": ["SRC:OT_P4"],
            "attrs": {"action_type": "AGONIST", "via_drugs": ["probe_drug"]}}]
    th = theorem_contradiction_detection(g, injected=inj)
    assert th["proved"], th["counterexamples"]
    assert th["stats"]["injection_detected"] is True
    assert th["stats"]["opposing_pairs_exposed"] >= 1
    # NC4: an uncited EVIDENCED edge must be refused by the build gate
    uncited = dict(edges[0], rel="gene->protein", src="XX1", dst="P99999",
                   sources=[])
    from v15.kgraph import theorem_evidence_provenance_completeness
    th = theorem_evidence_provenance_completeness(g, uncited=uncited)
    assert th["proved"] and th["stats"]["injection_detected"], \
        "uncited edge must be flagged"


def load_kgraph_ns():
    from v15.kgraph import load_kgraph
    return load_kgraph(verify_pin=True)


# ------------------------------------------------- E5..E7 theorem lanes
def t_theorems_e5_to_e7():
    bench = _load_bench()
    th = bench["theorems"]
    for key in ("E5", "E6", "E7"):
        assert th[key]["proved"], (key, th[key]["counterexamples"][:2])
    assert th["E5"]["stats"]["disagreements"] == 0
    assert th["E6"]["stats"]["chains"] == 233
    assert th["E7"]["stats"]["fabrications"] == 0


def t_tier_downgrade_negative_control():
    from v15.kgraph import KnowledgeGraph, tier_meet
    ns = load_kgraph_ns()
    g = KnowledgeGraph(ns["P8_EDGES"], ns["SOURCE_RECORDS_P8"],
                       ns["NODE_LAYERS"])
    # lattice spot checks
    assert tier_meet("EVIDENCED", "COMPUTATIONAL") == "COMPUTATIONAL"
    assert tier_meet("PROVEN_MATH", "EVIDENCED") == "EVIDENCED"
    assert tier_meet("COMPUTATIONAL", "COMPUTATIONAL") == "COMPUTATIONAL"
    # NC5: downgrading ONE edge of a chain must downgrade the chain
    # tier; no path can EVER be strengthened by re-computation
    chains = g.all_chains()
    victim = chains[0]
    edges = [dict(e) for e in ns["P8_EDGES"]]
    before = g.path_tier(victim)
    idx = victim[0]
    assert edges[idx]["tier"] == "EVIDENCED"
    edges[idx]["tier"] = "HYPOTHESIS"
    g2 = KnowledgeGraph(edges, ns["SOURCE_RECORDS_P8"], ns["NODE_LAYERS"])
    after = g2.path_tier(victim)
    assert after == "HYPOTHESIS", (before, after)


# ------------------------------------------------- E8..E10 theorem lanes
def t_theorems_e8_to_e10():
    bench = _load_bench()
    th = bench["theorems"]
    for key in ("E8", "E9", "E10"):
        assert th[key]["proved"], (key, th[key]["counterexamples"][:2])
    assert th["E8"]["stats"]["disk_match"] is True
    assert th["E8"]["stats"]["memory_match"] is True
    e9 = th["E9"]["stats"]
    assert e9["rdkit_live"] == e9["rdkit_pin"] == \
        e9["rdkit_in_frozen_pins"] == "2026.09.2"
    rt = e9["roundtrip"]
    assert rt["kb_molecules"] == 191 and rt["chi_mismatches"] == 0
    assert rt["member_violations"] == 0 and rt["false_positives"] == 0
    e10 = th["E10"]["stats"]
    assert e10["pairs_checked"] == 12144
    assert e10["mismatches"] == 0 and e10["cold_mismatches"] == 0
    assert e10["speedup_x"] and e10["speedup_x"] > 100


# ------------------------------------------------------- ranking report
def t_ranking_transparency():
    bench = _load_bench()
    assert bench["rankings_label"] == "COMPUTATIONAL_RANK"
    rk = bench["rankings"]
    assert set(rk) == {"CF", "D01", "D02", "D03", "D05", "D08", "D33",
                       "D50", "D51", "D54"}, sorted(rk)
    d08 = rk["D08"]["ranking"]
    drugs = [r["drug"] for r in d08]
    assert "dapagliflozin" in drugs and "sitagliptin" in drugs
    for row in d08:
        assert row["rank_label"] == "COMPUTATIONAL_RANK"
        assert row["chain_tier"] in ("PROVEN_MATH", "EVIDENCED",
                                     "COMPUTATIONAL", "HYPOTHESIS",
                                     "UNKNOWN")
    cf = rk["CF"]
    assert cf["found"] and cf["rank_label"] == "COMPUTATIONAL_RANK"
    # CF gene lane exists (CFTR) but the frozen packs carry no CFTR
    # mechanism rows: the drug ranking is HONESTLY EMPTY (absence, not
    # a fabricated recommendation)
    assert cf["ranking"] == [] or all(
        r["rank_label"] == "COMPUTATIONAL_RANK" for r in cf["ranking"])
    unknown = bench["rankings"].get("NOT_A_DISEASE")
    assert unknown is None                      # never invented


# ------------------------------------------------------------- hygiene
def t_frozen_file_integrity():
    snap = os.path.join(ROOT, "docs", "baseline",
                        "frozen_files_sha256_before.txt")
    expected = {}
    with open(snap, encoding="utf-8") as fh:
        for line in fh:
            h, name = line.split()
            expected[name] = h
    import hashlib
    for name in ("disease_drug_kb.py", "drug_structures.py",
                 "disease_mechanism_table.py", "postulates_v14.json"):
        h = hashlib.sha256()
        with open(os.path.join(ROOT, name), "rb") as fh:
            for chunk in iter(lambda: fh.read(1 << 16), b""):
                h.update(chunk)
        assert expected[name] == h.hexdigest(), name


def t_isolation_and_artifacts():
    # derivation modules must import no connector code (AST)
    for mod in ("v15/kgraph.py", "v15/molecular.py", "v15/chem/mol_io.py",
                "v15/kb_extensions/freeze_kgraph.py"):
        tree = ast.parse(open(os.path.join(ROOT, mod),
                              encoding="utf-8").read())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert not any("connectors" in a.name
                               for a in node.names), mod
            if isinstance(node, ast.ImportFrom):
                assert "connectors" not in (node.module or ""), mod
    # artifacts exist, parse, carry the theorem block
    js_path = os.path.join(ROOT, "v15", "out", "phase6_benchmark.json")
    txt_path = os.path.join(ROOT, "v15", "out", "phase6_benchmark.txt")
    assert os.path.exists(js_path) and os.path.exists(txt_path)
    bench = json.load(open(js_path, encoding="utf-8"))
    assert bench["all_proved"] is True
    assert len(bench["theorems"]) == 10
    txt = open(txt_path, encoding="utf-8").read()
    assert "COMPUTATIONAL_RANK" in txt
    assert "P8" in txt and "1539" in txt
    assert os.path.exists(os.path.join(
        ROOT, "v15", "write_phase6_artifacts.py"))


def t_claim_tier_language():
    banned = ("cure", "efficacious", "treats ")
    mods = ("v15/kgraph.py", "v15/kgraph_data.py",
            "v15/write_phase6_artifacts.py", "v15/molecular.py")
    for mod in mods:
        text = open(os.path.join(ROOT, mod),
                    encoding="utf-8").read().lower()
        for word in banned:
            assert word not in text, (mod, word)


def main() -> int:
    check("P6-1 P8 pin discipline + 1539-edge build gate refusal lanes",
          t_p8_pin_and_build_gate)
    check("E1-E4 theorems: consistency, identity uniqueness, "
          "contradiction, provenance", t_theorems_e1_to_e4)
    check("negative controls: back-edge, alias conflict, injected "
          "opposing pair, uncited edge", t_negative_controls_gate_and_detectors)
    check("E5-E7 theorems: rank integrity, tier propagation, "
          "out-of-domain", t_theorems_e5_to_e7)
    check("tier downgrade negative control (chain weakens, never "
          "strengthens)", t_tier_downgrade_negative_control)
    check("E8-E10 theorems: bit-for-bit reproducibility, fingerprint "
          "portability (P6-3), memo determinism (P6-4)",
          t_theorems_e8_to_e10)
    check("ranking transparency: COMPUTATIONAL_RANK labels, D08 "
          "recapitulates guideline classes, unknown absent",
          t_ranking_transparency)
    check("frozen-file integrity (sha256 vs baseline snapshot)",
          t_frozen_file_integrity)
    check("AST isolation + artifact integrity", t_isolation_and_artifacts)
    check("claim-tier language scan (no cure/treats/efficacious)",
          t_claim_tier_language)
    n_fail = sum(1 for _, ok, _ in CHECKS if not ok)
    print(f"\n{len(CHECKS) - n_fail}/{len(CHECKS)} checks passed")
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
