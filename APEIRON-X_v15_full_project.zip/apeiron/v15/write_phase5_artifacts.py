#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 5 acceptance artifacts writer.

Runs Module D (novel molecule discovery) and writes the machine
certificate + the human-readable report:

    v15/out/phase5_benchmark.json   — machine-checkable artifact
    v15/out/phase5_benchmark.txt    — readable tables + theorems

Fully offline: consumes only the frozen v14.1 structure corpus (read-
only), the frozen ChEMBL Phase 4 cache payloads, and the deterministic
generation pipeline. No network, no connectors.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # apeiron/ repo root
sys.path.insert(0, ROOT)

from v15.molecular import run_module_d          # noqa: E402
from v15.chem import mol_io                     # noqa: E402

OUT = os.path.join(ROOT, "v15", "out")
QUOTA = 100


def main() -> int:
    bench = run_module_d(quota=QUOTA)
    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(OUT, "phase5_benchmark.json"), "w",
              encoding="utf-8") as fh:
        json.dump(bench, fh, indent=1, sort_keys=True)

    lines = []
    A = lines.append
    A("APEIRON-X v15 - PHASE 5 NOVEL MOLECULE DISCOVERY - ACCEPTANCE REPORT")
    A("=" * 70)
    A("module: " + bench["module"] +
      "   schema: " + bench["molecule_schema_version"] +
      "   RDKit: " + bench["rdkit_version"])
    fs = bench["feature_space"]
    A(f"feature space: {fs['feature_space_id']}  "
      f"({fs['smarts_features']} SMARTS + "
      f"{fs['descriptor_features']} descriptor + "
      f"{fs['negation_features']} negation features; "
      f"tables sha256 {fs['tables_sha256'][:16]}...)")
    A("generation config sha256: " +
      bench["generation_config"]["config_sha256"])
    A("")
    rc = bench["reference_corpus"]
    A(f"reference corpus (novelty lane): {rc['kb_molecules']} KB "
      f"molecules (axiom A6, frozen) + {rc['chembl_molecules']} ChEMBL "
      f"structures (Phase 4 frozen cache)")
    for ab in rc["absences"]:
        A(f"  recorded absence: {ab['chembl_id']} -> {ab['absence']}")
    rt = bench["theorems"]["theorem_kb_roundtrip"]
    A("")
    A(f"ROUND-TRIP (acceptance): {rt['stats']['kb_molecules']} KB "
      f"molecules, chi mismatches "
      f"{rt['stats']['chi_mismatches']}, "
      f"{rt['stats']['laws_recertified']} proved laws re-certified, "
      f"member violations {rt['stats']['member_violations']}, "
      f"false positives {rt['stats']['false_positives']} "
      f"-> proved={rt['proved']}")
    A("")
    A(f"GENERATION: quota {bench['quota']}, emitted {bench['emitted_n']}, "
      f"rejected {bench['rejected_n']} "
      f"({bench['generation_stats']['products_evaluated']} products "
      f"evaluated over {bench['generation_stats']['seeds_scanned']} "
      f"law-satisfying seeds)")
    A("  rejections by reason (nothing silently dropped):")
    for reason, n in bench["rejections_by_reason"].items():
        A(f"    {reason:<24} {n}")
    A("")
    A("P5-3 registry status: " +
      bench["admet_registry"]["statement"][:80] + " ...")
    A("")
    A("P5-5 THEOREM RESULTS:")
    for tname, t in bench["theorems"].items():
        A(f"  [{'PROVED' if t['proved'] else 'FAILED'}] {tname} "
          f"({t['tier']})")
    A("ALL theorems proved: " + str(bench["theorems_all_proved"]))
    A("")
    A(f"TOP {min(20, bench['emitted_n'])} GENERATED CANDIDATES "
      f"(COMPUTATIONAL_RANK; rank hint only, never a probability, "
      f"never a predicted activity):")
    emitted = [m for m in bench["molecules"]
               if m["status"] == "GENERATED_CANDIDATE"
               and not m.get("rejected")]
    for r in emitted[:20]:
        laws = ",".join(r["laws_satisfied"][:3])
        if len(r["laws_satisfied"]) > 3:
            laws += f"+{len(r['laws_satisfied']) - 3}"
        A(f"  {r['mol_id']} {r['smiles'][:58]:<58} "
          f"agg={r['aggregate']:.4f} "
          f"nov={r['axes']['novelty_distance']:.2f} "
          f"sa={r['axes']['synthetic_accessibility_estimate']:.2f} "
          f"laws[{laws}]")
    A("")
    A("HONEST LIMITS")
    for lim in bench["honest_limits"]:
        A("  * " + lim)
    report = "\n".join(lines) + "\n"
    with open(os.path.join(OUT, "phase5_benchmark.txt"), "w",
              encoding="utf-8") as fh:
        fh.write(report)
    print(report)
    ok = (bench["emitted_n"] == QUOTA
          and bench["theorems_all_proved"]
          and bench["theorems"]["theorem_kb_roundtrip"]["proved"])
    print("wrote v15/out/phase5_benchmark.json and phase5_benchmark.txt")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
