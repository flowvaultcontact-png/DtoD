"""Provenance ledger — v15 data-integration foundation (master prompt §4).

Every external scientific record ingested into v15 must be wrapped in a
SourceRecord. Nothing is fabricated: a connector that failed to fetch
records the failure instead of inventing data. Ingested tables are frozen
(sha256) exactly like the v14.1 KB doctrine; a refresh means re-freeze +
re-pin + full cascade re-run.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field, asdict
from typing import Optional


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class SourceRecord:
    source_id: str            # e.g. "PUBCHEM_CID:11949646"
    resource: str             # e.g. "PubChem", "Open Targets Platform"
    resource_version: str     # release/version string as reported by source
    retrieval_utc: str        # ISO-8601 UTC timestamp of the fetch
    url: str                  # exact endpoint/landing page used
    license: str              # license identifier, e.g. "CC-BY-4.0" or "SEE_TERMS"
    evidence_type: str        # e.g. "experiment", "guideline", "annotation"
    confidence: str           # source-reported confidence class, if any
    sha256: Optional[str] = None  # hash of the frozen raw payload, if stored
    limitations: str = ""     # known limits, recorded honestly

    def __post_init__(self):
        for f in ("source_id", "resource", "resource_version", "retrieval_utc",
                  "url", "license", "evidence_type", "confidence"):
            v = getattr(self, f)
            if not isinstance(v, str) or not v:
                raise ValueError(f"SourceRecord.{f} must be a non-empty string")

    def freeze_payload(self, raw: bytes, cache_dir: str) -> str:
        """Store the raw payload under cache_dir and pin its sha256."""
        os.makedirs(cache_dir, exist_ok=True)
        digest = hashlib.sha256(raw).hexdigest()
        path = os.path.join(cache_dir, digest + ".json")
        if not os.path.exists(path):
            with open(path, "wb") as fh:
                fh.write(raw)
        self.sha256 = digest
        return path


@dataclass
class ProvenanceLedger:
    records: dict = field(default_factory=dict)

    def add(self, rec: SourceRecord) -> SourceRecord:
        if rec.source_id in self.records:
            raise ValueError(f"duplicate source_id {rec.source_id}")
        self.records[rec.source_id] = rec
        return rec

    def get(self, source_id: str) -> SourceRecord:
        if source_id not in self.records:
            raise KeyError(f"no provenance record for {source_id}")
        return self.records[source_id]

    def require(self, source_ids) -> None:
        """Raise unless every cited id has a record (anti-fabrication gate)."""
        missing = [s for s in source_ids if s not in self.records]
        if missing:
            raise KeyError("uncited/unrecorded source ids: " + ", ".join(missing))

    def dump(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({sid: asdict(r) for sid, r in sorted(self.records.items())},
                      fh, indent=1, sort_keys=True)

    @classmethod
    def load(cls, path: str) -> "ProvenanceLedger":
        with open(path, encoding="utf-8") as fh:
            raw = json.load(fh)
        led = cls()
        for sid, r in raw.items():
            led.add(SourceRecord(**r))
        return led
