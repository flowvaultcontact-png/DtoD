#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 3 acceptance artifacts writer.

Runs the target-discovery benchmark on the frozen evidence table and
writes the machine certificate + the human-readable report:

    v15/out/phase3_benchmark.json   — machine-checkable artifact
    v15/out/phase3_benchmark.txt    — readable rank tables + theorems

Fully offline: consumes only the frozen tables (v15/target_data.py,
sha256-pinned) and never touches the network or the connectors.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # apeiron/ repo root
sys.path.insert(0, ROOT)

from v15.targets import load_targets, benchmark   # noqa: E402

OUT = os.path.join(ROOT, "v15", "out")


def to_jsonable(bench: dict) -> dict:
    out = json.loads(json.dumps(bench))          # deep copy, plain types
    return out


def main() -> int:
    t = load_targets()
    bench = benchmark(t, k=10)
    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(OUT, "phase3_benchmark.json"), "w",
              encoding="utf-8") as fh:
        json.dump(to_jsonable(bench), fh, indent=1, sort_keys=True)

    lines = []
    A = lines.append
    A("APEIRON-X v15 — PHASE 3 TARGET DISCOVERY — ACCEPTANCE REPORT")
    A("=" * 70)
    A("frozen table sha256 (pinned): " + t.pins["target_data_sha256"])
    A("schema version: " + bench["schema_version"] +
      "   frozen_utc: " + bench["frozen_utc"])
    A("")
    A(f"macro recall@10 over {bench['panel_diseases']} diseases / "
      f"{bench['guideline_targets_total']} guideline targets: "
      f"{bench['macro_recall_at_10']}")
    A("anti-causal-illusion theorem proved on every rank report: " +
      str(bench["theorem_anti_causal_illusion_all_proved"]))
    A("rank determinism theorem proved on every disease: " +
      str(bench["rank_determinism_all_proved"]))
    A("")
    for did in sorted(bench["per_disease"]):
        p = bench["per_disease"][did]
        A("-" * 70)
        A(f"{did}  {p['disease']}")
        A(f"    guideline: {p['guideline']}")
        A(f"    guideline targets: {', '.join(p['guideline_targets'])}"
          f"   hits@10: {', '.join(p['hits']) or '-'}"
          f"   misses: {', '.join(p['misses']) or '-'}"
          f"   recall@10: {p['recall_at_10']}")
        if p["coverage_gaps"]:
            A("    known coverage gaps (recorded, not counted as misses):")
            for g in p["coverage_gaps"]:
                A("      - " + g)
        for r in p["ranked_all"]:
            flag = (" [" + ",".join(r["flags"]) + "]") if r["flags"] else ""
            A(f"    #{r['rank']:>2} {r['symbol']:<7} {r['aggregate']:.4f}"
              f"{flag}  kinds={','.join(r['kinds'])}")
            A("        axes: " + ", ".join(f"{k}={v}"
                                           for k, v in r["axes"].items()))
    A("-" * 70)
    A("HONEST LIMITS")
    for lim in bench["honest_limits"]:
        A("  * " + lim)
    report = "\n".join(lines) + "\n"
    with open(os.path.join(OUT, "phase3_benchmark.txt"), "w",
              encoding="utf-8") as fh:
        fh.write(report)
    print(report)
    print("wrote v15/out/phase3_benchmark.json and phase3_benchmark.txt")
    ok = (bench["macro_recall_at_10"] == 1.0
          and bench["theorem_anti_causal_illusion_all_proved"]
          and bench["rank_determinism_all_proved"])
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
