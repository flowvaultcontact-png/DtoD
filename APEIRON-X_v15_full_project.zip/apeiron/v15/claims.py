"""Tiered claim model — the v15 truth-in-labeling spine (Module E obligation).

Every statement emitted anywhere in APEIRON-X v15 must carry one ClaimTier.
A COMPUTATIONAL or HYPOTHESIS tier must never be rendered as clinical or
biological fact, and a PROVEN_MATH claim only ever holds on the encoded
closed-world corpus (never on biology at large).
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class ClaimTier(Enum):
    """Ordered from strongest to weakest. Ordering is display-only: the
    tiers are qualitatively different kinds of support, NOT a probability
    scale."""

    PROVEN_MATH = "PROVEN_MATH"          # machine-checked on the encoded corpus
    EVIDENCED = "EVIDENCED"              # cited experimental/guideline evidence
    COMPUTATIONAL = "COMPUTATIONAL"      # inference of the v15 engines
    HYPOTHESIS = "HYPOTHESIS"            # speculative research hypothesis
    UNKNOWN = "UNKNOWN"                  # absent information, reported as such


# A claim may only move UP this ladder with new evidence, never by
# re-computation. Enforced by refusing upgrades in from_external().
_LADDER = [ClaimTier.PROVEN_MATH, ClaimTier.EVIDENCED,
           ClaimTier.COMPUTATIONAL, ClaimTier.HYPOTHESIS, ClaimTier.UNKNOWN]


@dataclass
class Claim:
    statement: str
    tier: ClaimTier
    source_ids: tuple = field(default=())
    note: Optional[str] = None

    def __post_init__(self):
        if not self.statement or not isinstance(self.statement, str):
            raise ValueError("Claim.statement must be a non-empty string")
        if not isinstance(self.tier, ClaimTier):
            self.tier = ClaimTier(self.tier)
        self.source_ids = tuple(self.source_ids)
        if self.tier is ClaimTier.EVIDENCED and not self.source_ids:
            raise ValueError("EVIDENCED claims must cite >= 1 source id")

    def weaken_to(self, tier: ClaimTier) -> "Claim":
        """Deliberately downgrade a claim (never upgrade)."""
        if _LADDER.index(tier) < _LADDER.index(self.tier):
            raise ValueError("refusing to strengthen a claim by code path; "
                             "provide new evidence instead")
        return Claim(self.statement, tier, self.source_ids, self.note)
