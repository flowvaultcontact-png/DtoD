#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 7 acceptance artifacts writer.

Runs Module F (experimental-validation intelligence) and writes the
machine certificate + the human-readable report:

    v15/out/phase7_benchmark.json   — machine-checkable artifact
    v15/out/phase7_benchmark.txt    — readable plan tables + theorems

Fully offline: consumes the frozen P7 registry (sha256-pinned), the
frozen P4 pack and the frozen P8 graph (both read-only, pin-checked)
and the frozen Phase 5 artifact. No network access.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # apeiron/ repo root
sys.path.insert(0, ROOT)

from v15.validation_plan import run_module_f    # noqa: E402

OUT = os.path.join(ROOT, "v15", "out")


def _fmt_gate_row(p):
    states = []
    for g in p["stage_gates"]:
        sym = {"PROPOSED": "proposed",
               "REGISTRY_ACTIVITY_PRESENT": "REGISTRY",
               "COMPLETED_WITH_CITED_EVIDENCE": "COMPLETED"}[g["state"]]
        states.append(f"{g['gate'][:4]}:{sym}")
    return " ".join(states)


def _one_plan_block(p, out):
    A = out.append
    A(f"  plan {p['plan_id']}")
    A(f"    candidate     : {p['candidate']['id']} "
      f"(kind={p['candidate']['kind']}, status="
      f"{p['candidate']['status']}, tier={p['candidate']['tier']})")
    dc = p["disease_context"]
    dname = dc["disease_name"] or "(none - structure-only candidate)"
    dkey = dc["disease_key"] or "-"
    A(f"    disease       : {dname} [{dkey}] "
      f"specificity={dc['specificity']}")
    A(f"    mechanism     : ({p['mechanism_narrative']['tier']}) "
      + p["mechanism_narrative"]["text"][:110])
    te = p["target_engagement"]
    A(f"    engagement    : ({te['tier']}) target={te['primary_target']}"
      f" direction={te['direction']}")
    A(f"                    assay: {te['assay_class'][:100]}")
    A(f"    evidence      : support={len(p['supporting_evidence'])} rows,"
      f" contradiction={len(p['contradictory_evidence'])} rows")
    ds = p["datasets"]
    A(f"    datasets      : CT.gov={len(ds['ct_accessions'])} "
      f"GEO={len(ds['geo_accessions'])} "
      f"(specificity={ds['specificity']})")
    if ds["absence_note"]:
        A(f"                    absence: {ds['absence_note'][:100]}")
    A(f"    gates         : {_fmt_gate_row(p)}")
    tr = p["required_evidence_to_change_status"]
    A(f"    P7-3 status   : {tr['from']} -> {tr['to']} "
      f"(evidence classes listed; never by computation)")


def main() -> int:
    bench = run_module_f()
    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(OUT, "phase7_benchmark.json"), "w",
              encoding="utf-8") as fh:
        json.dump(bench, fh, indent=1, sort_keys=True)

    lines = []
    A = lines.append
    A("APEIRON-X v15 - PHASE 7 EXPERIMENTAL VALIDATION (MODULE F) - "
      "ACCEPTANCE REPORT")
    A("=" * 70)
    A("module: " + bench["module"] +
      "   schema: " + bench["schema_version"] +
      "   label: " + bench["plan_label"])
    r = bench["registry"]
    A(f"P7-2 frozen registry: {r['studies']} CT.gov studies / "
      f"{r['series']} GEO series; {r['sources']} provenance records; "
      f"{r['absences']} absences recorded (never guessed)")
    A(f"registry sha256 (pinned): {r['pin_sha256'][:32]}…")
    A(f"plans built: {bench['plan_count']} "
      f"(EVIDENCED+ plans: {bench['evidenced_plan_count']}); "
      f"HUMAN-gate REGISTRY_ACTIVITY_PRESENT states: "
      f"{bench['gate_registry_states']} (metadata only)")
    A("")
    A("THEOREMS (PROVEN_MATH, standard shape)")
    A("-" * 70)
    for key in sorted(bench["theorems"]):
        t = bench["theorems"][key]
        A(f"[{'PROVED' if t['proved'] else 'UNPROVED'}] {t['theorem']}")
        for s in t["proof_steps"]:
            A(f"       step: {s}")
        A(f"       stats: " + json.dumps(t["stats"], sort_keys=True)[:230])
    A("")
    A("PLAN TABLE (all candidates; one row per drug x disease pair, "
      "then generated molecules)")
    A("-" * 70)
    for p in bench["plans"]:
        if p["candidate"]["kind"] == "GENERATED_MOLECULE":
            continue
        cand = p["candidate"]
        ds = p["datasets"]
        A(f"{p['plan_id']:<28} {cand['status']:<24} tier={cand['tier']:<14}"
          f" rank={cand.get('rank') or '-':>3} "
          f"CT={len(ds['ct_accessions']):>2} GEO={len(ds['geo_accessions'])}"
          f"  gates[HUMAN]={next(g['state'] for g in p['stage_gates'] if g['gate']=='HUMAN')[:8]}")
    A("")
    A("GENERATED-MOLECULE PLANS (structural absence lane)")
    A("-" * 70)
    for p in bench["plans"]:
        if p["candidate"]["kind"] != "GENERATED_MOLECULE":
            continue
        A(f"{p['plan_id']:<14} laws={','.join(p['candidate']['laws_satisfied'])[:60]}"
          f"  datasets: none (recorded absence)")
    A("")
    A("EXAMPLE PLAN (complete rendering)")
    A("-" * 70)
    example = next((p for p in bench["plans"]
                    if p["plan_id"] == "PLAN:DAPAGLIFLOZIN@CKD"),
                   bench["plans"][0])
    block = []
    _one_plan_block(example, block)
    lines.extend(block)
    example2 = next((p for p in bench["plans"]
                     if p["candidate"]["kind"] == "GENERATED_MOLECULE"),
                    None)
    if example2:
        A("")
        block2 = []
        _one_plan_block(example2, block2)
        lines.extend(block2)
    A("")
    A("HONEST LIMITS")
    A("-" * 70)
    A("- this lane carries registry METADATA only: no result, effect "
      "size or outcome measure exists anywhere in the P7 pack or plans")
    A("- HFREF/HFPEF dataset links are CONDITION_LEVEL_ONLY (registry "
      "metadata cannot separate EF strata)")
    A("- assay/model/endpoint content is an authored rule table applied "
      "transparently (COMPUTATIONAL tier): a proposal to test, never a "
      "measurement or a claim")
    A("- REGISTRY_ACTIVITY_PRESENT gate states mean 'trials exist', "
      "never 'efficacy shown'")
    A("- generated molecules (APXD-*) have no registry records by "
      "construction; their plans record the structural absence")
    verdict = "ALL THEOREMS PROVED" if bench["all_proved"] else \
        "REGRESSION FAILED — engine refuses to certify"
    A("")
    A("VERDICT: " + verdict)

    with open(os.path.join(OUT, "phase7_benchmark.txt"), "w",
              encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    print(f"[write] {os.path.join(OUT, 'phase7_benchmark.json')}")
    print(f"[write] {os.path.join(OUT, 'phase7_benchmark.txt')}")
    print("[write] VERDICT: " + verdict)
    return 0 if bench["all_proved"] else 1


if __name__ == "__main__":
    sys.exit(main())
