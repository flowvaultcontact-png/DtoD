#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 6 acceptance artifacts writer.

Runs Module E (mathematical reasoning extensions) and writes the
machine certificate + the human-readable report:

    v15/out/phase6_benchmark.json   — machine-checkable artifact
    v15/out/phase6_benchmark.txt    — readable tables + theorems

Fully offline: consumes the frozen P8 knowledge-graph section (sha256-
pinned), the frozen v14.1 corpus (read-only) and the pinned RDKit.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # apeiron/ repo root
sys.path.insert(0, ROOT)

from v15.kgraph import run_module_e             # noqa: E402

OUT = os.path.join(ROOT, "v15", "out")


def main() -> int:
    bench = run_module_e()
    os.makedirs(OUT, exist_ok=True)

    with open(os.path.join(OUT, "phase6_benchmark.json"), "w",
              encoding="utf-8") as fh:
        json.dump(bench, fh, indent=1, sort_keys=True)

    lines = []
    A = lines.append
    A("APEIRON-X v15 - PHASE 6 MATHEMATICAL REASONING (MODULE E) - "
      "ACCEPTANCE REPORT")
    A("=" * 70)
    A("module: " + bench["module"] +
      "   schema: " + bench["kg_schema_version"] +
      "   RDKit: " + bench["rdkit_version"] +
      " (pin " + bench["rdkit_pin"] + ")")
    g = bench["graph"]
    A(f"P8 knowledge graph: {g['edges']} edges / {g['nodes']} nodes; "
      f"{g['absences_recorded']} absences recorded (never guessed)")
    A("relations: " + "  ".join(
        f"{r}={n}" for r, n in sorted(g["by_relation"].items())))
    A(f"chains enumerated: {g['chains_enumerated']}")
    A("")
    A("THEOREMS (PROVEN_MATH, standard shape)")
    A("-" * 70)
    for key in sorted(bench["theorems"]):
        t = bench["theorems"][key]
        A(f"[{'PROVED' if t['proved'] else 'UNPROVED'}] {t['theorem']}")
        for s in t["proof_steps"]:
            A(f"       step: {s}")
        A(f"       stats: " + json.dumps(
            {k: v for k, v in t["stats"].items()
             if k not in ("opposing", "opposing_pairs_exposed")},
            sort_keys=True)[:220])
    A("")
    A("RANKING DEMONSTRATION (aggregate label: " + bench["rankings_label"]
      + " — a rank hint, never a probability)")
    A("-" * 70)
    for did in sorted(bench["rankings"]):
        r = bench["rankings"][did]
        if not r["found"]:
            continue
        A(f"{did}: " + ", ".join(
            f"{row['drug']} [{'+'.join(row['mechanism_classes'])}] "
            f"chains={row['chain_count']} tier={row['chain_tier']}"
            for row in r["ranking"][:4]))
    A("")
    A("HONEST LIMITS")
    A("-" * 70)
    A("- graph coverage: the disease/gene lane covers the 10 panel "
      "diseases with machine-verified rows; the other 58 corpus "
      "diseases have NO disease->gene edges yet (absent, not guessed)")
    A("- protein->pathway: only proteins with a frozen UniProt entry "
      "payload carry Reactome edges (absences recorded per protein)")
    A("- structure->property edges are " + "PREDICTED_RULEBASED"
      + " triage values (rule layer), never measurements")
    A("- rankings are evidence-support hints over frozen edges; they "
      "claim no efficacy, no binding, no clinical validity")
    verdict = "ALL THEOREMS PROVED" if bench["all_proved"] else \
        "REGRESSION FAILED — engine refuses to certify"
    A("")
    A("VERDICT: " + verdict)

    with open(os.path.join(OUT, "phase6_benchmark.txt"), "w",
              encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n")

    print(f"[write] {os.path.join(OUT, 'phase6_benchmark.json')}")
    print(f"[write] {os.path.join(OUT, 'phase6_benchmark.txt')}")
    print("[write] VERDICT: " + verdict)
    return 0 if bench["all_proved"] else 1


if __name__ == "__main__":
    sys.exit(main())
