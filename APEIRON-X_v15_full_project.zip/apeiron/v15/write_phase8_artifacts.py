#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 8 acceptance artifacts writer.

Runs the P8-1..P8-4 acceptance program and writes the machine
certificate + the human-readable report + the research dashboard:

    v15/out/phase8_benchmark.json  — machine-checkable artifact
    v15/out/phase8_benchmark.txt   — readable summaries + theorems
    v15/out/dashboard.html         — static research dashboard (P8-2)

Fully offline: consumes the frozen v14.1 KB, the pin-checked v15 packs
(Modules A-F) and the frozen Phase 5 artifact. No network access; the
API layer is exercised through its in-process dispatcher.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                    # apeiron/ repo root
sys.path.insert(0, ROOT)

from v15.discover import (                      # noqa: E402
    discover, DISCOVER_SCHEMA_VERSION, REPORT_SECTIONS, WORKFLOW_STEPS,
    theorem_report_schema_completeness, theorem_report_determinism,
    theorem_report_absence_discipline, theorem_report_leakage_control,
    theorem_report_claim_tier_discipline, theorem_report_out_of_domain,
    sha256_of_report, _short_report_text,
)
from v15.limitation_report import build_limitation_report  # noqa: E402
from v15.dashboard import build_dashboard_html             # noqa: E402

OUT = os.path.join(ROOT, "v15", "out")

# (label, spec, as_of)
PROBES = [
    ("D02_hfref", {"did": "D02"}, None),
    ("D08_t2dm_by_name", {"name": "type 2 diabetes mellitus"}, None),
    ("D61_hfpef_by_name", {"name": "heart failure with preserved "
                           "ejection fraction"}, None),
    ("D05_hypercholesterolemia", {"did": "D05"}, None),
    ("CF_panel_non_kb", {"did": "CF"}, None),
    ("D02_hfref_as2015", {"did": "D02"}, 2015),
    ("OOD_probe_z_syndrome", {"name": "Acute Z-syndrome (OOD probe)",
                              "genetic_profile": ["ZZZ1 gain-of-function"]},
     None),
]


def main() -> int:
    print("[Phase 8] building probe reports ...")
    reports, texts = {}, {}
    for label, spec, as_of in PROBES:
        rep = discover(spec, as_of_year=as_of, verbose=False)
        reports[label] = rep
        texts[label] = _short_report_text(rep)
        print(f"  {label:<24} sha={rep['S01_report_header'][
            'canonical_sha256'][:16]}… sections={len(rep)}")

    print("[Phase 8] running report theorems ...")
    theorems = {
        "R1_report_schema_completeness":
            theorem_report_schema_completeness(reports),
        "R2_report_determinism": theorem_report_determinism(
            _rebuild, ["D02_hfref", "D61_hfpef_by_name", "OOD_probe_"
                       "z_syndrome"]),
        "R3_report_absence_discipline":
            theorem_report_absence_discipline(reports),
        "R4_report_leakage_control": theorem_report_leakage_control(
            reports),
        "R5_report_claim_tier_discipline":
            theorem_report_claim_tier_discipline(reports),
        "R6_report_out_of_domain": theorem_report_out_of_domain(reports),
    }
    for name, th in theorems.items():
        print(f"  {name:<38} proved={th['proved']} "
              f"stats={json.dumps(th['stats'])[:70]}")

    print("[Phase 8] API self-test (in-process dispatcher) ...")
    api_summary = _api_selftest()

    print("[Phase 8] limitation report (P8-4) ...")
    limits = build_limitation_report()

    print("[Phase 8] dashboard (P8-2) ...")
    dash_html = build_dashboard_html()
    with open(os.path.join(OUT, "dashboard.html"), "w",
              encoding="utf-8") as fh:
        fh.write(dash_html)

    bench = {
        "benchmark": "Phase 8 full-integration acceptance (plan §9)",
        "module": "P8-1..P8-4 — end-to-end pipeline, versioned read-only "
                  "API, module test suites, honest-limitation generator",
        "discover_schema_version": DISCOVER_SCHEMA_VERSION,
        "report_sections": list(REPORT_SECTIONS),
        "workflow_steps": list(WORKFLOW_STEPS),
        "probes": [{"label": lbl, "spec": spec, "as_of": as_of}
                   for lbl, spec, as_of in PROBES],
        "reports": {lbl: {"canonical_sha256":
                          rep["S01_report_header"]["canonical_sha256"],
                          "sections": len(rep),
                          "workflow_status": rep["S18_reproducibility_"
                                                  "and_non_goals"]
                          ["workflow_steps_status"],
                          "fusion_rows": rep["S13_evidence_weighted_"
                                             "ranking"]["row_count"],
                          "in_domain": rep["S05_encodability_verdict"]
                          ["in_domain"],
                          "absence_codes": sorted({
                              a["code"] for sec in rep.values()
                              if isinstance(sec, dict)
                              for a in (sec.get("absences") or [])})}
                    for lbl, rep in reports.items()},
        "theorems": theorems,
        "theorems_all_proved": all(t["proved"]
                                   for t in theorems.values()),
        "api_selftest": api_summary,
        "limitation_report": limits,
        "dashboard_bytes": len(dash_html),
        "honest_limits": [
            "discover reports serve FROZEN module content only; the "
            "novel-molecule lane is the frozen Phase 5 artifact (sha256 "
            "recorded per report), not a live generation run",
            "lane coverage is exactly the frozen coverage: targets for "
            "the 10-disease panel, repurposing for the cardio-renal "
            "prediction panel, plans for panel diseases + APXD "
            "molecules; everything else is an explicit absence",
            "the API is read-only and hermetic: GET-only routes, no "
            "connector imports, no outbound network; the live-server "
            "test binds 127.0.0.1 on an ephemeral port only",
            "fusion tier = strongest lane evidence (JOIN); every fused "
            "row is labelled COMPUTATIONAL_RANK, never a probability",
            "as_of views prune by the Phase 4 pack first-approval years "
            "where coverage exists; drugs outside the pack are recorded "
            "as approval-year UNKNOWN, never guessed",
            "the dashboard is a static deterministic HTML view; it "
            "computes nothing novel and carries no JavaScript",
        ],
    }

    with open(os.path.join(OUT, "phase8_benchmark.json"), "w",
              encoding="utf-8") as fh:
        json.dump(bench, fh, indent=2, sort_keys=True)
    with open(os.path.join(OUT, "phase8_benchmark.txt"), "w",
              encoding="utf-8") as fh:
        _write_txt(fh, bench, texts)

    n = sum(1 for t in theorems.values() if t["proved"])
    verdict = ("ALL THEOREMS PROVED" if bench["theorems_all_proved"]
               else "THEOREM FAILURES PRESENT")
    print(f"\nVERDICT: {verdict} ({n}/{len(theorems)})")
    print(f"artifacts written: phase8_benchmark.json, phase8_benchmark.txt, "
          f"dashboard.html")
    return 0 if bench["theorems_all_proved"] else 1


def _rebuild(label):
    for lbl, spec, as_of in PROBES:
        if lbl == label:
            return discover(spec, as_of_year=as_of, verbose=False)
    raise KeyError(label)


def _api_selftest() -> dict:
    from v15.api import dispatch, ROUTES, API_VERSION, API_SCHEMA_VERSION
    results, ok_all = [], True
    probes = [
        ("api/v1/health", 200),
        ("api/v1/schemas", 200),
        ("api/v1/diseases", 200),
        ("api/v1/diseases/D02", 200),
        ("api/v1/diseases/D02/targets", 200),
        ("api/v1/diseases/D61/repurposing", 200),
        ("api/v1/diseases/D02/discover", 200),
        ("api/v1/molecules", 200),
        ("api/v1/validation-plans", 200),
        ("api/v1/theorems", 200),
        ("api/v1/limits", 200),
        ("api/v1/diseases/D99", 404),
        ("api/v1/diseases/D01/repurposing", 404),
        ("api/v1/nope", 404),
    ]
    for path, want in probes:
        st, payload = dispatch("/" + path, {}, "GET")
        ok = st == want
        ok_all &= ok
        results.append({"route": path, "status": st, "expected": want,
                        "ok": ok})
    for m in ("POST", "PUT", "DELETE", "PATCH"):
        st, payload = dispatch("/api/v1/health", {}, m)
        ok = st == 405 and payload["error"]["code"] == "READ_ONLY_API"
        ok_all &= ok
        results.append({"route": f"{m} /api/v1/health", "status": st,
                        "expected": 405, "ok": ok})
    st, a = dispatch("/api/v1/diseases/D02/discover", {}, "GET")
    st, b = dispatch("/api/v1/diseases/D02/discover", {}, "GET")
    memo_ok = a == b
    ok_all &= memo_ok
    results.append({"route": "memo determinism (D02 discover x2)",
                    "status": 200, "expected": 200, "ok": memo_ok})
    return {"api_version": API_VERSION,
            "api_schema_version": API_SCHEMA_VERSION,
            "routes_registered": [r[0] for r in ROUTES],
            "checks": results,
            "all_ok": ok_all}


def _write_txt(fh, bench, texts) -> None:
    L = []

    def A(s):
        L.append(s)
    A("APEIRON-X v15 — PHASE 8 ACCEPTANCE (FULL INTEGRATION)")
    A("=" * 74)
    A(f"discover schema : {bench['discover_schema_version']}")
    A(f"report sections : {len(bench['report_sections'])}  "
      f"workflow steps: {len(bench['workflow_steps'])}")
    A(f"probes          : {len(bench['probes'])}")
    A("")
    A("report theorems (standard shape, all PROVEN_MATH when proved)")
    A("-" * 74)
    for name, th in bench["theorems"].items():
        A(f"  {name:<40} proved={th['proved']}")
        for k, v in th["stats"].items():
            if isinstance(v, (int, float, str, bool)):
                A(f"      {k}: {v}")
    A("")
    A("API self-test (in-process dispatcher)")
    A("-" * 74)
    api = bench["api_selftest"]
    for c in api["checks"]:
        A(f"  [{'OK ' if c['ok'] else 'FAIL'}] {c['route']:<44} "
          f"status={c['status']}")
    A(f"  routes registered: {len(api['routes_registered'])}; "
      f"all_ok={api['all_ok']}")
    A("")
    A("probe report summaries")
    A("-" * 74)
    for label, text in texts.items():
        A(f"\n----- {label} " + "-" * (60 - len(label)))
        L.extend(text.splitlines())
    A("")
    A("honest limits (P8)")
    A("-" * 74)
    for lim in bench["honest_limits"]:
        A(f"  - {lim}")
    A("")
    verdict = ("ALL THEOREMS PROVED" if bench["theorems_all_proved"]
               else "FAILURES PRESENT")
    A(f"VERDICT: {verdict}")
    A("reproduce:")
    A("  python3 v15/write_phase8_artifacts.py")
    A("  python3 v15/tests/test_v15_phase8.py")
    A("  python3 v15/run_full_regression.py")
    fh.write("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
