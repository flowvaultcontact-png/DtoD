"""Module E — mathematical reasoning extensions (Phase 6, plan §7).

P6-1  The typed knowledge graph over the frozen P8 postulate section
      (`v15/kgraph_data.py`, sha256-pinned). The 7 formal relations are
      layered DAG edges: disease->gene, gene->protein, protein->pathway,
      target->mechanism, mechanism->drug, drug->structure,
      structure->property. Every edge carries an evidence tier
      (PROVEN_MATH > EVIDENCED > COMPUTATIONAL > HYPOTHESIS > UNKNOWN,
      the v15 claim lattice) and resolvable source ids. The build gate
      REFUSES edges violating the layer order, unknown relations,
      unknown tiers, or EVIDENCED edges without sources — a cycle is
      structurally impossible in a built graph.

P6-2  The eight new proof obligations, each a `theorem_*` with the
      standard APEIRON-X shape (statement / proved / tier /
      counterexamples / stats / proof_steps):
        theorem_graph_consistency            no contradictory cycles
        theorem_disease_identity_uniqueness  normalized identity is a
                                             function; phi injective
        theorem_contradiction_detection      opposing mechanisms exposed
        theorem_evidence_provenance_completeness
                                             no uncited EVIDENCED edge
        theorem_rank_integrity               ranks invariant under row
                                             permutation
        theorem_tier_propagation             chain tier = lattice meet
        theorem_out_of_domain_detection      UNPROVEN doctrine extends to
                                             v15 profiles
        theorem_bit_for_bit_reproducibility  re-derivation byte-identical
                                             (extends C1/C8)

P6-3  theorem_fingerprint_portability (audit R4): the pinned RDKit line
      re-verifies the frozen identity laws on fresh fingerprints.

Doctrine: v14.1 engines are imported READ-ONLY; the v14.1 axiom corpus
is untouched (P8 is additive); nothing is fabricated — absent data is
reported as absent; no claim ever migrates tiers by computation.
"""

import json
import os
import random
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                     # apeiron/ repo root
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

KGRAPH_DATA_PATH = os.path.abspath(os.path.join(HERE, "kgraph_data.py"))
KGRAPH_PIN_PATH = os.path.join(HERE, "kb_extensions", "kgraph_pins.json")
GENERATOR_PATH = os.path.join(os.path.dirname(ROOT), "scripts",
                              "gen_phase6_pack.py")
REQUIREMENTS_PATH = os.path.join(ROOT, "requirements.txt")

KG_SCHEMA_VERSION = "15.6.0"
STATUS_FLAG = "COMPUTATIONAL_RANK"               # rank label, never a probability

# ---------------------------------------------------------------- tiers
# The v15 claim lattice (weakest-order list; meet = min index).
TIER_LADDER = ("PROVEN_MATH", "EVIDENCED", "COMPUTATIONAL", "HYPOTHESIS",
               "UNKNOWN")


def tier_meet(a: str, b: str) -> str:
    """Lattice meet: the weaker of two tiers (chain propagation rule)."""
    if a not in TIER_LADDER or b not in TIER_LADDER:
        raise ValueError(f"unknown tier in ({a!r}, {b!r})")
    return a if TIER_LADDER.index(a) >= TIER_LADDER.index(b) else b


def sha256_of(path: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def pinned_rdkit_version() -> str:
    """Parse the requirements.txt pin (audit R4)."""
    with open(REQUIREMENTS_PATH, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("rdkit=="):
                return line.split("==", 1)[1]
    raise RuntimeError("no rdkit pin found in requirements.txt")


# ---------------------------------------------------------------- loader
def load_kgraph(verify_pin: bool = True):
    """Load the frozen P8 section under the pin discipline. Refuses to
    serve data on a sha256 mismatch (same doctrine as
    v15.targets.load_targets / v15.repurposing.load_pack)."""
    if verify_pin:
        if not os.path.exists(KGRAPH_PIN_PATH):
            raise RuntimeError(
                f"kgraph pin file missing: {KGRAPH_PIN_PATH}. Run "
                "python3 v15/kb_extensions/freeze_kgraph.py")
        with open(KGRAPH_PIN_PATH, encoding="utf-8") as fh:
            pins = json.load(fh)
        digest = sha256_of(KGRAPH_DATA_PATH)
        if pins.get("kgraph_data_sha256") != digest:
            raise RuntimeError(
                "kgraph_data.py sha256 mismatch with "
                "kb_extensions/kgraph_pins.json — refuse to serve "
                "(frozen-table doctrine)")
    with open(KGRAPH_DATA_PATH, encoding="utf-8") as fh:
        src = fh.read()
    ns = {}
    exec(compile(src, KGRAPH_DATA_PATH, "exec"), ns)   # noqa: S102 — frozen file
    return ns


# ---------------------------------------------------------------- graph
REL_LAYER_MAP = {
    "disease->gene": ("disease", "gene"),
    "gene->protein": ("gene", "protein"),
    "protein->pathway": ("protein", "pathway"),
    "target->mechanism": ("gene", "mechanism"),   # target nodes on gene layer
    "mechanism->drug": ("mechanism", "drug"),
    "drug->structure": ("drug", "structure"),
    "structure->property": ("structure", "property"),
}


class KnowledgeGraph:
    """Typed layered graph over the frozen P8 edges, with a BUILD GATE:
    any edge that violates the relation/layer/tier/source discipline
    makes construction raise (loudly), so a contradictory graph cannot
    exist as an object of this class."""

    def __init__(self, edges, source_records, layers, meta=None):
        self.meta = meta or {}
        self.source_records = dict(source_records)
        self.layers = dict(layers)
        self.edges = []
        self.node_layer = {}
        self.adj = {}
        self._by_rel = {}
        violations = []
        for i, e in enumerate(edges):
            try:
                self._admit(e)
            except ValueError as exc:
                violations.append((i, str(exc)))
        if violations:
            raise ValueError(
                "knowledge-graph build gate refused %d edge(s): %s"
                % (len(violations), violations[:3]))
        self.stats = {"edges": len(self.edges),
                      "nodes": len(self.node_layer)}

    @classmethod
    def from_frozen(cls, verify_pin: bool = True) -> "KnowledgeGraph":
        ns = load_kgraph(verify_pin)
        return cls(ns["P8_EDGES"], ns["SOURCE_RECORDS_P8"],
                   ns["NODE_LAYERS"],
                   meta={"schema": ns["KG_SCHEMA_VERSION"],
                         "frozen_utc": ns["FROZEN_UTC"],
                         "absences": ns["P8_ABSENCES"],
                         "input_pins": ns["INPUT_PINS"],
                         "stats": ns["P8_STATS"],
                         "ns": ns})

    def _admit(self, e) -> None:
        rel, src, dst = e.get("rel"), e.get("src"), e.get("dst")
        tier = e.get("tier")
        sources = e.get("sources")
        if rel not in REL_LAYER_MAP:
            raise ValueError(f"unknown relation {rel!r}")
        if tier not in TIER_LADDER:
            raise ValueError(f"unknown tier {tier!r}")
        if tier == "EVIDENCED" and not sources:
            raise ValueError(f"EVIDENCED edge without sources: {e!r}")
        if not src or not dst or src == dst:
            raise ValueError(f"degenerate edge {e!r}")
        ka, kb = REL_LAYER_MAP[rel]
        la, lb = self.layers[ka], self.layers[kb]
        if la >= lb:
            raise ValueError(f"layer-order violation on {rel}")
        for node in (src, dst):
            prev = self.node_layer.get(node)
            if prev is None:
                self.node_layer[node] = la if node == src else lb
            elif prev not in (la, lb) and not (
                    node == src and prev == la) and not (
                    node == dst and prev == lb):
                raise ValueError(
                    f"node {node!r} appears on conflicting layers")
        idx = len(self.edges)
        self.edges.append(e)
        self.adj.setdefault(src, []).append((dst, rel, idx))
        self._by_rel.setdefault(rel, []).append(idx)

    # -- queries ---------------------------------------------------------
    def edges_of(self, rel: str):
        return [self.edges[i] for i in self._by_rel.get(rel, [])]

    def lookup(self, node):
        """Domain lookup: explicit None for absent nodes — the graph
        NEVER invents an entry for an unknown id (out-of-domain rule)."""
        if node in self.node_layer:
            return {"found": True, "layer": self.node_layer[node]}
        return {"found": False, "absence": "NODE_NOT_IN_FROZEN_GRAPH"}

    def chains_from(self, src):
        """All maximal directed chains (layer strictly increasing, so
        acyclic by construction). Returns list of (edge_idx_tuple)."""
        out = []

        def dfs(node, path):
            extended = False
            for dst, _rel, idx in self.adj.get(node, ()):
                if self.node_layer[dst] <= self.node_layer[node]:
                    continue                      # gate makes this dead code
                extended = True
                dfs(dst, path + (idx,))
            if not extended and path:
                out.append(path)

        dfs(src, ())
        return out

    def all_chains(self):
        chains = []
        for node, layer in sorted(self.node_layer.items(),
                                  key=lambda kv: (kv[1], kv[0])):
            if layer == self.layers.get("disease"):
                chains.extend(self.chains_from(node))
        return chains

    def path_tier(self, idx_tuple) -> str:
        t = "PROVEN_MATH"
        for i in idx_tuple:
            t = tier_meet(t, self.edges[i]["tier"])
        return t

    def rank_drugs_for_disease(self, did):
        """Transparent, deterministic ranking of mechanism classes and
        drugs reachable from a disease through the typed graph. The
        aggregate is explicitly labelled COMPUTATIONAL_RANK — a rank
        hint derived from frozen evidence, NEVER a probability and
        NEVER a prediction of efficacy."""
        if did not in self.node_layer or \
                self.node_layer[did] != self.layers.get("disease"):
            return {"disease": did, "found": False,
                    "absence": "DISEASE_NODE_NOT_IN_FROZEN_GRAPH",
                    "rank_label": STATUS_FLAG, "ranking": []}
        gene_scores = {}
        for dst, _rel, idx in self.adj.get(did, ()):
            if _rel != "disease->gene":
                continue
            e = self.edges[idx]
            sc = e["attrs"].get("association_score")
            sc = sc if isinstance(sc, (int, float)) else 0.0
            gene_scores[dst] = max(gene_scores.get(dst, 0.0), sc)
        mech_via = {}                            # mech -> {gene: info}
        for gene in gene_scores:
            for dst, rel, idx in self.adj.get(gene, ()):
                if rel == "target->mechanism":
                    mech_via.setdefault(dst, {})[gene] = idx
        rows = []
        for mech, genes in sorted(mech_via.items()):
            drugs = []
            for dst, rel, idx in self.adj.get(mech, ()):
                if rel == "mechanism->drug":
                    drugs.append((dst, idx))
            if not drugs:
                continue
            for drug, didx in sorted(drugs):
                rows.append({
                    "drug": drug,
                    "mechanism_class": mech,
                    "genes": sorted(genes),
                    "chain_count": len(genes),
                    "max_association_score": max(
                        (gene_scores[g] for g in genes), default=0.0),
                    "chain_tier": self.path_tier(
                        tuple(sorted({genes[g] for g in genes} | {didx}))),
                })
        # aggregate per drug (deterministic; transparent axes kept)
        agg = {}
        for r in rows:
            a = agg.setdefault(r["drug"], {
                "drug": r["drug"], "mechanism_classes": [],
                "genes": set(), "chain_count": 0, "max_association_score": 0.0,
                "chain_tier": "PROVEN_MATH"})
            a["mechanism_classes"] = sorted(
                set(a["mechanism_classes"]) | {r["mechanism_class"]})
            a["genes"] |= set(r["genes"])
            a["chain_count"] += r["chain_count"]
            a["max_association_score"] = max(a["max_association_score"],
                                             r["max_association_score"])
            a["chain_tier"] = tier_meet(a["chain_tier"], r["chain_tier"])
        ranking = sorted(agg.values(),
                         key=lambda a: (-a["chain_count"],
                                        -a["max_association_score"],
                                        a["drug"]))
        for a in ranking:
            a["genes"] = sorted(a["genes"])
            a["rank_label"] = STATUS_FLAG
        return {"disease": did, "found": True,
                "rank_label": STATUS_FLAG, "ranking": ranking}


# ---------------------------------------------------------------- shells
def _shell(name, statement, proved, counterexamples, stats, steps):
    return {"theorem": name, "statement": statement,
            "proved": bool(proved), "tier": "PROVEN_MATH" if proved
            else "UNPROVED",
            "counterexamples": counterexamples, "stats": stats,
            "proof_steps": steps}


# ------------------------------------------------------- P6-2 theorems
def theorem_graph_consistency(g: KnowledgeGraph) -> dict:
    """Obligation 1: the frozen graph is a layered DAG — every edge
    strictly increases the layer; a topological order exists; a full
    DFS cycle scan finds 0 cycles; no duplicate edges; every relation
    appears with its canonical layer pair."""
    bad_layers, dupes = [], []
    seen = set()
    for i, e in enumerate(g.edges):
        a, b = e["src"], e["dst"]
        if g.node_layer[a] >= g.node_layer[b]:
            bad_layers.append({"index": i, "edge": f"{a}->{b}"})
        key = (e["rel"], a, b)
        if key in seen:
            dupes.append({"index": i, "edge": key})
        seen.add(key)
    # full cycle scan (defensive: gate already forbids cycles)
    color = {}
    cycles = []

    def dfs(u, stack):
        color[u] = 1
        for v, _r, i in g.adj.get(u, ()):
            if color.get(v) == 1:
                cycles.append(stack + [(u, v, i)])
            elif color.get(v, 0) == 0:
                dfs(v, stack + [(u, v, i)])
        color[u] = 2

    for n in sorted(g.node_layer):
        if color.get(n, 0) == 0:
            dfs(n, [])
    rel_pairs_ok = all(
        any(e["rel"] == r for e in g.edges) for r in REL_LAYER_MAP)
    proved = not bad_layers and not dupes and not cycles
    return _shell(
        "E1 theorem_graph_consistency",
        "the P8 knowledge graph is a layered DAG over the 7 formal "
        "relations: 0 layer-order violations, 0 duplicate edges, 0 "
        "directed cycles in a full DFS scan",
        proved, bad_layers + dupes + cycles[:5],
        {"edges": len(g.edges), "nodes": len(g.node_layer),
         "layer_violations": len(bad_layers), "duplicates": len(dupes),
         "cycles": len(cycles),
         "relations_present": sum(1 for r in REL_LAYER_MAP
                                  if g.edges_of(r))},
        ["build gate: unknown relation/tier, empty EVIDENCED sources, "
         "layer-order violations raise at construction",
         "verify frozen edges: layer(src) < layer(dst) for all",
         "hash-set duplicate scan over (rel, src, dst)",
         "DFS cycle scan over every node (defensive redundancy)"])


def build_identity_map(extra=None) -> dict:
    """Normalized disease identity map from the frozen corpora (read-only).
    Returns {canonical_key: {name, external_id, phi_tuple_or_None}} plus
    the normalization function properties checked by the theorem."""
    post_path = os.path.join(ROOT, "postulates_v14.json")
    with open(post_path, "rb") as fh:
        post = json.loads(fh.read().decode("utf-8"))
    import v15.target_data as td
    ident = {}
    for d in post["diseases"]:
        ident[d["did"]] = {"name": d["name"],
                           "external_id": None,
                           "phi": tuple(d["channels"][c] for c in
                                        ("chronicity", "etiology", "microbe",
                                         "pathway", "site", "system"))}
    panel_ids = {}
    for key, row in td.BENCHMARK_PANEL.items():
        panel_ids[key] = row.get("ot_disease_id")
    for key, row in td.OT_ASSOCIATIONS.items():
        if row.get("efo_id"):
            panel_ids.setdefault(key, row["efo_id"])
    for k in list(ident):
        if k in panel_ids:
            ident[k]["external_id"] = panel_ids[k]
    for k in panel_ids:
        if k not in ident:
            ident[k] = {"name": td.BENCHMARK_PANEL.get(k, {}).get(
                "name", k), "external_id": panel_ids[k], "phi": None}
    if extra:
        for k, v in extra.items():
            if k in ident:
                ident[k]["external_id"] = v
    return ident


def theorem_disease_identity_uniqueness(g: KnowledgeGraph,
                                        tamper=None) -> dict:
    """Obligation 2: the normalized disease identity is a FUNCTION —
    (a) canonical keys are unique; (b) names are unique per key;
    (c) no external id (MONDO/HP) is shared by two distinct canonical
    keys; (d) normalization is idempotent; (e) phi is injective over the
    whole 68-disease corpus (0 collisions — extends T4/T5 to Phase 6);
    (f) every disease node of the graph is a known identity."""
    ident = build_identity_map()
    violations = []
    if tamper:
        ident.update({k: dict(ident.get(k, {"name": k, "phi": None}),
                              external_id=v) for k, v in tamper.items()})
    ids = sorted(ident)
    if len(ids) != len(set(ids)):
        violations.append("duplicate canonical keys")
    names = {}
    for k in ids:
        names.setdefault(ident[k]["name"], []).append(k)
    dup_names = {n: ks for n, ks in names.items() if len(ks) > 1}
    ext = {}
    for k in ids:
        e = ident[k]["external_id"]
        if e:
            ext.setdefault(e, []).append(k)
    ext_conflicts = {e: ks for e, ks in ext.items() if len(ks) > 1}
    # (d) idempotence: normalize maps key -> external id or key; applied
    # twice gives the same value because external ids never appear as keys
    idempotent = all((ident[k]["external_id"] or k) != k or True
                     for k in ids) and not any(
        (ident[k]["external_id"] or k) in ident and
        ident[(ident[k]["external_id"] or k)]["external_id"]
        for k in ids)
    # (e) phi injectivity over the corpus rows that carry channels
    seen_phi = {}
    phi_dupe = []
    for k in ids:
        p = ident[k]["phi"]
        if p is None:
            continue
        if p in seen_phi:
            phi_dupe.append((seen_phi[p], k))
        seen_phi[p] = k
    # (f) graph disease nodes are known identities
    orphans = [n for n, l in g.node_layer.items()
               if l == g.layers.get("disease") and n not in ident]
    proved = (not violations and not dup_names and not ext_conflicts
              and idempotent and not phi_dupe and not orphans)
    return _shell(
        "E2 theorem_disease_identity_uniqueness",
        "normalized disease identity is a function: unique canonical "
        "keys, unique names, no external id shared by two canonical "
        "keys, idempotent normalization, phi injective on the whole "
        "corpus (0 collisions), 0 unknown disease nodes in the graph",
        proved,
        [{"kind": "external_id_conflict", "id": e, "keys": ks}
         for e, ks in ext_conflicts.items()] +
        [{"kind": "duplicate_name", "name": n, "keys": ks}
         for n, ks in dup_names.items()] +
        [{"kind": "phi_collision", "keys": list(p)} for p in phi_dupe] +
        [{"kind": "orphan_disease_node", "node": n} for n in orphans],
        {"diseases": len(ids), "external_ids": len(ext),
         "phi_tuples": len(seen_phi), "graph_disease_nodes":
             sum(1 for n, l in g.node_layer.items()
                 if l == g.layers.get("disease"))},
        ["identity map built from postulates_v14.json + frozen panel ids",
         "uniqueness checks (keys/names/external ids)",
         "phi hash-insert injectivity over corpus rows",
         "graph disease nodes cross-checked against the identity map"])


_OPPOSING = {
    "AGONIST": {"ANTAGONIST", "BLOCKER", "INHIBITOR",
                "NEGATIVE_ALLOSTERIC_MODULATOR"},
    "ANTAGONIST": {"AGONIST", "POSITIVE_ALLOSTERIC_MODULATOR", "OPENER"},
    "BLOCKER": {"AGONIST", "OPENER"},
    "INHIBITOR": {"AGONIST", "INDUCER", "OPENER"},
    "OPEN_CHANNEL_BLOCKER": {"OPENER"},
    "OPENER": {"BLOCKER", "OPEN_CHANNEL_BLOCKER", "INHIBITOR",
               "ANTAGONIST"},
    "POSITIVE_ALLOSTERIC_MODULATOR": {"ANTAGONIST",
                                      "NEGATIVE_ALLOSTERIC_MODULATOR"},
    "NEGATIVE_ALLOSTERIC_MODULATOR": {"AGONIST",
                                      "POSITIVE_ALLOSTERIC_MODULATOR"},
}


def scan_opposing_actions(edges):
    """Pure detector: per gene, collect target->mechanism actions and
    report opposing action pairs with their citations (0 hidden)."""
    per_gene = {}
    for e in edges:
        if e["rel"] == "target->mechanism":
            act = e["attrs"].get("action_type")
            if act:
                per_gene.setdefault(e["src"], []).append(
                    (act, e["dst"],
                     tuple(e["attrs"].get("via_drugs") or ())))
    found = []
    for gene in sorted(per_gene):
        acts = sorted(per_gene[gene])
        for i in range(len(acts)):
            for j in range(i + 1, len(acts)):
                a1, m1, d1 = acts[i]
                a2, m2, d2 = acts[j]
                if a1 != a2 and (a2 in _OPPOSING.get(a1, ()) or
                                 a1 in _OPPOSING.get(a2, ())):
                    found.append({
                        "gene": gene, "action_1": a1, "class_1": m1,
                        "drugs_1": list(d1), "action_2": a2,
                        "class_2": m2, "drugs_2": list(d2),
                        "flag": "OPPOSING_ACTION_PAIR_EXPOSED"})
    return found


def theorem_contradiction_detection(g: KnowledgeGraph,
                                    injected=None) -> dict:
    """Obligation 3: opposing mechanisms are EXPOSED, never silently
    merged; the non-molecular remainder is CONSISTENT — every member of
    an excluded (structure-layer-exempt) class carries no molecular
    structure edge, and no excluded-class drug can masquerade as a
    molecular candidate; the detector reports every opposing action
    pair present (and any injected synthetic pair — 0 false negatives)."""
    edges = list(g.edges)
    if injected:
        edges.extend(injected)
    opposing = scan_opposing_actions(edges)
    injected_flagged = True
    if injected:
        opposing_genes = {p["gene"] for p in opposing}
        opposing_drugs = {d for p in opposing
                          for d in (p["drugs_1"] + p["drugs_2"])}
        injected_flagged = all(
            inj["src"] in opposing_genes
            or any(d in opposing_drugs
                   for d in (inj["attrs"].get("via_drugs") or []))
            for inj in injected)
    post_path = os.path.join(ROOT, "postulates_v14.json")
    with open(post_path, "rb") as fh:
        post = json.loads(fh.read().decode("utf-8"))
    excluded = set(post["excluded_classes"])
    # (a) excluded-class members are non-molecular: no drug->structure
    molecular = {e["src"] for e in g.edges_of("drug->structure")}
    viol_members = []
    for e in g.edges_of("mechanism->drug"):
        if e["src"] in excluded and e["dst"] in molecular:
            viol_members.append(e)
    # (b) diseases whose guideline class is structure-layer-exempt are
    # the DOCUMENTED non-molecular remainder (e.g. insulin analogs for
    # T1DM): surfaced here, consistent iff no member is molecular
    remainder = []
    for did, classes in post["mech_required"].items():
        hit = excluded & set(classes)
        if hit:
            remainder.append({"did": did, "excluded": sorted(hit)})
    proved = (not viol_members
              and (not injected or injected_flagged))
    return _shell(
        "E3 theorem_contradiction_detection",
        "opposing pharmacology is machine-exposed (0 hidden), the "
        "non-molecular remainder is consistent (excluded classes carry "
        "no molecular member), and injected opposing pairs are always "
        "detected",
        proved,
        [{"kind": "excluded_member_is_molecular", "edge": e}
         for e in viol_members],
        {"opposing_pairs_exposed": len(opposing),
         "excluded_classes": len(excluded),
         "excluded_member_violations": len(viol_members),
         "non_molecular_remainder_rows": len(remainder),
         "injection_detected": injected_flagged if injected else None,
         "opposing": opposing[:8]},
        ["per-gene action sets from target->mechanism edges",
         "opposition check against the declared OPPOSING lattice",
         "excluded-class members cross-checked against drug->structure",
         "injection lane proves 0 false negatives"])


def theorem_evidence_provenance_completeness(g: KnowledgeGraph,
                                             uncited=None) -> dict:
    """Obligation 4: every EVIDENCED edge cites >=1 source id that
    resolves in the frozen record table; every COMPUTATIONAL edge cites
    the registered rule-based generator record; alias records carry a
    non-empty alias_of. Uncited edges cannot exist (build gate), and an
    injected uncited edge is flagged (0 false negatives)."""
    bad = []
    for i, e in enumerate(g.edges):
        if not e["sources"]:
            bad.append({"index": i, "kind": "NO_SOURCES"})
        for sid in e["sources"]:
            rec = g.source_records.get(sid)
            if rec is None:
                bad.append({"index": i, "kind": "UNRESOLVABLE_SOURCE",
                            "source": sid})
            elif "alias_of" in rec and not rec.get("alias_of"):
                bad.append({"index": i, "kind": "EMPTY_ALIAS",
                            "source": sid})
        if e["tier"] == "COMPUTATIONAL" and \
                "GEN:P6_RULEBASED_PROPS" not in e["sources"]:
            bad.append({"index": i, "kind": "COMPUTATIONAL_WITHOUT_GENERATOR"})
    injected_bad = 0
    if uncited:
        fake = dict(uncited)
        try:
            KnowledgeGraph([fake], g.source_records, g.layers)
        except ValueError:
            injected_bad = 1
    proved = not bad and (uncited is None or injected_bad == 1)
    return _shell(
        "E4 theorem_evidence_provenance_completeness",
        "no uncited edge participates anywhere: every EVIDENCED edge "
        "cites resolvable records, every COMPUTATIONAL edge cites the "
        "registered rule-based generator, and the build gate rejects "
        "source-less EVIDENCED edges (injection detected)",
        proved,
        bad[:10],
        {"edges": len(g.edges), "evidenced":
            sum(1 for e in g.edges if e["tier"] == "EVIDENCED"),
         "computational":
            sum(1 for e in g.edges if e["tier"] == "COMPUTATIONAL"),
         "source_records": len(g.source_records),
         "violations": len(bad),
         "injection_detected": bool(injected_bad)},
        ["per-edge source scan against SOURCE_RECORDS_P8",
         "alias records must carry a non-empty alias_of",
         "COMPUTATIONAL edges must cite GEN:P6_RULEBASED_PROPS",
         "build-gate injection lane (negative control)"])


def theorem_rank_integrity(g: KnowledgeGraph, seeds=(11, 22, 33, 44, 55)) -> dict:
    """Obligation 5: the KG ranking is invariant under permuting the
    frozen edge-row order — re-building the graph from any permutation
    yields byte-identical ranking tables (extends the phase-3/5 rank
    determinism doctrine to Module E)."""
    ns = g.meta.get("ns") or {}
    edges = ns.get("P8_EDGES") or g.edges
    records = g.source_records
    layers = g.layers
    diseases = sorted({e["src"] for e in edges
                       if e["rel"] == "disease->gene"})
    base = {d: g.rank_drugs_for_disease(d) for d in diseases}
    disagrees = []
    for seed in seeds:
        perm = list(edges)
        random.Random(seed).shuffle(perm)
        g2 = KnowledgeGraph(perm, records, layers)
        for d in diseases:
            if g2.rank_drugs_for_disease(d) != base[d]:
                disagrees.append({"seed": seed, "disease": d})
    proved = not disagrees
    return _shell(
        "E5 theorem_rank_integrity",
        "rank order is invariant under permuting the input edge rows: "
        "%d diseases x %d permutation rebuilds, 0 disagreements; "
        "aggregates are labelled COMPUTATIONAL_RANK, never probabilities"
        % (len(diseases), len(seeds)),
        proved, disagrees[:5],
        {"diseases": len(diseases), "seeds": len(seeds),
         "rebuild_checks": len(diseases) * len(seeds),
         "disagreements": len(disagrees),
         "ranked_diseases": sum(1 for r in base.values() if r["found"])},
        ["base ranking over the frozen row order",
         "%d deterministic permutations (random.Random(seed))" % len(seeds),
         "graph rebuilt from each permutation; tables compared exactly"])


def theorem_tier_propagation(g: KnowledgeGraph) -> dict:
    """Obligation 6: chain tier = lattice meet of the edge tiers; the
    meet obeys the lattice laws on every pair; an independent min()-
    based recomputation agrees on EVERY chain; no chain ever propagates
    a tier stronger than its weakest edge."""
    laws_fail = []
    for a in TIER_LADDER:
        if tier_meet(a, a) != a:
            laws_fail.append(("idempotence", a))
        if tier_meet(a, "PROVEN_MATH") != a:
            laws_fail.append(("absorption", a))
        for b in TIER_LADDER:
            if tier_meet(a, b) != tier_meet(b, a):
                laws_fail.append(("commutativity", a, b))
    assoc_fail = []
    for a in TIER_LADDER:
        for b in TIER_LADDER:
            for c in TIER_LADDER:
                if tier_meet(tier_meet(a, b), c) != \
                        tier_meet(a, tier_meet(b, c)):
                    assoc_fail.append((a, b, c))
    chains = g.all_chains()
    disagree = []
    weak_violation = []
    for ch in chains:
        fold = g.path_tier(ch)
        brute = "PROVEN_MATH"
        for i in ch:
            brute = max(brute, g.edges[i]["tier"], key=TIER_LADDER.index)
        if fold != brute:
            disagree.append({"chain": ch[:4]})
        for i in ch:
            e_tier = g.edges[i]["tier"]
            if TIER_LADDER.index(fold) < TIER_LADDER.index(e_tier):
                # propagated tier STRONGER than one of its edges: illegal
                weak_violation.append({"chain": ch[:4], "edge": i})
    proved = not laws_fail and not assoc_fail and not disagree \
        and not weak_violation
    return _shell(
        "E6 theorem_tier_propagation",
        "uncertainty propagates by the lattice meet: laws verified on "
        "all pairs/triples, fold == independent min() recomputation on "
        "every chain, and no chain exceeds its weakest edge",
        proved,
        [{"kind": "law", "case": c} for c in (laws_fail + assoc_fail)[:5]] +
        [{"kind": "fold_vs_min", "row": r} for r in disagree[:5]] +
        [{"kind": "weaker_edge_exists", "row": r} for r in
         weak_violation[:5]],
        {"chains": len(chains), "lattice_pairs_checked":
            len(TIER_LADDER) ** 2, "lattice_triples_checked":
            len(TIER_LADDER) ** 3, "disagreements": len(disagree)},
        ["meet = weaker tier on the ordered 5-tier ladder",
         "lattice laws over all pairs and triples",
         "every graph chain: fold vs brute-force min"])


def theorem_out_of_domain_detection(g: KnowledgeGraph) -> dict:
    """Obligation 7 (extends the UNPROVEN doctrine to v15): unknown
    nodes/diseases return explicit absences (never invented links); a
    v15 profile that cannot cite channel values is NOT_ENCODABLE and is
    refused by the v14.1 normalizer; an out-of-vocabulary candidate
    value raises instead of being coerced."""
    probes = ["MONDO_0000000", "NOT_A_GENE", "PW_DOES_NOT_EXIST",
              "NO_SUCH_DRUG_XY"]
    fabricated = []
    for p in probes:
        res = g.lookup(p)
        if res["found"]:
            fabricated.append(p)
    rank_absent = g.rank_drugs_for_disease("NOT_A_DISEASE")
    if rank_absent["found"] or rank_absent["ranking"]:
        fabricated.append("rank_of_unknown_disease")
    from v15.disease_profile import (DiseaseProfile, Encodability,
                                     V15_CHANNELS)
    vocab = {"system": ["SYSTEM_CARDIOVASCULAR"], "etiology": ["ETIO_HYPERTENSIVE"],
             "microbe": ["NONE"], "site": ["SITE_ARTERIAL"],
             "chronicity": ["CHRONIC"], "pathway": ["PW_VASCULAR_TONE"]}
    prof = DiseaseProfile(name="synthetic unencodable profile")
    derived = prof.derive_phi(vocab)
    honest_refusal = (prof.encodability is Encodability.NOT_ENCODABLE
                      and not derived
                      and len(prof.unresolved_channels) == len(V15_CHANNELS))
    raised = False
    try:
        prof.to_phi_checked(__import__("apeiron_drug_discovery_proof"))
    except ValueError:
        raised = True
    coercion_refused = False
    try:
        bad = DiseaseProfile(
            name="coercion probe",
            phi_candidates={"pathway": [("PW_NOT_IN_VOCABULARY", "SRC:X")]})
        bad.derive_phi(vocab)
    except ValueError:
        coercion_refused = True
    proved = not fabricated and honest_refusal and raised \
        and coercion_refused
    return _shell(
        "E7 theorem_out_of_domain_detection",
        "out-of-domain inputs are refused loudly: unknown graph ids "
        "return explicit absences, unencodable profiles keep "
        "NOT_ENCODABLE and never reach phi, out-of-vocabulary values "
        "raise (never coerced into the corpus)",
        proved,
        [{"kind": "fabricated_result", "probe": p} for p in fabricated],
        {"probes": len(probes), "fabrications": len(fabricated),
         "honest_refusal": honest_refusal, "phi_gate_raises": raised,
         "coercion_refused": coercion_refused},
        ["graph lookups over 4 unknown ids (explicit absence objects)",
         "ranking over an unknown disease returns empty + absence flag",
         "DiseaseProfile.derive_phi with zero cited candidates",
         "to_phi_checked on an unencodable profile raises",
         "out-of-vocabulary phi candidate raises (no coercion)"])


def theorem_bit_for_bit_reproducibility(g: KnowledgeGraph,
                                        run_subprocess: bool = True) -> dict:
    """Obligation 8 (extends C1/C8): re-deriving the knowledge graph in
    fresh memory twice yields identical serialized hashes; regenerating
    the frozen artifact with the original freeze timestamp is
    byte-identical to the file on disk."""
    ns = g.meta.get("ns") or {}
    edges, records, layers = (ns.get("P8_EDGES"), ns.get("SOURCE_RECORDS_P8"),
                              ns.get("NODE_LAYERS"))
    h1 = sha256_of(KGRAPH_DATA_PATH)
    import io
    g_a = KnowledgeGraph(edges, records, layers)
    g_b = KnowledgeGraph(edges, records, layers)
    ser_a = json.dumps(g_a.edges, sort_keys=True).encode()
    ser_b = json.dumps(g_b.edges, sort_keys=True).encode()
    import hashlib
    mem_match = hashlib.sha256(ser_a).hexdigest() == \
        hashlib.sha256(ser_b).hexdigest()
    disk_match = None
    if run_subprocess:
        frozen_utc = ns.get("FROZEN_UTC")
        tmp = os.path.join(ROOT, "v15", "out", "_repro_kgraph_data.py")
        os.makedirs(os.path.dirname(tmp), exist_ok=True)
        proc = subprocess.run(
            [sys.executable, GENERATOR_PATH, "--utc", frozen_utc,
             "--out", tmp],
            capture_output=True, text=True, timeout=600)
        if proc.returncode != 0:
            disk_match = False
        else:
            disk_match = sha256_of(tmp) == h1
        try:
            os.remove(tmp)
        except OSError:
            pass
    proved = mem_match and (disk_match is not False) and bool(h1)
    return _shell(
        "E8 theorem_bit_for_bit_reproducibility",
        "bit-for-bit re-derivation: two fresh in-memory graph builds "
        "serialize identically; regenerating the frozen P8 artifact "
        "under the original freeze timestamp reproduces the file "
        "byte-exactly (extends C1/C8 to Module E)",
        proved,
        [] if proved else [{"kind": "mismatch", "memory": mem_match,
                            "disk": disk_match}],
        {"artifact_sha256": h1, "memory_match": mem_match,
         "disk_match": disk_match},
        ["fresh KnowledgeGraph build x2 -> canonical json sha256",
         "generator subprocess with --utc <frozen> -> byte compare",
         "frozen artifact sha256 recorded in the certificate"])


# ------------------------------------------------- P6-3 fingerprint gate
def theorem_fingerprint_portability(g: KnowledgeGraph = None) -> dict:
    """P6-3 (audit R4): the frozen identity laws re-verify under the
    PINNED RDKit — live version == requirements pin == the version the
    frozen property blocks were computed with, and the full phase-5
    round-trip re-certifies every proved law on freshly recomputed
    fingerprints (0 mismatches / 0 violations / 0 false positives)."""
    import rdkit
    live = rdkit.__version__
    pin = pinned_rdkit_version()
    ns = (g.meta.get("ns") or {}) if g is not None else {}
    frozen_rdkit = (ns.get("INPUT_PINS") or {}).get("rdkit_version")
    versions_ok = live == pin and (frozen_rdkit is None
                                   or frozen_rdkit == live)
    from v15.chem import mol_io
    from v15.molecular import theorem_kb_roundtrip
    layer = mol_io.get_layer()
    laws = mol_io.get_structure_laws(layer)
    rt = theorem_kb_roundtrip(layer, laws)
    laws_ok = (rt["proved"] and rt["stats"]["chi_mismatches"] == 0
               and rt["stats"]["member_violations"] == 0
               and rt["stats"]["false_positives"] == 0)
    proved = versions_ok and laws_ok
    return _shell(
        "E9 theorem_fingerprint_portability (P6-3, audit R4)",
        "fingerprint portability gate: the live RDKit equals the "
        "pinned version and the version recorded in the frozen P8 "
        "input pins, and all %d KB molecules re-verify the frozen "
        "identity laws on fresh fingerprints (0 chi mismatches, 0 "
        "member violations, 0 false positives)" %
        rt["stats"]["kb_molecules"],
        proved,
        [] if proved else [{"kind": "version_or_law_mismatch",
                            "live": live, "pin": pin,
                            "frozen": frozen_rdkit,
                            "roundtrip": rt["stats"]}],
        {"rdkit_live": live, "rdkit_pin": pin,
         "rdkit_in_frozen_pins": frozen_rdkit,
         "roundtrip": rt["stats"]},
        ["requirements.txt pin parsed and compared to the live build",
         "frozen INPUT_PINS rdkit_version cross-checked",
         "phase-5 round-trip re-certification on fresh fingerprints"])


# ------------------------------------------------------- P6-4 memo gate
def theorem_memo_determinism() -> dict:
    """P6-4 (audit R5): the memoized granular-set cache inside the
    v14.1 correspondence engine's `coupling` computes exactly the same
    B(d,m)/rho(d,m) as an unmemoized recomputation over the full
    corpus — memoized == recomputed, bit-for-bit, with the measured
    speedup reported honestly (a performance claim, never a proof
    claim)."""
    sys.path.insert(0, ROOT)
    import apeiron_correspondence as AC
    from apeiron_structure_proof import StructLayer
    import drug_structures as DS
    post, post_sha = AC.load_postulates()
    chem = AC.FrozenChemistry(post)
    corr = AC.Correspondence(post, chem)
    recs, _audit = corr.derive_all()
    rec_by_did = {r["did"]: r for r in recs}
    layer = StructLayer()

    def covered(drug):
        return [layer.comp_canon[c] for c in layer.drug_components[drug]]

    pairs = []
    for r in post["diseases"]:
        rec = rec_by_did.get(r["did"])
        if rec is None or not rec["has_structure_law"]:
            continue
        for g in sorted(layer.drug_components):
            pairs.append((rec, g))
    import time
    # pass 0: cold sweep (fills the memo; results kept)
    corr.clear_coupling_memo()
    memo = [(rec["did"], g) + corr.coupling(rec, covered(g))
            for rec, g in pairs]
    # pass 1: warm memoized sweep (pure cache hits)
    t0 = time.time()
    memo_warm = [(rec["did"], g) + corr.coupling(rec, covered(g))
                 for rec, g in pairs]
    t_memo = time.time() - t0
    # pass 2: forced unmemoized recomputation
    corr.clear_coupling_memo()
    corr.disable_coupling_memo = True
    t0 = time.time()
    fresh = [(rec["did"], g) + corr.coupling(rec, covered(g))
             for rec, g in pairs]
    t_fresh = time.time() - t0
    corr.disable_coupling_memo = False
    mismatches = [(a[0], a[1]) for a, b in zip(memo_warm, fresh)
                  if (a[2], a[3]) != (b[2], b[3])]
    cold_mismatches = [(a[0], a[1]) for a, b in zip(memo, fresh)
                       if (a[2], a[3]) != (b[2], b[3])]
    proved = not mismatches and not cold_mismatches \
        and len(memo) == len(fresh) > 0
    return _shell(
        "E10 theorem_memo_determinism (P6-4, audit R5)",
        "the coupling memo cache is a pure function of its inputs: "
        "memoized vs forced-recomputation agree on every (disease, "
        "molecule) pair of the full corpus (B and rho identical)",
        proved,
        [{"did": d, "drug": g} for d, g in mismatches[:5]],
        {"pairs_checked": len(pairs),
         "memo_seconds": round(t_memo, 3),
         "fresh_seconds": round(t_fresh, 3),
         "speedup_x": round(t_fresh / t_memo, 2) if t_memo > 0 else None,
         "mismatches": len(mismatches),
         "cold_mismatches": len(cold_mismatches),
         "postulates_sha256": post_sha[:16]},
        ["derive recs from the frozen postulates (hermetic)",
         "cold sweep fills the memo; warm sweep timed against a "
         "forced recomputation sweep",
         "exact (B, rho) comparison per pair, cold and warm"])


# ---------------------------------------------------------- orchestrator
def run_module_e() -> dict:
    g = KnowledgeGraph.from_frozen(verify_pin=True)
    import rdkit
    chains = g.all_chains()
    rankings = {}
    for did in sorted({e["src"] for e in g.edges_of("disease->gene")}):
        rankings[did] = g.rank_drugs_for_disease(did)
    theorems = {
        "E1": theorem_graph_consistency(g),
        "E2": theorem_disease_identity_uniqueness(g),
        "E3": theorem_contradiction_detection(g),
        "E4": theorem_evidence_provenance_completeness(g),
        "E5": theorem_rank_integrity(g),
        "E6": theorem_tier_propagation(g),
        "E7": theorem_out_of_domain_detection(g),
        "E8": theorem_bit_for_bit_reproducibility(g),
        "E9": theorem_fingerprint_portability(g),
        "E10": theorem_memo_determinism(),
    }
    return {
        "module": "APEIRON-X v15 Module E — mathematical reasoning "
                  "extensions (Phase 6)",
        "kg_schema_version": KG_SCHEMA_VERSION,
        "frozen_utc": g.meta.get("frozen_utc"),
        "rdkit_version": rdkit.__version__,
        "rdkit_pin": pinned_rdkit_version(),
        "graph": {
            "edges": len(g.edges),
            "nodes": len(g.node_layer),
            "by_relation": {r: len(g.edges_of(r))
                            for r in REL_LAYER_MAP},
            "nodes_by_layer": {
                layer: sum(1 for l in g.node_layer.values() if l == layer)
                for layer in sorted(set(g.node_layer.values()))},
            "absences_recorded": len(g.meta.get("absences", [])),
            "chains_enumerated": len(chains),
            "input_pins": {k: v for k, v in
                           (g.meta.get("input_pins") or {}).items()
                           if k != "cache_payloads"},
        },
        "rankings_label": STATUS_FLAG,
        "rankings": rankings,
        "theorems": theorems,
        "all_proved": all(t["proved"] for t in theorems.values()),
    }
