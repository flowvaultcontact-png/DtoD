#!/usr/bin/env python3
"""APEIRON-X v15 — full-cascade regression runner (Phase 1 acceptance gate).

Runs the complete v14.1 proof cascade in strict order as subprocesses and
exits non-zero if ANY entry exits non-zero or exceeds its stage timeout.
Also verifies the frozen-file sha256s (unless --allow-refreeze, which then
requires the new hashes to be written to the log by the caller).

Usage:
    python3 v15/run_full_regression.py [--quick] [--skip-frozen-check]
"""

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# (label, relative command list, stage timeout seconds)
STAGES = [
    ("v11.1 core T-battery", ["python3", "apeiron_drug_discovery_proof.py"], 600),
    ("v12.1 structure S-battery", ["python3", "apeiron_structure_proof.py"], 900),
    ("v13.0 direct-law D-battery", ["python3", "apeiron_direct_laws.py"], 900),
    ("v13.1 equation E-battery", ["python3", "apeiron_equations.py"], 900),
    ("v14.0 correspondence C-battery (hermetic + REG)",
     ["python3", "apeiron_correspondence.py"], 1200),
    ("demo: full mapping", ["python3", "demo_full_mapping.py"], 900),
    ("demo: extension stress", ["python3", "extension_stress_demo.py"], 600),
    ("v14.1 novel-disease harness",
     ["python3", os.path.join("..", "scripts", "apeiron_novel_disease_test.py")], 900),
    ("v14.1 smoke test",
     ["python3", os.path.join("..", "scripts", "smoke_test_fix.py")], 300),
    ("v15 scaffold tests", ["python3", "v15/tests/test_v15_scaffold.py"], 300),
    ("v15 phase-2 tests", ["python3", "v15/tests/test_v15_phase2.py"], 300),
    ("v15 phase-3 tests", ["python3", "v15/tests/test_v15_phase3.py"], 300),
    ("v15 phase-4 tests", ["python3", "v15/tests/test_v15_phase4.py"], 600),
    ("v15 phase-5 tests", ["python3", "v15/tests/test_v15_phase5.py"], 900),
    ("v15 phase-6 tests", ["python3", "v15/tests/test_v15_phase6.py"], 900),
    ("v15 phase-7 tests", ["python3", "v15/tests/test_v15_phase7.py"], 900),
    ("v15 phase-8 artifacts + tests",
     ["python3", "v15/write_phase8_artifacts.py"], 900),
    ("v15 phase-8 tests", ["python3", "v15/tests/test_v15_phase8.py"], 900),
]
QUICK = {"v11.1 core T-battery", "demo: extension stress",
         "v14.1 novel-disease harness", "v14.1 smoke test",
         "v15 scaffold tests", "v15 phase-2 tests", "v15 phase-3 tests",
         "v15 phase-4 tests", "v15 phase-5 tests", "v15 phase-6 tests",
         "v15 phase-7 tests", "v15 phase-8 artifacts + tests",
         "v15 phase-8 tests"}

FROZEN = ["disease_drug_kb.py", "drug_structures.py",
          "disease_mechanism_table.py", "postulates_v14.json"]


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true",
                    help="run only the fast stages (dev loop)")
    ap.add_argument("--skip-frozen-check", action="store_true")
    args = ap.parse_args()

    results, ok_all = [], True
    for label, cmd, timeout in STAGES:
        if args.quick and label not in QUICK:
            continue
        t0 = time.time()
        try:
            proc = subprocess.run(cmd, cwd=ROOT, capture_output=True,
                                  text=True, timeout=timeout)
            code = proc.returncode
            tail = (proc.stdout or "").strip().splitlines()[-2:]
        except subprocess.TimeoutExpired:
            code, tail = "TIMEOUT", [f"exceeded {timeout}s"]
        dt = time.time() - t0
        ok = code == 0
        ok_all &= ok
        results.append({"stage": label, "exit": code, "seconds": round(dt, 1)})
        print(f"[{'OK ' if ok else 'FAIL'}] {label:<48} exit={code} "
              f"({dt:.1f}s)")
        if not ok:
            for line in tail:
                print("        " + line)

    if not args.skip_frozen_check:
        print("\nfrozen-data integrity (sha256 vs baseline snapshot):")
        snap = os.path.join(ROOT, "docs", "baseline",
                            "frozen_files_sha256_before.txt")
        expected = {}
        with open(snap, encoding="utf-8") as fh:
            for line in fh:
                h, name = line.split()
                expected[name] = h
        for name in FROZEN:
            live = sha256(os.path.join(ROOT, name))
            match = expected.get(name) == live
            ok_all &= match
            print(f"[{'OK ' if match else 'DRIFT'}] {name:<32} {live[:16]}…")

    verdict = "ALL REGRESSION STAGES PASSED" if ok_all else \
              "REGRESSION FAILED — engine refuses to certify"
    print("\nVERDICT: " + verdict)
    out = os.path.join(ROOT, "docs", "baseline", "regression_last_run.json")
    with open(out, "w", encoding="utf-8") as fh:
        json.dump({"ok": ok_all, "stages": results}, fh, indent=1)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
