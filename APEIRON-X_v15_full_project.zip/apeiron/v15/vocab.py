"""APEIRON-X v15 vocabulary loader (P2-1).

Serves the frozen additive vocabulary tables of `v15.vocab_data` under a
hash-pin discipline identical in spirit to the v14.1 postulate freeze:
the sha256 of `vocab_data.py` is pinned in `v15/kb_extensions/
vocab_pins.json`; `load_vocab()` refuses to serve data on any mismatch,
so a silent edit of a frozen table cannot flow into any derivation.

This module is consumed ONLY by v15 code (profiles, packs, future
modules). No v14.1 derivation engine imports it, so the C0 hermeticity
doctrine of the correspondence core is untouched.
"""

import hashlib
import json
import os

from . import vocab_data as _data

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_PATH = os.path.abspath(_data.__file__)
PIN_PATH = os.path.join(HERE, "kb_extensions", "vocab_pins.json")


def sha256_of(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 16), b""):
            h.update(chunk)
    return h.hexdigest()


def _load_pins() -> dict:
    if not os.path.exists(PIN_PATH):
        raise RuntimeError(
            f"vocab pin file missing: {PIN_PATH}. Run "
            "v15/kb_extensions/freeze_vocab.py to create it (frozen-table "
            "doctrine: unpinned vocabulary is not served).")
    with open(PIN_PATH, encoding="utf-8") as fh:
        return json.load(fh)


class Vocabulary:
    """Read-only facade over the frozen vocabulary tables."""

    def __init__(self, verify_pin: bool = True):
        self.pins = _load_pins()
        self.data_sha256 = sha256_of(DATA_PATH)
        if verify_pin and self.pins.get("vocab_data_sha256") != self.data_sha256:
            raise RuntimeError(
                "vocab_data.py sha256 mismatch: frozen pin "
                f"{self.pins.get('vocab_data_sha256')} != live "
                f"{self.data_sha256}. If this change is intentional, "
                "re-run the documented re-freeze, never edit silently.")
        problems = _data.validate_vocab_module()
        if problems:
            raise ValueError("vocab module self-validation failed: "
                             + "; ".join(problems))
        self.diseases = dict(_data.DISEASE_ONTOLOGY)
        self.genes = dict(_data.GENE_TABLE)
        self.sources = dict(_data.SOURCE_RECORDS)
        self.coverage = dict(_data.COVERAGE_NOTES)
        self.limits = {
            "pathway": _data.PATHWAY_ONTOLOGY_LIMITS,
            "hpo": _data.PHENOTYPE_HPO_LIMITS,
        }

    # -- lookups ------------------------------------------------------
    def disease_by_mondo(self, mondo_id: str):
        for name, rec in self.diseases.items():
            if rec["mondo_id"] == mondo_id:
                return name, rec
        return None, None

    def disease_by_kb_link(self, did: str):
        for name, rec in self.diseases.items():
            if rec["kb_link"] == did:
                return name, rec
        return None, None

    def gene_by_symbol(self, symbol: str):
        return self.genes.get(symbol)

    def gene_for_class(self, mechanism_class: str):
        """All verified genes linked to a v14.1 mechanism class."""
        return {s: r for s, r in self.genes.items()
                if mechanism_class in r.get("class_links", ())}

    def require_sources(self, source_ids) -> None:
        missing = [s for s in source_ids if s not in self.sources]
        if missing:
            raise KeyError("uncited vocab sources: " + ", ".join(missing))

    # -- cardinality / admission reporting (R10 support) --------------
    def channel_value_counts(self, kb_module) -> dict:
        """Per channel: value -> occurrence count over the KB rows."""
        counts = {}
        for ch in kb_module.CHANNELS:
            counts[ch] = {}
            for r in kb_module.DISEASES:
                v = r[ch]
                counts[ch][v] = counts[ch].get(v, 0) + 1
        return counts

    def admission_report(self, pack_rows, kb_module) -> dict:
        """Merged-corpus cardinality for every channel value a pack uses
        (existing values included). Drives theorem_cardinality_guard."""
        counts = self.channel_value_counts(kb_module)
        merged_counts = {ch: dict(counts[ch]) for ch in counts}
        report = {"values": [], "n_new": 0, "n_existing": 0}
        for row in pack_rows:
            for ch in kb_module.CHANNELS:
                v = row[ch]
                in_kb = v in counts[ch]
                merged_counts[ch][v] = merged_counts[ch].get(v, 0) + 1
                report["values"].append({
                    "did": row["did"], "channel": ch, "value": v,
                    "existing_corpus_count": counts[ch].get(v, 0),
                    "pack_rows_using_it": 1,   # refined below
                    "merged_count": merged_counts[ch][v],
                })
                if not in_kb:
                    report["n_new"] += 1
                else:
                    report["n_existing"] += 1
        # refine pack_rows_using_it: occurrences of the value inside pack
        for entry in report["values"]:
            entry["pack_rows_using_it"] = sum(
                1 for row in pack_rows if row[entry["channel"]] == entry["value"])
        report["merged_counts"] = merged_counts
        return report
