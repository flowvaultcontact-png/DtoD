"""Module F — experimental-validation intelligence (Phase 7, plan §8).

P7-1 `validation_plan.py`: per candidate — mechanism narrative (tiered),
     target-engagement hypothesis (assay class), supporting +
     contradictory evidence with resolvable ids, proposed model systems,
     control groups, endpoints (measurable, assay-annotated), failure
     mechanisms, stage gates (biochemical -> cellular -> tissue ->
     animal -> human).

P7-2 External dataset hooks: the FROZEN registry
     `v15.validation_data` (sha256-pinned, metadata + accession records
     only — CT.gov study headers with a module whitelist that makes
     results content structurally absent; GEO esummary series metadata).
     Results are NEVER synthesized: a forbidden-token build gate makes a
     results-bearing plan impossible to construct.

P7-3 Report discipline: every plan carries a
     "required evidence to change status" section; the only permitted
     status movements are DECLARED transitions naming cited evidence
     classes. `attempt_status_upgrade` always raises — there is no code
     path that upgrades a candidate status (the claim-ladder doctrine of
     claims.py carried to the plan layer).

Theorems (PROVEN_MATH, standard shape):
    F1 theorem_plan_schema_completeness
       every EVIDENCED+ candidate ships a plan with all required
       sections; a section-missing plan is refused at construction
    F2 theorem_stage_gate_ordering
       gates are the canonical 5-ladder; COMPLETED states form a prefix
       chain; an out-of-order completion is refused
    F3 theorem_evidence_citation_completeness
       every cited id resolves in a known frozen ledger (P4 pack /
       P7 registry / P8 graph); an unknown id is refused at build
    F4 theorem_no_results_synthesis
       the registry carries metadata + accession only (structural
       fields whitelist at fetch; self-validation at freeze; forbidden-
       token gate at plan build) — results content cannot exist in any
       derived record
    F5 theorem_status_transition_discipline
       transitions are declared, evidence-class-based, and never
       computable; the upgrade code path always raises
    F6 theorem_plan_determinism
       plans re-derive byte-identically from the frozen inputs (two
       independent builds, canonical sha256; no wall-clock field exists
       in any plan payload)
    F7 theorem_out_of_domain_detection
       unknown candidate/disease -> explicit absence object; no plan is
       invented

Doctrine: v14.1 engines and v15 packs are consumed READ-ONLY under
their pins; the registry absences are reported, never guessed; every
proposal (assay class, model systems, controls, endpoints) is an
authored RULE TABLE applied transparently and labelled COMPUTATIONAL —
a proposal, never a measurement, never a claim.
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)                     # apeiron/ repo root
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

VALIDATION_DATA_PATH = os.path.abspath(os.path.join(
    HERE, "validation_data.py"))
VALIDATION_PIN_PATH = os.path.abspath(os.path.join(
    HERE, "kb_extensions", "validation_pins.json"))
PHASE5_BENCH_PATH = os.path.abspath(os.path.join(
    ROOT, "v15", "out", "phase5_benchmark.json"))

SCHEMA_VERSION = "15.7.0"
PLAN_LABEL = "VALIDATION_PLAN"                   # never a probability

# P7-1 stage gates (canonical order; prefix-completion discipline)
STAGE_GATES = ("BIOCHEMICAL", "CELLULAR", "TISSUE", "ANIMAL", "HUMAN")

# gate states (a gate is never silently marked done)
GATE_PROPOSED = "PROPOSED"
GATE_REGISTRY = "REGISTRY_ACTIVITY_PRESENT"      # metadata only, HUMAN lane
GATE_COMPLETED = "COMPLETED_WITH_CITED_EVIDENCE"  # requires >=1 cited id

# Defense in depth against synthesized results (P7-2 / F4).
FORBIDDEN_RESULT_TOKENS = ("resultSection", "outcomeMeasure",
                           "primaryOutcome", "secondaryOutcome",
                           "effectSize", "pValue", "p-value", "hazard ratio",
                           "odds ratio")

REQUIRED_SECTIONS = (
    "plan_id", "candidate", "disease_context", "mechanism_narrative",
    "target_engagement", "supporting_evidence", "contradictory_evidence",
    "model_systems", "control_groups", "endpoints", "failure_mechanisms",
    "stage_gates", "datasets", "required_evidence_to_change_status",
    "honest_limits")

# Statuses (P4-2 vocabulary; plans never move them)
STATUS_ORDER = ("COMPUTATIONAL_HYPOTHESIS", "EXPERIMENTALLY_VALIDATED",
                "INVESTIGATIONAL", "APPROVED_INDICATION")


class PlanBuildError(ValueError):
    """Raised instead of emitting an invalid or dishonest plan."""


# =====================================================================
# P7-1 rule tables (authored, transparent, applied as COMPUTATIONAL
# proposals; the basis of every rule is recorded in the plan)
# =====================================================================

# primary target symbol -> engagement assay template (biochemical gate)
ASSAY_RULES = {
    "SLC5A2": "recombinant-human-SLC5A2 transporter glucose-uptake assay "
              "(membrane potential / labeled glucose readout; reference "
              "inhibitor as positive control)",
    "ACE": "recombinant-human-ACE enzyme-inhibition assay (synthetic "
           "substrate cleavage readout; captopril reference curve)",
    "AGTR1": "human-AGTR1 receptor binding-competition assay "
             "(radiolabeled ligand displacement; losartan reference)",
    "NR3C2": "human-NR3C2 ligand-binding + transactivation assay "
             "(reporter construct; spironolactone reference)",
    "HMGCR": "recombinant-human-HMGCR catalytic-domain enzyme assay "
             "(NADPH-coupled readout; statin reference curve)",
    "DPP4": "recombinant-human-DPP4 enzyme-inhibition assay "
            "(chromogenic substrate; sitagliptin reference)",
    "ABCC8": "KATP channel complex (ABCC8/KCNJ11) functional assay "
             "(patch-clamp or thallium flux; sulfonylurea reference)",
    "KCNJ11": "KATP channel complex (ABCC8/KCNJ11) functional assay "
              "(patch-clamp or thallium flux; sulfonylurea reference)",
    "CACNA1C": "human L-type calcium-channel (CACNA1C) patch-clamp or "
               "flux assay (dihydropyridine reference)",
    "ADRB1": "human-ADRB1 antagonism assay (cAMP readout under agonist "
             "challenge; beta-blocker reference)",
    "GLP1R": "human-GLP1R agonism assay (cAMP accumulation reporter; "
             "exendin-4 reference curve)",
    "GPD2": "mitochondrial glycerophosphate dehydrogenase (GPD2) "
            "enzyme assay (electron-acceptor readout)",
    "NDUFA1": "mitochondrial complex-I (NADH dehydrogenase) activity "
              "assay in cells or submitochondrial particles",
}

ACTION_FALLBACK_RULES = {
    "INHIBITOR": "cited-target enzyme/binding inhibition assay (target "
                 "id from the Open Targets mechanism row)",
    "ANTAGONIST": "cited-target receptor binding-competition + "
                  "functional antagonism assay",
    "AGONIST": "cited-target receptor functional agonism assay "
               "(pathway-specific readout)",
    "BLOCKER": "cited-target ion-channel functional blockade assay "
               "(patch-clamp/flux)",
    "MODULATOR": "cited-target functional modulation assay (positive "
                 "and negative modulation arms)",
}

# mechanism class -> model-system ladder proposal (all lanes)
MODEL_SYSTEM_RULES = {
    "SGLT2_INHIBITOR": [
        "cells: human proximal-tubule monolayer expressing SLC5A2",
        "tissue: isolated perfused kidney / kidney organoid monolayer",
        "animal: diabetic rodent model with albuminuria readouts",
    ],
    "RAAS_BLOCKADE": [
        "cells: human endothelial / tubular epithelial monolayers",
        "tissue: isolated vessel ring or perfused kidney preparation",
        "animal: hypertensive rodent model with organ-damage readouts",
    ],
    "STEROID_RECEPTOR": [
        "cells: human receptor-transactivation reporter cells",
        "tissue: primary human fibroblast/epithelial cultures",
        "animal: receptor-specific rodent model with organ readouts",
    ],
    "METABOLIC_ENZYME": [
        "cells: hepatocyte/myocyte metabolic-flux cultures",
        "tissue: precision-cut liver slices",
        "animal: diet-induced metabolic-disease rodent model",
    ],
}
CLASS_TO_LADDER = {
    "SGLT2_INHIBITOR": "SGLT2_INHIBITOR",
    "ACEI_RAAS": "RAAS_BLOCKADE",
    "ARB_RAAS": "RAAS_BLOCKADE",
    "MINERALOCORTICOID_ANTAGONIST": "STEROID_RECEPTOR",
    "HMGCR_INHIBITOR": "METABOLIC_ENZYME",
    "BIGUANIDE_HEPATIC_GLUCOSE": "METABOLIC_ENZYME",
}

STATUS_TRANSITION_RULES = {
    "COMPUTATIONAL_HYPOTHESIS": {
        "to": "EXPERIMENTALLY_VALIDATED",
        "evidence_classes": [
            "BIOCHEMICAL-gate target-engagement record with a cited "
            "source id (assay run record, never this engine's output)",
            "CELLULAR-gate functional record reproducing the engagement "
            "in the disease-relevant model system",
            "adjudication of every contradictory finding listed in the "
            "plan (none left unaddressed)",
        ],
    },
    "EXPERIMENTALLY_VALIDATED": {
        "to": "INVESTIGATIONAL",
        "evidence_classes": [
            "cited clinical-program record (registry accession metadata "
            "or regulatory filing; fetched, never synthesized here)",
            "no unadjudicated safety contradiction (e.g. withdrawn_flag "
            "rows) in the pack",
        ],
    },
    "INVESTIGATIONAL": {
        "to": "APPROVED_INDICATION",
        "evidence_classes": [
            "cited regulatory approval row for the exact drug x "
            "indication (OT/ChEMBL/registry), human-readable source id",
        ],
    },
    "APPROVED_INDICATION": {
        "to": "APPROVED_INDICATION",
        "evidence_classes": [
            "none: already at the registry-derivable ceiling for this "
            "drug x indication; any stronger claim (efficacy) requires "
            "RESULTS content, which APEIRON-X never synthesizes — a "
            "researcher must fetch and adjudicate the trial results "
            "listed in this plan's datasets section",
        ],
    },
}


def sha256_text(text: str) -> str:
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


# =====================================================================
# P7-2 pin-checked registry facade + cross-ledger source resolution
# =====================================================================

class ValidationRegistry:
    """Pin-checked read-only facade over `v15.validation_data` with the
    anti-fabrication source resolver spanning the P4 pack, the P7
    registry and the P8 knowledge graph."""

    def __init__(self, verify_pin: bool = True):
        import importlib
        from . import validation_data as vd
        importlib.reload(vd)
        self._vd = vd
        self.data_sha256 = sha256_text(
            open(VALIDATION_DATA_PATH, encoding="utf-8").read())
        if not os.path.exists(VALIDATION_PIN_PATH):
            raise RuntimeError(
                f"validation pin file missing: {VALIDATION_PIN_PATH}. "
                "Run v15/kb_extensions/freeze_validation.py (frozen-"
                "table doctrine: unpinned tables are not served).")
        with open(VALIDATION_PIN_PATH, encoding="utf-8") as fh:
            self.pins = json.load(fh)
        if verify_pin and self.pins.get("validation_data_sha256") != \
                self.data_sha256:
            raise RuntimeError(
                "validation_data.py sha256 mismatch with "
                "kb_extensions/validation_pins.json — refuse to serve "
                "(frozen-table doctrine)")
        problems = vd.validate_validation_module()
        if problems:
            raise ValueError("validation registry self-validation "
                             "failed: " + "; ".join(problems))
        self.schema_version = vd.PACK_SCHEMA_VERSION
        self.frozen_utc = vd.FROZEN_UTC
        self.studies = dict(vd.CT_STUDIES_P7)
        self.series = dict(vd.GEO_SERIES_P7)
        self.ct_panel = list(vd.CT_QUERY_PANEL_P7)
        self.geo_panel = list(vd.GEO_QUERY_PANEL_P7)
        self.links = list(vd.CANDIDATE_DATASET_LINKS_P7)
        self.geo_links = list(vd.GEO_DISEASE_LINKS_P7)
        self.disease_tokens = dict(vd.DISEASE_TOKEN_SPECS_P7)
        self.absences = list(vd.ABSENCES_P7)
        self.limits = list(vd.HONEST_LIMITS_P7)
        self._extra_ledgers = {}

    def attach_ledger(self, name: str, records: dict) -> None:
        """Register an additional id->source-record ledger (the P4 pack
        and P8 graph sources attach here)."""
        self._extra_ledgers[name] = dict(records)

    # -- evidence resolution (F3 gate) ---------------------------------
    def resolve(self, source_id: str):
        if source_id in self._vd.SOURCE_RECORDS_P7:
            return ("P7", dict(self._vd.SOURCE_RECORDS_P7[source_id]))
        for name, records in sorted(self._extra_ledgers.items()):
            if source_id in records:
                return (name, dict(records[source_id]))
        return None

    def study_ids_for(self, drug: str, disease_key: str):
        for lnk in self.links:
            if lnk["drug"] == drug and lnk["disease_key"] == disease_key:
                return lnk
        return None

    def geo_series_for(self, disease_key: str):
        return [lnk for lnk in self.geo_links
                if lnk["disease_key"] == disease_key]


def _registry_with_ledgers(pack=None, graph_ns=None) -> ValidationRegistry:
    reg = ValidationRegistry()
    if pack is None:
        from .repurposing import load_pack
        pack = load_pack()
    from . import repurposing_data as rd
    ledger = {}
    ledger.update(getattr(rd, "SOURCE_RECORDS", {}))
    ledger.update(getattr(rd, "INTERNAL_SOURCE_RECORDS", {}))
    for lit_id, rec in getattr(rd, "LITERATURE", {}).items():
        if lit_id not in ledger:
            ledger[lit_id] = {
                "resource": "Europe PMC record (frozen literature lane)",
                "resource_version": "frozen pack literature table",
                "retrieval_utc": pack.frozen_utc,
                "url": f"https://europepmc.org/article/MED/{rec['pmid']}",
                "license": "SEE_TERMS (Europe PMC)",
                "evidence_type": "publication",
                "confidence": "machine_verified_citation",
            }
    reg.attach_ledger("P4", ledger)
    if graph_ns is None:
        from .kgraph import load_kgraph
        graph_ns = load_kgraph(verify_pin=True)
    reg.attach_ledger("P8", dict(graph_ns["SOURCE_RECORDS_P8"]))
    return reg


# =====================================================================
# P7-1 plan construction (build gate refuses anything dishonest)
# =====================================================================

def _scan_forbidden(obj, path="plan"):
    """Depth-first forbidden-token scan over every string leaf (F4)."""
    hits = []
    if isinstance(obj, str):
        for tok in FORBIDDEN_RESULT_TOKENS:
            if tok.lower() in obj.lower():
                hits.append((path, tok))
    elif isinstance(obj, dict):
        for k, v in obj.items():
            hits.extend(_scan_forbidden(v, f"{path}.{k}"))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            hits.extend(_scan_forbidden(v, f"{path}[{i}]"))
    return hits


def _require_evidence(item, where, reg):
    if not isinstance(item, dict) or "kind" not in item or \
            "source_ids" not in item:
        raise PlanBuildError(
            f"{where}: evidence rows need 'kind' and 'source_ids'")
    ids = item["source_ids"]
    if not isinstance(ids, tuple) and not isinstance(ids, list):
        raise PlanBuildError(f"{where}: source_ids must be a list")
    if not ids:
        raise PlanBuildError(f"{where}: evidence without a cited id is "
                             "not allowed (anti-fabrication gate)")
    for sid in ids:
        if reg.resolve(sid) is None:
            raise PlanBuildError(
                f"{where}: evidence id {sid!r} resolves in NO frozen "
                "ledger (P4/P7/P8) — refuse to build")


def _build_gates(reg, drug, disease_key):
    """Derive gate states HONESTLY: only the HUMAN lane can carry
    REGISTRY_ACTIVITY_PRESENT (n trials exist = research activity,
    never efficacy); all other gates start PROPOSED."""
    gates = []
    lnk = reg.study_ids_for(drug, disease_key) if drug else None
    n_studies = lnk["matched_total"] if lnk else 0
    for gate in STAGE_GATES:
        if gate == "HUMAN" and n_studies > 0:
            gates.append({
                "gate": gate,
                "state": GATE_REGISTRY,
                "basis": f"{n_studies} registry studies linked by the "
                         "recorded token filter (metadata only; no "
                         "results content was fetched or synthesized)",
                "cited_source_ids": [],
                "registry_reference": lnk["link_id"],
                "registry_accessions": list(lnk["study_ids"]),
            })
        else:
            reason = ("no registry record linked for this drug x "
                      "disease (absence recorded, not guessed)"
                      if gate == "HUMAN" else
                      "proposed gate — no experimental record exists in "
                      "any v15 lane")
            gates.append({"gate": gate, "state": GATE_PROPOSED,
                          "basis": reason, "cited_source_ids": [],
                          "registry_reference": None})
    return gates


def build_plan(reg: ValidationRegistry, *, plan_id: str, candidate: dict,
               disease_context: dict, mechanism_narrative: dict,
               target_engagement: dict, supporting_evidence: list,
               contradictory_evidence: list, model_systems: list,
               control_groups: list, endpoints: list,
               failure_mechanisms: list, stage_gates: list,
               datasets: dict, honest_limits: list,
               current_status: str = None) -> dict:
    """THE BUILD GATE. Assembles the plan dict and refuses to return
    anything that violates the P7 discipline. Returns the plan dict
    (already canonical-serializable). current_status defaults to the
    candidate's own declared status."""
    if current_status is None:
        current_status = candidate.get("status")
    plan = {
        "plan_id": plan_id,
        "candidate": candidate,
        "disease_context": disease_context,
        "mechanism_narrative": mechanism_narrative,
        "target_engagement": target_engagement,
        "supporting_evidence": supporting_evidence,
        "contradictory_evidence": contradictory_evidence,
        "model_systems": model_systems,
        "control_groups": control_groups,
        "endpoints": endpoints,
        "failure_mechanisms": failure_mechanisms,
        "stage_gates": stage_gates,
        "datasets": datasets,
        "required_evidence_to_change_status":
            transition_section(current_status),
        "honest_limits": honest_limits,
    }
    # THE GATE: the full P7 discipline (artifact-layer validator, shared
    # with plans loaded from artifacts / API payloads).
    validate_loaded_plan(reg, plan)
    return plan


def validate_loaded_plan(reg: ValidationRegistry, plan: dict) -> None:
    """Artifact-layer validator (P7 discipline) — same gate build_plan
    applies, usable on plans loaded from an artifact / API payload so a
    tampered plan cannot pass unnoticed."""
    plan_id = plan.get("plan_id", "<unknown>")
    cand = plan.get("candidate") or {}
    for sec in REQUIRED_SECTIONS:
        if sec not in plan:
            raise PlanBuildError(f"plan {plan_id}: missing required "
                                 f"section {sec!r}")
        if plan[sec] is None:
            raise PlanBuildError(f"plan {plan_id}: section {sec!r} is "
                                 "None")
    if not plan["honest_limits"]:
        raise PlanBuildError(f"plan {plan_id}: honest_limits empty — "
                             "every plan must state its limits")
    for f in ("id", "kind", "status", "tier"):
        if not cand.get(f):
            raise PlanBuildError(f"plan {plan_id}: candidate.{f} missing")
    if cand["status"] not in STATUS_ORDER:
        raise PlanBuildError(f"plan {plan_id}: unknown status "
                             f"{cand['status']!r}")
    tiers = ("PROVEN_MATH", "EVIDENCED", "COMPUTATIONAL", "HYPOTHESIS",
             "UNKNOWN")
    if cand["tier"] not in tiers:
        raise PlanBuildError(f"plan {plan_id}: unknown candidate tier "
                             f"{cand['tier']!r}")
    if cand["tier"] in ("PROVEN_MATH", "EVIDENCED") and \
            not plan["supporting_evidence"]:
        raise PlanBuildError(
            f"plan {plan_id}: EVIDENCED+ candidate without any "
            "supporting evidence row is not allowed")
    for i, ev in enumerate(plan["supporting_evidence"]):
        _require_evidence(ev, f"plan {plan_id} supporting[{i}]", reg)
    for i, ev in enumerate(plan["contradictory_evidence"]):
        _require_evidence(ev, f"plan {plan_id} contradictory[{i}]", reg)
    if not plan["endpoints"]:
        raise PlanBuildError(f"plan {plan_id}: endpoints empty")
    for i, ep in enumerate(plan["endpoints"]):
        if not ep.get("name") or not ep.get("assay_annotation"):
            raise PlanBuildError(
                f"plan {plan_id} endpoint[{i}]: needs 'name' and a "
                "non-empty 'assay_annotation' (measurable + annotated)")
    gates = plan["stage_gates"]
    if [g["gate"] for g in gates] != list(STAGE_GATES):
        raise PlanBuildError(
            f"plan {plan_id}: stage gates must be exactly "
            f"{STAGE_GATES} in order")
    seen_completed = True
    for g in gates:
        state = g["state"]
        if state not in (GATE_PROPOSED, GATE_REGISTRY, GATE_COMPLETED):
            raise PlanBuildError(f"plan {plan_id}: unknown gate state "
                                 f"{state!r}")
        if state == GATE_COMPLETED:
            if not g.get("cited_source_ids"):
                raise PlanBuildError(
                    f"plan {plan_id}: gate {g['gate']} marked "
                    f"{GATE_COMPLETED} without cited source ids")
            if not seen_completed:
                raise PlanBuildError(
                    f"plan {plan_id}: gate {g['gate']} completed while "
                    "an earlier gate is not — prefix discipline broken")
        else:
            seen_completed = False
        if state == GATE_REGISTRY and g["gate"] != "HUMAN" and \
                not g.get("allow_non_human_registry"):
            raise PlanBuildError(
                f"plan {plan_id}: REGISTRY_ACTIVITY_PRESENT is only "
                f"derivable on the HUMAN lane (gate {g['gate']} "
                "refused)")
    hits = _scan_forbidden(plan)
    if hits:
        raise PlanBuildError(
            f"plan {plan_id}: synthesized-results tokens detected "
            f"({hits[:3]}) — the P7 lane never carries results")
    ds = plan["datasets"]
    for acc in ds.get("ct_accessions", []):
        if acc not in reg.studies:
            raise PlanBuildError(f"plan {plan_id}: dataset accession "
                                 f"{acc} not in the frozen registry")
    for acc in ds.get("geo_accessions", []):
        if acc not in reg.series:
            raise PlanBuildError(f"plan {plan_id}: dataset accession "
                                 f"{acc} not in the frozen registry")
    for sid in ds.get("source_ids", []):
        if reg.resolve(sid) is None:
            raise PlanBuildError(f"plan {plan_id}: dataset source id "
                                 f"{sid} unresolved")
    if not ds.get("absence_note") and not (ds.get("ct_accessions") or
                                           ds.get("geo_accessions")):
        raise PlanBuildError(
            f"plan {plan_id}: datasets section is empty without an "
            "absence note (nothing may be silently empty)")
    tr = plan["required_evidence_to_change_status"]
    if tr["from"] != cand["status"]:
        raise PlanBuildError(
            f"plan {plan_id}: transition section status "
            f"{tr['from']!r} != candidate status {cand['status']!r}")
    if tr.get("never_by_computation") is not True:
        raise PlanBuildError(
            f"plan {plan_id}: transition section must declare "
            "never_by_computation=true")


def transition_section(current_status: str) -> dict:
    rule = STATUS_TRANSITION_RULES.get(current_status)
    if rule is None:
        raise PlanBuildError(f"no transition rule for status "
                             f"{current_status!r}")
    return {"from": current_status, "to": rule["to"],
            "evidence_classes": list(rule["evidence_classes"]),
            "never_by_computation": True}


def attempt_status_upgrade(plan: dict) -> str:
    """There is NO code path that upgrades a candidate status (F5).
    Calling this always raises — the machine-checked proof."""
    raise PlanBuildError(
        "status upgrade by code path is forbidden (P7-3 / claim-ladder "
        "doctrine): provide cited evidence of the classes listed in "
        f"{plan['plan_id']}.required_evidence_to_change_status instead")


# =====================================================================
# plan content builders (transparent rule application)
# =====================================================================

def _assay_template(moa_rows, kb_mech_class):
    """Primary target + action -> assay-class proposal (COMPUTATIONAL).
    Returns (assay_class, primary_target, direction, basis)."""
    primary = None
    action = None
    for r in moa_rows or []:
        if r.get("target_symbols") and r.get("action_type"):
            primary = r["target_symbols"][0]
            action = r["action_type"]
            break
    basis = ("Open Targets mechanism row (frozen P4 pack, machine-"
             "fetched) + authored rule table")
    if primary and primary in ASSAY_RULES:
        direction = {("SLC5A2"): "inhibit", "ACE": "inhibit",
                     "AGTR1": "antagonize", "NR3C2": "antagonize",
                     "HMGCR": "inhibit", "DPP4": "inhibit",
                     "ABCC8": "block", "KCNJ11": "block",
                     "CACNA1C": "block", "ADRB1": "antagonize",
                     "GLP1R": "agonize", "GPD2": "inhibit",
                     "NDUFA1": "inhibit"}.get(primary, "modulate")
        return ASSAY_RULES[primary], primary, direction, basis
    if primary and action in ACTION_FALLBACK_RULES:
        return (ACTION_FALLBACK_RULES[action] +
                f" — primary target {primary}"), primary, \
            {"INHIBITOR": "inhibit", "ANTAGONIST": "antagonize",
             "AGONIST": "agonize", "BLOCKER": "block"}.get(
                action, "modulate"), basis
    if kb_mech_class:
        return (f"assay class for KB class {kb_mech_class}: NOT in the "
                "rule table — UNRESOLVED (proposals are never invented)"), \
            None, "unknown", basis
    return ("UNRESOLVED — no cited mechanism row and no KB class; assay "
            "class NOT invented"), None, "unknown", basis


def _model_ladder(kb_mech_class, primary_target):
    ladder_key = CLASS_TO_LADDER.get(kb_mech_class or "")
    if ladder_key:
        return list(MODEL_SYSTEM_RULES[ladder_key]), \
            f"authored ladder rule {ladder_key}"
    # target-symbol fallback: biochemical proposal only; higher lanes
    # honestly left generic
    if primary_target:
        return ["cells: cell line or primary culture expressing the "
                "cited target (target from the OT mechanism row)",
                "tissue: disease-relevant primary-tissue preparation "
                "(to be specified by the experimenter)",
                "animal: species expressing the target ortholog "
                "(to be specified by the experimenter)"], \
            "target-symbol fallback rule (generic, honestly labelled)"
    return ["UNRESOLVED — no mechanism evidence; model systems are NOT "
            "invented"], "honest-absence rule"


def plan_for_drug(reg: ValidationRegistry, pack, row: dict,
                  disease_key: str, disease_name: str) -> dict:
    """Build a plan for one ranked (drug, disease) candidate row of the
    Phase 4 temporal benchmark (row fields carried, never recomputed)."""
    drug = row["drug"]
    d = pack.drugs[drug]
    status = row["status"]["status"]
    tier = row["status"]["tier"]
    moa = d.get("moa_rows") or []
    kb_class = d.get("kb_mech_class")
    assay, primary_target, direction, assay_basis = _assay_template(
        moa, kb_class)
    models, model_basis = _model_ladder(kb_class, primary_target)

    mech_text = (f"{drug} ({kb_class or 'no KB class'}): "
                 + "; ".join(
                     f"{r['action_type']} of {', '.join(r['target_symbols'])}"
                     for r in moa[:2] if r.get("target_symbols"))
                 or "no mechanism row")
    mech_tier = tier
    mech_sources = tuple(row["status"].get("source_ids") or ("SRC:OT_P4",))

    supporting = []
    for sid in row["status"].get("source_ids") or ["SRC:OT_P4"]:
        supporting.append({
            "kind": f"status row ({row['status']['note']})",
            "source_ids": [sid],
            "note": f"candidate status {status} served by the frozen "
                    "P4 pack",
        })
    if row.get("matched_channels"):
        supporting.append({
            "kind": "channel support (Phase 4 axes)",
            "source_ids": [s for s in row.get("sources") or ["SRC:KB_P4"]],
            "note": "matched disease channels: "
                    + ", ".join(row["matched_channels"]),
        })
    if moa:
        supporting.append({
            "kind": "mechanism-of-action rows",
            "source_ids": ["SRC:OT_P4"],
            "note": f"action {moa[0]['action_type']} on target "
                    f"{primary_target}",
        })

    contradictory = []
    bridge = row.get("bridge") or {}
    if bridge.get("finding") == "MECH_STRUCTURE_CONFLICT":
        contradictory.append({
            "kind": "MECH_STRUCTURE_CONFLICT",
            "source_ids": ["SRC:KB_P4"],
            "note": bridge.get("detail", ""),
        })
    if d.get("withdrawn_flag"):
        contradictory.append({
            "kind": "WITHDRAWN_DRUG",
            "source_ids": ["SRC:CHEMBL_P4"],
            "note": d.get("withdrawn_reason") or "withdrawn_flag set",
        })

    # datasets lane (P7-2): mechanical links + honest absences
    lnk = reg.study_ids_for(drug, disease_key)
    ct_accs = list(lnk["study_ids"]) if lnk and lnk["study_ids"] else []
    geo_rows = reg.geo_series_for(disease_key)
    geo_accs = []
    for g in geo_rows:
        geo_accs.extend(g["series_ids"])
    # CT source ids: derive from the query panels that served the
    # linked studies (each study carries its query_panels list)
    ct_panel_ids = set()
    for acc in ct_accs:
        for pid in reg.studies[acc].get("query_panels", []):
            ct_panel_ids.add("SRC:P7_CT_" + pid)
    ds_sources = sorted(ct_panel_ids |
                        {g["source_id"] for g in geo_rows})
    absence_notes = []
    if not ct_accs:
        absence_notes.append(
            "no linked CT.gov study for this drug x disease pair "
            "(token filter recorded in the registry; absence, not "
            "guessed)")
    datasets = {
        "lane": "P7-2 metadata + accession records only",
        "ct_accessions": ct_accs,
        "geo_accessions": geo_accs,
        "source_ids": sorted(set(ds_sources)),
        "specificity": (lnk or {}).get(
            "specificity", "NO_LINK_RECORDED"),
        "absence_note": ("; ".join(absence_notes) if absence_notes
                         else None),
        "results_note": "no results content exists in this lane; trial "
                        "outcomes must be fetched and adjudicated by a "
                        "researcher, never synthesized",
    }

    limits = list(pack.limits[:1]) + [
        "gate PROPOSED states are proposals, not results; the "
        "REGISTRY_ACTIVITY_PRESENT state (if any) is trial EXISTENCE "
        "metadata, never efficacy",
        "assay/model/endpoint proposals are authored rule-table "
        "outputs (COMPUTATIONAL tier) and must be protocol-reviewed "
        "before any experiment",
    ]

    plan = build_plan(
        reg,
        plan_id=f"PLAN:{drug.upper()}@{disease_key}",
        candidate={
            "id": drug, "kind": "DRUG",
            "status": status, "tier": tier,
            "chembl_id": d.get("chembl_id"),
            "first_approval": d.get("first_approval"),
            "rank": row.get("rank"), "aggregate": row.get("aggregate"),
            "aggregate_label": row.get("aggregate_label",
                                       "COMPUTATIONAL_RANK"),
        },
        disease_context={
            "disease_key": disease_key, "disease_name": disease_name,
            "kb_did": row.get("bridge", {}).get("kb_did"),
            "specificity": (lnk or {}).get(
                "specificity", "EXACT_DISEASE_CONTEXT"),
        },
        mechanism_narrative={
            "text": mech_text, "tier": mech_tier,
            "source_ids": list(mech_sources),
        },
        target_engagement={
            "primary_target": primary_target,
            "assay_class": assay,
            "direction": direction,
            "tier": "COMPUTATIONAL",
            "basis": assay_basis,
        },
        supporting_evidence=supporting,
        contradictory_evidence=contradictory,
        model_systems={"systems": models, "basis": model_basis,
                       "tier": "COMPUTATIONAL"},
        control_groups={
            "positive_control": "class-reference inhibitor/antagonist "
                                "recorded in the assay rule (cited "
                                "assay class)",
            "negative_control": "vehicle-only arm",
            "selectivity_control": "closely-related-target counter-screen "
                                   "(per assay rule)",
            "tier": "COMPUTATIONAL",
        },
        endpoints=[
            {"name": "target engagement (biochemical gate)",
             "assay_annotation": assay,
             "measurable": "concentration-response curve with a "
                           "reported IC50/EC50 from the RUN RECORD"},
            {"name": "functional read-through (cellular gate)",
             "assay_annotation": models[0] if models else assay,
             "measurable": "pathway readout shift vs vehicle with "
                           "pre-registered analysis"},
            {"name": "counter-screen (safety lane)",
             "assay_annotation": "closely-related-target panel per "
                                 "assay rule",
             "measurable": "selectivity window (fold) from the run "
                           "record"},
        ],
        failure_mechanisms=[
            "no engagement at achievable concentrations -> candidate "
            "fails the BIOCHEMICAL gate; the COMPUTATIONAL prediction "
            "is falsified for this target",
            "engagement without functional read-through -> fails the "
            "CELLULAR gate; mechanism link unsupported",
            "an unadjudicated MECH_STRUCTURE_CONFLICT stays on the "
            "record and caps the candidate below EVIDENCED ranking",
        ],
        stage_gates=_build_gates(reg, drug, disease_key),
        datasets=datasets,
        honest_limits=limits,
        current_status=status,
    )
    return plan


def plan_for_generated_molecule(reg: ValidationRegistry, mol: dict,
                                phase5_sha: str) -> dict:
    """Plan for a Phase 5 GENERATED_CANDIDATE (APXD-*): honest
    structural absence of any registry record; chem-lane gates."""
    mol_id = mol["mol_id"]
    laws = list(mol.get("laws_satisfied") or [])
    status = "COMPUTATIONAL_HYPOTHESIS"
    assay, primary, direction, _ = _assay_template([], None)
    assay = ("structure-law consistency lane: no target claim exists; "
             "assay class UNRESOLVED until a target is evidenced"
             if not primary else assay)
    plan = build_plan(
        reg,
        plan_id=f"PLAN:{mol_id}",
        candidate={
            "id": mol_id, "kind": "GENERATED_MOLECULE",
            "status": status, "tier": "COMPUTATIONAL",
            "smiles_canonical": mol.get("smiles_canonical")
                               or mol.get("smiles"),
            "laws_satisfied": laws,
            "novelty": mol.get("novelty"),
        },
        disease_context={
            "disease_key": None,
            "disease_name": None,
            "kb_did": None,
            "specificity": "NO_DISEASE_CONTEXT (structure-only "
                           "candidate; disease mapping not claimed)",
        },
        mechanism_narrative={
            "text": "generated molecule satisfying structure laws ["
                    + ", ".join(laws) + "] (rule-based structure layer)",
            "tier": "COMPUTATIONAL",
            "source_ids": [],
        },
        target_engagement={
            "primary_target": None,
            "assay_class": assay,
            "direction": "unknown",
            "tier": "COMPUTATIONAL",
            "basis": "honest absence: a generated candidate has NO "
                     "cited target; the engagement hypothesis is not "
                     "invented",
        },
        supporting_evidence=[{
            "kind": "structure-law consistency (Phase 5 generation)",
            "source_ids": ["SRC:KB_P4"],
            "note": f"law classes {laws} satisfied at generation time "
                    "(rule layer, no binding claim)",
        }],
        contradictory_evidence=[],
        model_systems={
            "systems": ["no model system proposed: without a target "
                        "hypothesis every model choice would be "
                        "invented"],
            "basis": "honest-absence rule", "tier": "COMPUTATIONAL"},
        control_groups={
            "positive_control": "UNRESOLVED (no target hypothesis)",
            "negative_control": "vehicle-only arm",
            "selectivity_control": "UNRESOLVED (no target hypothesis)",
            "tier": "COMPUTATIONAL",
        },
        endpoints=[{
            "name": "registration + identity confirmation (chem lane)",
            "assay_annotation": "structure verification (canonical "
                                "SMILES + fingerprint re-derivation) "
                                "with the pinned RDKit build",
            "measurable": "byte-identical re-derivation of the stored "
                          "fingerprint",
        }],
        failure_mechanisms=[
            "identity re-derivation mismatch -> candidate record "
            "invalidated",
            "a target is later claimed WITHOUT a cited mechanism row -> "
            "the claim is refused by the evidence gate (F3)",
        ],
        stage_gates=[
            {"gate": g, "state": GATE_PROPOSED,
             "basis": "generated molecule: no experimental record can "
                      "exist yet (structural absence, recorded)",
             "cited_source_ids": [], "registry_reference": None}
            for g in STAGE_GATES],
        datasets={
            "lane": "P7-2 metadata + accession records only",
            "ct_accessions": [], "geo_accessions": [],
            "source_ids": [],
            "specificity": "STRUCTURAL_ABSENCE",
            "absence_note": "ABS:APXD_NO_REGISTRY_RECORD — a generated "
                            "candidate cannot have registry records",
            "results_note": "no results content exists in this lane",
        },
        honest_limits=[
            "the molecule is a research candidate (COMPUTATIONAL tier); "
            "no binding, activity, safety or clinical claim is made",
            f"candidate ids and structures come from the frozen Phase 5 "
            f"artifact (sha256 {phase5_sha[:16]}…); regenerating the "
            "artifact under the pinned RDKit re-derives them "
            "identically (phase-5 theorems)",
            "plans for generated molecules exist to TEST the hypothesis "
            "chain, never to assert it",
        ],
        current_status=status,
    )
    return plan


# =====================================================================
# plan universe (deterministic over the frozen packs)
# =====================================================================

APXD_UNIVERSE_N = 3
DRUG_TOP_N = 3


def plan_universe(pack, kbench) -> list:
    """Deterministic candidate universe: per panel disease — the top
    DRUG_TOP_N ranked rows + every truth-pair drug (dedup), then the
    top APXD_UNIVERSE_N emitted molecules of the frozen Phase 5
    artifact."""
    universe = []
    for key in sorted(kbench["per_disease"]):
        p = kbench["per_disease"][key]
        seen = set()
        for r in p["rows"][:DRUG_TOP_N]:
            if r["drug"] not in seen:
                seen.add(r["drug"])
                universe.append((r, key))
        for t in p["truth_pairs"]:
            if t["drug"] not in seen:
                for r in p["rows"]:
                    if r["drug"] == t["drug"]:
                        seen.add(t["drug"])
                        universe.append((r, key))
                        break
                else:
                    raise RuntimeError(
                        f"truth drug {t['drug']} missing from {key} rows")
    universe.sort(key=lambda x: (x[1], x[0]["drug"]))
    return universe


def load_apxd_universe() -> list:
    with open(PHASE5_BENCH_PATH, encoding="utf-8") as fh:
        bench5 = json.load(fh)
    emitted = [m for m in bench5["molecules"] if not m.get("rejected")]
    emitted.sort(key=lambda m: m["mol_id"])
    return emitted[:APXD_UNIVERSE_N], bench5


# =====================================================================
# theorems (standard shape)
# =====================================================================

def _th(name, proved, steps, stats, counterexamples=None):
    return {"theorem": name, "proved": bool(proved),
            "tier": "PROVEN_MATH", "proof_steps": steps,
            "stats": stats, "counterexamples": counterexamples or []}


def theorem_plan_schema_completeness(reg, plans):
    # Sections that must be NON-EMPTY. contradictory_evidence is
    # deliberately exempt: an empty contradiction list is the honest
    # report of "no contradiction found". datasets lists may be empty
    # only with an explicit absence note (build-gate enforced).
    nonempty_required = tuple(s for s in REQUIRED_SECTIONS
                              if s != "contradictory_evidence")
    missing = []
    for p in plans:
        for sec in nonempty_required:
            if sec not in p or p[sec] is None or p[sec] == "" or \
                    p[sec] == {}:
                missing.append((p["plan_id"], sec))
        if not isinstance(p.get("contradictory_evidence"), list):
            missing.append((p["plan_id"], "contradictory_evidence(type)"))
    evidenced = [p for p in plans
                 if p["candidate"]["tier"] in ("PROVEN_MATH", "EVIDENCED")]
    injections = []
    if plans:
        bad = dict(plans[0])
        bad["endpoints"] = None                # missing-section lane
        try:
            build_plan(reg, plan_id="INJ:null-endpoints",
                       **{k: v for k, v in bad.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
            injections.append("null-section plan was ACCEPTED")
        except PlanBuildError:
            pass
        bad2 = dict(plans[0])
        bad2["endpoints"] = [{"name": "x"}]     # no assay annotation
        try:
            build_plan(reg, plan_id="INJ:unannotated-endpoint",
                       **{k: v for k, v in bad2.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
            injections.append("unannotated-endpoint plan was ACCEPTED")
        except PlanBuildError:
            pass
    stats = {"plans": len(plans), "evidenced_plans": len(evidenced),
             "missing_sections": len(missing),
             "injection_failures": [x for x in injections if x]}
    return _th("theorem_plan_schema_completeness", not missing
               and not stats["injection_failures"],
               ["schema: every plan carries the 15 required sections",
                "EVIDENCED+ subset checked for complete evidence rows",
                "negative control: a section-missing plan is refused at "
                "construction",
                "negative control: an unannotated endpoint is refused"],
               stats, missing)


def theorem_stage_gate_ordering(reg, plans):
    violations = []
    for p in plans:
        states = [g["state"] for g in p["stage_gates"]]
        completed_idx = [i for i, s in enumerate(states)
                         if s == GATE_COMPLETED]
        if completed_idx:
            lo, hi = min(completed_idx), max(completed_idx)
            if hi - lo + 1 != len(completed_idx) or lo != 0:
                violations.append((p["plan_id"], "non-prefix completion"))
    injections = []
    if plans:
        bad = json.loads(json.dumps(plans[0]))
        bad["stage_gates"] = [
            {"gate": g["gate"], "state": GATE_PROPOSED, "basis": "x",
             "cited_source_ids": [], "registry_reference": None}
            for g in STAGE_GATES and bad["stage_gates"]]
        # inject an out-of-order completion: ANIMAL completed, HUMAN not
        gates = bad["stage_gates"]
        by_name = {g["gate"]: g for g in gates}
        by_name["ANIMAL"]["state"] = GATE_COMPLETED
        by_name["ANIMAL"]["cited_source_ids"] = ["SRC:OT_P4"]
        by_name["BIOCHEMICAL"]["state"] = GATE_PROPOSED
        try:
            build_plan(reg, plan_id="INJ:gate-order",
                       **{k: v for k, v in bad.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
            injections.append("out-of-order completion was ACCEPTED")
        except PlanBuildError:
            pass
        # inject a no-citation completion
        bad2 = json.loads(json.dumps(plans[0]))
        g0 = bad2["stage_gates"][0]
        g0["state"] = GATE_COMPLETED
        g0["cited_source_ids"] = []
        try:
            build_plan(reg, plan_id="INJ:gate-nocite",
                       **{k: v for k, v in bad2.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
            injections.append("uncited completion was ACCEPTED")
        except PlanBuildError:
            pass
    stats = {"plans": len(plans), "violations": len(violations),
             "injection_failures": injections,
             "gate_ladder": list(STAGE_GATES)}
    return _th("theorem_stage_gate_ordering", not violations
               and not injections,
               ["canonical 5-gate ladder fixed in order",
                "completion states must form a prefix chain",
                "negative control: out-of-order completion refused",
                "negative control: uncited completion refused"],
               stats, violations)


def theorem_evidence_citation_completeness(reg, plans):
    unresolved = []
    checked = 0
    for p in plans:
        for sec in ("supporting_evidence", "contradictory_evidence"):
            for ev in p[sec]:
                for sid in ev["source_ids"]:
                    checked += 1
                    if reg.resolve(sid) is None:
                        unresolved.append((p["plan_id"], sid))
    # datasets lane too
    for p in plans:
        for sid in p["datasets"]["source_ids"]:
            checked += 1
            if reg.resolve(sid) is None:
                unresolved.append((p["plan_id"], sid))
    injections = []
    if plans:
        bad = json.loads(json.dumps(plans[0]))
        bad["supporting_evidence"].append({
            "kind": "injected", "source_ids": ["SRC:DOES_NOT_EXIST"],
            "note": "fabricated"})
        try:
            build_plan(reg, plan_id="INJ:unknown-source",
                       **{k: v for k, v in bad.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
            injections.append("unresolvable evidence id was ACCEPTED")
        except PlanBuildError:
            pass
    stats = {"plans": len(plans), "evidence_ids_checked": checked,
             "unresolved": len(unresolved),
             "injection_failures": injections,
             "ledgers": sorted(["P7"] + list(reg._extra_ledgers.keys()))}
    return _th("theorem_evidence_citation_completeness", not unresolved
               and not injections,
               ["every evidence id resolved against P4/P7/P8 ledgers",
                "datasets source ids resolved",
                "negative control: an unknown id is refused at build"],
               stats, unresolved)


def theorem_no_results_synthesis(reg, plans):
    token_hits = []
    for p in plans:
        token_hits.extend(_scan_forbidden(p))
    reg_blob = json.dumps({
        "studies": reg.studies, "series": reg.series,
        "links": reg.links, "geo_links": reg.geo_links})
    reg_hits = []
    for tok in FORBIDDEN_RESULT_TOKENS:
        if tok.lower() in reg_blob.lower():
            reg_hits.append(tok)
    # structural check of the connector source (whitelist enforcement):
    # parse the module AST and verify that (a) the module whitelist is
    # a 6-tuple containing no outcomes/results module, and (b) the
    # request fields are built FROM that whitelist (so the payload
    # cannot carry results content at fetch time).
    import ast as _ast
    ct_src = open(os.path.join(ROOT, "v15", "connectors",
                               "clinicaltrials.py"),
                  encoding="utf-8").read()
    tree = _ast.parse(ct_src)
    allowed = None
    for node in tree.body:
        if isinstance(node, _ast.Assign) and \
                getattr(node.targets[0], "id", "") == "_ALLOWED_MODULES":
            allowed = [e.value for e in node.value.elts]
    fields_from_whitelist = (
        '_FIELDS = "|".join(f"protocolSection.{m}" for m in '
        '_ALLOWED_MODULES)') in ct_src
    whitelist_ok = (
        allowed is not None and len(allowed) == 6
        and not any(("outcome" in a.lower() or "result" in a.lower())
                    for a in allowed)
        and fields_from_whitelist)
    injections = []
    if plans:
        bad = json.loads(json.dumps(plans[0]))
        bad["endpoints"] = list(bad["endpoints"]) + [{
            "name": "injected", "assay_annotation": "ok",
            "measurable": "primaryOutcome effectSize reported"}]
        try:
            build_plan(reg, plan_id="INJ:results-token",
                       **{k: v for k, v in bad.items()
                          if k not in ("plan_id",
                                       "required_evidence_to_change_status")})
            injections.append("results-token plan was ACCEPTED")
        except PlanBuildError:
            pass
    stats = {"plans": len(plans), "plan_token_hits": len(token_hits),
             "registry_token_hits": reg_hits,
             "connector_whitelist_enforced": bool(whitelist_ok),
             "injection_failures": injections,
             "registry_absences_recorded": len(reg.absences)}
    return _th("theorem_no_results_synthesis", not token_hits
               and not reg_hits and not injections
               and whitelist_ok,
               ["registry structural check: CT.gov fields whitelist "
                "makes results content absent at fetch time",
                "registry self-validation scan over the frozen pack",
                "plan build-gate forbidden-token scan",
                "negative control: a results-token endpoint is refused"],
               stats, token_hits)


def theorem_status_transition_discipline(reg, plans):
    bad_rules = []
    for p in plans:
        tr = p["required_evidence_to_change_status"]
        if tr["from"] != p["candidate"]["status"]:
            bad_rules.append(p["plan_id"])
        if tr["to"] not in STATUS_ORDER:
            bad_rules.append(p["plan_id"])
        if not tr["evidence_classes"] or not tr["never_by_computation"]:
            bad_rules.append(p["plan_id"])
    raised = False
    if plans:
        try:
            attempt_status_upgrade(plans[0])
        except PlanBuildError:
            raised = True
    # monotone check: every declared 'to' is not weaker than 'from'
    weaker = []
    for p in plans:
        tr = p["required_evidence_to_change_status"]
        if STATUS_ORDER.index(tr["to"]) < \
                STATUS_ORDER.index(tr["from"]):
            weaker.append(p["plan_id"])
    stats = {"plans": len(plans), "malformed_rules": len(bad_rules),
             "upgrade_path_raises": raised,
             "downgrade_declarations": len(weaker)}
    return _th("theorem_status_transition_discipline", not bad_rules
               and raised and not weaker,
               ["every plan declares from/to/evidence_classes",
                "declared transitions are never weaker than current",
                "the upgrade code path attempt_status_upgrade always "
                "raises (no computation can upgrade a status)"],
               stats, bad_rules)


def theorem_plan_determinism(reg, pack, kbench, apxd, phase5_sha):
    universe = plan_universe(pack, kbench)

    def build_all():
        out = []
        for row, key in universe:
            pname = kbench["per_disease"][key]["disease"]
            out.append(plan_for_drug(reg, pack, row, key, pname))
        for mol in apxd:
            out.append(plan_for_generated_molecule(reg, mol, phase5_sha))
        out.sort(key=lambda p: p["plan_id"])
        return out
    a = build_all()
    b = build_all()
    da = sha256_text(json.dumps(a, sort_keys=True))
    db = sha256_text(json.dumps(b, sort_keys=True))
    # no wall-clock fields anywhere
    wall = []
    def scan(o, path=""):
        if isinstance(o, dict):
            for k, v in o.items():
                kp = f"{path}.{k}"
                if any(t in k.lower() for t in
                       ("utc", "timestamp", "now", "today")):
                    wall.append(kp)
                scan(v, kp)
        elif isinstance(o, list):
            for i, v in enumerate(o):
                scan(v, f"{path}[{i}]")
    scan(a)
    stats = {"plans": len(a), "sha_build1": da[:16],
             "sha_build2": db[:16], "identical": da == db,
             "wall_clock_fields": len(wall)}
    return _th("theorem_plan_determinism", da == db and not wall,
               ["two independent builds over the frozen inputs",
                "canonical-json sha256 comparison per build",
                "key scan: no wall-clock field exists in any plan"],
               stats)


def theorem_out_of_domain_detection(reg, pack):
    absences = {}
    ghost_drug = reg.study_ids_for("notarealdrug", "CKD")
    absences["ghost_drug_link"] = ghost_drug is None
    ghost_geo = reg.geo_series_for("NOT_A_DISEASE")
    absences["ghost_disease_geo"] = ghost_geo == []
    ghost_plan_probe = None
    try:
        # a rank row for an unknown drug cannot exist; probing the
        # pack raises (dict lookup), so the honest answer is an
        # explicit absence object, never an invented plan
        pack.drugs["notarealdrug"]
        ghost_plan_probe = "PACK_SERVED_GHOST_ROW"
    except KeyError:
        ghost_plan_probe = "EXPLICIT_KEYERROR"
    absences["ghost_plan_probe"] = ghost_plan_probe
    ok = (absences["ghost_drug_link"] and absences["ghost_disease_geo"]
          and ghost_plan_probe == "EXPLICIT_KEYERROR")
    stats = {"probes": 3, "fabrications": 0,
             "honest_refusal": ok, "ghost_drug_link_absent":
                 absences["ghost_drug_link"],
             "ghost_disease_geo_absent": absences["ghost_disease_geo"],
             "ghost_plan_probe": ghost_plan_probe}
    return _th("theorem_out_of_domain_detection", ok,
               ["dataset links: unknown drug -> None (no link invented)",
                "GEO links: unknown disease -> empty (no series invented)",
                "plan path: unknown drug -> explicit KeyError, no plan"],
               stats)


# =====================================================================
# Module F run (benchmark input for the artifacts writer)
# =====================================================================

def run_module_f(verbose: bool = True) -> dict:
    from .repurposing import load_pack, benchmark_temporal
    from .kgraph import load_kgraph

    def log(m):
        if verbose:
            print(f"[Module F] {m}")

    pack = load_pack()
    kbench = benchmark_temporal(pack, k=10)
    reg = _registry_with_ledgers(pack)
    apxd, bench5 = load_apxd_universe()
    import hashlib
    phase5_sha = hashlib.sha256(
        open(PHASE5_BENCH_PATH, "rb").read()).hexdigest()
    log(f"registry: {len(reg.studies)} CT.gov studies / "
        f"{len(reg.series)} GEO series, "
        f"{len(reg.absences)} recorded absences")
    log(f"universe: {len(plan_universe(pack, kbench))} drug x disease "
        f"pairs + {len(apxd)} generated molecules")

    plans = []
    for row, key in plan_universe(pack, kbench):
        pname = kbench["per_disease"][key]["disease"]
        plans.append(plan_for_drug(reg, pack, row, key, pname))
    for mol in apxd:
        plans.append(plan_for_generated_molecule(reg, mol, phase5_sha))
    plans.sort(key=lambda p: p["plan_id"])
    log(f"plans built: {len(plans)}")

    theorems = {
        "F1": theorem_plan_schema_completeness(reg, plans),
        "F2": theorem_stage_gate_ordering(reg, plans),
        "F3": theorem_evidence_citation_completeness(reg, plans),
        "F4": theorem_no_results_synthesis(reg, plans),
        "F5": theorem_status_transition_discipline(reg, plans),
        "F6": theorem_plan_determinism(reg, pack, kbench, apxd,
                                       phase5_sha),
        "F7": theorem_out_of_domain_detection(reg, pack),
    }

    evidenced_plans = [p for p in plans
                       if p["candidate"]["tier"] in
                       ("PROVEN_MATH", "EVIDENCED")]
    gates_registry = sum(
        1 for p in plans for g in p["stage_gates"]
        if g["state"] == GATE_REGISTRY)
    return {
        "module": "APEIRON-X v15 Module F — experimental-validation "
                  "intelligence (Phase 7)",
        "schema_version": SCHEMA_VERSION,
        "plan_label": PLAN_LABEL,
        "registry": {
            "studies": len(reg.studies),
            "series": len(reg.series),
            "absences": len(reg.absences),
            "sources": len(reg._vd.SOURCE_RECORDS_P7),
            "frozen_utc": reg.frozen_utc,
            "validation_data_sha256": reg.data_sha256,
            "pin_sha256": reg.pins.get("validation_data_sha256"),
        },
        "plans": plans,
        "plan_count": len(plans),
        "evidenced_plan_count": len(evidenced_plans),
        "gate_registry_states": gates_registry,
        "phase5_artifact_sha256": phase5_sha,
        "theorems": theorems,
        "all_proved": all(t["proved"] for t in theorems.values()),
    }
