# =====================================================================
# APEIRON-X v15 — FROZEN ADDITIVE VOCABULARY TABLES (P2-1, Module A)
# ---------------------------------------------------------------------
# This data module EXTENDS (never replaces) the v14.1 channel
# vocabulary with standard-biology identifier tables:
#   * DISEASE_ONTOLOGY : MONDO records + ICD-10 / MeSH / OMIM xrefs
#   * GENE_TABLE       : HGNC / Ensembl / UniProt identifiers
#   * PATHWAY_ONTOLOGY : (empty this round — see HONEST_LIMITS)
#   * PHENOTYPE_HPO    : (empty this round — see HONEST_LIMITS)
#
# DOCTRINE (V15_IMPLEMENTATION_PLAN P0):
#   1. Every row below was machine-verified against its source REST API
#      on FROZEN_UTC. Nothing is hand-invented; identifiers that failed
#      verification were DROPPED (e.g. a wrong MONDO id for rheumatoid
#      arthritis was caught and excluded by the verification run).
#   2. This module is FROZEN: after authoring, its sha256 is pinned in
#      v15/kb_extensions/vocab_pins.json and v15.vocab.load_vocab()
#      refuses to serve data on a hash mismatch. Any edit means a
#      documented re-freeze.
#   3. These tables are v15-only: no v14.1 derivation engine imports
#      them (the C0 hermeticity doctrine of the correspondence core is
#      untouched; KB_MODULES stays exactly as it was).
#   4. Coverage is PARTIAL by design and reported honestly: see
#      HONEST_LIMITS. Absent mappings are reported as absent.
# =====================================================================

from datetime import datetime, timezone

VOCAB_SCHEMA_VERSION = "15.2.0"

FROZEN_UTC = "2026-11-24T00:00:00Z"   # authoring/verification timestamp
MONDO_OLS_VERSION = "2026-11-03"      # MONDO release as served by EBI OLS4

# ---------------------------------------------------------------------
# Resource-level provenance (master prompt §4: source id, version,
# retrieval date, license, evidence type). Per-row citations reference
# these keys.
# ---------------------------------------------------------------------
SOURCE_RECORDS = {
    "SRC:MONDO_OLS": {
        "resource": "Mondo Disease Ontology via EBI OLS4 API",
        "resource_version": MONDO_OLS_VERSION,
        "retrieval_utc": "2026-11-24T00:00:00Z",
        "url": "https://www.ebi.ac.uk/ols4/api/ontologies/mondo/terms",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_verified_label_and_xrefs",
        "limitations": "cross-references (ICD10/MeSH/OMIM) are the ones the "
                       "MONDO release itself carries; no independent re-"
                       "resolution against WHO ICD-11 or NLM MeSH APIs",
    },
    "SRC:HGNC_REST": {
        "resource": "HUGO Gene Nomenclature Committee REST API",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://rest.genenames.org/fetch/symbol/{symbol}",
        "license": "unrestricted academic use (HGNC data policy)",
        "evidence_type": "annotation",
        "confidence": "machine_verified_symbol_report",
        "limitations": "identifier-level record only; no locus/sequence data ingested",
    },
    "SRC:UNIPROT_REST": {
        "resource": "UniProtKB REST API (reviewed SwissProt entries)",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://rest.uniprot.org/uniprotkb/search",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_verified_reviewed_entry",
        "limitations": "accession-level record only",
    },
    "SRC:ICD10_CODING_INDEX": {
        "resource": "ICD-10-CM coding index (icd10data.com, cross-checked "
                    "against MONDO xrefs where present)",
        "resource_version": "2026 release pages, snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://www.icd10data.com/",
        "license": "SEE_TERMS (coding reference; WHO ICD-10 is the "
                   "underlying classification)",
        "evidence_type": "annotation",
        "confidence": "web_verified_secondary_source",
        "limitations": "used only where MONDO carries no ICD xref "
                       "(bacterial vaginosis, periapical abscess)",
    },
}

# ---------------------------------------------------------------------
# DISEASE_ONTOLOGY: disease name -> verified MONDO record.
# kb_link: the v14.1 disease id this record anchors (existing row) or
#          the growth-pack row it will anchor (P2-3 pack D64-D68).
# tier: ClaimTier-compatible label for the MAPPING (not for biology).
# ---------------------------------------------------------------------
DISEASE_ONTOLOGY = {
    "impetigo": {
        "mondo_id": "MONDO:0004592",
        "label_ols": "impetigo",
        "xrefs": ["ICD10WHO:L01", "ICD10CM:L01", "ICD10CM:L01.0",
                  "MESH:D007169", "ICD9:684"],
        "sources": ("SRC:MONDO_OLS",),
        "tier": "EVIDENCED",
        "kb_link": "D64",
        "note": "contagious bacterial cutaneous infection (Staphylococcus "
                "aureus / Streptococcus pyogenes)",
    },
    "purulent acute otitis media": {
        "mondo_id": "MONDO:0001031",
        "label_ols": "purulent acute otitis media",
        "xrefs": ["ICD10CM:H66.0", "ICD9:382.02"],
        "sources": ("SRC:MONDO_OLS",),
        "tier": "EVIDENCED",
        "kb_link": "D65",
        "note": "bacterial/acute suppurative middle-ear infection; the KB "
                "row anchors on the bacterial (suppurative) form",
    },
    "bacterial vaginosis": {
        "mondo_id": "MONDO:0005316",
        "label_ols": "bacterial vaginosis",
        "xrefs": ["MESH:D016585"],
        "icd10cm_secondary_source": "N76.0",
        "sources": ("SRC:MONDO_OLS", "SRC:ICD10_CODING_INDEX"),
        "tier": "EVIDENCED",
        "kb_link": "D66",
        "note": "infection caused by bacterial overgrowth in the vagina "
                "(polymicrobial anaerobic dysbiosis)",
    },
    "suppurative periapical periodontitis": {
        "mondo_id": "MONDO:0006989",
        "label_ols": "suppurative periapical periodontitis",
        "xrefs": ["MESH:D010482"],
        "icd10cm_secondary_source": "K04.7",
        "sources": ("SRC:MONDO_OLS", "SRC:ICD10_CODING_INDEX"),
        "tier": "EVIDENCED",
        "kb_link": "D67",
        "note": "dentoalveolar (periapical) abscess — polymicrobial "
                "anaerobic odontogenic infection",
    },
    "preeclampsia": {
        "mondo_id": "MONDO:0005081",
        "label_ols": "preeclampsia",
        "xrefs": ["ICD10CM:O14", "MESH:D011225", "ICD9:642.4"],
        "sources": ("SRC:MONDO_OLS",),
        "tier": "EVIDENCED",
        "kb_link": "D68",
        "note": "KB row anchors on PRE-ECLAMPSIA PROPHYLAXIS (low-dose "
                "aspirin for high-risk women), an indicated use of the "
                "preeclampsia record",
    },
    "type 2 diabetes mellitus": {
        "mondo_id": "MONDO:0005148",
        "label_ols": "type 2 diabetes mellitus",
        "xrefs": ["ICD10WHO:E11", "ICD10CM:E11", "MESH:D003924",
                  "OMIM:125853"],
        "sources": ("SRC:MONDO_OLS",),
        "tier": "EVIDENCED",
        "kb_link": "D08",
        "note": "existing KB row (v11.1 corpus)",
    },
    "hypertensive disorder": {
        "mondo_id": "MONDO:0005044",
        "label_ols": "hypertensive disorder",
        "xrefs": ["ICD10CM:I10-I16", "ICD10CM:I15", "MESH:D006973",
                  "ICD9:401-405"],
        "sources": ("SRC:MONDO_OLS",),
        "tier": "EVIDENCED",
        "kb_link": "D01",
        "note": "parent-class record verified for essential hypertension "
                "D01; MONDO xrefs of the parent are recorded verbatim",
    },
    "asthma": {
        "mondo_id": "MONDO:0004979",
        "label_ols": "asthma",
        "xrefs": ["ICD10WHO:J45", "ICD10CM:J45", "MESH:D001249",
                  "ICD9:493"],
        "sources": ("SRC:MONDO_OLS",),
        "tier": "EVIDENCED",
        "kb_link": "D15",
        "note": "existing KB rows D15/D16",
    },
}

# ---------------------------------------------------------------------
# GENE_TABLE: HGNC symbol -> verified identifier record. drug_links are
# the v14.1 mechanism classes whose listed drugs act on the gene product
# (pharmacological tractability anchor; tier = EVIDENCED for the
# identifier, the drug-target relationship is carried by the KB class
# itself and will receive external literature citations via the Phase 3
# connectors).
# ---------------------------------------------------------------------
GENE_TABLE = {
    "SLC5A2": {
        "hgnc_id": "HGNC:11037",
        "ensembl": "ENSG00000140675",
        "uniprot": "P31639",
        "name": "solute carrier family 5 member 2",
        "prev_symbol": "SGLT2",
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": ("SGLT2_INHIBITOR",),
        "kb_dids": ("D02", "D08", "D61"),
        "note": "sodium/glucose cotransporter 2 — molecular target of the "
                "SGLT2_INHIBITOR class (empagliflozin, dapagliflozin)",
    },
    "HMGCR": {
        "hgnc_id": "HGNC:5006",
        "ensembl": "ENSG00000113161",
        "uniprot": "P04035",
        "name": "3-hydroxy-3-methylglutaryl-CoA reductase",
        "prev_symbol": None,
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": ("HMGCR_INHIBITOR",),
        "kb_dids": ("D05",),
        "note": "rate-limiting enzyme of cholesterol biosynthesis — target "
                "of the statin class",
    },
    "PCSK9": {
        "hgnc_id": "HGNC:20001",
        "ensembl": None,
        "ensembl_absent_reason": "not captured this round; absent, not guessed",
        "uniprot": "Q8NBP7",
        "name": "proprotein convertase subtilisin/kexin type 9",
        "prev_symbol": "HCHOLA3",
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": (),         # no PCSK9-antibody class in the KB yet
        "kb_dids": (),
        "note": "verified for Phase 3 target-discovery benchmarking "
                "(guideline-recognized target, no KB drug class yet)",
    },
    "CFTR": {
        "hgnc_id": "HGNC:1884",
        "ensembl": None,
        "ensembl_absent_reason": "not captured this round; absent, not guessed",
        "uniprot": "P13569",
        "name": "CF transmembrane conductance regulator",
        "prev_symbol": None,
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": (),
        "kb_dids": (),
        "note": "verified for the Phase 3 benchmark (CFTR modulators)",
    },
    "EGFR": {
        "hgnc_id": "HGNC:3236",
        "ensembl": "ENSG00000146648",
        "uniprot": "P00533",
        "name": "epidermal growth factor receptor",
        "prev_symbol": "ERBB; ERBB1; HER1",
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": ("EGFR_TYROSINE_KINASE_INHIBITOR",),
        "kb_dids": ("D51",),
        "note": "target of the EGFR TKI class (osimertinib, gefitinib, "
                "erlotinib, afatinib)",
    },
    "PTGS1": {
        "hgnc_id": "HGNC:9604",
        "ensembl": "ENSG00000095303",
        "uniprot": "P23219",
        "name": "prostaglandin-endoperoxide synthase 1",
        "prev_symbol": "COX1",
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": ("COX1_PLATELET_INHIBITOR",),
        "kb_dids": ("D06", "D68"),
        "note": "COX-1 — target of irreversible platelet COX1 inhibitors "
                "(aspirin; low-dose aspirin pre-eclampsia prophylaxis D68)",
    },
    "ACE": {
        "hgnc_id": "HGNC:2707",
        "ensembl": "ENSG00000159640",
        "uniprot": "P12821",
        "name": "angiotensin I converting enzyme",
        "prev_symbol": "DCP; DCP1",
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": ("ACEI_RAAS",),
        "kb_dids": ("D01", "D02"),
        "note": "target of the ACE-inhibitor RAAS class",
    },
    "ABL1": {
        "hgnc_id": "HGNC:76",
        "ensembl": "ENSG00000097007",
        "uniprot": "P00519",
        "name": "ABL proto-oncogene 1, non-receptor tyrosine kinase",
        "prev_symbol": "ABL; JTK7",
        "sources": ("SRC:HGNC_REST", "SRC:UNIPROT_REST"),
        "tier": "EVIDENCED",
        "class_links": ("BCR_ABL_TYROSINE_KINASE_INHIBITOR",),
        "kb_dids": ("D50",),
        "note": "BCR-ABL fusion kinase moiety — target of the TKI class "
                "in chronic myeloid leukaemia",
    },
}

# ---------------------------------------------------------------------
# HONEST LIMITS: tables deferred rather than guessed (master prompt
# strict rule: absent data is reported as absent, with the field named).
# ---------------------------------------------------------------------
PATHWAY_ONTOLOGY = {}
PATHWAY_ONTOLOGY_LIMITS = (
    "Numeric Reactome (R-HSA-*) / KEGG (hsa*) identifiers for the 57 "
    "PW_* channel values are NOT included in this round: none were "
    "machine-verified, and the closed-world doctrine forbids guessing. "
    "They arrive in Phase 3 (P3-4 connector skeleton with the "
    "frozen-response pattern) which fetches and freezes real records "
    "with retrieval metadata."
)

PHENOTYPE_HPO = {}
PHENOTYPE_HPO_LIMITS = (
    "HPO phenotype term ids are deferred to a later growth round for the "
    "same reason: no machine-verified records this round. The "
    "DiseaseProfile field 'progression' can already carry phenotype "
    "STRINGS with citations; numeric HPO ids were not fabricated."
)

COVERAGE_NOTES = {
    "diseases_with_verified_ontology_records": len(DISEASE_ONTOLOGY),
    "diseases_total_kb": 63,            # v14.1 corpus at authoring time
    "genes_verified": len(GENE_TABLE),
    "pathway_ids_verified": 0,
    "hpo_ids_verified": 0,
}


def validate_vocab_module() -> list:
    """Structural self-validation: every record complete + cited."""
    problems = []
    for name, rec in DISEASE_ONTOLOGY.items():
        for key in ("mondo_id", "label_ols", "xrefs", "sources", "tier",
                    "kb_link"):
            if key not in rec or not rec[key]:
                problems.append(f"DISEASE_ONTOLOGY[{name}]: missing {key}")
        for s in rec.get("sources", ()):
            if s not in SOURCE_RECORDS:
                problems.append(f"DISEASE_ONTOLOGY[{name}]: unknown source {s}")
    for sym, rec in GENE_TABLE.items():
        for key in ("hgnc_id", "uniprot", "sources", "tier"):
            if key not in rec or not rec[key]:
                problems.append(f"GENE_TABLE[{sym}]: missing {key}")
        for s in rec.get("sources", ()):
            if s not in SOURCE_RECORDS:
                problems.append(f"GENE_TABLE[{sym}]: unknown source {s}")
        if not rec.get("ensembl") and not rec.get("ensembl_absent_reason"):
            # recorded absence is allowed but must be deliberate
            problems.append(f"GENE_TABLE[{sym}]: ensembl absent without "
                            "an explicit absence note")
    return problems
