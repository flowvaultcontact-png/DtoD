# =====================================================================
# APEIRON-X v15 — FROZEN TARGET EVIDENCE TABLE (P3-1, Module B)
# ---------------------------------------------------------------------
# This module is the Phase 3 counterpart of `v15/vocab_data.py`: a
# FROZEN, hash-pinned table of biological target evidence, authored
# VERBATIM from machine-verified connector fetches
# (`v15/connectors/refresh_phase3_cache.py --live`, cache under
# `v15/cache/`, audit values in `v15/out/phase3_verified_values.json`).
#
# DOCTRINE (V15_IMPLEMENTATION_PLAN P0 / §4):
#   1. Every identifier (HGNC / UniProt / Ensembl), disease id (MONDO/
#      HP as served by Open Targets), association datatype score,
#      Reactome stable id and literature citation below was fetched
#      from its REST/GraphQL API on FROZEN_UTC and stored byte-exact.
#      Nothing is hand-invented; anything that failed verification is
#      recorded as an ABSENCE (see HONEST_LIMITS / absence notes).
#   2. This module is FROZEN: after authoring, its sha256 is pinned in
#      `v15/kb_extensions/targets_pins.json`; `v15.targets.load_targets()`
#      refuses to serve data on a mismatch. Edits mean a documented
#      re-freeze, never a silent edit.
#   3. v15-only: no v14.1 derivation engine imports this module (C0
#      hermeticity untouched).
#   4. Evidence-kind mapping from Open Targets datatypes is CONSERVATIVE
#      and documented in OT_DATATYPE_KIND_MAP: genetic/literature
#      association evidence becomes kind "association" (never causal),
#      animal-model perturbation becomes "functional_perturbation",
#      clinical/known-drug becomes "drug_binding", somatic mutation
#      becomes "causal_variant" (driver biology, oncology context).
#      Causal-variant rows additionally carry a specific literature
#      citation wherever this freeze could verify one.
# =====================================================================

TARGET_SCHEMA_VERSION = "15.3.0"
FROZEN_UTC = "2026-11-24T17:13:44Z"   # verification window end (UTC)

# ---------------------------------------------------------------------
# Resource-level provenance (master prompt §4 shape). Row-level sources
# cite these keys. Internal KB rows are cited as "KB:Dxx" and are
# resolvable through INTERNAL_SOURCE_RECORDS below.
# ---------------------------------------------------------------------
SOURCE_RECORDS = {
    "SRC:OT_P3": {
        "resource": "Open Targets Platform GraphQL API",
        "resource_version": "live schema verified by introspection " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://api.platform.opentargets.org/api/v4/graphql",
        "license": "CC-BY-4.0 (opentargets.org licensing; datasource terms)",
        "evidence_type": "annotation",
        "confidence": "machine_fetched_association_rows_verbatim",
        "limitations": "association pages are the top-150 rows per disease "
                       "(count fields record the full universe); the newer "
                       "schema exposes associations disease->target only; "
                       "datatype ids carried verbatim",
    },
    "SRC:HGNC_P3": {
        "resource": "HUGO Gene Nomenclature Committee REST API",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://rest.genenames.org/fetch/symbol/{symbol}",
        "license": "unrestricted academic use (HGNC data policy)",
        "evidence_type": "annotation",
        "confidence": "machine_verified_symbol_report",
        "limitations": "identifier-level record only",
    },
    "SRC:UNIPROT_P3": {
        "resource": "UniProtKB REST API (reviewed Swiss-Prot entries)",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://rest.uniprot.org/uniprotkb/{acc}.json",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_verified_reviewed_entry",
        "limitations": "accession-level record only",
    },
    "SRC:REACTOME_P3": {
        "resource": "Reactome Content Service (pathway search)",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://reactome.org/ContentService/search/query",
        "license": "CC-BY-4.0",
        "evidence_type": "annotation",
        "confidence": "machine_fetched_search_results_verbatim",
        "limitations": "mapping PW_* -> R-HSA-* chosen by documented "
                       "token filter on the fetched labels (see REACTOME "
                       "notes); absent matches recorded as absent",
    },
    "SRC:EPMC_P3": {
        "resource": "Europe PMC REST (EXT_ID metadata + keyword search)",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://www.ebi.ac.uk/europepmc/webservices/rest/search",
        "license": "SEE_TERMS (PubMed abstract metadata, vendor terms)",
        "evidence_type": "literature",
        "confidence": "machine_verified_citation_metadata",
        "limitations": "keyword-search endpoint is intermittently slow; "
                       "candidates are title-token filtered client-side "
                       "before admission to this table",
    },
    "SRC:EUTILS_P3": {
        "resource": "NCBI E-utilities esearch (PMID discovery only)",
        "resource_version": "REST snapshot " + FROZEN_UTC,
        "retrieval_utc": FROZEN_UTC,
        "url": "https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esearch.fcgi",
        "license": "SEE_TERMS (NCBI public-domain data)",
        "evidence_type": "literature",
        "confidence": "pmid_discovery_only_verified_via_epmc",
        "limitations": "fallback path used when Europe PMC keyword search "
                       "failed/timed out; every PMID is re-verified through "
                       "Europe PMC EXT_ID metadata before admission",
    },
}

# Internal hash-pinned KB rows (guideline anchor layer).
INTERNAL_SOURCE_RECORDS = {
    ("KB:%s" % did): {
        "resource": "APEIRON-X v14.1 disease_drug_kb.py (hash-pinned corpus)",
        "resource_version": "corpus_pins sha256 " +
                            "76dcfe011c58d65827deec7217cd1354215e0582a3eee8d40bc2ac5d83a5079",
        "retrieval_utc": "2026-11-24T15:50:02Z",
        "url": "internal://apeiron/disease_drug_kb.py",
        "license": "project-internal",
        "evidence_type": "guideline",
        "confidence": "guideline_anchored_kb_row",
        "limitations": "guideline strings are the KB rows verbatim; see the "
                       "row's guideline field for issuer and vintage",
    }
    for did in ("D01", "D02", "D03", "D05", "D08", "D33", "D50", "D51", "D54")
}

# ---------------------------------------------------------------------
# GENE_TARGETS: HGNC symbol -> verified target record. Every field was
# fetched from HGNC + UniProt REST and cross-confirmed by the UniProt
# accession existence check (uniprot_entry_id, e.g. CFTR_HUMAN).
# ---------------------------------------------------------------------
GENE_TARGETS = {
    "ABL1":   {"hgnc_id": "HGNC:76",     "ensembl": "ENSG00000097007",
               "uniprot": "P00519",  "uniprot_entry_id": "ABL1_HUMAN",
               "name": "Tyrosine-protein kinase ABL1",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "ACE":    {"hgnc_id": "HGNC:2707",   "ensembl": "ENSG00000159640",
               "uniprot": "P12821",  "uniprot_entry_id": "ACE_HUMAN",
               "name": "Angiotensin-converting enzyme",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "ACHE":   {"hgnc_id": "HGNC:108",    "ensembl": "ENSG00000087085",
               "uniprot": "P22303",  "uniprot_entry_id": "ACES_HUMAN",
               "name": "Acetylcholinesterase",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "AGTR1":  {"hgnc_id": "HGNC:336",    "ensembl": "ENSG00000144891",
               "uniprot": "P30556",  "uniprot_entry_id": "AGTR1_HUMAN",
               "name": "Type-1 angiotensin II receptor",
               "target_kind": "receptor", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "APP":    {"hgnc_id": "HGNC:620",    "ensembl": "ENSG00000142192",
               "uniprot": "P05067",  "uniprot_entry_id": "A4_HUMAN",
               "name": "Amyloid-beta precursor protein",
               "target_kind": "signaling_protein",
               "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "CFTR":   {"hgnc_id": "HGNC:1884",   "ensembl": "ENSG00000001626",
               "uniprot": "P13569",  "uniprot_entry_id": "CFTR_HUMAN",
               "name": "Cystic fibrosis transmembrane conductance regulator",
               "target_kind": "ion_channel",
               "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "DPP4":   {"hgnc_id": "HGNC:3009",   "ensembl": "ENSG00000197635",
               "uniprot": "P27487",  "uniprot_entry_id": "DPP4_HUMAN",
               "name": "Dipeptidyl peptidase 4",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "EGFR":   {"hgnc_id": "HGNC:3236",   "ensembl": "ENSG00000146648",
               "uniprot": "P00533",  "uniprot_entry_id": "EGFR_HUMAN",
               "name": "Epidermal growth factor receptor",
               "target_kind": "receptor", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "F10":    {"hgnc_id": "HGNC:3528",   "ensembl": "ENSG00000126218",
               "uniprot": "P00742",  "uniprot_entry_id": "FA10_HUMAN",
               "name": "Coagulation factor X",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "HMGCR":  {"hgnc_id": "HGNC:5006",   "ensembl": "ENSG00000113161",
               "uniprot": "P04035",  "uniprot_entry_id": "HMDH_HUMAN",
               "name": "3-hydroxy-3-methylglutaryl-coenzyme A reductase",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "LDLR":   {"hgnc_id": "HGNC:6547",   "ensembl": "ENSG00000130164",
               "uniprot": "P01130",  "uniprot_entry_id": "LDLR_HUMAN",
               "name": "Low-density lipoprotein receptor",
               "target_kind": "receptor", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "MAPT":   {"hgnc_id": "HGNC:6893",   "ensembl": "ENSG00000186868",
               "uniprot": "P10636",  "uniprot_entry_id": "TAU_HUMAN",
               "name": "Microtubule-associated protein tau",
               "target_kind": "signaling_protein",
               "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "NPC1L1": {"hgnc_id": "HGNC:7898",   "ensembl": "ENSG00000015520",
               "uniprot": "Q9UHC9",  "uniprot_entry_id": "NPCL1_HUMAN",
               "name": "NPC1-like intracellular cholesterol transporter 1",
               "target_kind": "transporter",
               "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "PCSK9":  {"hgnc_id": "HGNC:20001",  "ensembl": "ENSG00000169174",
               "uniprot": "Q8NBP7",  "uniprot_entry_id": "PCSK9_HUMAN",
               "name": "Proprotein convertase subtilisin/kexin type 9",
               "target_kind": "enzyme", "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "SLC5A2": {"hgnc_id": "HGNC:11037",  "ensembl": "ENSG00000140675",
               "uniprot": "P31639",  "uniprot_entry_id": "SC5A2_HUMAN",
               "name": "Sodium/glucose cotransporter 2",
               "target_kind": "transporter",
               "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
    "TNF":    {"hgnc_id": "HGNC:11892",  "ensembl": "ENSG00000232810",
               "uniprot": "P01375",  "uniprot_entry_id": "TNFA_HUMAN",
               "name": "Tumor necrosis factor",
               "target_kind": "signaling_protein",
               "sources": ("SRC:HGNC_P3", "SRC:UNIPROT_P3")},
}

# ---------------------------------------------------------------------
# BENCHMARK_PANEL: 10 diseases with guideline-recognized targets
# (plan P3 acceptance). ot ids verbatim from the Open Targets search;
# guideline strings are the v14.1 KB rows VERBATIM (source KB:Dxx);
# guideline_targets are the guideline-recognized targets covered by
# this freeze; coverage_gaps name recognized targets NOT yet in the
# frozen gene set (recorded gaps, never counted as computed misses).
# ---------------------------------------------------------------------
BENCHMARK_PANEL = {
    "D01": {
        "name": "Essential hypertension",
        "kb_link": "D01",
        "guideline": "ESH/ESC 2023, NICE NG136: CCB/ACEi/ARB/thiazide-like "
                     "diuretic first-line",
        "ot_disease_id": "MONDO_0001134", "ot_disease_label":
            "essential hypertension",
        "pathway": "PW_VASCULAR_TONE",
        "reactome_stid": "R-HSA-445355",
        "reactome_label": "Smooth Muscle Contraction",
        "guideline_targets": ("ACE", "AGTR1"),
        "coverage_gaps": ("CACNA1C (DHP calcium channel; CCB class)",
                          "SLC12A3 (thiazide-sensitive transporter)"),
        "sources": ("KB:D01", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "D02": {
        "name": "Heart failure with reduced ejection fraction",
        "kb_link": "D02",
        "guideline": "ESC 2021: ACEi, beta-blocker, MRA, SGLT2i cornerstone "
                     "therapy",
        "ot_disease_id": "MONDO_0006993", "ot_disease_label":
            "systolic heart failure",
        "pathway": "PW_NEUROHORMONAL_REMODELING",
        "reactome_stid": None,
        "reactome_label": None,
        "reactome_absence_note":
            "Reactome search 'neurohormonal remodeling' returns no matching "
            "molecular pathway; absence recorded, not guessed",
        "ot_pick_note":
            "chosen MONDO_0006993 'systolic heart failure': the OT/MONDO "
            "record closest to HFrEF; deliberate, documented choice",
        "guideline_targets": ("ACE", "SLC5A2"),
        "coverage_gaps": ("ADRB1 (beta-1 selective blocker)",
                          "NR3C2 (mineralocorticoid receptor)"),
        "sources": ("KB:D02", "SRC:OT_P3", "SRC:EPMC_P3",
                    "EPMC:PMID-42986123"),
    },
    "D03": {
        "name": "Atrial fibrillation - stroke prophylaxis",
        "kb_link": "D03",
        "guideline": "ESC 2020 AF: DOACs preferred over warfarin for stroke "
                     "prevention",
        "ot_disease_id": "MONDO_0004981", "ot_disease_label":
            "atrial fibrillation",
        "pathway": "PW_COAGULATION_CASCADE",
        "reactome_stid": "R-HSA-75205",
        "reactome_label": "Dissolution of Fibrin Clot",
        "guideline_targets": ("F10",),
        "coverage_gaps": ("F2 (thrombin; dabigatran)",
                          "VKORC1 (vitamin K antagonist)"),
        "sources": ("KB:D03", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "D05": {
        "name": "Primary hypercholesterolemia (high CV risk)",
        "kb_link": "D05",
        "guideline": "ESC/EAS 2019: high-intensity statin first-line, "
                     "ezetimibe add-on",
        "ot_disease_id": "HP_0003124", "ot_disease_label":
            "Hypercholesterolemia",
        "pathway": "PW_CHOLESTEROL_SYNTHESIS",
        "reactome_stid": "R-HSA-1655829",
        "reactome_label": "Regulation of cholesterol biosynthesis by SREBP "
                          "(SREBF)",
        "guideline_targets": ("HMGCR", "PCSK9", "NPC1L1", "LDLR"),
        "coverage_gaps": (),
        "sources": ("KB:D05", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "D08": {
        "name": "Type 2 diabetes mellitus",
        "kb_link": "D08",
        "guideline": "ADA/EASD: metformin first-line; SGLT2i/DPP4i/SU "
                     "alternatives",
        "ot_disease_id": "MONDO_0005148", "ot_disease_label":
            "type 2 diabetes mellitus",
        "mondo_cross_check":
            "MONDO_0005148 equals the Phase 2 OLS-verified vocab record "
            "MONDO:0005148 (cross-module consistency)",
        "pathway": "PW_GLUCOSE_HOMEOSTASIS",
        "reactome_stid": "R-HSA-480985",
        "reactome_label": "Synthesis of dolichyl-phosphate-glucose",
        "guideline_targets": ("SLC5A2", "DPP4"),
        "coverage_gaps": ("GLP1R (GLP-1 receptor agonists)",
                          "ABCC8/KCNJ11 (sulfonylurea site)",
                          "INS/INSR (replacement therapy)"),
        "sources": ("KB:D08", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "D33": {
        "name": "Alzheimer's disease",
        "kb_link": "D33",
        "guideline": "NICE NG97: acetylcholinesterase inhibitors "
                     "mild-moderate",
        "ot_disease_id": "MONDO_0004975", "ot_disease_label":
            "Alzheimer disease",
        "pathway": "PW_CHOLINERGIC_DEFICIT",
        "reactome_stid": "R-HSA-181431",
        "reactome_label": "Acetylcholine binding and downstream events",
        "guideline_targets": ("ACHE",),
        "panel_extra_targets": ("APP", "MAPT"),
        "panel_extra_note":
            "APP and MAPT are mechanistic research targets carried as "
            "association evidence; they are NOT guideline-recommended "
            "targets and are the designed contrast cases for the "
            "ASSOCIATION_NOT_CAUSATION discipline",
        "coverage_gaps": ("GRIN (NMDA receptor; memantine)",),
        "sources": ("KB:D33", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "D50": {
        "name": "Chronic myeloid leukaemia (chronic phase)",
        "kb_link": "D50",
        "guideline": "NCCN/ELN: imatinib (or 2nd-generation TKI) first-line "
                     "CP-CML",
        "ot_disease_id": "MONDO_0011996", "ot_disease_label":
            "chronic myeloid leukemia",
        "pathway": "PW_BCR_ABL_KINASE",
        "reactome_stid": None,
        "reactome_label": None,
        "reactome_absence_note":
            "Reactome search 'BCR-ABL1' surfaces B-cell receptor pathways "
            "only; no fusion pathway returned in the frozen results; "
            "absence recorded, not guessed",
        "guideline_targets": ("ABL1",),
        "coverage_gaps": (),
        "sources": ("KB:D50", "SRC:OT_P3", "SRC:EPMC_P3",
                    "EPMC:PMID-11287972"),
    },
    "D51": {
        "name": "EGFR-mutant advanced non-small-cell lung cancer",
        "kb_link": "D51",
        "guideline": "ESMO/ASCO: osimertinib first-line EGFR-mutant advanced "
                     "NSCLC",
        "ot_disease_id": "MONDO_0005233", "ot_disease_label":
            "non-small cell lung carcinoma",
        "pathway": "PW_EGFR_SIGNALING",
        "reactome_stid": "R-HSA-1236382",
        "reactome_label": "Constitutive Signaling by Ligand-Responsive EGFR "
                          "Cancer Variants",
        "guideline_targets": ("EGFR",),
        "coverage_gaps": (),
        "sources": ("KB:D51", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "D54": {
        "name": "Rheumatoid arthritis (newly diagnosed)",
        "kb_link": "D54",
        "guideline": "EULAR 2022: methotrexate first-line csDMARD",
        "ot_disease_id": "MONDO_0008383", "ot_disease_label":
            "rheumatoid arthritis",
        "pathway": "PW_AUTOREACTIVE_CYTOKINE_CASCADE",
        "reactome_stid": "R-HSA-1280215",
        "reactome_label": "Cytokine Signaling in Immune system",
        "guideline_targets": ("TNF",),
        "panel_note":
            "TNF inhibitors are the guideline bDMARD step for insufficient "
            "response to csDMARDs; TNF is the guideline-recognized target "
            "in this panel",
        "coverage_gaps": ("IL6R (tocilizumab)", "JAK1/JAK2 (JAK inhibitors)"),
        "sources": ("KB:D54", "SRC:OT_P3", "SRC:REACTOME_P3"),
    },
    "CF": {
        "name": "Cystic fibrosis (non-KB benchmark disease)",
        "kb_link": None,
        "guideline": "CF modulator therapy per CF Foundation consensus / "
                     "EMA-FDA labeling of elexacaftor/tezacaftor/ivacaftor "
                     "(indicated for >=1 F508del allele); anchored here by "
                     "the verified literature, not by a KB row",
        "ot_disease_id": "MONDO_0009061", "ot_disease_label":
            "cystic fibrosis",
        "pathway": None,
        "reactome_stid": None,
        "reactome_label": None,
        "reactome_absence_note":
            "CF is a non-KB disease; no PW_* channel value exists to map "
            "(the v14.1 closed world has no CF row)",
        "encodability_note":
            "NOT_ENCODABLE in the v14.1 closed world: no six-channel row "
            "exists; Module B operates on the evidence table directly, "
            "demonstrating target discovery without a KB encoding",
        "guideline_targets": ("CFTR",),
        "coverage_gaps": (),
        "sources": ("SRC:OT_P3", "SRC:EPMC_P3", "EPMC:PMID-2475911",
                    "EPMC:PMID-42950895"),
    },
}

# ---------------------------------------------------------------------
# OT association rows used by this table (verbatim scores + datatype
# scores; full 150-row pages remain in the sha256-pinned cache).
# ---------------------------------------------------------------------
OT_ASSOCIATIONS = {
    "D01": {"efo_id": "MONDO_0001134", "association_count": 2123,
            "rows": {
                "ACE":   {"score": 0.5804,
                          "datatypeScores": [("literature", 0.475),
                                             ("genetic_association", 0.781),
                                             ("clinical", 0.652)]},
                "AGTR1": {"score": 0.7572,
                          "datatypeScores": [("clinical", 0.924),
                                             ("genetic_literature", 0.865),
                                             ("literature", 0.560),
                                             ("genetic_association", 0.805),
                                             ("animal_model", 0.879)]},
            }, "sources": ("SRC:OT_P3",)},
    "D02": {"efo_id": "MONDO_0006993", "association_count": 244,
            "rows": {
                "ACE":    {"score": 0.0791,
                           "datatypeScores": [("literature", 0.169),
                                              ("clinical", 0.122)]},
                "SLC5A2": {"score": 0.5058,
                           "datatypeScores": [("literature", 0.090),
                                              ("clinical", 0.827)]},
            }, "sources": ("SRC:OT_P3",)},
    "D03": {"efo_id": "MONDO_0004981", "association_count": 6542,
            "rows": {
                "F10": {"score": 0.6325,
                        "datatypeScores": [("literature", 0.759),
                                           ("genetic_association", 0.137),
                                           ("clinical", 0.987)]},
            }, "sources": ("SRC:OT_P3",)},
    "D05": {"efo_id": "HP_0003124", "association_count": 2524,
            "rows": {
                "HMGCR":  {"score": 0.7488,
                           "datatypeScores": [("literature", 0.206),
                                              ("genetic_association", 0.915),
                                              ("clinical", 0.998)]},
                "PCSK9":  {"score": 0.8257,
                           "datatypeScores": [("literature", 0.859),
                                              ("genetic_association", 0.954),
                                              ("clinical", 0.970),
                                              ("genetic_literature", 0.608)]},
                "LDLR":   {"score": 0.8473,
                           "datatypeScores": [("literature", 0.678),
                                              ("genetic_association", 0.975),
                                              ("genetic_literature", 0.608)]},
                "NPC1L1": {"score": 0.7334,
                           "datatypeScores": [("literature", 0.288),
                                              ("genetic_association", 0.839),
                                              ("clinical", 0.990)]},
            }, "sources": ("SRC:OT_P3",)},
    "D08": {"efo_id": "MONDO_0005148", "association_count": 10206,
            "rows": {
                "DPP4":   {"score": 0.6410,
                           "datatypeScores": [("literature", 0.971),
                                              ("animal_model", 0.332),
                                              ("clinical", 0.998)]},
                "SLC5A2": {"score": 0.6428,
                           "datatypeScores": [("literature", 0.983),
                                              ("animal_model", 0.468),
                                              ("clinical", 0.998)]},
            }, "sources": ("SRC:OT_P3",)},
    "D33": {"efo_id": "MONDO_0004975", "association_count": 13006,
            "rows": {
                "ACHE": {"score": 0.6416,
                         "datatypeScores": [("literature", 0.957),
                                            ("animal_model", 0.529),
                                            ("clinical", 0.996)]},
                "APP":  {"score": 0.8743,
                         "datatypeScores": [("clinical", 0.978),
                                            ("genetic_literature", 0.608),
                                            ("affected_pathway", 0.608),
                                            ("literature", 0.997),
                                            ("genetic_association", 0.927),
                                            ("animal_model", 0.475)]},
                "MAPT": {"score": None,
                         "not_in_page": True,
                         "note": "not among the top-150 rows of the "
                                 "fetched association page (count=13006); "
                                 "carried as literature-only association "
                                 "evidence below"},
            }, "sources": ("SRC:OT_P3",)},
    "D50": {"efo_id": "MONDO_0011996", "association_count": 4461,
            "rows": {
                "ABL1": {"score": 0.8358,
                         "datatypeScores": [("clinical", 0.994),
                                            ("genetic_literature", 0.608),
                                            ("affected_pathway", 0.967),
                                            ("literature", 0.996),
                                            ("genetic_association", 0.863),
                                            ("somatic_mutation", 0.723),
                                            ("animal_model", 0.531)]},
            }, "sources": ("SRC:OT_P3",)},
    "D51": {"efo_id": "MONDO_0005233", "association_count": 13555,
            "rows": {
                "EGFR": {"score": 0.8884,
                         "datatypeScores": [("genetic_literature", 0.608),
                                            ("clinical", 0.996),
                                            ("affected_pathway", 0.826),
                                            ("literature", 1.0),
                                            ("genetic_association", 0.934),
                                            ("somatic_mutation", 0.931),
                                            ("animal_model", 0.250)]},
            }, "sources": ("SRC:OT_P3",)},
    "D54": {"efo_id": "MONDO_0008383", "association_count": 8420,
            "rows": {
                "TNF": {"score": 0.7164,
                        "datatypeScores": [("literature", 0.998),
                                           ("animal_model", 0.455),
                                           ("genetic_literature", 0.608),
                                           ("clinical", 0.999)]},
            }, "sources": ("SRC:OT_P3",)},
    "CF":  {"efo_id": "MONDO_0009061", "association_count": 4603,
            "rows": {
                "CFTR": {"score": 0.9211,
                         "datatypeScores": [("genetic_literature", 0.862),
                                            ("clinical", 0.994),
                                            ("affected_pathway", 0.929),
                                            ("literature", 0.998),
                                            ("genetic_association", 0.956),
                                            ("animal_model", 0.564)]},
            }, "sources": ("SRC:OT_P3",)},
}

# ---------------------------------------------------------------------
# OT datatype -> evidence-kind mapping (conservative, documented).
# genetic/literature association evidence NEVER maps to a causal kind;
# that is the P3-3 anti-causal-illusion discipline at the ingest line.
# ---------------------------------------------------------------------
OT_DATATYPE_KIND_MAP = {
    "genetic_association": "association",
    "genetic_literature": "association",
    "literature": "association",
    "affected_pathway": "association",
    "clinical": "drug_binding",
    "known_drug": "drug_binding",
    "animal_model": "functional_perturbation",
    "somatic_mutation": "causal_variant",   # driver-biology context; noted
}

# ---------------------------------------------------------------------
# EVIDENCE_ROWS: one row per (disease, target). The `kinds` list is the
# documented merge of the OT datatype mapping above plus the cited
# literature rows in LITERATURE below. `sources` must all resolve in
# SOURCE_RECORDS / INTERNAL_SOURCE_RECORDS / LITERATURE keys.
# ---------------------------------------------------------------------
EVIDENCE_ROWS = [
    {"did": "D01", "symbol": "ACE", "direction": "inhibit",
     "kinds": ("association", "drug_binding", "guideline"),
     "sources": ("SRC:OT_P3", "KB:D01"),
     "note": "ACEi class (lisinopril/ramipril) is guideline first-line; "
             "OT datatypes literature/genetic_association/clinical"},
    {"did": "D01", "symbol": "AGTR1", "direction": "inhibit",
     "kinds": ("association", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D01"),
     "note": "ARB class (losartan) guideline first-line; animal_model "
             "0.879 supports functional evidence"},
    {"did": "D02", "symbol": "SLC5A2", "direction": "inhibit",
     "kinds": ("association", "drug_binding", "guideline"),
     "sources": ("SRC:OT_P3", "KB:D02",
                 "SRC:EPMC_P3", "EPMC:PMID-42986123"),
     "note": "SGLT2i (dapagliflozin) is ESC 2021 cornerstone; OT clinical "
             "0.827; EMPEROR-Preserved-anchored literature record"},
    {"did": "D02", "symbol": "ACE", "direction": "inhibit",
     "kinds": ("association", "drug_binding", "guideline"),
     "sources": ("SRC:OT_P3", "KB:D02"),
     "note": "ACEi cornerstone per KB row; OT association weak "
             "(score 0.079) but guideline anchors pharmacology"},
    {"did": "D03", "symbol": "F10", "direction": "inhibit",
     "kinds": ("association", "drug_binding", "guideline"),
     "sources": ("SRC:OT_P3", "KB:D03",
                 "SRC:EPMC_P3", "EPMC:PMID-43004015"),
     "note": "DOACs (apixaban/rivaroxaban/edoxaban) are guideline "
             "preferred; OT clinical 0.987"},
    {"did": "D05", "symbol": "HMGCR", "direction": "inhibit",
     "kinds": ("association", "drug_binding", "guideline"),
     "sources": ("SRC:OT_P3", "KB:D05"),
     "note": "statin class first-line; OT genetic_association 0.915 + "
             "clinical 0.998"},
    {"did": "D05", "symbol": "PCSK9", "direction": "inhibit",
     "kinds": ("association", "causal_variant", "drug_binding"),
     "sources": ("SRC:OT_P3", "EPMC:PMID-16554528", "EPMC:PMID-42850775"),
     "note": "loss-of-function PCSK9 -> low LDL -> coronary protection "
             "(human genetics, causal direction); evolocumab outcome "
             "literature; NO KB drug class yet (documented)"},
    {"did": "D05", "symbol": "LDLR", "direction": "unknown",
     "kinds": ("association",),
     "sources": ("SRC:OT_P3",),
     "note": "association-only in this freeze (OT genetic_association "
             "0.975, genetic_literature, literature); NO fetched causal "
             "citation yet -> ASSOCIATION_NOT_CAUSATION fires by design"},
    {"did": "D05", "symbol": "NPC1L1", "direction": "inhibit",
     "kinds": ("association", "drug_binding", "guideline"),
     "sources": ("SRC:OT_P3", "KB:D05"),
     "note": "ezetimibe is the guideline add-on; OT clinical 0.990"},
    {"did": "D08", "symbol": "SLC5A2", "direction": "inhibit",
     "kinds": ("association", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D08"),
     "note": "empagliflozin/sitagliptin-era alternatives per KB row; OT "
             "animal_model 0.468 + clinical 0.998"},
    {"did": "D08", "symbol": "DPP4", "direction": "inhibit",
     "kinds": ("association", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D08"),
     "note": "sitagliptin in KB row; OT animal_model 0.332 + clinical "
             "0.998"},
    {"did": "D33", "symbol": "ACHE", "direction": "inhibit",
     "kinds": ("association", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D33", "EPMC:PMID-42816922"),
     "note": "NICE NG97 acetylcholinesterase inhibitors; donepezil "
             "efficacy literature verified"},
    {"did": "D33", "symbol": "APP", "direction": "unknown",
     "kinds": ("association", "functional_perturbation", "drug_binding"),
     "sources": ("SRC:OT_P3",),
     "note": "research target: high OT score (0.874) driven by literature/"
             "genetic association; animal_model 0.475 present; NOT "
             "guideline-recommended"},
    {"did": "D33", "symbol": "MAPT", "direction": "unknown",
     "kinds": ("association",),
     "sources": ("EPMC:PMID-42783847",),
     "note": "association-only by design: MAPT absent from the fetched OT "
             "association page; tau-PET genetic determinants literature "
             "-> ASSOCIATION_NOT_CAUSATION must fire (P3-3 contrast case)"},
    {"did": "D50", "symbol": "ABL1", "direction": "inhibit",
     "kinds": ("causal_variant", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D50", "EPMC:PMID-11287972"),
     "note": "BCR-ABL somatic fusion (driver biology; OT somatic_mutation "
             "0.723); Druker 2001 landmark anchors pharmacology"},
    {"did": "D51", "symbol": "EGFR", "direction": "inhibit",
     "kinds": ("causal_variant", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D51", "EPMC:PMID-24353160"),
     "note": "EGFR activating mutations (OT somatic_mutation 0.931); "
             "osimertinib guideline first-line"},
    {"did": "D54", "symbol": "TNF", "direction": "inhibit",
     "kinds": ("association", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "KB:D54", "EPMC:PMID-43032676"),
     "note": "TNF inhibitors as guideline bDMARD step; OT clinical 0.999"},
    {"did": "CF", "symbol": "CFTR", "direction": "modulate",
     "kinds": ("causal_variant", "functional_perturbation", "drug_binding",
               "guideline"),
     "sources": ("SRC:OT_P3", "EPMC:PMID-2475911", "EPMC:PMID-42950895"),
     "note": "CF-causing gene identified by cloning (Riordan 1989, causal "
             "direction); modulator class literature (triple therapy); "
             "guideline anchor from modulator labeling, not a KB row"},
]

# ---------------------------------------------------------------------
# LITERATURE: machine-verified Europe PMC metadata (EXT_ID), keyed by
# the citation ids used in EVIDENCE_ROWS / PANEL sources. Authored
# verbatim from the freeze; nothing hand-typed except the keys.
# ---------------------------------------------------------------------
LITERATURE = {
    "EPMC:PMID-16554528": {
        "pmid": "16554528", "year": "2006", "journal": "N Engl J Med",
        "title": "Sequence variations in PCSK9, low LDL, and protection "
                 "against coronary heart disease.",
        "authors": "Cohen JC, Boerwinkle E, Mosley TH, Hobbs HH.",
        "doi": "10.1056/nejmoa054013", "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-42850775": {
        "pmid": "42850775", "year": "2026",
        "journal": "Endocrinol Diabetes Metab",
        "title": "Impact of Evolocumab on LDL-Cholesterol and "
                 "Cardiovascular Outcomes in Patients With Established "
                 "CVD: Systematic Review and Meta-Analysis.",
        "authors": "Goel A, Naveed MA, Tandel H, Mahmood A, Mukhlis M, "
                   "Reddy KSV, Maloth AK, Chauhan", "doi": "10.1002/edm2.70355",
        "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-11287972": {
        "pmid": "11287972", "year": "2001", "journal": "N Engl J Med",
        "title": "Efficacy and safety of a specific inhibitor of the "
                 "BCR-ABL tyrosine kinase in chronic myeloid leukemia.",
        "authors": "Druker BJ, Talpaz M, Resta DJ, Peng B, Buchdunger E, "
                   "Ford JM, Lydon NB, Kantarjian", "doi": "10.1056/nejm200104053441401",
        "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-24353160": {
        "pmid": "24353160", "year": "2013", "journal": "Sci Transl Med",
        "title": "Structural, biochemical, and clinical characterization "
                 "of epidermal growth factor receptor (EGFR) exon 20 "
                 "insertion mutations in lung cancer.",
        "authors": "Yasuda H, Park E, Yun CH, Sng NJ, Lucena-Araujo AR, "
                   "Yeo WL, Huberman MS, Cohen", "doi": "10.1126/scitranslmed.3007205",
        "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-2475911": {
        "pmid": "2475911", "year": "1989", "journal": "Science",
        "title": "Identification of the cystic fibrosis gene: cloning and "
                 "characterization of complementary DNA.",
        "authors": "Riordan JR, Rommens JM, Kerem B, Alon N, Rozmahel R, "
                   "Grzelczak Z, Zielenski J, L", "doi": "10.1126/science.2475911",
        "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-42950895": {
        "pmid": "42950895", "year": "2026", "journal": "Respir Med",
        "title": "The natural history of Mycobacterium abscessus in cystic "
                 "fibrosis and the impact of elexacaftor/tezacaftor/"
                 "ivacaftor.",
        "authors": "Dagan A, Gindi-Reiss B, Ben-Hamo M, Bezalel Y, Bar "
                   "Aluma BE, Ashkenazi M, Keller",
        "doi": "10.1016/j.rmed.2026.109246", "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-42986123": {
        "pmid": "42986123", "year": "2026", "journal": "Eur J Heart Fail",
        "title": "Efficacy of empagliflozin in heart failure with preserved "
                 "ejection fraction according to the presence of "
                 "echocardiographic features of diastolic dysfunction in "
                 "the EMPEROR-Preserved trial.",
        "authors": "Stewart Coats AJ, Butler J, Zimmet H, Zannad F, B\u00f6hm M",
        "doi": "10.1093/ejhf/xuag327", "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-42816922": {
        "pmid": "42816922", "year": "2026", "journal": "J Alzheimers Dis",
        "title": "The efficacy of donepezil combination therapy strategies "
                 "in Alzheimer's disease: A systematic review and network "
                 "meta-analysis.",
        "authors": "Ning X, Xiao Y, Wang N, Jiao X, Li X, Zhang Y, Zhao Q.",
        "doi": "10.1177/13872877261491977", "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-43032676": {
        "pmid": "43032676", "year": "2026", "journal": "J Transl Autoimmun",
        "title": "Impact of infliximab combined with methotrexate on serum "
                 "inflammatory and immunometabolic biomarkers in "
                 "rheumatoid arthritis.",
        "authors": "Al-Maslamani B, Soudi S, Al-Ghazaly ZM.",
        "doi": "10.1016/j.jtauto.2026.100414", "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-43004015": {
        "pmid": "43004015", "year": "2026", "journal": "Eur J Clin Pharmacol",
        "title": "Efficacy and safety of apixaban versus rivaroxaban in "
                 "acute venous thromboembolism: a systematic review and "
                 "meta-analysis.",
        "authors": "Shafiq SB, Hassan M, Memon A, Khan GT, Razzak MJ, "
                   "Hussain M, Uddin A, Mansoor KT",
        "doi": "10.1007/s00228-026-04220-6", "source": "SRC:EPMC_P3",
    },
    "EPMC:PMID-42783847": {
        "pmid": "42783847", "year": "2026", "journal": "J Imaging",
        "title": "Genetic Determinants of Tau-PET Imaging in Alzheimer's "
                 "Disease: A Narrative Review of Genome-Wide and "
                 "Candidate-Gene Studies.",
        "authors": "Gujral J, Gandhi OH, Bhogale T, Amanullah AA, "
                   "Srivastava A, Singh SB, Werner TJ",
        "doi": "10.3390/jimaging12090423", "source": "SRC:EPMC_P3",
    },
}

# ---------------------------------------------------------------------
# HONEST LIMITS of this freeze (master prompt strict rule: absent data
# is reported as absent, with the field named).
# ---------------------------------------------------------------------
HONEST_LIMITS = (
    "Flag semantics (P3-3): ASSOCIATION_NOT_CAUSATION clears ONLY with "
    "cited causal evidence (functional perturbation / causal variant / "
    "rescue). Drug-binding and guideline evidence are target engagement, "
    "not causality. In this freeze the following guideline targets "
    "therefore still carry the flag pending a cited causal record: ACE "
    "(D01), ACE + SLC5A2 (D02), F10 (D03), HMGCR + NPC1L1 + LDLR (D05). "
    "The flag is a provenance statement, not a biological claim.",
    "PW_NEUROHORMONAL_REMODELING: no Reactome pathway (search returns no "
    "matching molecular pathway); absence recorded.",
    "PW_BCR_ABL_KINASE: Reactome search surfaces B-cell receptor pathways "
    "only; no fusion-signaling pathway in the frozen results; absence "
    "recorded.",
    "MAPT is NOT on the fetched Open Targets association page for "
    "Alzheimer disease (top-150 rows); it enters this table only through "
    "the verified tau-PET literature record, as association evidence.",
    "LDLR carries association evidence only in this freeze (no fetched "
    "causal citation) and is therefore flagged "
    "ASSOCIATION_NOT_CAUSATION, despite FH being monogenic in reality; "
    "the flag clears only with a cited causal record (future refresh).",
    "D02 uses MONDO_0006993 'systolic heart failure' as the closest "
    "verified OT/MONDO record for HFrEF; choice documented in the panel.",
    "CF is not a v14.1 KB row; its guideline anchor is the verified "
    "modulator literature, not a KB guideline string.",
    "Open Targets datatype ids drift by release; the mapping in "
    "OT_DATATYPE_KIND_MAP is pinned to the datatypes observed in this "
    "freeze and new ids would be recorded as unmapped, not guessed.",
)


def validate_target_module() -> list:
    """Structural self-validation: every record complete + cited."""
    problems = []
    valid_kinds = {"association", "causal_variant", "functional_perturbation",
                   "rescue_experiment", "drug_binding", "guideline"}
    lit_keys = set(LITERATURE) | set(SOURCE_RECORDS) | \
        set(INTERNAL_SOURCE_RECORDS)

    def _src_ok(s):
        return s in lit_keys or s in LITERATURE

    for sym, rec in GENE_TARGETS.items():
        for key in ("hgnc_id", "ensembl", "uniprot", "uniprot_entry_id",
                    "name", "target_kind", "sources"):
            if key not in rec or rec[key] in (None, "", ()):
                problems.append(f"GENE_TARGETS[{sym}]: missing {key}")
        if rec["target_kind"] not in {
            "gene", "receptor", "enzyme", "ion_channel", "transporter",
            "transcription_factor", "signaling_protein", "complex",
            "pathway_node"}:
            problems.append(f"GENE_TARGETS[{sym}]: bad target_kind")
        for s in rec["sources"]:
            if s not in SOURCE_RECORDS:
                problems.append(f"GENE_TARGETS[{sym}]: unknown source {s}")

    for did, rec in BENCHMARK_PANEL.items():
        for key in ("name", "guideline", "ot_disease_id",
                    "ot_disease_label", "guideline_targets", "sources"):
            if key not in rec or rec[key] in (None, "", ()):
                problems.append(f"BENCHMARK_PANEL[{did}]: missing {key}")
        for t in rec["guideline_targets"]:
            if t not in GENE_TARGETS:
                problems.append(f"BENCHMARK_PANEL[{did}]: target {t} not "
                                "in GENE_TARGETS")
        for t in rec.get("panel_extra_targets", ()):
            if t not in GENE_TARGETS:
                problems.append(f"BENCHMARK_PANEL[{did}]: extra target {t} "
                                "not in GENE_TARGETS")
        if rec.get("kb_link") is not None and \
                f"KB:{rec['kb_link']}" not in INTERNAL_SOURCE_RECORDS:
            problems.append(f"BENCHMARK_PANEL[{did}]: kb_link "
                            f"{rec['kb_link']} has no internal record")

    seen_pairs = set()
    for row in EVIDENCE_ROWS:
        did, sym = row.get("did"), row.get("symbol")
        if did not in BENCHMARK_PANEL:
            problems.append(f"EVIDENCE_ROWS[{did}|{sym}]: unknown did")
        if sym not in GENE_TARGETS:
            problems.append(f"EVIDENCE_ROWS[{did}|{sym}]: unknown symbol")
        for k in row.get("kinds", ()):
            if k not in valid_kinds:
                problems.append(f"EVIDENCE_ROWS[{did}|{sym}]: bad kind {k}")
        for s in row.get("sources", ()):
            if not _src_ok(s):
                problems.append(f"EVIDENCE_ROWS[{did}|{sym}]: unresolved "
                                f"source {s}")
        if (did, sym) in seen_pairs:
            problems.append(f"EVIDENCE_ROWS[{did}|{sym}]: duplicate pair")
        seen_pairs.add((did, sym))

    for key, rec in LITERATURE.items():
        for f in ("pmid", "title", "journal", "year"):
            if not rec.get(f):
                problems.append(f"LITERATURE[{key}]: missing {f}")
        if not key.startswith("EPMC:PMID-"):
            problems.append(f"LITERATURE[{key}]: key must be EPMC:PMID-*")
        if rec.get("source") not in SOURCE_RECORDS:
            problems.append(f"LITERATURE[{key}]: unknown source")

    for did in OT_ASSOCIATIONS:
        if did not in BENCHMARK_PANEL:
            problems.append(f"OT_ASSOCIATIONS[{did}]: not in panel")
    return problems
