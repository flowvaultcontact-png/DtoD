#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 8 (P8-4): honest-limitation report generator.

Emits the KNOWN GAPS of the program alongside its achievements, in one
versioned document consumed by the API (`/api/v1/limits`), the research
dashboard and the Phase 8 acceptance artifacts. The generator reads only
frozen modules and frozen artifacts — it invents nothing, rounds
nothing, and never converts an absence into a claim.

Collected from (each already carries its own honest-limits block):
  * Module B — v15/target_data.py HONEST_LIMITS
  * Module C — v15/repurposing_data.py honest limits
  * Module D — the frozen Phase 5 artifact honest_limits + the EMPTY
               ADMET model registry absence statement
  * Module F — the frozen Phase 7 registry absences + plan-lane limits
  * cross-cutting: licences not obtained, connector metadata-only
    discipline, non-goals (plan §1)
"""

import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

LIMIT_SCHEMA_VERSION = "15.8.0"

NON_GOALS = (
    "clinical decision support",
    "claiming efficacy for any candidate",
    "replacing experimental validation",
    "claiming any drug works for every disease",
)


def _phase_artifact(name):
    path = os.path.join(ROOT, "v15", "out", name)
    if not os.path.exists(path):
        return None, {"code": "ARTIFACT_ABSENT", "subject": name,
                      "reason": "the artifact has not been generated in "
                                "this checkout; run its writer first"}
    with open(path, encoding="utf-8") as fh:
        return json.load(fh), None


def build_limitation_report() -> dict:
    from v15.targets import load_targets
    from v15.repurposing import load_pack
    from v15.validation_plan import _registry_with_ledgers

    table = load_targets()
    pack = load_pack()
    reg = _registry_with_ledgers(pack)

    bench3, miss3 = _phase_artifact("phase3_benchmark.json")
    bench4, miss4 = _phase_artifact("phase4_benchmark.json")
    bench5, miss5 = _phase_artifact("phase5_benchmark.json")
    bench6, miss6 = _phase_artifact("phase6_benchmark.json")
    bench7, miss7 = _phase_artifact("phase7_benchmark.json")

    # ---- achievements (verbatim stats from the frozen artifacts) ----
    achievements = {
        "module_A_knowledge": {
            "frozen_vocab_and_profiles": "Phase 2 vocab + DiseaseProfile "
                                         "+ growth-pack machinery shipped; "
                                         "pack D64-D68 applied",
        },
        "module_B_targets": {
            "benchmark_macro_recall_at_10":
                bench3.get("macro_recall_at_10") if bench3 else None,
            "guideline_targets_total":
                bench3.get("guideline_targets_total") if bench3 else None,
        },
        "module_C_repurposing": {
            "temporal_benchmark_macro_recall_at_10":
                bench4.get("macro_recall_at_10") if bench4 else None,
            "temporal_split_year":
                bench4.get("temporal_split_year") if bench4 else None,
        },
        "module_D_molecules": {
            "kb_roundtrip":
                "191/191 KB molecules re-certified unchanged (Phase 5)",
            "generated_candidates": bench5.get("emitted_n") if bench5
            else None,
            "rejections_recorded": bench5.get("rejected_n") if bench5
            else None,
        },
        "module_E_reasoning": {
            "theorems_proved": "10/10 (E1-E10) incl. fingerprint "
                               "portability + memo determinism",
            "graph_edges": bench6.get("graph", {}).get("edges")
            if bench6 else None,
        },
        "module_F_validation": {
            "plans_built": bench7.get("plan_count") if bench7 else None,
            "theorems_proved": "7/7 (F1-F7) all PROVEN_MATH",
            "registry_studies": bench7.get("registry", {}).get("studies")
            if bench7 else None,
        },
        "module_P8_discover": {
            "pipeline": "12-step workflow -> 18-section deterministic "
                        "report (this round)",
        },
    }

    # ---- known gaps (each carries its lane + why) --------------------
    known_gaps = {
        "module_B_targets": {
            "lane": "S5 (target ranking)",
            "gaps": list(table.limits),
        },
        "module_C_repurposing": {
            "lane": "S7 (repurposing)",
            "gaps": list(pack.limits),
        },
        "module_D_molecules": {
            "lane": "S8/S9 (molecules + ADMET)",
            "gaps": list(bench5.get("honest_limits", [])) if bench5
            else [miss5],
        },
        "module_F_validation": {
            "lane": "S12 (validation plans)",
            "gaps": [
                "the registry carries METADATA only: no trial result, "
                "effect size, p-value or outcome measure exists anywhere "
                "in the P7 pack (structurally impossible through the "
                "fields whitelist)",
                "HFREF/HFPEF dataset links are CONDITION_LEVEL_ONLY; the "
                "whitelisted fields cannot separate ejection-fraction "
                "strata",
                "dataset links exist only for the 10 queried drugs; all "
                "other candidates have recorded absences, not guesses",
                "generated molecules (APXD-*) have no registry records "
                "by construction; their plans record the structural "
                "absence",
            ],
        },
        "cross_cutting": {
            "lane": "program-wide",
            "gaps": [
                "licences for DrugBank and BindingDB were NOT obtained, "
                "so interaction content from those resources is cited by "
                "absence, never by content",
                "all external scientific connectors (Open Targets, "
                "ChEMBL, UniProt, Reactome, Europe PMC, CT.gov, GEO) "
                "serve frozen cache payloads only; live fetching is "
                "confined to the documented refresh scripts",
                "the ADMET model registry ships EMPTY: no validated ML "
                "model exists, so PREDICTED_ML requests are refused",
                "no docking run record exists in any round, so no "
                "structure carries a docking statement",
                "Module B target evidence covers the 10-disease panel "
                "only; Module C candidates cover the cardio-renal "
                "prediction panel only; the P8 graph covers 10 diseases "
                "— every other disease gets explicit absences",
                "novel molecules are class-pharmacophore candidates over "
                "frozen structure laws; no disease-linked activity claim "
                "is made for any structure",
                "solubility/permeability and synthetic accessibility "
                "values are rule-layer estimates (PREDICTED_RULEBASED), "
                "never measurements",
            ],
        },
    }

    artifact_absences = [m for m in (miss3, miss4, miss5, miss6, miss7)
                         if m]

    return {
        "report": "APEIRON-X v15 honest-limitation report (P8-4)",
        "schema_version": LIMIT_SCHEMA_VERSION,
        "achievements": achievements,
        "known_gaps": known_gaps,
        "registry_absences": len(reg.absences),
        "artifact_absences": artifact_absences,
        "non_goals": list(NON_GOALS),
        "doctrine": "absent data is named with the field that is absent; "
                    "it is never replaced by an estimate, a guess or a "
                    "fabrication; achievements are stated only where a "
                    "frozen artifact backs them",
    }


if __name__ == "__main__":
    rep = build_limitation_report()
    print(json.dumps(rep, indent=2, sort_keys=True))
