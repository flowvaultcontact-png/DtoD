#!/usr/bin/env python3
"""APEIRON-X v15 — Phase 8 (P8-2b): static research dashboard writer.

Renders a self-contained HTML research dashboard (inline CSS, zero
JavaScript, zero external assets, zero network) over the same pin-checked
facades the API serves. The dashboard is a VIEW: it recomputes
transparent lane summaries from the frozen modules and embeds one worked
discover-report example. Deterministic: no wall-clock fields anywhere.

Usage (also called by write_phase8_artifacts.py):
    python3 v15/dashboard.py --out v15/out/dashboard.html
"""

import argparse
import html
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)


def _esc(x) -> str:
    return html.escape(str(x), quote=True)


def build_dashboard_html() -> str:
    import disease_drug_kb as kb
    kb.validate_kb()
    from v15.targets import load_targets
    from v15.repurposing import load_pack, predict_repurposing
    from v15.kgraph import KnowledgeGraph
    from v15.discover import (discover, DISCOVER_SCHEMA_VERSION,
                              _load_phase5)
    from v15.limitation_report import build_limitation_report
    from v15.api import ROUTES, API_VERSION

    table = load_targets()
    pack = load_pack()
    graph = KnowledgeGraph.from_frozen()
    bench5, phase5_sha, emitted = _load_phase5()
    limits = build_limitation_report()

    pred = predict_repurposing(pack)

    rows = []
    for did in table.dids():
        p = table.panel[did]
        top = table.rank_targets(did, k=3)
        sym = ", ".join(t["symbol"] for t in top) or "-"
        rows.append(
            f"<tr><td class='mono'>{_esc(did)}</td>"
            f"<td>{_esc(p['name'])}</td>"
            f"<td class='mono'>{_esc(sym)}</td></tr>")
    targets_tbl = "\n".join(rows)

    rows = []
    for key in pack.prediction_diseases:
        block = pred["diseases"][key]
        top = block["rows"][:3]
        cells = []
        for r in top:
            flag = " <span class='conflict'>bridge:CONFLICT</span>" \
                if r["rank_tier"] == "MECH_STRUCTURE_CONFLICT" else ""
            cells.append(f"{_esc(r['drug'])} "
                         f"(#{r['rank']}, {r['support_level']}){flag}")
        rows.append(
            f"<tr><td class='mono'>{_esc(key)}</td>"
            f"<td>{_esc(pack.diseases[key]['name'])}</td>"
            f"<td>{_esc('; '.join(cells))}</td></tr>")
    repurp_tbl = "\n".join(rows)

    # validation plans (same universe the API serves)
    from v15 import validation_plan as vp
    from v15.repurposing import benchmark_temporal
    kbench = benchmark_temporal(pack, k=10)
    reg = vp._registry_with_ledgers(pack)
    apxd, _ = vp.load_apxd_universe()
    plans = []
    for row, key in vp.plan_universe(pack, kbench):
        pname = kbench["per_disease"][key]["disease"]
        plans.append(vp.plan_for_drug(reg, pack, row, key, pname))
    for mol in apxd:
        plans.append(vp.plan_for_generated_molecule(reg, mol, phase5_sha))
    plans.sort(key=lambda p: p["plan_id"])
    rows = []
    for p in plans[:14]:
        gates = " ".join(
            "R" if g["state"] == "REGISTRY_ACTIVITY_PRESENT"
            else ("C" if g["state"] == "COMPLETED_WITH_CITED_EVIDENCE"
                  else ".") for g in p["stage_gates"])
        rows.append(
            f"<tr><td class='mono'>{_esc(p['plan_id'])}</td>"
            f"<td class='mono'>{_esc(p['candidate']['status'])}</td>"
            f"<td class='mono gates' title='bio/cell/tissue/animal/human'>"
            f"{gates}</td></tr>")
    plans_tbl = "\n".join(rows)
    plans_rest = len(plans) - min(14, len(plans))

    ex = discover({"did": "D02"}, verbose=False)
    rows = []
    for r in ex["S13_evidence_weighted_ranking"]["rows"][:8]:
        rows.append(
            f"<tr><td>#{r['rank']}</td>"
            f"<td class='mono'>{_esc(r['name'])}</td>"
            f"<td><span class='tier t{_esc(r['fusion_tier'])}'>"
            f"{_esc(r['fusion_tier'])}</span></td>"
            f"<td class='mono'>{_esc(','.join(r['lanes']))}</td></tr>")
    example_tbl = "\n".join(rows)

    gaps = limits["known_gaps"]
    gap_items = []
    for lane, block in sorted(gaps.items()):
        gap_items.append(f"<li><b>{_esc(block['lane'])}</b><ul>" + "".join(
            f"<li>{_esc(g)}</li>" for g in block["gaps"][:3]) +
            (f"<li>… +{len(block['gaps'])-3} more (see /api/v1/limits)</li>"
             if len(block["gaps"]) > 3 else "") + "</ul></li>")
    gaps_html = "\n".join(gap_items)

    routes_html = "\n".join(
        f"<li class='mono'>/{_esc(r[0])}</li>" for r in ROUTES)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>APEIRON-X v15 — Research Dashboard</title>
<style>
  :root {{ --ink:#0B1C2C; --accent:#529286; --soft:#E8ECEB; --muted:#5B6B7D; }}
  body {{ font-family: Georgia, 'Times New Roman', serif; color:#111;
         max-width: 1080px; margin: 2rem auto; padding: 0 1.25rem 4rem; }}
  h1 {{ color: var(--ink); font-size: 1.7rem; margin-bottom: .2rem; }}
  h2 {{ color: var(--ink); border-bottom: 2px solid var(--accent);
       padding-bottom: .25rem; margin-top: 2.2rem; font-size: 1.15rem; }}
  .meta {{ color: var(--muted); font-size: .85rem; }}
  table {{ border-collapse: collapse; width: 100%; font-size: .88rem;
           margin-top: .6rem; }}
  th, td {{ border-bottom: 1px solid #C9D4D2; padding: .38rem .5rem;
            text-align: left; vertical-align: top; }}
  th {{ background: var(--accent); color: #fff; }}
  tr:nth-child(even) td {{ background: var(--soft); }}
  .mono {{ font-family: 'DejaVu Sans Mono', Consolas, monospace;
           font-size: .8rem; }}
  .tier {{ font-size: .72rem; padding: .1rem .4rem; border-radius: 3px;
           color:#fff; }}
  .tPROVEN_MATH {{ background:#2C6E63; }} .tEVIDENCED {{ background:#529286; }}
  .tCOMPUTATIONAL {{ background:#8A9BA8; }} .tHYPOTHESIS {{ background:#B0B8C0; }}
  .conflict {{ color:#8A2B2B; font-size:.75rem; }}
  .gates {{ letter-spacing: .12em; }}
  .card {{ background: var(--soft); padding: .8rem 1rem; margin: .5rem 0;
           border-left: 4px solid var(--accent); }}
  .grid {{ display: flex; flex-wrap: wrap; gap: .7rem; }}
  .kpi {{ flex: 1 1 150px; background: var(--soft); border-left:
          4px solid var(--accent); padding: .6rem .8rem; }}
  .kpi b {{ display:block; font-size: 1.3rem; color: var(--ink); }}
  ul {{ margin: .3rem 0; }}
</style>
</head>
<body>
<h1>APEIRON-X v15 — Research Dashboard</h1>
<p class="meta">static view over the frozen, sha256-pinned corpora ·
deterministic (no wall-clock fields) · read-only ·
discover schema {_esc(DISCOVER_SCHEMA_VERSION)} ·
Phase 5 artifact sha256 <span class="mono">{_esc(phase5_sha[:16])}…</span></p>

<h2>Program at a glance</h2>
<div class="grid">
  <div class="kpi"><b>{len(kb.DISEASES)}</b>diseases (v14.1 KB, pinned)</div>
  <div class="kpi"><b>{len(kb.DRUGS)}</b>drugs (KB corpus)</div>
  <div class="kpi"><b>{len(table.dids())}</b>target-panel diseases (Module B)</div>
  <div class="kpi"><b>{len(pack.prediction_diseases)}</b>repurposing-panel diseases (Module C)</div>
  <div class="kpi"><b>{len(plans)}</b>validation plans (Module F)</div>
  <div class="kpi"><b>{len(emitted)}</b>generated molecules (Module D, frozen artifact)</div>
  <div class="kpi"><b>{graph.stats['edges']}</b>typed P8 graph edges (Module E)</div>
  <div class="kpi"><b>{limits['registry_absences']}</b>recorded registry absences (honesty ledger)</div>
</div>
<p class="meta">every number above is read from a frozen, pin-checked
store; the dashboard computes nothing novel and fabricates nothing.</p>

<h2>Target panel — top-3 intervention points per disease (Module B)</h2>
<table><tr><th>did</th><th>disease</th><th>top-3 targets (transparent rank)</th></tr>
{targets_tbl}
</table>

<h2>Repurposing panel — top-3 candidates per disease (Module C)</h2>
<table><tr><th>key</th><th>disease</th><th>top-3 (rank, channel support, bridge)</th></tr>
{repurp_tbl}
</table>
<p class="meta">bridge:CONFLICT = MECH_STRUCTURE_CONFLICT — the candidate
conflicts with the disease's proved structure law and is EXPOSED, never
silently dropped (Phase 4 theorem).</p>

<h2>Experimental validation plans (Module F)</h2>
<table><tr><th>plan id</th><th>candidate status</th><th>stage gates
bio/cell/tissue/animal/human (R=registry activity, C=completed+cited,
.=proposed)</th></tr>
{plans_tbl}
</table>
<p class="meta">showing 14 of {len(plans)} plans{f" (+{plans_rest} more)" if plans_rest > 0 else ""} ·
a REGISTRY_ACTIVITY_PRESENT gate means "trials exist", never "efficacy shown".</p>

<h2>Worked example — D02 heart failure (HFrEF), fused ranking</h2>
<table><tr><th>rank</th><th>candidate</th><th>fusion tier</th><th>contributing lanes</th></tr>
{example_tbl}
</table>
<p class="meta">fusion tier = strongest lane evidence (JOIN); the fusion
label is COMPUTATIONAL_RANK — a rank hint, never a probability.</p>

<h2>Honest limitations (P8-4 generator, condensed)</h2>
<ul>
{gaps_html}
</ul>

<h2>Non-goals (explicit)</h2>
<ul>{" ".join(f"<li>{_esc(n)}</li>" for n in limits['non_goals'])}</ul>

<h2>Read-only API routes (versioned)</h2>
<ul>
{routes_html}
</ul>
<p class="meta">API version {_esc(API_VERSION)} · GET-only (mutations
answer 405) · hermetic (no network) · deterministic payloads.</p>
</body>
</html>
"""


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--out", default=os.path.join(
        ROOT, "v15", "out", "dashboard.html"))
    args = ap.parse_args()
    html_doc = build_dashboard_html()
    with open(args.out, "w", encoding="utf-8") as fh:
        fh.write(html_doc)
    print(f"[dashboard] written to {args.out} "
          f"({len(html_doc)} bytes)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
