#!/usr/bin/env python3
# =====================================================================
# DEMO — APEIRON-X v12.0 Structure-Layer Extension
# Run:  python3 demo_structure.py
# Requires: RDKit (pip install rdkit), drug_structures.py,
#           disease_drug_kb.py, apeiron_drug_discovery_proof.py,
#           apeiron_structure_proof.py in the same directory.
# =====================================================================
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from apeiron_structure_proof import (
    StructLayer, derive_structure_laws, reverse_class_match,
    GenericOracle, enrich_query_result, SIBLINGS,
)
from apeiron_drug_discovery_proof import DrugOracle, phi_dict
import disease_drug_kb as KB


def main():
    print("=" * 70)
    print("APEIRON-X v12.0 — disease -> drug -> MOLECULE (proof-only demo)")
    print("=" * 70)

    layer = StructLayer()
    rows = KB.DISEASES
    oracle = DrugOracle(rows)
    oracle.learn()
    laws, excluded = derive_structure_laws(layer, verbose=False)
    gen = GenericOracle(rows, oracle, layer, laws)
    n_ok = sum(1 for c in laws.values() if c["proved"])
    print(f"\n[1] structure layer: {len(DS := __import__('drug_structures').SMILES)} "
          f"PubChem molecules, {len(layer.feat_names)} features")
    print(f"    structure->class laws: {n_ok}/{len(laws)} PROVED "
          f"(0 false positives over the whole drug universe)")
    print(f"    excluded classes: {len(excluded)} (biologics / polymers / "
          f"heterogeneous scaffolds — explicit, with reasons)")

    print("\n[2] FORWARD: disease -> ranked drugs -> molecule proof")
    for name in ["Type 2 diabetes mellitus",
                 "Atrial fibrillation - stroke prophylaxis"]:
        row = next(r for r in rows if r["name"] == name)
        res = enrich_query_result(oracle.query(phi_dict(row)), layer, laws)
        print(f"\n  {res['disease']}")
        print(f"    verdict: {res['verdict']}   class: {res['mechanism_class']}")
        print(f"    first-line: {res['first_line']}  "
              f"alternatives: {', '.join(res['alternatives'])}")
        s = res["structure_layer"][0]
        comp = s["components"][0]
        print(f"    molecule   : {s['drug']} = {comp['smiles_canonical']}")
        print(f"      PubChem CID {comp['pubchem_cid']}, MW {comp['mw']}, "
              f"cLogP {comp['logp']}")
        print(f"      structure law satisfied: "
              f"{s['structure_law_satisfied']}  fragments: "
              f"{', '.join(s['matched_fragments'])}")

    print("\n[3] REVERSE: SMILES -> mechanism class -> indications")
    probes = [
        ("metformin (KB)", "CN(C)C(=N)N=C(N)N"),
        ("salbutamol (KB)", "CC(C)(C)NCC(C1=CC(=C(C=C1)O)CO)O"),
        ("caffeine (NOT in KB)", "Cn1cnc2c1c(=O)n(C)c(=O)n2C"),
        ("benzene (NOT in KB)", "c1ccccc1"),
    ]
    for label, smi in probes:
        res = reverse_class_match(layer, laws, smi)
        if res["verdict"] == "PROVEN_CLASS_MATCH":
            cls = res["classes"][0]
            print(f"  {label:26} -> class {cls['mechanism_class']} "
                  f"(law: {' AND '.join(cls['structure_law'])})")
        else:
            print(f"  {label:26} -> {res['verdict']} ({res['reason'][:52]})")

    print("\n[4] GENERIC: a NEW disease (not in the KB) inside the "
          "mechanism vocabulary")
    novel = {"system": "RESPIRATORY", "etiology": "ALLERGIC_ATOPIC",
             "microbe": "NONE", "site": "AIRWAY", "chronicity": "CHRONIC",
             "pathway": "PW_AIRWAY_EOSINOPHILIC_INFLAMMATION"}
    res = gen.query(novel)
    print(f"  verdict: {res['verdict']}  class: {res['mechanism_class']}")
    for c in res["candidate_set"]:
        print(f"    {c['drug']:<28} tier {c['tier']} eff {c['efficacy']} "
              f"K={c['rank_key']} structure-verified: {c['structure_verified']}")

    print("\n[5] SOUND REFUSAL: outside the vocabulary")
    bad = dict(novel, pathway="PW_FOREIGN_UNKNOWN")
    res = gen.query(bad)
    print(f"  unknown pathway -> {res['verdict']}: {res['reason'][:70]}")
    res = reverse_class_match(layer, laws, "not-a-smiles")
    print(f"  broken SMILES   -> {res['verdict']}")

    print("\nNOT clinical advice. Structure laws are verified over the closed")
    print("KB drug universe; reverse matches identify pharmacophoric")
    print("fragments, never bio-identity or safety. Re-verify everything:")
    print("  python3 apeiron_structure_proof.py --out-dir ./apeiron_structure_out")
    print("  (exit code 0 <=> all theorems EXACT_UNIVERSAL_PROOF)")


if __name__ == "__main__":
    main()
