#!/usr/bin/env python3
"""Generate COMPLETE LaTeX table environments for the APEIRON-X equations
document, from the engine's machine artifacts (equation_traces.json +
certificate). Complete environments are \\input at top level (inside table
floats) - \\input of bare rows inside an alignment does not compile."""
import json
import os
import sys

DL = "/home/z/my-project/download"
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, DL)
import disease_drug_kb as KB  # noqa: E402

DNAME = {r["did"]: r["name"] for r in KB.DISEASES}

RR = r">{\raggedright\arraybackslash}"


def esc(s):
    """Escape LaTeX special characters in plain text."""
    out = (str(s).replace("\\", "\\textbackslash{}")
           .replace("&", "\\&").replace("%", "\\%").replace("$", "\\$")
           .replace("#", "\\#").replace("_", "\\_")
           .replace("{", "\\{").replace("}", "\\}")
           .replace("~", "\\textasciitilde{}")
           .replace("^", "\\textasciicircum{}"))
    return out


def law_tex(law):
    """Readable law: feature names in \\texttt, AND/OR bold."""
    parts = law.split(" OR ")
    or_terms = []
    for term in parts:
        feats = [f"\\texttt{{{esc(f)}}}" for f in term.split(" AND ")]
        or_terms.append(" \\textbf{AND} ".join(feats))
    return " \\textbf{OR} ".join(or_terms)


def write(name, text):
    with open(os.path.join(HERE, name), "w") as fh:
        fh.write(text.rstrip() + "\n")


def main():
    traces = json.load(open(os.path.join(DL, "equations_out/equation_traces.json")))
    cert = json.load(open(os.path.join(DL, "equations_out/equations_certificate.json")))
    ev = {d["did"]: d for d in traces}

    # ------------------------------------------------------------------
    # 1. Worked-example candidate set (D08) - complete tabular
    # ------------------------------------------------------------------
    lines = [
        "\\begin{tabular}{lll}",
        "\\toprule",
        "Drug & Mechanism class & Status \\\\",
        "\\midrule",
    ]
    for c in ev["D08"]["eq4"]["candidates"]:
        tag = {"*": "guideline (test)", "+": "same class",
               "s": "sibling", "!": "violation"}[c["tag"]]
        lines.append(
            f"\\texttt{{{esc(c['drug'])}}} & \\texttt{{{esc(c['class'])}}} & {tag} \\\\")
    lines += ["\\bottomrule", "\\end{tabular}"]
    write("tab_candidates.tex", "\n".join(lines))

    # ------------------------------------------------------------------
    # 2. E-battery results - complete tabularx
    # ------------------------------------------------------------------
    e6 = [t for t in cert["theorems"] if t["theorem"].startswith("E6")][0]
    s6 = e6["stats"]
    rows = [
        ("E0", "Chain totality on $\\mathcal{D}$",
         "60/60 chains evaluate; EQ2 fires exactly one class on every encoding"),
        ("E1", "EQ2 exactness (channel $\\to$ mechanism)",
         "54 channel laws, 54 proved, 0 non-unique firings"),
        ("E2", "EQ3/EQ4 pair coverage",
         "217/217 known pairs satisfy $\\Theta_d$; superset property 0 "
         "violations; 0 ANF failures"),
        ("E3", "EQ4 discrimination",
         "11,040-pair matrix: 0 strict cross-class false positives; "
         "15 sibling overlaps; 99 same-class boundary pairs"),
        ("E4", "EQ5 first-line membership",
         "55/55 structure-covered first-line drugs inside the proved set; "
         "3 non-molecular first lines (N/A by proof)"),
        ("E5", "EQ6 identity round-trip",
         "55/55 first-line SMILES recover the exact KB drug through the "
         "identity law"),
        ("E6", "EQ7 master coupling",
         f"{s6['pairs_covered']}/{s6['pairs_covered']} known pairs coupled "
         "(0 misses); "
         f"full {s6['matrix_checks']:,}-pair matrix: 0 strict false "
         "positives; 0 per-disease audit failures"),
        ("E7", "Held-out external pairs",
         "18/18 external guideline pairs predicted; 11/11 guideline-true "
         "refusals refused"),
    ]
    lines = [
        f"\\begin{{tabularx}}{{\\textwidth}}{{l {RR}p{{4.4cm}} {RR}X}}",
        "\\toprule",
        "Tag & Subject & Result \\\\",
        "\\midrule",
    ]
    for tag, title, res in rows:
        lines.append(f"{tag} & {title} & {res} \\\\")
    lines += ["\\bottomrule", "\\end{tabularx}"]
    write("tab_battery.tex", "\n".join(lines))

    # ------------------------------------------------------------------
    # 3. Held-out pairs - complete tabularx each
    # ------------------------------------------------------------------
    e7 = [t for t in cert["theorems"] if t["theorem"].startswith("E7")][0]
    for fname, results in (("tab_heldout_pos.tex", e7["pos_results"]),
                           ("tab_heldout_neg.tex", e7["neg_results"])):
        lines = [
            f"\\begin{{tabularx}}{{\\textwidth}}{{{RR}p{{4.5cm}} l {RR}X}}",
            "\\toprule",
            "Disease & Drug & Guideline source \\\\",
            "\\midrule",
        ]
        for x in results:
            lines.append(f"{esc(x['did'])} {esc(DNAME.get(x['did'], ''))} & "
                         f"\\texttt{{{esc(x['drug'])}}} & {esc(x['cite'])} \\\\")
        lines += ["\\bottomrule", "\\end{tabularx}"]
        write(fname, "\n".join(lines))

    # ------------------------------------------------------------------
    # 4. Appendix - complete longtable with all 60 direct laws
    # ------------------------------------------------------------------
    lines = [
        "{\\footnotesize\\setlength{\\tabcolsep}{4pt}",
        f"\\begin{{longtable}}{{@{{}}l {RR}p{{4.0cm}} {RR}p{{8.4cm}}@{{}}}}",
        "\\caption{The direct disease $\\to$ structure laws "
        "($\\Theta_d$, verbatim).}\\label{tab:alllaws}\\\\",
        "\\toprule",
        "Did & Disease & Direct law $\\Theta_d(\\chi)$ \\\\",
        "\\midrule",
        "\\endfirsthead",
        "\\toprule",
        "Did & Disease & Direct law $\\Theta_d(\\chi)$ \\\\",
        "\\midrule",
        "\\endhead",
        "\\bottomrule",
        "\\endfoot",
    ]
    for did in sorted(ev):
        d = ev[did]
        theta = d["eq3"]["theta_readable"]
        if not d["eq3"]["has_structure_law"]:
            nonmol = ", ".join(d["eq3"]["non_molecular_classes"])
            law = ("\\emph{no molecular law} --- mechanisms "
                   f"\\texttt{{{esc(nonmol)}}} are biologic/polymer/extract "
                   "(structure N/A by proof)")
        else:
            law = law_tex(theta)
        lines.append(f"{did} & {esc(d['name'])} & {law} \\\\")
    lines += ["\\end{longtable}", "}"]
    write("tab_all_laws.tex", "\n".join(lines))

    # ------------------------------------------------------------------
    # 5. Worked-example EQ6 outputs - complete tabular
    # ------------------------------------------------------------------
    lines = [
        "\\begin{tabular}{lllllll}",
        "\\toprule",
        "Did & First line & ATC & $K$ & CID & MW \\\\",
        "\\midrule",
    ]
    for did in ("D08", "D01", "D03", "D15"):
        d = ev[did]
        comps = d["eq6"].get("components") or []
        smis = [c["smiles_canonical"] for c in comps]
        cids = [str(c["pubchem_cid"]) for c in comps]
        mws = [str(c["mw"]) for c in comps]
        lines.append(f"{did} & "
                     f"\\texttt{{{esc(d['eq5']['first_line'])}}} & "
                     f"{esc(d['eq5']['atc'])} & {d['eq5']['rank_key']} & "
                     f"{', '.join(cids)} & {', '.join(mws)} \\\\")
        for s in smis:
            lines.append(f"\\multicolumn{{6}}{{l}}{{\\scriptsize"
                         f"\\texttt{{{esc(s)}}}}} \\\\")
        lines.append("\\addlinespace[2pt]")
    lines += ["\\bottomrule", "\\end{tabular}"]
    write("tab_examples.tex", "\n".join(lines))

    print("tables written:", sorted(f for f in os.listdir(HERE)
                                    if f.startswith("tab_")))


if __name__ == "__main__":
    main()
