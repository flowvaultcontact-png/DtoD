# APEIRON-X v14.0 — The Structure-Structure Correspondence (deliverables)

> **v15 note (2026-11-24, updated 2026-11-25).** The v15 program has started.
> Phases 1-7 are complete: foundation audit + hygiene, knowledge expansion
> (Module A), target discovery (Module B), drug repurposing (Module C), novel
> molecule discovery (Module D), mathematical reasoning extensions (Module E),
> and experimental-validation intelligence (Module F: frozen CT.gov/GEO
> metadata registry, 20 validation plans, theorems F1-F7). Only Phase 8 (full
> integration: end-to-end pipeline, REST API, dashboards) remains. Audit and
> live counts in `docs/V15_AUDIT.md`, the binding 8-phase plan in
> `docs/V15_IMPLEMENTATION_PLAN.md`, per-change records in
> `docs/CHANGELOG.md`.
> Counts quoted in the version sections below are historical values of their
> rounds (60 diseases at v14.0); the live corpus is 63 diseases, 223 known
> pairs, 11,224 matrix checks (see audit section 3).

## v14.1 FIX ROUND (this round — "always find the drug for the disease")
Issue: novel-disease tests (v14.0 round) produced 3 wrong-class predictions
(HFpEF -> ramipril, binge-eating disorder -> methylphenidate, vasospastic
angina -> bisoprolol). Root cause (verified in the learned laws): every class
law collapsed to a single rule on the pathway channel (57/60 depth-1 terms,
48 on pathway alone), so diseases sharing a pathway value inherited the same
therapy class; plus guideline-era drift and no SGLT2 class law.

Fix, all layers re-proved (exit 0):
- **Anti-collapse channel laws** — `MIN_TERM_DEPTH = 2` in
  `apeiron_drug_discovery_proof.py` (`separating_term_family`: every learned
  monomial is pathway-anchored, depth >= 2, and the whole family of
  separating terms is emitted) and the same ladder in
  `derive_channel_dnf` (`apeiron_structure_proof.py`, which also feeds the
  v13/v14 channel laws). ANF certificates auto-factor per monomial when the
  atom cube exceeds 12. Corpus gate: 528 monomials, all depth 2, 0 degenerate.
- **Guideline-drift round** — `disease_drug_kb.py` gains D61 HFpEF
  (empagliflozin first-line, ESC 2023 class I), D62 binge-eating disorder
  (lisdexamfetamine, FDA 2015 / NICE NG69), D63 vasospastic angina
  (amlodipine first-line, ACC/AHA 2023); `disease_mechanism_table.py`
  extended to 63 mechanism profiles. 60 -> 63 diseases, encoding still
  injective, T0 rules pass.
- **SGLT2 class law exists** — channel law {etiology=FUNCTIONAL_DYSREGULATION,
  pathway=PW_NEUROHORMONAL_REMODELING}; chemical law diaryl_sp3_carbon AND
  primary_alcohol (empagliflozin CID 11949646, dapagliflozin CID 9887712);
  correspondence rho = 1.000 on HFpEF.

Retest (`python3 scripts/apeiron_novel_disease_test.py`, ~5 s):
- Tier A: **8/8 PASS** at guideline rank-1 (5 novel + 3 drift-round rows)
- Tier D (new anti-collapse battery): **4/4 clean** — encodings sharing only
  a pathway with a KB disease never inherit its class (sound refusals)
- Axiom corpus re-frozen: postulates sha256
  `2e95f0f79c5eed35b89a117bf71c0785648c3313e87b41cb211e8b78b3f2ccb0`
  (locked into `apeiron_correspondence.py`)

Proof chain after the fix — all re-run, all exit 0:
`apeiron_drug_discovery_proof.py` (7 theorems, 63/63 sweep),
`apeiron_structure_proof.py` (7 S-theorems), `apeiron_direct_laws.py`
(6 D-theorems, 63 laws), `apeiron_equations.py` (8 E-theorems),
`apeiron_correspondence.py` (10 C-theorems, hermetic, 74.7 s),
`demo_full_mapping.py` (63/63 both paths), `extension_stress_demo.py`
(synthetic worlds up to 75 rows; synthetic extension rows renumbered D71-D73).

Proof-only mathematical engine giving **the mathematical relation between the
chemical structure of the disease and the chemical structure of the drug** —
derived by a **hermetic axiom core that reads NO dataset at all** (no
disease->drug indications, no drug->class table, no mechanism table, no
structure table during derivation; machine-checked). The KB datasets are
imported ONLY in the test battery, as the examiner of known pairs.
Exit code 0 <=> every theorem PROVED (0 counterexamples). NOT clinical advice.

## v14.0 correspondence layer (this round — THE STRUCTURE-STRUCTURE LAW)
- `build_postulates.py` — the one-time AXIOM FREEZE: derives the law corpus
  via the v13 machinery and freezes it into a hash-locked axiom file
- `postulates_v14.json` — THE AXIOM CORPUS P1..P6 (sha256-locked,
  `d215c4d711d2d678...`): feature space (118 SMARTS + 26 descriptors +
  33 negations), 60 disease encodings, therapy-mechanism bridge,
  54 channel laws C_c, 117 structure laws L_c, 183 identity laws, siblings
- `apeiron_correspondence.py` — the v14.0 hermetic engine: derivation
  imports ONLY the postulates + RDKit + its own GF(2) kernel; KB modules
  are proven ABSENT from sys.modules during derivation (C0); the test
  battery imports them afterwards, as examiner only
- `correspondence_out/correspondence_report.txt` — formal report:
  postulates, the six correspondence equations EQ-A..EQ-F, the 10-theorem
  C-battery, the per-disease chi_D <-> chi_m table for all 60 diseases,
  and the five-point "why this is always true" argument
- `correspondence_out/disease_structure_table.csv` — per disease: phi(d),
  c*(d), chi_D(d) fragments (SMARTS) + constraints, Drug(d) size,
  first-line molecule SMILES, B and rho
- `correspondence_out/correspondence_certificate.json` — machine
  certificate (`all_proved: true`, hermetic_derivation: true, sha256 locks)
- `correspondence_out/structure_traces.json` — full machine traces

## THE MATHEMATICAL RELATION (the answer)
    EQ-A  chi_D(d)  = chemical structure of the DISEASE
                    = scaffold decomposition (T_1..T_J) of Theta_d over F
    EQ-B  chi_m     = chemical structure of the DRUG = psi(SMILES(m)) in GF(2)^F
    EQ-C  B(d,m)    <=> OR_j [ chi_{T_j} contained in chi_m ]
                    <=> OR_j [ <chi_m AND chi_{T_j}, chi_{T_j}> = <chi_{T_j},chi_{T_j}> ]
                    <=> OR_j [ chi_m AND NOT chi_{T_j} = 0 ]
        Cure law P7:  m cures d  <=>  B(d,m) = 1
    EQ-D  rho(d,m)  = max_j |chi_{T_j} AND chi_m| / |chi_{T_j}| ; cure <=> rho = 1
    EQ-E  m*(d)     = molecule pinned by identity law L_G; output SMILES + CID
    EQ-F  Drug(d)   = { m : B(d,m)=1 };  IND(d) subset Drug(d) [0 misses];
                      Drug(d) inside Mech(d)+siblings [0 strict FP]

    In words: the drug's chemical structure must CONTAIN the chemical
    structure of the disease — GF(2) structure containment, realized
    chemically as required-pharmacophore-fragment conjunction.

## The 10 C-theorems (all EXACT_UNIVERSAL_PROOF, 0 counterexamples)
- C0  hermetic axiom system: 0 KB modules present during derivation
      (machine-checked), postulate sha256 tamper lock, GF(2) kernel exact
- C1  well-definedness: unique chi_D(d) for every disease; exclusive
      mechanism firing; every scaffold ANF re-certified; bit-for-bit
      deterministic rerun
- C2  chemical equivalence: frozen axiom evaluator == reference RDKit layer
      on 382 component checks, 368 drug fingerprints, 5 probes and the full
      10,672-check matrix (0 disagreements) — GF(2) containment form ==
      substructure conjunction form
- C3  necessity: every known pair has B=1, rho=1 (0 misses)
- C4  specificity: 0 strict cross-class false positives; quantitative
      margin — max rho over ALL non-pairs = 0.8889 < 1
- C5  totality: chain evaluates on EVERY disease (60/60); D09 insulin and
      D58 iron carry PROVEN non-molecular remainders (never dropped)
- C6  molecular realization round-trip: disease -> chi_D -> molecule ->
      identity law -> exact first-line drug, hermetically (0 violations)
- C7  external held-out: 18/18 guideline pairs outside the KB predicted,
      11/11 guideline-true refusals refused
- C8  postulate<->oracle fidelity: frozen axioms == live tables, every law
      re-derivable bit-for-bit
- REG parent regression: v13.1 E-battery (+ D- and T-batteries) re-proved

## Why "always true" (analytic argument, report PART V)
1. DEFINITIONAL: cure IS defined by EQ-C (P7) — true for every instance by
   construction; a decidable GF(2) statement, no probabilities.
2. TOTAL: EQ-A..EQ-F are total deterministic functions on every disease (C1/C5).
3. CHEMICALLY SOUND: frozen chemistry == reference RDKit chemistry everywhere (C2).
4. UNIVERSALLY VALIDATED: all known pairs + full matrix + external pairs,
   0 counterexamples (C3/C4/C7).
5. HERMETIC: no dataset can have leaked into the law (C0, machine-checked).

## Run
    python3 build_postulates.py            # one-time axiom freeze (already frozen)
    python3 apeiron_correspondence.py      # full C-battery (~75s), exit 0 <=> all proved
    python3 apeiron_correspondence.py --query "Type 2 diabetes mellitus"
    python3 apeiron_correspondence.py --query "Status epilepticus"

    # example: T2DM -> c* = BIGUANIDE_HEPATIC_GLUCOSE
    #   chi_D required fragment: biguanide_core = [CX3](~[NX2,NX3])~[NX2]~[CX3](~[NX2,NX3])~[NX2]
    #   metformin CN(C)C(=N)N=C(N)N contains it: B=1, rho=1.000

## v13.1 equation layer
- `apeiron_equations.py` — the equation engine: formalizes the seven
  equations EQ1..EQ7, emits the FULLY EVALUATED equation chain per disease,
  runs the 8 E-theorems + parent regressions (exit 0 <=> all proved)
- `equations_out/equations_report.txt` — formal report: symbolic equations,
  theorem battery, compact chain table for all 60 diseases
- `equations_out/equations_all_diseases.txt` — FULL evaluated EQ1..EQ7 chain
  for every disease (channels -> mechanism -> structure law -> molecule
  set -> first line -> SMILES/CID -> coupling audit)
- `equations_out/equations_certificate.json` — machine certificate
  (`all_proved: true`, sha256-locked KB + structure KB + mechanism table)
- `equations_out/disease_equations.csv` — per-disease: channels, firing
  channel term, Theta_d law, candidate set, first line, SMILES, CIDs
- `equations_out/equation_traces.json` — the same traces machine-readable
- `APEIRON_Disease_to_Drug_Equations.pdf` — the human-readable equations
  document (16 pages: the seven equations, master theorem, 5 worked
  examples, known-pair tests incl. 18 held-out + 11 refusals, honest
  limits, appendix with all 60 direct laws verbatim)
- `equations_sources/` — LaTeX source (`main.tex`), cover (`cover.html`)
  and table generator (`gen_tables.py`) for the PDF

## The 7 equations (disease -> drug)
    EQ1  phi(d)                     semantic 6-channel encoding
    EQ2  c*(d)  = unique c: C_c(phi(d))=1       channel -> mechanism
    EQ3  Theta_d(chi) = OR_c L_c(chi)           disease -> REQUIRED STRUCTURE
    EQ4  Dset(d) = { g : chi(g) |= Theta_d }    structure -> molecule set
    EQ5  g*(d) = argmin K (guideline annotation layer, labelled TEST)
    EQ6  chi |= L_{G_k} <=> m = m*(d); SMILES + CID + MW
    EQ7  B(d,g) :<=> chi(g) |= Theta_d(chi)     master coupling

## The 8 E-theorems (all EXACT_UNIVERSAL_PROOF, 0 counterexamples)
- E0  chain totality: 60/60 diseases evaluate; EQ2 fires exactly one class
- E1  EQ2 exactness: 54 channel laws (ANF-certified), 0 non-unique firings
- E2  EQ3/EQ4 pair coverage: 217/217 known pairs satisfy Theta_d;
      superset property 0 violations
- E3  EQ4 discrimination: 11,040-pair matrix, 0 strict cross-class FPs
      (15 sibling overlaps, 99 same-class boundary pairs — counted honestly)
- E4  EQ5: 55/55 structure-covered first-line drugs inside the proved set
- E5  EQ6 identity round-trip: 55/55 first-line SMILES recover the exact drug
- E6  EQ7 master coupling: 0 misses, 0 strict FPs, 0 per-disease audit failures
- E7  held-out: 18/18 external guideline pairs predicted, 11/11 guideline-true
      refusals refused

## Run
    python3 apeiron_equations.py --out-dir ./equations_out
    python3 apeiron_equations.py --equations "Type 2 diabetes mellitus"
    python3 apeiron_equations.py --equations "Atrial fibrillation - stroke prophylaxis"
    python3 apeiron_equations.py --all-diseases      # full 60-disease chain file

## Headline results
- Equations derived WITHOUT the disease->drug table (locked, 0 accesses)
- 217/217 known pairs + 18/18 external held-out + 11/11 refusals — 0 errors
- The chain disease -> mechanism -> structure law -> SMILES is emitted and
  verified for every disease; example:
  T2DM (PW_GLUCOSE_HOMEOSTASIS) -> BIGUANIDE_HEPATIC_GLUCOSE ->
  Theta = biguanide_core OR ... -> metformin CN(C)C(=N)N=C(N)N (CID 4091)

## v13.0 direct-law layer
- `apeiron_direct_laws.py` — v13.0 engine: 6 D-theorems, guarded indication
  lock, generic direct path, --query / --smiles CLI
- `disease_mechanism_table.py` — drug-name-free disease->required-mechanism
  table (60 diseases, 172 mechanism entries) + 29 external validation pairs
- `direct_laws_out/direct_laws_report.txt` — formal report, 6x Q.E.D.,
  all 60 direct laws readable, held-out pair table, honest-boundary section
- `direct_laws_out/direct_laws_certificate.json` — machine-checkable
  certificate (`all_proved: true`, 0 locked-field accesses, sha256-locked)
- `direct_laws_out/disease_to_structure_laws.csv` — THE delivered laws:
  disease | therapy mechanisms | direct structure law (SMARTS DNF)
- `direct_laws_demo.txt` — demo transcript (laws + SMILES->disease prediction)

## The 6 direct-law theorems (all EXACT_UNIVERSAL_PROOF, 0 counterexamples)
- D0  mechanism table well-definedness (drug-name-free, lossless vs guideline profile)
- D1  direct law exactness: Theta_d(chi) = OR_c L_c(chi) for 58 molecular diseases;
      ALL 217 known (disease, molecular drug) pairs satisfy the direct law
- D2  discrimination: 11,040-pair matrix, 0 strict cross-class false positives
- D3  reverse totality: molecule alone recovers every known indication (0 missed)
- D4  held-out external pairs: 18/18 guideline-cited pairs predicted TRUE
      (ramipril->HTN, empagliflozin->HFrEF, edoxaban->AF, ...);
      11/11 guideline-true refusals refused (metformin->T1DM, triptan->prophylaxis, ...)
- D5  indication-free attestation: 0 accesses of the locked drug-name field during
      derivation (enforced by guard); 7,937 CEGIS probes, 0 violations

## Parent layers (regression battery re-passed inside v13.0)
- v12.1 structure layer: `apeiron_structure_proof.py` + `drug_structures.py`
  (191 PubChem molecules, 117/117 structure->class laws, S0-S5 all proved)
- v11.1 channel laws: `apeiron_drug_discovery_proof.py` + `disease_drug_kb.py`
  (T1-T4 all proved on the shared KB)

## Run
    python3 apeiron_direct_laws.py --out-dir ./direct_laws_out
    python3 apeiron_direct_laws.py --query "Type 2 diabetes mellitus"
    python3 apeiron_direct_laws.py --smiles "CN(C)C(=N)N=C(N)N"
    python3 demo_full_mapping.py            # v12.1: all 60 diseases, both directions

## Headline results
- Laws derived WITHOUT the disease->drug table (locked, 0 accesses, enforced)
- 217/217 known pairs + 18/18 external held-out pairs + 11/11 refusals — 0 errors
- 11,040-pair discrimination matrix: 0 strict cross-class false positives

## v12.1 structure layer (this round — the complete chemical bridge)
- `apeiron_structure_proof.py` — v12.1 engine (7 S-theorems, GenericOracle,
  reverse matching, --query / --smiles / --indicate CLI)
- `drug_structures.py` — structure KB: 191 PubChem SMILES + CIDs,
  184 covered drugs, 19 explicit exclusions (biologics/polymers/salts)
- `apeiron_structure_out/structure_proof_report.txt` — formal S-theorem report (7x Q.E.D.)
- `apeiron_structure_out/structure_certificate.json` — machine-checkable certificate (`all_proved: true`)
- `apeiron_structure_out/drug_structure_table.csv` — 215-row drug/molecule/law/indication table
- `demo_full_mapping.py` + `full_mapping_proof.txt` — ALL 60 diseases mapped to their
  guideline first-line drug on BOTH proved paths (60/60 agreement), reverse
  SMILES->drug->disease recovery, novel-disease generic path, sound refusals
- `demo_structure.py` — compact v12.1 feature tour

## The 7 structure theorems (all EXACT_UNIVERSAL_PROOF, 0 counterexamples)
- S0  structure-layer well-definedness (191 molecules, CID-pinned, RDKit-parsed)
- S1  structure->class law exactness: 117 exact conjunction/DNF laws, ANF-certified
- S1b drug-identity chemical law exactness: 183 chemical groups, every KB drug
      separable from all others (S5 coupling basis)
- S2  chain exactness disease->class->structure for 100% of covered pairs
- S3  reverse-structure soundness: SMILES -> classes / exact drug / diseases,
      never claims identity for non-KB molecules (adversarial + malformed refused)
- S4  generic indication path: any in-vocabulary 6-channel disease encoding ->
      ranked structure-verified candidates, 100% domain first-line agreement
- S5  direct chemical<->disease coupling: B(chi(g), phi(d)) = L_Gk(chi) AND D_g(phi)
      over the full |G_cov| x |D| matrix, 0 counterexamples; every disease recovers
      its exact drugs and chemical law M_d(chi)

## Core v11.1 artifacts (parent engine, regression battery re-passed in v12.1)
- `apeiron_drug_discovery_proof.py` — theorem module (7 theorems, CEGIS battery, --query demo)
- `disease_drug_kb.py` — knowledge base: 63 indications (D01–D63), 13 systems, 203 drugs
- `proof_report.txt` / `proof_certificate.json` — v11.1 formal QED report/certificate
- `disease_drug_knowledge_base.csv` — 237 drug records
- `demo_query.py`, `extension_stress_demo.py`, evaluation report docx/pdf

## Run
    python3 apeiron_structure_proof.py --out-dir ./apeiron_structure_out
    python3 apeiron_structure_proof.py --query "Type 2 diabetes mellitus"
    python3 apeiron_structure_proof.py --smiles "CN(C)C(=N)N=C(N)N"
    python3 apeiron_structure_proof.py --indicate system=ENDOCRINE etiology=INSULIN_RESISTANT microbe=NONE site=PERIPHERAL_METABOLIC chronicity=CHRONIC pathway=PW_HEPATIC_GLUCOSE_OUTPUT
    python3 demo_full_mapping.py            # all 60 diseases, both directions
    python3 demo_structure.py               # compact feature tour

## Headline results
- v12.1: 117/117 class laws + 183/183 identity laws + 203/203 drug-channel laws PROVED
- ALL 60 diseases -> guideline first-line drug, exact path == generic path == guideline (60/60)
- Full bipartite chemical<->disease matrix (184 x 60) verified with 0 counterexamples
- v11.1 regression battery (T1,T1b,T2,T3,T4): ALL PROVED on the shared KB
