# APEIRON-X v15 — DETAILED IMPLEMENTATION PLAN

Companion document: `docs/V15_AUDIT.md` (Phase 1 foundation audit, baseline
evidence, risk register R1–R12). This plan is binding for the v15 rounds:
incremental, evidence-gated, never at the cost of the v14.1 proof engine.

## 0. PRINCIPLES (inviolable)

1. The v14.1 cascade must exit 0 after EVERY round (T/S/D/E/C batteries,
   demos, novel-disease harness). A round that breaks it is not merged.
2. Never weaken a mathematical constraint; never edit a law to make a test
   pass; never touch the three hash-pinned KB files or `postulates_v14.json`
   without a full re-freeze + re-pin (audit R1).
3. Separation of claim tiers is mandatory in every output:
   `PROVEN_MATH` (exact, machine-checked, closed corpus) / `EVIDENCED`
   (cited experimental/guideline evidence) / `COMPUTATIONAL` (inference) /
   `HYPOTHESIS` (speculative). No tier migration without new evidence.
4. Never fabricate data, references, interactions or experimental results.
   Absent data is reported as absent, with the field named.
5. Every KB growth follows the checklist of V15_AUDIT §5(c) and ends with the
   full cascade re-run.
6. New data modules MUST be appended to `KB_MODULES` (C0 hermeticity audit)
   and to postulate `provenance`.

## 1. TARGET END-STATE (12 months, 8 phases)

DISEASE (any name/ontology/genetic profile) -> normalized molecular profile ->
genes/proteins/pathways -> ranked targets -> approved & investigational drugs ->
repurposing hypotheses -> novel candidate molecules -> ADMET/toxicity screen ->
evidence-weighted transparent ranking -> APEIRON-X consistency checks ->
structured discovery report with experimental validation plan.

Non-goals (explicit): clinical decision support; claiming efficacy; replacing
experimental validation; live-claiming "always cures".

## 2. PHASE 1 — FOUNDATION AUDIT & ENGINEERING HYGIENE (this round)

Status: audit complete (`V15_AUDIT.md`); hygiene patch + scaffold in progress.

- P1-1 DONE — Full source audit, architecture map, data shapes, extension
  points (V15_AUDIT §§2–5).
- P1-2 DONE — Baseline cascade executed, all 9 entries exit 0; logs in
  `docs/baseline/`.
- P1-3 Hygiene patch (engines only, no hash-pinned file): correct stale
  narrative counts (audit R2) so no report claims a number the live corpus
  contradicts; make the D9/D58 non-molecular remainder line and the stress-demo
  world labels dynamic.
- P1-4 Dependency pinning: `requirements.txt` (numpy, rdkit==2026.09.2) +
  engine version banner; RDKit-fingerprint portability gate becomes a Phase 6
  proof obligation (R4).
- P1-5 v15 scaffold (additive only): `apeiron/v15/` package with
  provenance-record model, tiered-claim model, extended disease profile
  (Module A data model), target-scoring skeleton (Module B), a regression
  runner `run_full_regression.py` that executes the whole v14.1 cascade and
  fails on any non-zero exit. v15 code imports v14.1 modules read-only.
- Acceptance: cascade exit 0; v15 unit tests pass; no file under `apeiron/`
  hash-pinned modified (verified by sha256 before/after).

## 3. PHASE 2 — SCIENTIFIC KNOWLEDGE EXPANSION (Module A)

Status: DONE (2026-11-24). P2-1 vocab frozen + pinned; P2-2 profiles +
derive_phi + injectivity shipped and tested; P2-3 growth-pack machinery
shipped and the first pack (D64–D68, five new organ systems) applied
with documented re-freeze; P2-4 cardinality theorem T5 proved on the
pack (0 counterexamples). Evidence: CHANGELOG "v15 Phase 2" entry;
`v15/kb_extensions/`; cascade 11/11 exit 0.

Goal: representation beyond the 6-channel vocabulary WITHOUT breaking phi
injectivity or the frozen corpus.

- P2-1 `v15/vocab.py`: additive vocabularies — disease ontology (MONDO/OMIM/
  ICD-10/MeSH mapping table, frozen), gene (HGNC/Ensembl), protein (UniProt
  accession), pathway (Reactome/KEGG ids as data, license fields), GO terms,
  phenotype (HPO). All frozen tables carry: source id, version, retrieval
  date, license, evidence tier, sha256 (audit §5(d) pattern).
- P2-2 `v15/disease_profile.py`: `DiseaseProfile` = the v14.1 six-channel
  encoding (optional) + layered evidence map: `established / inferred /
  unknown` per field (genetics, expression, protein abnormality, metabolic,
  immune, cellular, tissue, pathways, progression, environment/infectious).
  Converter `profile -> phi(d)` when the six channels are derivable, else
  explicit `NOT_ENCODABLE(v15)` verdict (extends Tier B honesty to v15).
- P2-3 `v15/kb_extensions/`: growth procedure for D64+ rows as DATA PACKS:
  each pack = new diseases + drugs + mechanism profiles + molecules + citations,
  applied by one script that (i) validates packs, (ii) applies the §5(c)
  checklist, (iii) re-freezes postulates, (iv) re-pins the sha, (v) re-runs the
  full cascade. This automates R1 instead of hand-editing.
- P2-4 Cardinality guard theorem (new T5): every vocabulary value used by a
  knowledge pack has cardinality >= 2 in the merged KB, or the pack documents
  the degenerate-channel consequence (audit R10).
- Acceptance: profile round-trip tests; phi-converters injective on the merged
  corpus; cascade exit 0 after the first growth pack (e.g. +5 diseases spanning
  new systems).

## 4. PHASE 3 — BIOLOGICAL TARGET DISCOVERY (Module B)

Status: DONE (2026-11-25). P3-1 frozen target table (`v15/target_data.py`, sha256-pinned in
`v15/kb_extensions/targets_pins.json`) authored verbatim from machine-verified fetches;
P3-2 transparent ranking + `theorem_rank_determinism`; P3-3 `theorem_anti_causal_illusion`
(new C-class obligation, PROVEN_MATH on the encoded panel); P3-4 connector skeleton with the
frozen-response pattern (`v15/connectors/`, cache under `v15/cache/`, only tool with network
access is `refresh_phase3_cache.py --live`). Acceptance: 10-disease benchmark with macro
recall@10 = 1.0 (16/16 guideline targets, honest coverage gaps recorded); evidence in
CHANGELOG 'v15 Phase 3'; cascade 12/12 exit 0.

Goal: disease -> ranked molecular intervention points, evidence-tiered.

- P3-1 `v15/targets.py`: target types (gene, receptor, enzyme, ion channel,
  transporter, TF, signaling protein, complex, pathway node); per-target
  evidence records: genetic (GWAS/OMIM/ClinGen), functional (KO/CRISPR
  screens), pharmacological (existing drugs), literature (Europe PMC citations
  with ids — never fabricated).
- P3-2 Scoring (transparent, no hidden merge): separate axes —
  `genetic_evidence`, `functional_evidence`, `pharmacological_tractability`,
  `safety_penalty`, `novelty`. Displayed individually; an aggregate is
  explicitly labelled `COMPUTATIONAL_RANK` and never a probability.
- P3-3 Anti-causal-illusion theorem (new C-class obligation): a target whose
  only evidence is disease association is flagged
  `ASSOCIATION_NOT_CAUSATION`; ranking must expose this flag.
- P3-4 Connector skeleton `v15/connectors/` with a frozen-response pattern:
  `opentargets.py`, `uniprot.py`, `reactome.py` fetchers store raw responses +
  retrieval metadata under `v15/cache/<sha256>.json`; derivation still consumes
  only frozen tables (keeps C0 hermeticity doctrine intact).
- Acceptance: benchmark on 10 diseases with guideline-recognized targets
  (e.g. PCSK9, BCR-ABL, CFTR) — top-10 recall reported honestly incl. misses.

## 5. PHASE 4 — DRUG REPURPOSING ENGINE (Module C)

Status: DONE (2026-11-25). P4-1 frozen pack (`v15/repurposing_data.py`, sha256-pinned in
`v15/kb_extensions/repurposing_pins.json`, generator `scripts/gen_phase4_pack.py`) authored
verbatim from machine-verified fetches (18 drugs x Open Targets/ChEMBL/UniProt, 5 indication
diseases, 13 Europe PMC landmark citations, 0 absences); P4-2 status discipline + theorem;
P4-3 Theta_d consistency bridge (read-only v14.1 import; MECH_STRUCTURE_CONFLICT /
NOT_IN_CORPUS exposed, never silent); P4-4 temporal benchmark with hermeticity theorem.
Acceptance: macro recall@10 = 1.0 over 4 diseases / 6 post-2015 outcomes (SGLT2i era);
truth pairs separated from zero-support candidates on all four diseases; HFpEF ranks
dapagliflozin #1 from pre-2015 knowledge alone; finerenone/semaglutide structurally absent
from every pre-2015 candidate list. Evidence in CHANGELOG 'v15 Phase 4'; cascade 13/13 exit 0.
- P4-1 `v15/repurposing.py`: for (disease, target) pairs, retrieve known
  drug-target interactions (DrugBank/ChEMBL/BindingDB licences permitting;
  frozen packs) -> drugs affecting the target -> mechanism-vs-disease
  compatibility check against `MECH_REQUIRED`-style profiles -> contradiction
  scan (opposing pharmacology rows) -> safety/contraindication annotations.
- P4-2 Status discipline: every candidate carries exactly one of
  `APPROVED_INDICATION` / `INVESTIGATIONAL` / `COMPUTATIONAL_HYPOTHESIS` /
  `EXPERIMENTALLY_VALIDATED` + traceable citation ids. Never present a
  computational hypothesis as treatment.
- P4-3 Consistency bridge (mathematical): repurposing candidates whose
  disease has a v14.1 encoding must ALSO satisfy the direct structure law
  Theta_d (B(d,m)=1) to be ranked `EVIDENCED`; violations surface as
  `MECH_STRUCTURE_CONFLICT` findings, not silent drops.
- P4-4 Held-out benchmark: temporal split (pre-2015 evidence -> predict
  post-2015 repurposing successes, e.g. SGLT2i HF) + negative controls.
- Acceptance: 100% of emitted candidates carry status + citations; benchmark
  report includes false leads examined.

## 6. PHASE 5 — NOVEL MOLECULE DISCOVERY (Module D)

Status: DONE (2026-11-25). P5-1..P5-3 chem package shipped (`v15/chem/`:
mol_io + frozen P1-v15 feature-space manifest, props all
PREDICTED_RULEBASED, admet registry shipped EMPTY + docking gate +
PAINS/Brenk alerts); P5-4 deterministic law-guided pipeline (100
candidates emitted, 178 rejections recorded, 0 silent drops); P5-5
truth-in-labeling theorem proved with 4 negative controls. Acceptance:
round-trip on all 191 KB molecules unchanged (0 chi mismatches, 117
laws re-certified, 0 member violations, 0 false positives); 100/100
generated molecules pass validity+labeling; cascade 14/14 exit 0.
Evidence in CHANGELOG 'v15 Phase 5'.
- P5-1 `v15/chem/mol_io.py`: SMILES sanitize/validate, fingerprints (extend
  the 118-SMARTS space versioned as P1-v15), substructure/similarity search,
  pharmacophore queries derived from structure laws L_c.
- P5-2 `v15/chem/props.py`: RDKit-based descriptors (MW, cLogP, TPSA, HBD/HBA,
  rotB), lipinski/veber flags, approximate solubility/permeability classes —
  all labelled `PREDICTED_RULEBASED`, never measured.
- P5-3 `v15/chem/admet.py`: model registry with per-model version, training
  provenance and validation sheet; outputs are `PREDICTED_ML` with confidence
  intervals where the model provides them. No docking claim without a docking
  run record (PDB/structure id, protocol, version).
- P5-4 Generation + filtering pipeline: enumerate analogs around law-satisfying
  scaffolds (structure-law-guided), then filters: chemical validity (RDKit),
  synthetic accessibility (SA score), novelty (vs KB + ChEMBL pack), toxicity
  alerts (PAINS/Brenk flags), pharmacological plausibility (satisfies some L_c).
- P5-5 Truth-in-labeling theorem (new S-class obligation): every emitted
  molecule record carries `status in {KNOWN_MOLECULE, GENERATED_CANDIDATE}`
  and zero records claim binding or efficacy.
- Acceptance: round-trip SMILES->features->laws on all 191 KB molecules
  unchanged; 100 generated molecules all pass validity+labeling tests.

## 7. PHASE 6 — MATHEMATICAL REASONING EXTENSIONS (Module E)

Status: DONE (2026-11-25). P6-1 frozen P8 knowledge-graph section shipped (`v15/kgraph_data.py`, sha256-pinned in
`v15/kb_extensions/kgraph_pins.json`, generator `scripts/gen_phase6_pack.py`): 1539 edges over the 7 formal
relations, 726 nodes, 48 provenance records, 73 recorded absences, byte-identical regeneration proven;
P6-2 all eight new proof obligations proved (E1-E8) plus the P6-3 fingerprint-portability gate (E9, live RDKit ==
2026.09.2 pin, 191-molecule round-trip re-certification) and the P6-4 memo-determinism theorem (E10: 12,144 pairs,
0 mismatches, warm sweep 33.955s -> 0.010s, C-battery 78.5s -> 46.1s with C1 intact). Acceptance: 10/10 theorems,
10/10 battery checks (4 negative controls + tier-downgrade control), cascade 15/15 exit 0, frozen files untouched.
Evidence in CHANGELOG 'v15 Phase 6'.

- P6-1 Formal relations as typed edges: disease->gene, gene->protein,
  protein->pathway, target->mechanism, mechanism->drug, drug->structure,
  structure->property; each edge carries evidence tier + provenance + sha256.
  A new postulate section P8 (knowledge graph) frozen like P1–P6 (R1 automated
  by P2-3 tooling).
- P6-2 New proof obligations (each a `theorem_*` with the standard shape):
  graph consistency (no contradictory cycles), uniqueness of normalized
  disease identity, contradiction detection (opposing mechanisms), evidence
  provenance completeness (no uncited edge in an `EVIDENCED` chain), ranking
  integrity (rank order invariant under permuting input row order),
  uncertainty propagation (tier propagation rules), out-of-domain detection
  (extends UNPROVEN doctrine to v15 profiles), reproducibility (bit-for-bit
  re-derivation, extends C1/C8).
- P6-3 Fingerprint-portability gate (R4): theorem that frozen identity laws
  re-verify under the pinned RDKit; CI job pins rdkit==2026.09.2.
- P6-4 Performance with proofs intact (R5): memoize granular sets inside
  `coupling` guarded by a determinism theorem (memoized == recomputed on the
  full corpus).
- Acceptance: new theorems enter the battery; exit 0 cascade retained.

## 8. PHASE 7 — EXPERIMENTAL VALIDATION INTELLIGENCE (Module F)

Status: DONE (2026-11-25). P7-2 frozen dataset registry shipped (`v15/validation_data.py`,
sha256-pinned in `v15/kb_extensions/validation_pins.json`, generator
`scripts/gen_phase7_pack.py`): 158 CT.gov studies + 35 GEO series (metadata + accession
ONLY; the CT.gov fields whitelist makes results content structurally unfetchable), 15
provenance records, 4 recorded absences, mechanical candidate/disease links with their
token filters recorded in the link rows; P7-1 `v15/validation_plan.py`: 20 validation plans
(17 drug x disease + 3 generated molecules), stage gates biochemical->cellular->tissue->
animal->human with honest states, P7-3 required-evidence-to-change-status on every plan,
the upgrade code path always raises; acceptance F1-F7 all PROVEN_MATH, 14/14 battery
checks (16 build-gate refusal lanes), cascade 16/16 exit 0, frozen files untouched.
Evidence in CHANGELOG 'v15 Phase 7'.

- P7-1 `v15/validation_plan.py`: per candidate — mechanism narrative (tiered),
  target-engagement hypothesis (assay class), supporting + contradictory
  evidence with ids, proposed model systems, control groups, endpoints
  (measurable, assay-annotated), failure mechanisms, stage gates
  (biochemical -> cellular -> tissue -> animal -> human).
- P7-2 External dataset hooks (GEO/CT.gov): metadata + accession records
  only; results never synthesized.
- P7-3 Report discipline: "required evidence to change status" section per
  candidate.
- Acceptance: every `EVIDENCED`+ candidate ships with a complete plan; plans
  pass a schema test.

## 9. PHASE 8 — FULL INTEGRATION & BENCHMARKS

Status: DONE (2026-11-25). P8-1 `v15/discover.py` shipped: the 12-step
workflow (§5) emitting the 18-section versioned report (schema 15.8.0,
canonical sha256 in the header, zero wall-clock fields), exact-match
resolution with 4-field absence records everywhere, uncited-phi
refusals, OOD inputs -> honest empty world, `as_of` temporal lane; six
report theorems R1-R6 all PROVEN_MATH. P8-2 `v15/api.py`: versioned
read-only REST API (`/api/v1/`, GET-only, 405 on mutations, explicit
404s, memoized deterministic payloads, hermetic — no connector imports,
no outbound network) + `v15/dashboard.py` static research dashboard
(zero JS, deterministic). P8-3 `v15/tests/test_v15_phase8.py`: 19-check
battery (temporal validation, APXD leakage, negative controls, live
ephemeral-port server round trip, AST hermeticity gates, module
coverage scan); cascade grows 16 -> 18 stages, 18/18 exit 0. P8-4
`v15/limitation_report.py`: achievements (artifact-backed) + known gaps
per lane + non-goals, served at `/api/v1/limits`. Acceptance: 6/6
report theorems, 19/19 battery checks, 18/18 cascade stages exit 0,
frozen files untouched. Evidence in CHANGELOG 'v15 Phase 8'.

- P8-1 End-to-end pipeline `v15/discover.py` implementing the 12-step
  workflow (master prompt §5) emitting the 18-section report (§9).
- P8-2 REST API (read-only, versioned) + research dashboard; structured JSON
  schemas versioned.
- P8-3 Test suites per module (master prompt §7 list) + temporal validation +
  negative controls + leakage checks; CI runner with staged timeouts (R7),
  harness path refactor (R8), demo expectations moved to data files (R9),
  stress demo isolated to subprocess (R12).
- P8-4 Honest-limitation report generator: emits known gaps (licences not
  obtained, models not validated, endpoints refused) alongside achievements.

## 10. ROUND ORDER & CURRENT POSITION

| Round | Content | Status |
|---|---|---|
| 0 | v14.1 fix (anti-collapse, drift D61–D63, SGLT2 law) | DONE (prior round, re-verified today) |
| 1 | Phase 1: audit + baseline + hygiene + scaffold | DONE (2026-11-24) |
| 2 | Phase 2: vocab + profiles + growth packs | DONE (2026-11-24: P2-1..P2-4 + pack D64–D68 applied, cascade 11/11 exit 0; see CHANGELOG) |
| 3 | Phase 3: target discovery (Module B) | DONE (2026-11-25: P3-1..P3-4, benchmark
|   | | macro recall@10 = 1.0, cascade 12/12 exit 0; see CHANGELOG) |
| 4 | Phase 4: drug repurposing (Module C) | DONE (2026-11-25: P4-1..P4-4, temporal
|   | | benchmark macro recall@10 = 1.0, cascade 13/13 exit 0; see CHANGELOG) |
| 5 | Phase 5: novel molecule discovery (Module D) | DONE (2026-11-25: P5-1..P5-5,
|   | | round-trip 191/191 unchanged + 100/100 candidates, cascade 14/14 exit 0; see CHANGELOG) |
| 6 | Phase 6: mathematical reasoning extensions (Module E) | DONE (2026-11-25: P6-1..P6-4, 1539-edge frozen
|   | | P8 graph + 10/10 theorems incl. E9 fingerprint gate + E10 memo determinism, cascade 15/15 exit 0; see CHANGELOG) |
| 7 | Phase 7: experimental-validation intelligence (Module F) | DONE (2026-11-25: P7-1..P7-3,
|   | | frozen CT.gov/GEO metadata registry + 20 validation plans + 7/7 theorems,
|   | | cascade 16/16 exit 0; see CHANGELOG) |
| 8 | Phase 8: full integration & benchmarks as above | DONE (2026-11-25: P8-1..P8-4, 12-step pipeline -> 18-section
|   | | deterministic report, versioned read-only API + dashboard, 19-check battery,
|   | | honest-limitation generator, cascade 18/18 exit 0; see CHANGELOG) |

## 11. ACCEPTANCE GATE FOR EVERY ROUND (binding)

1. `run_full_regression.py` exit 0 (whole v14.1 cascade + v15 tests).
2. sha256 of `disease_drug_kb.py`, `drug_structures.py`,
   `disease_mechanism_table.py`, `postulates_v14.json` unchanged, or a
   documented re-freeze with new pin + full cascade evidence.
3. No claim-tier violation in emitted artifacts (automated scan for
   "cure"/"treats"/"efficacious" outside quoted citations).
4. Changelog entry with per-file diff summary and reproducible commands.
