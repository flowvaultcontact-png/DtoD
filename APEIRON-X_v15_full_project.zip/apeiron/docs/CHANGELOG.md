# APEIRON-X CHANGELOG — v15 program

Format: each round lists what changed, why, and how to reproduce the
verification. Frozen-data files (`disease_drug_kb.py`, `drug_structures.py`,
`disease_mechanism_table.py`, `postulates_v14.json`) must keep their sha256
unless a round documents a full re-freeze; their reference hashes are
recorded in `docs/baseline/frozen_files_sha256_before.txt`.

## v15 Phase 1 — Foundation audit & engineering hygiene (2026-11-24)

Scope: documentation + narrative-string corrections in engine files only.
No law, proof constraint, theorem, KB row, vocabulary or axiom changed.
The three hash-pinned KB files and the axiom corpus were NOT modified
(sha256 verified identical before/after this round).

### Added
- `docs/V15_AUDIT.md` — Phase 1 foundation audit: architecture map (11
  modules, file:line refs), live data shapes, verification of the v14.1 fix
  (anti-collapse, drift rows D61–D63, SGLT2 laws), extension points, risk
  register R1–R12, honest limits.
- `docs/V15_IMPLEMENTATION_PLAN.md` — binding 8-phase v15 plan (Modules A–F,
  data connectors, ranking architecture, test suites, acceptance gates).
- `docs/CHANGELOG.md` — this file.
- `apeiron/v15/` — additive scaffold package (v15_ provenance model, tiered
  claim model, Module A disease profile, Module B target-scoring skeleton,
  full-cascade regression runner). Imports v14.1 modules read-only.
- `docs/baseline/` — baseline run logs (9/9 exit 0) + frozen-file hashes.

### Changed (narrative hygiene, no behavior change)
- `apeiron_drug_discovery_proof.py` — header docstring "|D| = 60" -> 63
  (stale since the v14.1 drift round).
- `apeiron_correspondence.py` — C5 comment "60/60" -> "63/63"; end-of-run
  summary now prints the matrix check count, external-pair count and refusal
  count dynamically from the C2/C7 theorem stats instead of the stale
  hard-coded "11,040-check" line (live value 11,224).
- `apeiron_equations.py` — E0 docstring "60/60" -> "63/63".
- `apeiron_direct_laws.py` — D0 proof step now lists the non-molecular
  remainder diseases dynamically (computed from the live mechanism table vs
  structure laws) instead of the stale hard-coded "D09 insulin, D24 laxative,
  D58 iron" list (live remainder: D09, D58 — D24 is molecular).
- `demo_query.py` / `demo_full_mapping.py` — header "60/60" claims replaced
  with corpus-size-annotated wording.
- `extension_stress_demo.py` — battery world labels ("baseline 60",
  "extended 63", "stressed 71", "saturated 72") now computed from the live
  row counts.
- `README.md` — v15 pointer block added; historical section counts annotated
  in the pointer rather than rewritten (they were true for their rounds).

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 apeiron_drug_discovery_proof.py        # exit 0
    python3 apeiron_structure_proof.py             # exit 0
    python3 apeiron_direct_laws.py                 # exit 0
    python3 apeiron_equations.py                   # exit 0
    python3 apeiron_correspondence.py              # exit 0 (hermetic C0–C8 + REG)
    python3 demo_full_mapping.py && python3 extension_stress_demo.py
    python3 ../scripts/apeiron_novel_disease_test.py
    python3 ../scripts/smoke_test_fix.py
    python3 v15/tests/test_v15_scaffold.py         # exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Not done yet (explicit)
- Phases 2–8 of `docs/V15_IMPLEMENTATION_PLAN.md` are not implemented in
  this round. Nothing in this round changes any scientific claim.

## v15 Phase 3 — Biological target discovery, Module B (2026-11-25)

Scope: additive v15 target-discovery layer built on machine-verified
external records. The v14.1 proof engine was NOT modified: all four
hash-pinned files kept their sha256 (verified by the cascade), the
complete 12-stage cascade exits 0, and the C0 hermeticity doctrine is
extended (derivation modules import no connector code, machine-checked
by AST in the phase-3 battery).

### Added (P3-4 — frozen-response connector skeleton)
- `v15/connectors/base.py` — fetcher that stores RAW responses with
  retrieval metadata under `v15/cache/<sha256(raw)>.json` + a manifest;
  `load_frozen()` raises `ABSENT_CACHE` for missing names (absence is
  reported, never fabricated); stdlib-only (urllib), so no new
  dependency.
- `v15/connectors/opentargets.py` — Open Targets Platform GraphQL.
  NOTE: the older `target{associatedDiseases(efoId:...)}` signature
  returns HTTP 400 on the live schema ("Unknown argument 'efoId'");
  the connector uses the introspection-verified disease-side form
  `disease(efoId){associatedTargets(page:{size:150})}` and carries the
  datatype ids verbatim (genetic_association, genetic_literature,
  literature, clinical, animal_model, somatic_mutation,
  affected_pathway).
- `v15/connectors/uniprot.py` — reviewed-entry resolution/existence
  checks; `v15/connectors/reactome.py` — pathway search (R-HSA-*),
  with documented tag-stripping for display only (raw payload stays
  frozen); `v15/connectors/europepmc.py` — citation verification with
  a bounded EPMC search, client-side title-token filtering, and an
  NCBI E-utilities esearch fallback (PMID discovery only, every PMID
  re-verified through Europe PMC EXT_ID metadata).
- `v15/connectors/refresh_phase3_cache.py` — the ONLY live-network
  tool; idempotent (`--live` serves frozen names from cache, fetches
  only missing ones; `--force-live` refetches). Live results of this
  round: 16/16 genes verified (HGNC+UniProt), 10/10 panel disease ids
  verified, 17/18 association rows verified (MAPT honestly
  NOT_IN_PAGE), 7/9 Reactome mappings (2 documented absences), 11/11
  citations verified incl. the canonical landmarks (Riordan 1989
  PMID:2475911, Druker 2001 PMID:11287972, Cohen 2006 PMID:16554528).
  ABSENT records: 2 (Reactome neurohormonal-remodeling and BCR-ABL1
  pathway searches) — recorded, not guessed.

### Added (P3-1 — frozen target evidence table)
- `v15/target_data.py` — FROZEN, sha256-pinned table
  (`v15/kb_extensions/targets_pins.json`, tool `freeze_targets.py`):
  16 verified gene-target records, the 10-disease benchmark panel
  (9 KB rows with guideline strings verbatim + cystic fibrosis as a
  deliberate non-KB NOT_ENCODABLE case), verbatim Open Targets
  association rows, the CONSERVATIVE OT-datatype->evidence-kind map
  (association evidence NEVER becomes causal), 18 evidence rows, 11
  machine-verified literature records, and HONEST_LIMITS (flag
  semantics + every absence).
- `v15/targets.py` — extended (Phase 1 skeleton API preserved): the
  pin-checked `load_targets()`/`TargetTable` facade with a source
  resolver covering external + internal (KB:Dxx) + literature ids;
  `hypotheses_for`/`rank_targets` (deterministic transparent ranking,
  every row carries axes + flags + sources);
  `theorem_anti_causal_illusion` (flag iff no cited causal evidence,
  checks BOTH under- and over-flagging; PROVEN_MATH);
  `theorem_rank_determinism` (permutation invariance; PROVEN_MATH);
  `benchmark()` — the acceptance harness.

### Acceptance benchmark (plan §4)
- `v15/write_phase3_artifacts.py` emits `v15/out/phase3_benchmark.json`
  + `.txt`. Result: **macro recall@10 = 1.0** over 10 diseases /
  16 guideline targets (0 computed misses; known coverage gaps such as
  CACNA1C/ADRB1/IL6R are recorded in the panel and never silently
  counted); plan-named examples PCSK9 (D05), BCR-ABL/ABL1 (D50) and
  CFTR (CF) each rank #1 in their disease; MAPT (association-only by
  design) and LDLR (association-only in this freeze) carry
  ASSOCIATION_NOT_CAUSATION exactly as the P3-3 discipline demands;
  CF demonstrates Module B operating on a disease outside the v14.1
  closed world.
- `v15/tests/test_v15_phase3.py` — 8-check battery: pin tamper
  refusal, anti-fabrication source gate, identifier cross-check
  against the Phase 2 vocabulary (HGNC/UniProt agreement + T2DM MONDO
  cross-check MONDO_0005148 == vocab record), transparency (axes
  exposed, COMPUTATIONAL_RANK label, no probability language),
  illusion theorem + negative controls (stripped flag -> fails,
  spurious flag on ABL1 -> fails) + finalize() clearing rule,
  connector cache integrity + absence refusal + derivation/connector
  AST isolation, live-driver refusal without --live, benchmark
  arithmetic consistency.
- `v15/run_full_regression.py` — phase-3 battery appended (12 stages).

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 v15/tests/test_v15_phase3.py               # 8/8
    python3 v15/write_phase3_artifacts.py              # exit 0
    python3 v15/connectors/refresh_phase3_cache.py --live   # idempotent
    python3 v15/run_full_regression.py                 # 12/12 exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Not done yet (explicit)
- Phases 4-8 of `docs/V15_IMPLEMENTATION_PLAN.md` are not implemented
  in this round (repurposing engine, molecule discovery, math
  extensions, validation intelligence, integration/REST API). The
  safety_penalty axis stays a documented 0.0 placeholder until Module
  C/D safety data arrives. Nothing in this round claims clinical
  validity; target ranks are COMPUTATIONAL_RANK hints, not
  probabilities and not treatment advice.

## v15 Phase 4 — Drug repurposing engine, Module C (2026-11-25)

Scope: additive v15 repurposing layer built on machine-verified
external records. The v14.1 proof engine was NOT modified: all four
hash-pinned files kept their sha256 (verified by the cascade), the
complete 13-stage cascade exits 0, and the C0-style derivation/
connector isolation is extended to Module C (AST-checked). RDKit was
re-installed from the Phase 1 pin (`rdkit==2026.09.2`) after the
sandbox recycle; the exact pinned version matched.

### Added (P4-1 — connectors + frozen pack)
- `v15/connectors/chembl.py` — ChEMBL webresource connector (molecule
  records -> first_approval / withdrawn_flag / maximum_phase;
  mechanisms; drug indications). The live REST base is
  `/chembl/api/data/` (the older `/chembl/api/core/` path 404s on the
  current build; documented in the module docstring).
- `v15/connectors/opentargets.py` — Phase 4 additions
  (introspection-verified live schema): `search_drug`, `drug_record`
  (Drug type now carries `maximumClinicalStage` + a paged
  `indications` block; the retired `isApproved/firstApproval/
  withdrawn` fields are gone), `disease_drug_candidates` (the live
  replacement of the retired `disease.knownDrugs` field). MOA rows
  expose `targets{approvedSymbol}`; the older `targetId` field 400s.
- `v15/connectors/uniprot.py` — additive `entry_function` (function
  excerpt anchors the target-channel law table).
- `v15/connectors/refresh_phase4_cache.py` — the ONLY live-network
  tool: 18-drug candidate universe (15 molecules with ChEMBL
  first_approval < 2015 + finerenone/semaglutide as named post-2015
  NEGATIVE CONTROLS), 5 indication diseases (HFREF MONDO_0006993,
  HFPEF MONDO_0006727 = diastolic heart failure, CKD MONDO_0005300,
  DKD MONDO_0005016, T2DM MONDO_0005148), UniProt records for 70
  resolved target symbols, and 13 Europe PMC landmark citations.
  PMID hints are used ONLY as search candidates: every admitted record
  passed EXT_ID verification + title-token filtering (wrong remembered
  PMIDs were rejected by the gate, by design). Live results:
  18/18 drug records, 5/5 disease pages, 13/13 citations, 0 absences.
- `v15/repurposing_data.py` — FROZEN, sha256-pinned pack
  (`v15/kb_extensions/repurposing_pins.json`, tool
  `freeze_repurposing.py`, generator `scripts/gen_phase4_pack.py`):
  18 verbatim drug records, the curated target-channel law table
  (13 symbols with UniProt anchors + the KB mechanism-class fallback),
  pre-2015 disease-channel profiles with class-precedent anchors
  (CONSENSUS 1987 -> ACEI_RAAS, RALES 1999 -> MRA, RENAAL 2000 ->
  ARB_RAAS, UKPDS 33 1998 -> BIGUANIDE), the cited CARDIORENAL /
  HYPERGLYCEMIA adjacency bridge, 96 indication-evidence rows, and 6
  post-2015 ground-truth outcomes (DAPA-HF, DAPA-CKD, EMPEROR-Reduced,
  EMPA-KIDNEY, CREDENCE, DELIVER — every row cites a verified PMID;
  OT approval-row coverage gaps recorded in the notes).
- `v15/repurposing.py` — Module C: pin-checked `load_pack()` facade
  with source resolution; the compatibility law channel
  (direct / adjacent / none + contradiction handling); P4-2 status
  assignment (APPROVED_INDICATION / INVESTIGATIONAL /
  EXPERIMENTALLY_VALIDATED / COMPUTATIONAL_HYPOTHESIS, exactly one
  per candidate); the P4-3 Theta_d consistency bridge importing the
  v14.1 engines READ-ONLY (findings: THETA_SATISFIED /
  MECH_STRUCTURE_CONFLICT / NOT_IN_CORPUS / NO_DISEASE_ENCODING /
  NO_MOLECULAR_LAW — nothing is silently dropped); four theorems
  (status discipline, bridge exposure, temporal hermeticity, candidate
  determinism — all PROVEN_MATH) and the temporal benchmark.

### Acceptance benchmark (plan §5, P4-4)
- `v15/write_phase4_artifacts.py` emits `v15/out/phase4_benchmark.json`
  + `.txt`. Design: predictions use ONLY pre-2015 knowledge (molecules
  by ChEMBL first_approval < 2015; disease channels by cited pre-2015
  anchors; precedent classes by trial anchors); ground truth = the
  post-2015 repurposing outcomes. Result: **macro recall@10 = 1.0**
  over 4 diseases / 6 outcomes; the law channel separates every truth
  pair from zero-support candidates (separation = True on all four);
  HFpEF — the plan-named case — ranks dapagliflozin #1 from pre-2015
  knowledge alone (adjacent via the cited cardiorenal bridge, no
  precedent); HFrEF shows the honest 2015 epistemics (RAAS/MRA
  precedent classes top the list, SGLT2i sit at ranks 7-8 as
  channel-supported, precedent-less frontier candidates — the
  divergence is documented as examined false leads, not hidden);
  finerenone (2021) and semaglutide (2017) are structurally absent
  from every pre-2015 candidate list.
- Theorem highlights (PROVEN_MATH): temporal hermeticity (removing
  every post-2015 record reproduces the prediction bit-for-bit);
  bridge exposure (losartan x HFrEF carries MECH_STRUCTURE_CONFLICT
  and stays visible — Theta_D02(chi)=0 — while dapagliflozin x HFrEF
  is THETA_SATISFIED; canagliflozin is honestly NOT_IN_CORPUS).
- `v15/tests/test_v15_phase4.py` — 9-check battery: pin tamper,
  verbatim cross-check against `phase4_verified_values.json`, law
  channel + bridge + precedent, status discipline + negative control,
  bridge findings + negative control, hermeticity + named controls +
  determinism, benchmark acceptance, connector AST isolation +
  pure-data pack + driver refusal, claim-tier language scan.
- `v15/run_full_regression.py` — phase-4 battery appended (13 stages).

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 v15/tests/test_v15_phase4.py               # 9/9
    python3 v15/write_phase4_artifacts.py              # exit 0
    python3 v15/connectors/refresh_phase4_cache.py --live   # idempotent
    python3 v15/run_full_regression.py                 # 13/13 exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Not done yet (explicit)
- Phases 5-8 of `docs/V15_IMPLEMENTATION_PLAN.md` are not implemented
  in this round (molecule discovery, math extensions, validation
  intelligence, integration/REST API). Ranking aggregates remain
  COMPUTATIONAL_RANK hints; statuses are data-derived labels, not
  efficacy claims; nothing in this round claims clinical validity or
  treatment advice.

## v15 Phase 2 — Scientific knowledge expansion, Module A (2026-11-24)

Scope: additive v15 vocabulary + universal profiles + the first
knowledge growth pack (D64–D68) applied through the new automated
§5(c) checklist. This round includes a DOCUMENTED RE-FREEZE of the
hash-pinned corpus (new pins recorded in
`docs/baseline/frozen_files_sha256_before.txt`,
`v15/kb_extensions/corpus_pins.json` and
`apeiron_correspondence.EXPECTED_POSTULATES_SHA256`). The v14.1 proof
engine was NOT weakened: every theorem re-proved exit 0 on the grown
corpus (561/561 depth-2 monomials, was 528).

### Added (P2-1 — frozen additive vocabulary)
- `v15/vocab_data.py` — frozen tables: 8 machine-verified MONDO disease
  records (EBI OLS4 API, MONDO release 2026-11-03, with ICD-10/MeSH/
  OMIM xrefs as carried by MONDO), 8 verified gene records (HGNC REST +
  UniProt REST: SLC5A2/SGLT2, HMGCR, PCSK9, CFTR, EGFR, PTGS1, ACE,
  ABL1), resource-level SOURCE_RECORDS (version, retrieval_utc,
  license, evidence_type, limitations). Reactome/KEGG numeric ids and
  HPO ids are honestly ABSENT (named limitations), deferred to the
  Phase 3 connector skeleton — nothing was guessed. A wrong MONDO id
  (0005152 = hypopituitarism, mistakenly proposed for rheumatoid
  arthritis) was caught by the verification run and EXCLUDED.
  Verification tool + report: `scripts/verify_vocab_ols.py`,
  `scripts/ols_verification_report.json`.
- `v15/vocab.py` — pin-checked loader (refuses to serve the table on
  sha256 mismatch with `v15/kb_extensions/vocab_pins.json`), lookups,
  per-channel cardinality reports and pack admission reports (R10).
- `v15/kb_extensions/freeze_vocab.py` — the vocab re-freeze tool.

### Changed (P2-2 — universal disease profile)
- `v15/disease_profile.py` — layered per-field evidence statuses
  (established/inferred/unknown), cited `phi_candidates` resolution
  (`derive_phi`) with the strict live-vocabulary gate (unknown values
  raise, never coerced), three-valued encodability verdict
  (ENCODABLE / PARTIALLY_ENCODABLE / NOT_ENCODABLE), KB-row round-trip
  builder, and the phi-injectivity theorem helper (standard
  {theorem, statement, proved, tier, counterexamples, stats,
  proof_steps} shape).

### Added (P2-3 — growth-pack machinery + first pack)
- `v15/kb_extensions/pack_d64_d68.py` — PACK-2026-11-24-D64-D68: five
  new diseases across five NEW organ systems (DERMATOLOGIC,
  OTOLARYNGOLOGIC, GYNECOLOGIC, ORAL_DENTAL, OBSTETRIC), guideline-
  anchored and content-verified: impetigo (NICE CKS: flucloxacillin
  first-line, clarithromycin alt.), acute otitis media (NICE CKS:
  amoxicillin 5–7 d), bacterial vaginosis (CDC STI 2021: metronidazole
  500 mg BID 7 d), dentoalveolar abscess (NICE CKS: amoxicillin/
  phenoxymethylpenicillin, metronidazole for penicillin allergy),
  pre-eclampsia prophylaxis (NICE NG133 rec 1.1.2: aspirin 75–150 mg
  from 12 weeks). NO new drug, molecule, mechanism class or sibling
  pair: every listed drug already carries a verified structure law, so
  the chemical layer is untouched by construction. All guideline URLs
  were live-verified (CDC 200; NICE 403-to-non-browser agents,
  content verified via search snapshots — recorded in the source
  limitations fields).
- `v15/kb_extensions/apply_pack.py` — the §5(c) checklist automation:
  schema + cross-check validation (166 checks), the P2-4 cardinality
  theorem (below), textual insertion into the two hash-pinned data
  modules with unique-anchor assertions, fresh-subprocess post-apply
  structural validation, postulate rebuild + sha re-pin + snapshot +
  corpus-pins update, and the full cascade as the merge gate. Modes:
  --dry-run (no mutation), --apply (refuses double-apply),
  --resume-from-refreeze (interrupted-run recovery), --skip-cascade
  (debug only). `validate_pack` verifies FRESH (pre-merge) and APPLIED
  (verbatim consistency) states.
- `v15/kb_extensions/corpus_pins.json` — pin file consumed by the v15
  tests (counts + sha256s updated by every re-freeze; replaces the
  stale hardcoded counts of Phase 1).

### Changed (engines / corpus — documented re-freeze)
- `disease_drug_kb.py` — SYSTEMS +5 (DERMATOLOGIC, OTOLARYNGOLOGIC,
  GYNECOLOGIC, ORAL_DENTAL, OBSTETRIC), ETIOLOGIES +1
  (PLACENTAL_VASCULAR_DYSFUNCTION), MICROBES +1
  (ANAEROBE_MIXED_OVERGROWTH, shared by D66+D67), SITES +4
  (MIDDLE_EAR_TYMPANIC_CAVITY, VAGINAL_MUCOSA, ORAL_CAVITY_JAW,
  UTEROPLACENTAL_UNIT), DISEASES +5 rows D64–D68.
- `disease_mechanism_table.py` — MECH_REQUIRED +5 entries (validated:
  primary mech == class of first guideline drug; mech set == drug
  class set).
- `postulates_v14.json` — rebuilt; new sha256
  f8f59e5f9ab8c1087358a23daa0353b5b06e59443e9c8eed44cd9c5d025c5715,
  re-pinned in `apeiron_correspondence.py` line 81.
- `v15/run_full_regression.py` — the two v15 test batteries appended
  to the cascade (11 stages total).
- `v15/tests/test_v15_scaffold.py` — corpus-size assertions now read
  the corpus pins file instead of hardcoded literals.
- `v15/tests/test_v15_phase2.py` — NEW battery: vocab pin tamper
  refusal, named absences, provenance-backed EVIDENCED claims through
  the tier model, profile<->phi round-trip + injectivity on the WHOLE
  corpus, derive_phi verdict ladder + unknown-value refusal, pack
  validation + three refusal paths (tuple collision, mech/label
  mismatch, applied-row verbatim check), pins presence.

### P2-4 — cardinality-guard theorem (new T5, audit R10)
- `theorem_cardinality_guard` in `apply_pack.py`: every channel value a
  pack uses must reach merged-corpus cardinality >= 2, or carry a
  documented degenerate-channel consequence. On this pack: 8 values
  non-degenerate (incl. PW_PLATELET_AGGREGATION raised 1->2 by D68 and
  ANAEROBE_MIXED_OVERGROWTH born at 2 via D66+D67), 14 values born
  cardinality-1 with documented consequences, 0 counterexamples.
  Rationale documented per value in `NEW_VOCAB_VALUES`.

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 v15/kb_extensions/apply_pack.py --dry-run   # 166/166 + T5 proved
    python3 v15/kb_extensions/apply_pack.py             # refuses double-apply
    python3 v15/run_full_regression.py                  # 11/11 exit 0
    python3 ../scripts/apeiron_v15_phase2_spotcheck.py  # D64-D68 spot verdicts
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Post-merge evidence
- 561 learned monomials, depth histogram {2: 561} — anti-collapse
  invariant HOLDS on the grown corpus (was 528 at 63 diseases).
- Novel-disease harness exit 0: A1 stroke -> COX1_PLATELET_INHIBITOR,
  A3 HFpEF -> SGLT2_INHIBITOR, A7 BED -> AMPHETAMINE_RELEASER, foreign
  probes -> UNPROVEN (sound refusals intact).
- Spot-check: D64->flucloxacillin, D65->amoxicillin, D66->metronidazole,
  D67->amoxicillin, D68->aspirin (all PROVEN_EXACT); novel chronic-
  impetigo variant -> UNPROVEN (no single-channel inheritance).
- Claim-tier scan: no "cure"/"treats"/"efficacious" outside quoted
  citations in any v15 source.

### Not done yet (explicit)
- Phases 3–8 of `docs/V15_IMPLEMENTATION_PLAN.md` are not implemented
  in this round. The v15 vocab deliberately omits unverified numeric
  ontology ids (Reactome/KEGG/HPO) — they arrive via the Phase 3
  frozen-response connectors. Nothing in this round claims any new
  clinical validity; the KB remains a mathematical identification
  corpus, not medical advice.

## v15 Phase 5 — Novel molecule discovery, Module D (2026-11-25)

Scope: additive v15 chem/discovery layer over the frozen v14.1
structure corpus. The v14.1 proof engine was NOT modified: all four
hash-pinned files kept their sha256 (verified by the cascade), the
complete 14-stage cascade exits 0, and the derivation/connector
isolation extends to Module D (AST-checked; the ChEMBL novelty lane
reads the FROZEN Phase 4 cache payload files directly, importing no
connector code). RDKit 2026.09.2 (the Phase 1 pin) re-verified after
the sandbox recycle.

### Added (P5-1..P5-3 — chem package)
- `v15/chem/mol_io.py` — SMILES sanitize/validate + canonicalisation
  with visible refusal reasons; the frozen feature space of the v14.1
  structure layer (118 SMARTS + 26 descriptor + 33 negation features)
  consumed READ-ONLY and versioned as manifest APEIRON-FEATSPACE-P1-v15
  (tables sha256 recorded; the law space is never redefined); additive
  topological-fingerprint Tanimoto lane (the same fingerprint call as
  the v14.1 tier-2 invariants); substructure search; law queries that
  re-evaluate ALREADY-PROVED L_c certificates on freshly computed
  features (single-molecule semantics, documented, COMPUTATIONAL tier).
- `v15/chem/props.py` — deterministic RDKit descriptors (MW, cLogP,
  TPSA, HBD/HBA, rotB, rings, Fsp3), Lipinski/Veber rule-of-thumb
  windows (threshold sources named), coarse solubility/permeability
  buckets with the rule text inlined — every block labelled
  PREDICTED_RULEBASED, never measured.
- `v15/chem/admet.py` — model registry schema with per-model version,
  training provenance and a REQUIRED validation sheet; the registry
  ships EMPTY (no validated ML model exists — the PREDICTED_ML lane has
  zero entries and predict() is refused with UnregisteredModelError;
  absence reported, never filled); PAINS/Brenk structural alerts via
  the RDKit filter catalogs (version recorded; conservative flags, not
  verdicts — aspirin itself carries a Brenk phenol-ester flag); the
  hard docking gate: the only permitted docking labels are
  DOCKING_EVIDENCE (complete run record) or NO_DOCKING_RUN_RECORD.
- `v15/chem/generate.py` — P5-4 deterministic structure-law-guided
  pipeline: seeds = KB molecules satisfying >= 1 proved L_c (sorted);
  single-site aromatic-CH substitutions from a fixed ordered
  substituent library (F, Cl, CH3, OH, OCH3, CN, NH2, CF3) via
  reaction SMARTS; visible filters with RECORDED rejections (validity,
  single-fragment, novelty vs the frozen 191-molecule KB corpus + the
  17 ChEMBL Phase 4 structures with 1 recorded absence, PAINS/Brenk
  alerts, law plausibility) — nothing silently dropped; transparent
  per-axis ranking (novelty distance, drug-likeness, Ertl-Schuffenhauer
  SA estimate, law plausibility, seed conservation), aggregate labelled
  COMPUTATIONAL_RANK (a rank hint, never a probability, never a
  predicted activity). No random search anywhere.

### Added (Module D facade + theorems)
- `v15/molecular.py` — reference-corpus builder (KNOWN_MOLECULE rows
  for 191 KB + 17 ChEMBL structures, absence recorded); five theorems,
  all PROVEN_MATH:
  theorem_kb_roundtrip (SMILES -> fresh chi -> laws on ALL 191 KB
  molecules: chi mismatches 0, 117 proved laws re-certified, 0 member
  violations, 0 false positives — the acceptance clause "round-trip on
  all 191 KB molecules unchanged");
  theorem_truth_in_labeling (NEW S-class obligation P5-5: every
  molecule record carries exactly one status in {KNOWN_MOLECULE,
  GENERATED_CANDIDATE}, every generated record carries binding=NO_CLAIM
  / efficacy=NO_CLAIM, banned-token scan over every text leaf);
  theorem_no_docking_claims; theorem_generation_determinism
  (bit-for-bit); theorem_rank_determinism (permutation invariance).
- `v15/write_phase5_artifacts.py` — emits `v15/out/phase5_benchmark.json`
  + `.txt` (fully offline). Result: quota 100 emitted (all valid,
  novel, alert-free, law-plausible), 178 rejections all recorded with
  reasons (168 toxicity_alert, 10 no_law_plausibility), ALL theorems
  proved, exit 0. Config sha256 locks the run (93f4a84fce0c6918...).
- `v15/tests/test_v15_phase5.py` — 9-check battery: feature-space
  manifest + mol_io gates; round-trip theorem on all 191 molecules;
  property labels + v14.1 cross-check; registry/docking/alert
  discipline; generation pipeline incl. per-record recomputation
  negative control; truth-in-labeling + four negative controls (fake
  binding claim, claim language, illegal status, docking claim);
  frozen-file integrity vs baseline snapshot; AST isolation +
  artifact integrity; claim-tier language scan.
- `v15/run_full_regression.py` — phase-5 battery appended (14 stages).

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 v15/tests/test_v15_phase5.py               # 9/9
    python3 v15/write_phase5_artifacts.py              # exit 0
    python3 v15/run_full_regression.py                 # 14/14 exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Not done yet (explicit)
- Phases 6-8 of `docs/V15_IMPLEMENTATION_PLAN.md` are not implemented
  in this round (math extensions incl. the P6-3 fingerprint-portability
  gate, validation intelligence, integration/REST API). The ADMET
  registry is deliberately empty; no docking, no ML predictions;
  generated molecules are research candidates only — nothing in this
  round claims binding, activity, or clinical validity.

## v15 Phase 6 — Mathematical reasoning extensions, Module E (2026-11-25)

Scope: additive v15 reasoning layer over the frozen corpora. The v14.1
proof engine was NOT weakened: all four hash-pinned files kept their
sha256 (cascade-verified), the complete 15-stage cascade exits 0, and
the P8 knowledge-graph section is an ADDITIVE frozen artifact under the
same freeze discipline (sha256 pin + refusal loader), never an edit of
postulates_v14.json. One ENGINE file received the audit-planned P6-4
performance patch (apeiron_correspondence.py `coupling` memo cache) —
results proven bit-for-bit identical to recomputation, and the C1
re-derivation inside the C-battery still passes (battery wall time
78.5s -> 46.1s in this run).

### Added (P6-1 — frozen P8 knowledge-graph section)
- `scripts/gen_phase6_pack.py` — deterministic generator reading ONLY
  frozen inputs (postulates_v14.json, drug_structures.py,
  disease_mechanism_table.py, v15/target_data.py,
  v15/repurposing_data.py, frozen Phase 3/4 cache payloads) and
  emitting `v15/kgraph_data.py` VERBATIM. 1539 edges over the 7 formal
  relations (disease->gene 18, gene->protein 73, protein->pathway 130,
  target->mechanism 63, mechanism->drug 28, drug->structure 207,
  structure->property 1020), 726 nodes on 8 canonical layers, every
  edge tiered (EVIDENCED / COMPUTATIONAL) + resolvable source ids
  (48 records) + explicit attributes; 73 unverifiable lanes recorded in
  P8_ABSENCES (never guessed). Byte-identical regeneration proven
  (artifact sha256 7d93e60415d02f92... under a fixed freeze timestamp).
- `v15/kb_extensions/freeze_kgraph.py` + `kgraph_pins.json` — the
  freeze tool (audit-R1 pattern; refreeze history auditable).
- `v15/kgraph.py` — the loader (refuses to serve on pin mismatch) and
  the typed KnowledgeGraph with a BUILD GATE: unknown relation/tier,
  empty EVIDENCED sources, layer-order violations and cross-layer node
  aliases all raise at construction, so a contradictory graph cannot
  exist as an object of this class.

### Added (P6-2 — eight new proof obligations, all PROVEN_MATH)
- E1 theorem_graph_consistency: layered DAG over the 7 relations — 0
  layer violations, 0 duplicates, 0 cycles in a full DFS scan.
- E2 theorem_disease_identity_uniqueness: normalized identity is a
  function (69 identities: 68 corpus + CF; unique keys/names; no
  external MONDO/HP id shared by two keys; idempotent normalization;
  phi injective on the corpus, 68 distinct tuples; 0 orphan graph
  disease nodes).
- E3 theorem_contradiction_detection: opposing pharmacology exposed
  via the declared OPPOSING lattice (0 pairs present, injection lane
  proves 0 false negatives); the non-molecular remainder (8 required
  structure-exempt classes, e.g. insulin analogs) verified CONSISTENT:
  no excluded-class member carries a molecular structure edge.
- E4 theorem_evidence_provenance_completeness: every EVIDENCED edge
  cites resolvable records, every COMPUTATIONAL edge cites the
  registered rule-based generator (GEN:P6_RULEBASED_PROPS); an
  uncited edge cannot pass the build gate (injection detected).
- E5 theorem_rank_integrity: 10 diseases x 5 deterministic edge-row
  permutations, rebuilt graphs produce byte-identical ranking tables
  (0 disagreements); aggregates labelled COMPUTATIONAL_RANK.
- E6 theorem_tier_propagation: chain tier = lattice meet over the
  5-tier ladder; laws verified on all 25 pairs + 125 triples; fold ==
  independent min() recomputation on all 233 chains; a chain can never
  propagate a tier stronger than its weakest edge (negative control:
  one HYPOTHESIS edge downgrades the chain, never the reverse).
- E7 theorem_out_of_domain_detection: unknown ids return explicit
  absence records; unencodable profiles keep NOT_ENCODABLE and never
  reach phi; out-of-vocabulary candidate values raise (no coercion).
- E8 theorem_bit_for_bit_reproducibility: fresh in-memory builds
  serialize identically; regenerating the P8 artifact under the
  original freeze timestamp reproduces the file byte-exactly
  (extends C1/C8 to Module E).

### Added (P6-3 — fingerprint-portability gate, audit R4)
- E9 theorem_fingerprint_portability: live RDKit == requirements pin
  (2026.09.2) == the version recorded in the frozen P8 input pins, AND
  the full phase-5 round-trip re-certifies the frozen identity laws on
  fresh fingerprints (191 molecules, 0 chi mismatches, 0 member
  violations, 0 false positives). A version drift fails loudly.

### Added (P6-4 — performance with proofs intact, audit R5)
- `apeiron_correspondence.py` — `coupling` memo cache (per-instance,
  keyed by (disease id, structure)); E10 theorem_memo_determinism:
  warm memoized sweep vs forced recomputation over 12,144 (disease,
  molecule) pairs — 0 mismatches cold, 0 warm, measured speedup
  ~3400x on the warm lane (33.955s -> 0.010s per sweep). C-battery
  wall time 78.5s -> 46.1s in the same run with every C-theorem still
  proved (C1 bit-for-bit intact).
- Transparent KG ranking demonstration (COMPUTATIONAL_RANK, never a
  probability): D08 chain-recapitulates SGLT2_INHIBITOR (dapagliflozin,
  empagliflozin) + DPP4_INHIBITOR (sitagliptin) from frozen evidence
  chains; D05 recapitulates HMGCR_INHIBITOR; D03/D33/D50/D51/CF drug
  lanes are HONESTLY EMPTY (no mechanism rows for their targets in the
  frozen packs — absence reported, never fabricated).

### Added (battery + artifacts)
- `v15/write_phase6_artifacts.py` — emits `v15/out/phase6_benchmark.json`
  + `.txt`; VERDICT: ALL THEOREMS PROVED (10/10).
- `v15/tests/test_v15_phase6.py` — 10-check battery: P8 pin
  discipline + 4 build-gate refusal lanes; E1-E4; 4 negative controls
  (back-edge refused, alias conflict flagged, injected opposing pair
  exposed, uncited edge refused); E5-E7; tier-downgrade control;
  E8-E10 incl. the pinned-RDKit gate; ranking transparency; frozen-file
  integrity; AST isolation (kgraph imports no connector code);
  claim-tier language scan.
- `v15/run_full_regression.py` — phase-6 battery appended (15 stages).

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 scripts/gen_phase6_pack.py --utc 2026-11-25T06:04:16Z --out /tmp/repro.py
    sha256sum /tmp/repro.py v15/kgraph_data.py            # byte-identical
    python3 v15/write_phase6_artifacts.py                 # 10/10 theorems
    python3 v15/tests/test_v15_phase6.py                  # 10/10 checks
    python3 v15/run_full_regression.py                    # 15/15 exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Not done yet (explicit)
- Phases 7-8 of `docs/V15_IMPLEMENTATION_PLAN.md` are not implemented
  in this round (experimental-validation intelligence, full
  integration/REST API/12-test-suite program). The KG disease/gene lane
  covers the 10 machine-verified panel diseases; the other 58 corpus
  diseases have NO disease->gene edges yet (recorded absences). The
  ranking demonstration is evidence-support over frozen edges only —
  it claims no efficacy, no binding, no clinical validity.

## v15 Phase 7 — Experimental-validation intelligence, Module F (2026-11-25)

Scope: additive v15 validation-planning layer. The v14.1 proof engine was
NOT weakened: all four hash-pinned files kept their sha256 (cascade-
verified), the complete 16-stage cascade exits 0, and the P7 dataset
registry is an ADDITIVE frozen artifact under the same freeze discipline
(sha256 pin + refusal loader + self-validation). No prior pack, graph
section or law was edited.

### Added (P7-2 — frozen dataset registry, metadata + accession ONLY)
- `v15/connectors/clinicaltrials.py` — ClinicalTrials.gov API v2
  connector with a STRUCTURAL results guarantee: the request pins
  `fields` to exactly six whitelisted protocolSection modules
  (identification/status/sponsor/design/conditions/armsInterventions),
  so outcome/results content (outcomesModule, resultSection) is never
  even fetched; a whitelist + forbidden-token check re-verifies every
  distilled row at connector level.
- `v15/connectors/geo.py` — GEO series metadata via E-utilities
  (esearch db=gds + esummary); accession + summary fields only, raw
  expression data never fetched; non-series rows (GSM/GPL) dropped with
  the drop recorded as an absence.
- `v15/connectors/refresh_phase7_cache.py` — the ONLY live-network
  path: deterministic 10-query CT.gov panel (dapagliflozin/empagliflozin/
  canagliflozin/lisinopril/losartan/spironolactone/metformin/finerenone
  x cardio-renal-metabolic conditions) + 5-query GEO panel + a
  negative-control query (generated molecule APXD-0001, which cannot
  have registry records). Fetched 2026-11-25: 180 study-metadata rows /
  40 series-metadata rows frozen under sha256-keyed payloads; machine-
  verified values in `v15/out/phase7_verified_values.json`.
- `scripts/gen_phase7_pack.py` — deterministic generator emitting
  `v15/validation_data.py` VERBATIM from the verified values: 158 unique
  CT.gov studies, 35 GEO series, 40 mechanical candidate/disease links
  (33 with hits) whose token filters are RECORDED IN THE LINK ROWS,
  8 GEO disease-context links, 15 provenance records, 4 recorded
  absences (including the structural APXD absence and the never-fetched
  results lane), honest limits. Pure data module: zero imports
  (AST-checked). Self-validation enforced at load time.
- `v15/kb_extensions/freeze_validation.py` + `validation_pins.json` —
  freeze tool (sha256 502c4a328a1b03e0..., refreeze history auditable).

### Added (P7-1 + P7-3 — validation-plan engine)
- `v15/validation_plan.py` — Module F: pin-checked ValidationRegistry
  facade with cross-ledger source resolution (P4 pack + P7 registry +
  P8 graph), the ValidationPlan BUILD GATE (refuses missing sections,
  unknown statuses/tiers/gate states, non-canonical gate order,
  out-of-prefix completion, uncited completion, REGISTRY state below
  the HUMAN lane, unresolvable evidence ids, unresolvable dataset
  accessions, datasets empty without an absence note, forbidden
  results tokens, transition/status mismatch), the artifact-layer
  `validate_loaded_plan` (re-validates plans loaded from artifacts or
  API payloads), transparent authored rule tables (target->assay-class,
  class->model-system ladder, status->required-evidence-to-change-
  status; every rule labelled COMPUTATIONAL with its basis recorded),
  stage gates biochemical -> cellular -> tissue -> animal -> human with
  HONEST states (PROPOSED / REGISTRY_ACTIVITY_PRESENT (metadata only,
  HUMAN lane) / COMPLETED_WITH_CITED_EVIDENCE), the P7-3
  "required evidence to change status" section on every plan, and
  `attempt_status_upgrade` which ALWAYS raises (no code path upgrades a
  candidate status).
  Plans built this round: 20 (17 drug x disease pairs = top-3 ranked +
  ground-truth drugs per panel disease; 3 Phase 5 generated molecules
  APXD-* in the structural-absence lane); 10 EVIDENCED+ plans; 13
  HUMAN-gate REGISTRY_ACTIVITY_PRESENT states (trial-existence
  metadata, never efficacy).

### Added (theorems, all PROVEN_MATH, standard shape)
- F1 theorem_plan_schema_completeness: 20/20 plans carry all required
  sections; EVIDENCED+ subset (10) all carry complete evidence rows;
  section-missing and unannotated-endpoint injections refused.
- F2 theorem_stage_gate_ordering: canonical 5-gate ladder; completion
  states form a prefix chain; out-of-order and uncited completions
  refused (injection lanes).
- F3 theorem_evidence_citation_completeness: 131 evidence ids across
  20 plans all resolve against the P4/P7/P8 ledgers; an unknown id is
  refused at build (injection detected).
- F4 theorem_no_results_synthesis: 0 results tokens in plans, 0 in the
  registry, connector whitelist AST-verified (fields built FROM the
  6-module whitelist); a results-token endpoint injection is refused.
- F5 theorem_status_transition_discipline: every plan declares
  from/to/evidence_classes with never_by_computation=true; the upgrade
  code path raises on every plan.
- F6 theorem_plan_determinism: two independent builds -> identical
  canonical sha256 (abe8daaf5af8f18a...); zero wall-clock fields in
  any plan payload.
- F7 theorem_out_of_domain_detection: ghost drug/disease probes return
  explicit absences; an unknown drug raises KeyError on the pack — no
  plan invented.

### Added (battery + artifacts)
- `v15/write_phase7_artifacts.py` — emits `v15/out/phase7_benchmark.json`
  + `.txt` (theorem stats, full plan table, two complete example plans,
  honest limits); VERDICT: ALL THEOREMS PROVED (7/7).
- `v15/tests/test_v15_phase7.py` — 14-check battery: registry pin
  discipline + tamper-refusal + structural results absence; 16
  build-gate refusal lanes (13 constructor + 3 loaded-plan incl.
  transition mismatch and never_by_computation tamper); F1-F7;
  gate-state honesty (REGISTRY only on the HUMAN lane; generated
  molecules all-PROPOSED); dataset panel spot-checks (link filters,
  specificity discipline, GEO metadata shape); AST isolation
  (validation_plan imports no connector code; validation_data imports
  NOTHING); artifacts integrity; frozen-file integrity; claim-tier
  language scan.
- `v15/run_full_regression.py` — phase-7 battery appended (16 stages).

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 v15/connectors/refresh_phase7_cache.py --check   # offline audit
    python3 v15/write_phase7_artifacts.py                    # 7/7 theorems
    python3 v15/tests/test_v15_phase7.py                     # 14/14 checks
    python3 v15/run_full_regression.py                       # 16/16 exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Honest limits (explicit)
- The registry carries registry METADATA only: no trial result, effect
  size, p-value or outcome measure exists anywhere in the P7 pack or in
  any plan (structurally impossible through the fields whitelist).
- HFREF/HFPEF dataset links are CONDITION_LEVEL_ONLY: the whitelisted
  fields cannot separate ejection-fraction strata.
- Assay/model/endpoint content is an authored rule table applied
  transparently (COMPUTATIONAL tier): a proposal to test, never a
  measurement or a claim.
- A REGISTRY_ACTIVITY_PRESENT gate state means "trials exist", never
  "efficacy shown".
- Generated molecules (APXD-*) have no registry records by
  construction; their plans record the structural absence.
- Dataset links exist only for the 10 queried drugs; all other
  candidates have recorded absences, not guesses.

### Not done yet (explicit)
- Phase 8 of `docs/V15_IMPLEMENTATION_PLAN.md` is not implemented in
  this round (end-to-end discover pipeline, REST API + dashboard, the
  full 12-test-suite program, leakage checks, honest-limitation report
  generator). The P7 plan universe covers the 4-disease cardio-renal
  panel + 3 generated molecules; other v15 lanes (Module B targets,
  Phase 2 profiles) are not yet plan sources.

## v15 Phase 8 — Full integration & benchmarks (2026-11-25)

Scope: additive integration round only. No law, theorem, KB row,
vocabulary, axiom or frozen artifact changed; the four hash-pinned files
kept their baseline sha256 (verified before and after the round); the
whole 18-stage cascade exits 0.

### Added (P8-1 — end-to-end pipeline)
- `v15/discover.py` — the 12-step workflow (master prompt §5, plan §1)
  as a deterministic pipeline over the v14.1 engine (read-only) and the
  v15 modules A–F: input normalization -> Module A profile (KB round-trip
  or OOD builder) -> six-channel identity -> P8 graph neighborhood ->
  Module B intervention points -> KB guideline drugs -> Module C
  repurposing (Theta_d bridge exposed) -> Module D molecules (frozen
  Phase 5 artifact) -> rule-layer ADMET screen -> transparent evidence
  fusion (tier JOIN, every lane value displayed) -> consistency checks
  (KB self-validation, phi injectivity, graph build gate, forbidden-
  language scan) -> Module F validation plans. Emits the 18-section
  versioned report (`REPORT_SECTIONS`, schema 15.8.0); no wall-clock
  fields; canonical sha256 in the header equals `sha256_of_report`.
  CLI: `--disease/--json-spec [--as-of YYYY] [--out FILE]`,
  `--list-steps`.
- Resolution discipline: exact matches only (did / case-insensitive
  name / cited six-channel phi); name+genetic_profile combo allowed;
  every miss is a 4-field absence record. Uncited phi raises (Tier-B
  honesty carries into v15 profiles). OOD inputs get the honest empty
  world: NOT_ENCODABLE, explicit absences in every lane, HYPOTHESIS
  tier, nothing fabricated.
- Temporal lane: `as_of_year` prunes by the Phase 4 pack first-approval
  years where coverage exists (hermeticity machinery reused); drugs
  outside the pack are recorded approval-year UNKNOWN, never guessed.
- Report-level theorems (standard shape, all PROVEN_MATH):
  R1 schema completeness (18 sections / 12 steps), R2 determinism
  (double build, byte-identical canonical sha256), R3 absence
  discipline (4-field records everywhere), R4 leakage control (no
  post-split knowledge in an as_of view; APXD-* never in
  approved/repurposing lanes), R5 claim-tier discipline (tiers from the
  ladder; fusion rows labelled COMPUTATIONAL_RANK), R6 out-of-domain
  (OOD probe = honest empty world).

### Added (P8-2 — versioned read-only API + dashboard)
- `v15/api.py` — REST API on the stdlib `http.server`, versioned under
  `/api/v1/`: health, schemas, diseases index, disease profile,
  targets, repurposing (with `?as_of=`), discover (full report,
  memoized — payload deterministic), molecules (frozen Phase 5 store),
  validation-plans (Module F universe), theorems (runtime
  introspection inventory + v14.1 battery labels), limits (P8-4
  generator). GET-only by design: every mutation verb answers 405
  READ_ONLY_API; unknown route/version/disease answer explicit 404
  error objects. Hermetic: imports no connector code and no
  outbound-network machinery (AST-gated in the battery); the only
  socket is the local serving socket.
- `v15/dashboard.py` — static research dashboard
  (`v15/out/dashboard.html`): inline CSS, zero JavaScript, zero
  external assets, deterministic (no wall-clock), built from the same
  pin-checked facades (KPIs, target panel, repurposing panel with
  bridge conflicts, plan gate table, worked D02 fusion example,
  condensed honest limitations, non-goals, API route list).

### Added (P8-3 — test suites, cascade wiring)
- `v15/tests/test_v15_phase8.py` — 19-check battery: the six R-theorems
  over 7 probe reports (D02, D08 by name, D61 by name, D05, CF, D02
  as-of-2015, OOD Z-syndrome probe); temporal validation (no
  APPROVED_INDICATION row with first_approval >= 2015, post-split drugs
  never ranked, as_of sha differs); APXD leakage; per-report
  consistency checks; negative controls (ghost did/name, uncited phi,
  multi-selector and unknown-key specs); API read-only + routing +
  explicit-404 lanes; live-server round trip on an ephemeral port (GET
  200 with read-only headers, POST 405 over the wire); API hermetic AST
  gate; module test-suite coverage scan (all 11 v15 modules named in
  some battery); cascade wiring; P8-4 limitation-report checks
  (artifact-backed achievements, all five gap lanes); dashboard
  checks; artifacts integrity; frozen-file integrity vs baseline
  snapshot; claim-tier language scan.
- `v15/run_full_regression.py` — phase-8 stages appended (artifacts
  writer + battery): cascade grows 16 -> 18 stages.

### Added (P8-4 — honest-limitation generator)
- `v15/limitation_report.py` — one versioned document (schema 15.8.0)
  collecting, per lane, the KNOWN GAPS (licences not obtained —
  DrugBank/BindingDB cited by absence; connectors serve frozen cache
  payloads only; ADMET model registry EMPTY; no docking run record;
  panel-only coverage of Modules B/C/E; class-pharmacophore-only
  molecule statements; rule-layer ADMET estimates) alongside the
  ACHIEVEMENTS, each backed by a frozen artifact value (macro recall
  figures, plan counts, round-trip results, theorem counts). Served at
  `/api/v1/limits` and embedded in the dashboard.

### Added (battery + artifacts)
- `v15/write_phase8_artifacts.py` — builds the 7 probe reports, runs
  R1–R6 (6/6 PROVED), the API self-test (18 dispatcher checks: 14 GET
  lanes incl. explicit 404s, 4 mutation-refusal lanes, memo
  determinism), the limitation report and the dashboard; writes
  `v15/out/phase8_benchmark.json` + `.txt` + `dashboard.html`.
- `docs/baseline/v15_phase8_regression.log` — full-cascade evidence.

### Verification (reproduce with)
    cd /home/z/my-project/apeiron
    python3 v15/write_phase8_artifacts.py                   # 6/6 theorems
    python3 v15/tests/test_v15_phase8.py                    # 19/19 checks
    python3 v15/discover.py --disease D02                   # worked example
    python3 v15/api.py --routes                             # route table
    python3 v15/run_full_regression.py                      # 18/18 exit 0
    sha256sum -c docs/baseline/frozen_files_sha256_before.txt

### Honest limits (explicit)
- Discover serves FROZEN module content only; the novel-molecule lane
  is the frozen Phase 5 artifact (its sha256 travels in every report),
  not a live generation run.
- Lane coverage is exactly the frozen coverage (targets: 10-disease
  panel; repurposing: cardio-renal prediction panel; plans: panel
  diseases + APXD molecules); every other disease gets explicit
  absences — never extrapolated rows.
- The API is read-only and hermetic; it serves the frozen knowledge and
  the deterministic pipeline, adds no new claims, and refuses mutations
  at the protocol level.
- The fusion tier is the strongest lane evidence (JOIN) and every
  fused row is labelled COMPUTATIONAL_RANK — a rank hint, never a
  probability, never a predicted efficacy.
- R9 assessment: the v14.1 demos carry no hardcoded expectation
  constants to move (they are proof printers); the regression runner
  itself is data-driven, so R9 needs no change this round. R7/R8/R12
  were already satisfied by the Phase 1 runner design (staged
  timeouts, scripts/ harness location, subprocess isolation).

### Program status
- All eight phases of `docs/V15_IMPLEMENTATION_PLAN.md` are now
  implemented; the v15 program is complete as planned. Remaining work
  is program-level maintenance only: re-running the documented refresh
  scripts for newer external data (with re-freeze + re-pin), and the
  master-prompt month-scale items that were explicitly OUT of scope for
  the code round (obtaining DrugBank/BindingDB licences, training
  validated ADMET ML models, docking runs).
