# APEIRON-X v15 — PHASE 1 FOUNDATION AUDIT (v14.1 baseline)

Audit date: 2026-11-24 · Auditor: APEIRON-X v15 engineering round · Scope: full
read-only audit of `/home/z/my-project/apeiron/` (~10,000 LOC, 11 Python modules,
1 frozen axiom corpus, 4 demos, 2 test harnesses) plus baseline execution of the
complete proof cascade. Method: every module read in full; counts, depth
histograms, sha256 locks and certificate claims independently re-computed.

## 0. EXECUTIVE SUMMARY

- The v14.1 engine is **healthy**: all 9 baseline entries exit 0 (T/S/D/E/C
  batteries + demos + stress + novel-disease harness). Axiom corpus sha256
  `2e95f0f7…ccb0` verified against the pin in `apeiron_correspondence.py:81`.
- The v14.1 fix round is **verified as implemented**: `MIN_TERM_DEPTH = 2`
  anti-collapse doctrine in `apeiron_drug_discovery_proof.py` (separating-term
  family ladder) mirrored in `derive_channel_dnf` (`apeiron_structure_proof.py`),
  guideline-drift rows D61/D62/D63 in `disease_drug_kb.py`, SGLT2_INHIBITOR
  channel law `{etiology=FUNCTIONAL_DYSREGULATION AND
  pathway=PW_NEUROHORMONAL_REMODELING}` + structure law
  `diaryl_sp3_carbon AND primary_alcohol`. Corpus gate: 528/528 monomials at
  depth 2, 0 degenerate. Tier D anti-collapse battery 4/4 clean.
- Main v15 debts (fix in plan, not by editing frozen data): sha256 freeze/re-pin
  coupling on every KB growth; ~15 stale hardcoded narrative counts ("60/60",
  "11,040 matrix"); manually curated `SIBLINGS` map that is completeness-
  critical; unpinned RDKit version feeding frozen `rdkfp_*` fingerprint-bit
  identity laws; un-memoized O(|D|x|G|) RDKit sweeps in the C2/C4 matrices.

## 1. BASELINE EXECUTION (this round, re-produced)

| # | Entry point (version layer) | Exit | Evidence |
|---|---|---|---|
| 1 | `apeiron_drug_discovery_proof.py` (v11.1, 7 theorems) | 0 | 63/63 domain sweep; 8,703 CEGIS probes 0 false outputs |
| 2 | `apeiron_structure_proof.py` (v12.1, 7 S-theorems) | 0 | 117 class laws + 183 identity laws; full bipartite matrix 0 counterexamples |
| 3 | `apeiron_direct_laws.py` (v13.0, 6 D-theorems) | 0 | 63 direct laws; 18 held-out pairs + 11 refusals 0 errors |
| 4 | `apeiron_equations.py` (v13.1, 8 E-theorems) | 0 | EQ1–EQ7 evaluated per disease; indication-free derivation |
| 5 | `apeiron_correspondence.py` (v14.0, 10 C-theorems, hermetic + REG subprocess) | 0 | `all_proved: true`, `hermetic_derivation: true` |
| 6 | `demo_full_mapping.py` | 0 | all diseases both paths == guideline rank-1 |
| 7 | `extension_stress_demo.py` | 0 | synthetic worlds to 75 rows, all checks |
| 8 | `scripts/apeiron_novel_disease_test.py` (v14.1 harness) | 0 | Tier A 8/8, Tier B honest refusals, Tier C adversarial clean, Tier D 4/4 no collapse, corpus gate holds |
| 9 | `scripts/smoke_test_fix.py` | 0 | SGLT2/AMPHETAMINE/ACEI law dumps, exclusivity, 8 predictions |
| – | axiom lock | OK | `postulates_v14.json` sha256 == pin `2e95f0f7…ccb0` |

Logs: `docs/baseline/*.log` (regenerated each run; engines are deterministic,
certificates bit-for-bit reproducible — C1 re-derives twice and diffs).

## 2. ARCHITECTURE MAP

Layered proof cascade; each layer re-proves its parent battery as a regression
gate and exits non-zero unless every theorem is `EXACT_UNIVERSAL_PROOF`.
Common idiom: exact DNF laws over Boolean atoms, certified by Reed–Muller ANF
over GF(2) (Möbius transform), falsified by adversarial CEGIS batteries.

### 2.1 `apeiron_drug_discovery_proof.py` — v11.1 core engine (1,158 ln)
- Computes `f(d) = RANK_LEX(IND(d))` over a closed guideline KB; class law =
  exact DNF of the 6-channel encoding phi(d); ranking embed `K = 100*tier −
  10*eff + pen` (`rank_key` :155), lex tie-break by name (:164).
- Imports: stdlib + NumPy + `disease_drug_kb` only (:43–56). No RDKit.
- Key: `anf_certificate` :97 (v14.1: auto-factors per-monomial when union cube
  >12 atoms), `phi/phi_dict` :205, `build_index` :213 (raises on phi collision —
  injectivity A2), `unobserved_values` :231 (hardcoded per-channel foreign
  probes), `MIN_TERM_DEPTH = 2` :251, `minimal_exclusion_term` :258,
  `separating_term_family` :280, `learn_dnf_law` :316, `classify_by_laws` :367,
  `normalize_query` :383, `DrugOracle` :400 (refuses UNPROVEN out-of-domain).
- Theorems: T0 KB well-definedness :469 · T1 class-law exactness + depth
  histogram :502 · T1b regimen law :576 · T2 indication-set exactness :605 ·
  T3 ranking-law exactness :640 · T4 totality + sound refusal (3 CEGIS
  batteries) :688–743 · C1 corollary :777.
- Outputs: `proof_certificate.json` :989, `proof_report.txt` :833,
  `disease_drug_knowledge_base.csv` :1024. Exit 0 <=> all proved (:1142).

### 2.2 `disease_drug_kb.py` — v11.1 knowledge base (742 ln)
- `CHANNELS = (system, etiology, microbe, site, chronicity, pathway)` :32.
  Vocabularies: SYSTEMS 13 :34, ETIOLOGIES 19 :40, MICROBES 9 :48, SITES 38
  :54, CHRONICITIES 2 :67; pathway vocabulary implicit (57 values).
- `DRUGS`: **203 drugs** -> (ATC, mechanism class) :70–281 (129 distinct
  classes). `DISEASES`: **63 rows D01–D63** :285–704, each = 6 channels +
  regimen + guideline citation + ordered `(drug, tier, eff, pen)`.
- v14.1 drift rows: **D61 HFpEF** (empagliflozin rank-1, ESC 2023) :680,
  **D62 binge-eating disorder** (lisdexamfetamine, FDA 2015/NICE NG69) :689,
  **D63 vasospastic angina** (amlodipine, ACC/AHA 2023) :696. 4 regimen rows
  (D19, D22, D45, D52). `validate_kb` :707 (uniqueness, typing, tier/eff/pen
  ranges, exactly one tier-1 rank-1 per non-regimen row).

### 2.3 `apeiron_structure_proof.py` — v12.1 structure layer (2,328 ln)
- Imports RDKit (:74) + KB + `drug_structures` + **re-uses the v11.1 kernel**
  (:82–88, incl. `MIN_TERM_DEPTH`, `learn_dnf_law`, `DrugOracle`). Not
  hermetic — built on v11.1 law machinery.
- Feature space: `SMARTS_FEATURES` 118 :98, `NEGATION_OF` 33 :232,
  `DESCRIPTOR_FEATURES` 26 :268, `SIBLINGS` 12 entries :364 (manually curated).
- `StructLayer` :383 (existential component features :430, RDKit invariants
  `_inv_mol` :440 incl. `rdkfp_<bit>` from `RDKFingerprint`, de-Morgan
  negations :458, salt-aware variant :495).
- Law solvers: `safe_anf_certificate` :555; `_find_minimal_conjunction_bitmask`
  :617 (budget 3,000,000 combos; exact <=5 features when <=35 candidates, else
  <=3; greedy fallback); `_derive_separating_law` :773; `derive_structure_laws`
  :858 (117 laws); `derive_drug_laws` :936 (183 identity laws).
- v14.1 mirror: `derive_channel_dnf` :995 — same ladder (pathway-anchored
  depth>=2 first, depth>=2 any, depth-1 flagged degenerate), set-cover loop
  with max-coverage selection :1013–1055; feeds `derive_drug_channel_laws`
  :1067 (203 drug-channel laws) and, via v13, **all** v13/v14 channel laws.
- Theorems: S0 :1102 · S1 :1143 · S1b :1199 · S2 :1240 · S3 reverse soundness
  incl. adversarial non-KB molecules :1378 · S4 generic path (`GenericOracle`
  :1517, theorem :1635, 100% first-line agreement required) · S5 full coupling
  matrix :1783. Re-runs v11.1 T-battery in-process :2203. Outputs:
  `structure_certificate.json` :2061, report :1983, table :2084.

### 2.4 `drug_structures.py` — v12.1 structure KB (644 ln)
- `COMPONENTS` 184 drugs -> components :20; `SMILES` **191 PubChem molecules**
  :207; `SOURCE` CIDs :401; `SOURCE_URL`/`FETCHED_UTC` :595; `EXCLUDED` 19
  drugs with machine-readable reasons :598; `validate_structures` :622
  (parse + partition cover/excluded).

### 2.5 `apeiron_direct_laws.py` — v13.0 (1,005 ln)
- **Indication-free derivation**: drug-name lists locked behind `GuardedRow`
  (:98, raises `LockedFieldAccessError`; counter `LOCK` :119), unlocked only
  for tests (:295). Training = mechanism table + drug->class->molecule.
- `derive_primary_class_laws` :135 (channel->class DNFs via v12.1
  `derive_channel_dnf`); `exclusive_firing_violations` :158;
  `derive_direct_laws` :172 (Theta_d = OR of class structure laws);
  `direct_structure_query` :214; test oracles :300–481 (pair coverage,
  discrimination matrix with sibling closure :202, reverse, held-out, CEGIS).
- Theorems D0 :487 · D1 :537 · D2 :570 · D3 :602 · D4 :631 · D5 indication-free
  attestation (guard_count == 0) + generic path :669. Re-runs T-battery :902.
  Pins 3 KB sha256s :915. Outputs: certificate :795, report :709 (HONEST
  BOUNDARY :770), `disease_to_structure_laws.csv` :819.

### 2.6 `disease_mechanism_table.py` — v13 KB (200 ln)
- `MECH_REQUIRED`: did -> ordered mechanism classes (element 0 = primary =
  class of guideline first-line), drug-name-free, all 63 diseases (D61–D63 at
  :124). `HELD_OUT_POSITIVE` 18 guideline-cited pairs :138;
  `HELD_OUT_NEGATIVE` 11 guideline-true refusals :159; `validate_mech_table`
  :174 (TEST-labelled).

### 2.7 `apeiron_equations.py` — v13.1 (966 ln)
- EQ1–EQ7 formalized `FORMAL_EQUATIONS` :90; per-disease evaluator :178;
  traces :293. Imports v11.1 + v12.1 + v13.0 (:64–80).
- Theorems E0 :367 · E1 :392 · E2 :416 · E3 :459 · E4 :486 · E5 :527 · E6 :570
  · E7 :606. Regressions D0–D5 + T-battery in-process :865–890. Pins 3
  sha256s :892. Outputs: certificate :730, report :643, CSV :754, traces :919,
  all-diseases chain :922.

### 2.8 `build_postulates.py` + `postulates_v14.json` — v14.0 axiom freeze
- One-time freeze of the v13-derived corpus (builder :46–190; asserts channel-
  law exclusivity before freeze :93). Corpus keys: `feature_space` (P1: 118
  SMARTS + 33 negations + 26 descriptors), `diseases` (P2: 63 encodings,
  therapeutic fields absent), `mech_required` (P3), `channel_laws` (P4a: 56
  class DNFs), `structure_laws` (P4b: 117 + 12 `excluded_classes`),
  `identity_laws` (P5: 183), `sibling_pairs` (P6: 12), `provenance` (3 KB
  sha256s + counts — verified to match live files).
- Lock: sha256 of the corpus pinned at `apeiron_correspondence.py:81`
  (`2e95f0f7…ccb0`), enforced on load (:545, SystemExit on mismatch) and
  re-asserted in C0 (:1019). **P7** (cure <=> B(d,m)=1) lives in the engine
  text (:1170), not the JSON.

### 2.9 `apeiron_correspondence.py` — v14 hermetic engine (1,629 ln)
- EQ-A..EQ-F formalized :1090–1141. Imports ONLY NumPy + RDKit + frozen JSON
  (:64–77). `load_postulates` tamper lock :545. `FrozenChemistry` :188 (frozen
  SMARTS + verbatim descriptor lambdas). `Correspondence.derive_all` :424
  (unique firing + ANF re-certification vs frozen + scaffold counts);
  `coupling` (B, rho) :526.
- Hermeticity machine-check: `KB_MODULES` tuple :90; `kb_absent` audit of
  `sys.modules` at :1501 (C0 :1018). C1 double-derivation determinism :1047.
- Test battery (only place KB modules are imported) `run_test_battery` :568:
  C8 fidelity :590 · C2 chemical equivalence of both B forms :654 · C3
  necessity :720 · C4 specificity + margin :756 · C5 totality 63/63 :824 ·
  C6 realization round-trip :867 · C7 held-out :944 · REG subprocess re-runs
  `apeiron_equations.py` (timeout 2400 s) :989.
- Outputs: certificate :1375, report :1178 (WHY ALWAYS TRUE :1316, HONEST
  BOUNDARY :1349), disease/structure table :1401, traces :1568.

### 2.10 Demos & harnesses
- `demo_query.py` (v11.1, exit-gated expectations :47–56), `demo_structure.py`
  (tour, no gate), `demo_full_mapping.py` (both paths == guideline for all
  diseases), `extension_stress_demo.py` (runtime KB mutation + sha-restore
  :477; parts A/B incl. pathway-saturation B5 :393).
- `scripts/apeiron_novel_disease_test.py` (596 ln): corpus gate :93 (every
  monomial min-depth >= 2) · Tier A 8 novel diseases with guideline truth
  :129 · Tier B 6 unencodable diseases with `why_unencodable` :228 · Tier C
  adversarial encoding/SMILES probes :285 · Tier D anti-collapse regression
  (4 pathway-sharing encodings with `must_not_return`) :332. Exit 0 <=>
  (A fails==0) AND (D collapses==0) AND corpus gate (:595).
- `scripts/smoke_test_fix.py` (103 ln): no gate; KB validation, depth
  histograms, SGLT2 law dump, exclusivity, 8 spot predictions.

## 3. DATA SHAPES (live, re-verified)

| Object | Count | Notes |
|---|---|---|
| diseases (P2) | 63 | D01–D63, injective phi (A2) |
| channel values | system 13 · etiology 19 · microbe 9 · site 38 · chronicity 2 · pathway 57 | pathway implicit in rows |
| drugs (KB.DRUGS) | 203 -> 129 classes | tier in {1,2}, eff 1–10, pen 0–10 |
| channel laws (P4a) | 56 | one per distinct primary mechanism |
| structure laws (P4b) | 117 (+12 excluded non-molecular classes) | SMARTS/DNF + descriptors |
| identity laws (P5) | 183 | per distinct canonical SMILES |
| molecules | 191 PubChem SMILES, 184 covered drugs, 19 excluded | CID-pinned |
| learned monomials | 528 | all depth 2, 0 degenerate (corpus gate) |
| held-out | 18 positive pairs + 11 refusals | guideline-cited |
| discrimination matrices | C2/C4 11,224 checks (61 mol-diseases x 184 drugs); E3/D2 11,592 (184 x 63) | dynamic counts |

## 4. THE v14.1 FIX (verified in code, not just docs)

- Doctrine (`apeiron_drug_discovery_proof.py:247–251`): a single shared channel
  is NOT sufficient disease identity; terms must anchor on >= 2 channels.
- `minimal_exclusion_term` :258: ladder searches depth 2..6 FIRST; depth-1 only
  as flagged-degenerate fallback (:269–277).
- `separating_term_family` :280: L1 = depth>=2 AND pathway-anchored -> L2 =
  depth>=2 any -> L3 degenerate; emits the WHOLE family at the first feasible
  level (:301–313) so sibling syndromes sharing driver + any anchored cofactor
  fire the law.
- Mirror in v12.1 `derive_channel_dnf` :995–1064 (same ladder, max-coverage
  set-cover selection) propagates the invariant to v13/v14 channel laws.
- SGLT2 law: channel `{FUNCTIONAL_DYSREGULATION AND PW_NEUROHORMONAL_REMODELING}`
  (born from D61), structure `diaryl_sp3_carbon AND primary_alcohol`
  (empagliflozin CID 11949646, dapagliflozin CID 9887712); rho = 1.000 on HFpEF.
- Machine-checked: corpus gate 528/528 depth-2; Tier D 4/4 clean; B5 stress
  re-anchoring check (`extension_stress_demo.py:444–449`).

## 5. EXTENSION POINTS FOR v15

(a) **Beyond 6 channels**: touch `CHANNELS`/vocab tuples (disease_drug_kb.py
:32–67) — FROZEN (hash-pinned): add via a *new* vocabulary module + re-freeze;
update `unobserved_values` :231 and the S4 foreign dict
(apeiron_structure_proof.py:1725) with one probe per new channel; fix
channel-name literals in correspondence printers (:1275, :1584) and equations
CSV header (:757); re-freeze corpus + re-pin sha (build_postulates.py ->
apeiron_correspondence.py:81). Combinatorics of the separating ladder grow as
C(n,2) — fine at n=7–10.

(b) **Gene/protein/pathway tables**: no slot today. Follow the
`disease_mechanism_table.py` pattern: a frozen, drug-name-free sibling module,
consumed by derivation, frozen as a NEW P-section, added to `provenance`, and
— critically — appended to `KB_MODULES` (:90) or C0 hermeticity stops covering
it. Indication lock (`GuardedRow`) covers only the `"drugs"` key; new tables
must not smuggle drug names into derivation. `PW_*` values can be backed by an
ontology table without touching phi.

(c) **New drugs/molecules**: checklist order = KB.DRUGS + >=1 disease row ->
MECH_REQUIRED entry (validate cross-check) -> DS.COMPONENTS/SMILES/SOURCE (or
EXCLUDED reason) -> consider SIBLINGS (a missing sibling entry turns
pharmacophore overlap into a strict FP and fails S1/D2/C4 loudly) -> re-run
cascade v11.1->v14.0 freeze->re-pin->correspondence.

(d) **External connectors**: established provenance pattern = frozen source
tables + identifiers (DS.SOURCE CID + URL + FETCHED_UTC), cited guideline
triples, certificate-embedded sha256s. A v15 connector ships as a frozen
module; every refresh triggers re-freeze + re-pin (closed-world doctrine).

(e) **New proof obligations**: convention = `theorem_X*()` returning
`{theorem, statement, proved, tier, counterexamples, stats, proof_steps}`,
appended in `main()`, gating exit code; law-level reuse of
`verify_law_certificate` (:456). Regression nesting propagates new theorems
upward automatically (v12/v13/v13.1 in-process; v14 via REG subprocess).

## 6. RISKS / DEBT REGISTER (drives the v15 plan)

| ID | Risk | Where | Plan item |
|---|---|---|---|
| R1 | sha256 tamper lock couples EVERY KB edit to re-freeze + code edit (C8 is bit-for-bit) | apeiron_correspondence.py:81, :545; build_postulates.py | P1-3 freeze automation |
| R2 | ~15 stale narrative counts ("60/60", "11,040", D09/D24/D58 list at apeiron_direct_laws.py:518, extension labels) | engine docstrings/printers | P1-2 hygiene patch (engines only; NOT the 3 hash-pinned KB files) |
| R3 | `SIBLINGS` 12-entry hand-curated map is completeness-critical (missing entry -> strict FP) | apeiron_structure_proof.py:364 | P3 sibling-derivation + audit theorem |
| R4 | RDKit version unpinned; frozen `rdkfp_*` bits + `uses_extended` laws break C6/C8 on upgrade | apeiron_structure_proof.py:453; FrozenChemistry | P1-4 version pin + requirements.txt + fingerprint-portability gate |
| R5 | Un-memoized per-pair RDKit parse/featurize in `coupling` (:526); C2/C4 sweep 2x11,224 evaluations | apeiron_correspondence.py | P6 memoized granular set cache (must keep C1 bit-for-bit determinism) |
| R6 | `_find_minimal_conjunction_bitmask` can silently drop to greedy / return None as feature space grows | apeiron_structure_proof.py:617 | P6 budget telemetry theorem (report exact/greedy path per law) |
| R7 | REG subprocess hard timeout 2400 s | apeiron_correspondence.py:993 | P8 CI runner with staged timeouts |
| R8 | scripts write outside repo (hardcoded /download paths) | apeiron_novel_disease_test.py:56 | P8 harness refactor |
| R9 | demos with brittle exact-expectation lists | demo_query.py:47, smoke_test_fix.py:88 | P8 test-data separation |
| R10 | depth-2 doctrine degrades if a future channel has cardinality 1 (all depth-2 terms non-separating) | separating_term_family ladder | P2 cardinality guard in vocabulary admission test |
| R11 | no requirements.txt / pyproject.toml; deps unpinned | repo root | P1-4 |
| R12 | extension_stress mutates KB module globals in-process | extension_stress_demo.py:247 | P8 isolation rule (subprocess only) |

## 7. HONEST LIMITS (unchanged by v15 so far)

The engine proves statements about its OWN encoded corpus (closed world,
guideline-labelled KB). It does not and cannot claim: clinical efficacy,
biological causality of encoded associations, completeness of the drug
universe, or validity for diseases outside the 6-channel vocabulary (Tier B
diseases are refused, honestly). Everything v15 adds (targets, repurposing,
molecules, ADMET) is computational hypothesis until experimentally validated —
the report/certificate tiers (`EXACT_UNIVERSAL_PROOF` vs cited-evidence vs
`HYPOTHESIS`) must keep that separation explicit.
