Here are all the generated files.

# APEIRON-X — deliverables index

## Program completion (v15, all 8 phases DONE as of 2026-11-25)

### Phase reports (docx + pdf per phase)
- `APEIRON-X_v15_Phase1_Audit_and_Plan.docx` / `.pdf` — foundation audit + binding 8-phase plan
- `APEIRON-X_v15_Phase2_Knowledge_Expansion.docx` / `.pdf` — Module A (vocab, profiles, growth packs D64–D68)
- `APEIRON-X_v15_Phase3_Target_Discovery.docx` / `.pdf` — Module B (frozen target table, recall@10 = 1.0)
- `APEIRON-X_v15_Phase4_Drug_Repurposing.docx` / `.pdf` — Module C (temporal benchmark, Theta_d bridge)
- `APEIRON-X_v15_Phase5_Molecular_Discovery.docx` / `.pdf` — Module D (191-molecule round-trip, 100 candidates)
- `APEIRON-X_v15_Phase6_Mathematical_Reasoning.docx` / `.pdf` — Module E (P8 graph, theorems E1–E10)
- `APEIRON-X_v15_Phase7_Experimental_Validation.docx` / `.pdf` — Module F (CT.gov/GEO metadata registry, 20 plans)
- `APEIRON-X_v15_Phase8_Integration.docx` / `.pdf` — full integration: 12-step discover pipeline -> 18-section report, versioned read-only API + dashboard, 19-check battery, honest-limitation generator

### Per-phase benchmark artifacts (machine-checkable)
- `apeiron_v15_phase2_spotcheck.json`
- `apeiron_v15_phase3_benchmark.json` / `.txt`
- `apeiron_v15_phase4_benchmark.json` / `.txt` + `apeiron_v15_phase4_verified_values.json`
- `apeiron_v15_phase5_benchmark.json` / `.txt`
- `apeiron_v15_phase6_benchmark.json` / `.txt`
- `apeiron_v15_phase7_benchmark.json` / `.txt` + `apeiron_v15_phase7_verified_values.json`
- `apeiron_v15_phase8_benchmark.json` / `.txt` (6/6 report theorems, API self-test, 7 probe reports)
- `apeiron_v15_dashboard.html` — the static research dashboard (zero JS, deterministic)

### v14.1 out-of-domain (OOD) test round
- `APEIRON-X_novel_disease_test_report.docx` / `.pdf`
- `apeiron_novel_disease_results.json`, `apeiron_novel_disease_transcript.txt`

## Where the code lives
- v14.1 engine + v15 program: `/home/z/my-project/apeiron/` (see `docs/CHANGELOG.md`, `docs/V15_IMPLEMENTATION_PLAN.md`, `docs/V15_AUDIT.md`)
- Phase 8 entry points: `apeiron/v15/discover.py`, `apeiron/v15/api.py`, `apeiron/v15/dashboard.py`, `apeiron/v15/limitation_report.py`
- Reproduce the acceptance gate: `python3 v15/run_full_regression.py` inside `apeiron/` (18/18 stages exit 0; frozen-file sha256 verified)
